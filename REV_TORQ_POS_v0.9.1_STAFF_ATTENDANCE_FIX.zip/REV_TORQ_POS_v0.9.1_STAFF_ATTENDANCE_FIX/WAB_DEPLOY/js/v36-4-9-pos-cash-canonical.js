/* REV TORQ V36.4.9.10 — CANONICAL POS + CASH DRAWER
   - One final POS checkout handler loaded last.
   - Resolves staff_code (e.g. AQIL) to staff.id UUID before any FK insert.
   - Normal product-only sales use the existing transactional rt_post_pos_sale RPC.
   - Job/service sales keep the existing Job->POS flow, but use real staff UUIDs.
   - Cash drawer uses ONLY rt_cash_open / rt_cash_move / rt_cash_close; no unsafe fallback writes.
   - Opening float is recorded as a real OPENING cash movement.
*/
(function(){
  'use strict';
  const sb=window.supabaseClient;
  if(!sb)return;
  const $=id=>document.getElementById(id);
  const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  const money=v=>'RM '+Number(v||0).toLocaleString('ms-MY',{minimumFractionDigits:2,maximumFractionDigits:2});
  const err=e=>e?.message||e?.details||e?.hint||String(e);
  const toast=(m,t='success')=>{try{window.showToast?.(m,t)}catch(_){alert(m)}};
  const profile=()=>window.currentProfile||{};
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));

  async function staffRow(){
    const p=profile();
    if(p.uid){
      const r=await sb.from('staff').select('id,staff_code,name,company_id,location_id,role,active,auth_user_id').eq('auth_user_id',p.uid).eq('active',true).eq('removed_from_active_list',false).limit(1).maybeSingle();
      if(r.error)throw r.error;
      if(r.data)return r.data;
    }
    const code=String(p.staffId||p.staff_code||'').trim().toUpperCase();
    if(code){
      const r=await sb.from('staff').select('id,staff_code,name,company_id,location_id,role,active,auth_user_id').eq('staff_code',code).eq('active',true).eq('removed_from_active_list',false).limit(1).maybeSingle();
      if(r.error)throw r.error;
      if(r.data)return r.data;
    }
    throw new Error(`Staff aktif tidak dijumpai untuk login "${code||'-'}". Login/session staff perlu dipetakan.`);
  }
  async function ctx(){
    const s=await staffRow();
    let loc=s.location_id;
    if(!loc){
      const r=await sb.from('locations').select('id').eq('company_id',s.company_id).eq('active',true).order('code').limit(1).maybeSingle();
      if(r.error)throw r.error;if(!r.data)throw new Error('Lokasi bengkel aktif tidak dijumpai.');loc=r.data.id;
    }
    return {s,companyId:s.company_id,locationId:loc,staffId:s.id};
  }

  // ---------------- CASH DRAWER ----------------
  const DENOMS=[100,50,20,10,5,1,.5,.2,.1,.05];
  function cashModal(mode){
    let m=$('rtCashManageModal');
    if(m)return m;
    m=document.createElement('div');m.id='rtCashManageModal';m.className='fixed inset-0 z-[1000] hidden items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm';
    m.innerHTML=`<div class="w-full max-w-xl overflow-hidden rounded-3xl bg-white shadow-2xl">
      <div class="flex items-center justify-between border-b p-5"><div><div id="rtCashManageKicker" class="text-[10px] font-black tracking-[.18em] text-red-600">CASH DRAWER</div><h3 id="rtCashManageTitle" class="text-2xl font-black text-slate-900">Modal Permulaan</h3><p id="rtCashManageSub" class="mt-1 text-xs text-slate-500"></p></div><button type="button" id="rtCashManageClose" class="h-10 w-10 rounded-xl bg-slate-100 text-xl font-black">×</button></div>
      <div class="max-h-[72vh] overflow-auto p-5">
        <div id="rtCashExpectedBox" class="mb-4 hidden rounded-2xl bg-slate-50 p-4"><div class="flex justify-between"><span class="font-bold text-slate-500">Jangkaan sistem</span><b id="rtCashExpectedModal">RM 0.00</b></div></div>
        <label class="mb-2 block text-xs font-black uppercase tracking-wide text-slate-500">Jumlah tunai (RM)</label>
        <input id="rtCashManageAmount" type="number" min="0" step="0.01" inputmode="decimal" class="mb-4 w-full rounded-2xl border-2 border-slate-200 px-4 py-4 text-2xl font-black outline-none focus:border-red-500" placeholder="0.00">
        <button type="button" id="rtCashUseDenoms" class="mb-3 text-xs font-black text-red-600">KIRA IKUT PECAHAN DUIT</button>
        <div id="rtCashDenoms" class="hidden grid grid-cols-2 gap-2 rounded-2xl bg-slate-50 p-3 sm:grid-cols-3"></div>
        <label id="rtCashReasonLabel" class="mb-2 mt-4 block text-xs font-black uppercase tracking-wide text-slate-500">Nota / sebab</label>
        <input id="rtCashManageReason" class="w-full rounded-2xl border border-slate-200 px-4 py-3 font-bold outline-none focus:border-red-500" placeholder="Contoh: Tambah duit tukar">
      </div>
      <div class="flex gap-3 border-t bg-slate-50 p-4"><button type="button" id="rtCashManageCancel" class="flex-1 rounded-2xl border border-slate-300 bg-white px-4 py-3 font-black text-slate-600">BATAL</button><button type="button" id="rtCashManageConfirm" class="flex-1 rounded-2xl bg-red-600 px-4 py-3 font-black text-white">SAHKAN</button></div>
    </div>`;
    document.body.appendChild(m);
    const close=()=>{m.classList.add('hidden');m.classList.remove('flex')};
    $('rtCashManageClose').onclick=close;$('rtCashManageCancel').onclick=close;m.addEventListener('click',e=>{if(e.target===m)close()});
    $('rtCashUseDenoms').onclick=()=>{
      const box=$('rtCashDenoms');box.classList.toggle('hidden');
      if(!box.children.length)box.innerHTML=DENOMS.map(d=>`<label class="rounded-xl bg-white p-2"><span class="block text-[10px] font-black text-slate-500">RM ${d.toFixed(2)}</span><input data-denom="${d}" type="number" min="0" step="1" value="0" class="mt-1 w-full rounded-lg border border-slate-200 px-2 py-2 text-center font-black"></label>`).join('');
      box.querySelectorAll('input').forEach(i=>i.oninput=()=>{let total=0;box.querySelectorAll('input').forEach(x=>total+=Number(x.dataset.denom)*Math.max(0,Number(x.value)||0));$('rtCashManageAmount').value=total.toFixed(2)});
    };
    return m;
  }
  function openCashModal(){
    const m=cashModal();$('rtCashManageKicker').textContent='CASH DRAWER';$('rtCashManageTitle').textContent='Buka Peti / Modal Permulaan';$('rtCashManageSub').textContent='Masukkan jumlah tunai fizikal yang diletakkan dalam peti sebelum jualan.';$('rtCashExpectedBox').classList.add('hidden');$('rtCashManageReason').value='Modal awal / opening float';$('rtCashManageAmount').value='';$('rtCashManageConfirm').textContent='BUKA PETI';$('rtCashManageConfirm').dataset.mode='OPEN';$('rtCashReasonLabel').classList.remove('hidden');m.classList.remove('hidden');m.classList.add('flex');setTimeout(()=>$('rtCashManageAmount').focus(),60);
  }
  async function openCash(){
    const m=cashModal();const amount=Math.max(0,Number($('rtCashManageAmount').value)||0);if(!Number.isFinite(amount))throw new Error('Jumlah modal tidak sah.');
    const r=await sb.rpc('rt_cash_open',{p_opening_float:amount,p_drawer_code:'MAIN'});if(r.error)throw r.error;
    m.classList.add('hidden');m.classList.remove('flex');toast(`Peti dibuka. Modal permulaan ${money(amount)} direkod.`,'success');await refreshCash();
  }
  async function cashMove(type){
    const m=cashModal();$('rtCashManageKicker').textContent='CASH MANAGEMENT';$('rtCashManageTitle').textContent=type==='CASH_IN'?'Tambah Tunai':'Keluarkan Tunai';$('rtCashManageSub').textContent=type==='CASH_IN'?'Pay-in: tambah tunai ke peti.':'Pay-out: keluarkan tunai dari peti.';$('rtCashExpectedBox').classList.remove('hidden');const d=await getDrawer(true);if(!d)throw new Error('Peti tunai belum OPEN.');$('rtCashExpectedModal').textContent=money(d.expected_amount);$('rtCashManageReason').value=type==='CASH_IN'?'Tambah duit tukar':'Belanja / cash out';$('rtCashManageAmount').value='';$('rtCashManageConfirm').textContent=type==='CASH_IN'?'TAMBAH TUNAI':'KELUARKAN';$('rtCashManageConfirm').dataset.mode=type;$('rtCashReasonLabel').classList.remove('hidden');m.classList.remove('hidden');m.classList.add('flex');setTimeout(()=>$('rtCashManageAmount').focus(),60);
  }
  async function closeCash(){
    const d=await getDrawer(true);if(!d)throw new Error('Peti tunai belum OPEN.');
    const m=cashModal();$('rtCashManageKicker').textContent='CASH DRAWER';$('rtCashManageTitle').textContent='Tutup Akaun / Kira Tunai';$('rtCashManageSub').textContent='Kira duit fizikal dalam peti dan bandingkan dengan jangkaan sistem.';$('rtCashExpectedBox').classList.remove('hidden');$('rtCashExpectedModal').textContent=money(d.expected_amount);$('rtCashManageAmount').value=Number(d.expected_amount||0).toFixed(2);$('rtCashManageReason').value='';$('rtCashReasonLabel').classList.add('hidden');$('rtCashManageConfirm').textContent='TUTUP AKAUN';$('rtCashManageConfirm').dataset.mode='CLOSE';m.classList.remove('hidden');m.classList.add('flex');setTimeout(()=>$('rtCashManageAmount').focus(),60);
  }
  async function cashConfirm(){
    const mode=$('rtCashManageConfirm').dataset.mode;
    try{
      if(mode==='OPEN')return await openCash();
      if(mode==='CLOSE'){
        const actual=Math.max(0,Number($('rtCashManageAmount').value)||0);const r=await sb.rpc('rt_cash_close',{p_actual_amount:actual});if(r.error)throw r.error;const diff=Number(r.data||0);$('rtCashManageModal').classList.add('hidden');$('rtCashManageModal').classList.remove('flex');toast(`Akaun ditutup. ${diff===0?'Seimbang.':diff>0?'Lebih '+money(diff):'Kurang '+money(Math.abs(diff))}.`,'success');await refreshCash();return;
      }
      const amount=Math.max(0,Number($('rtCashManageAmount').value)||0);if(amount<=0)throw new Error('Jumlah mesti lebih daripada RM0.');const reason=String($('rtCashManageReason').value||'').trim();const r=await sb.rpc('rt_cash_move',{p_type:mode,p_amount:amount,p_reason:reason});if(r.error)throw r.error;$('rtCashManageModal').classList.add('hidden');$('rtCashManageModal').classList.remove('flex');toast(mode==='CASH_IN'?`Tunai masuk ${money(amount)} direkod.`:`Tunai keluar ${money(amount)} direkod.`,'success');await refreshCash();
    }catch(e){toast('Cash drawer gagal | '+err(e),'error')}
  }
  async function getDrawer(openOnly=false){
    const {companyId}=await ctx();let q=sb.from('cash_drawers').select('*').eq('company_id',companyId).eq('drawer_code','MAIN').limit(1).maybeSingle();if(openOnly)q=sb.from('cash_drawers').select('*').eq('company_id',companyId).eq('drawer_code','MAIN').eq('status','OPEN').limit(1).maybeSingle();const r=await q;if(r.error)throw r.error;return r.data;
  }
  async function refreshCash(){
    const st=$('rtCashDrawerStatus'),ex=$('rtCashDrawerExpected'),openBtn=$('rtOpenCashDrawerBtn'),inBtn=$('rtCashInBtn'),outBtn=$('rtCashOutBtn'),closeBtn=$('rtCloseCashDrawerBtn');
    if(!st||!ex)return null;
    const setUi=(isOpen,d)=>{
      st.textContent=isOpen?'OPEN':'CLOSED';
      st.classList.toggle('is-open',!!isOpen);
      st.classList.toggle('is-closed',!isOpen);
      ex.textContent=isOpen?money(d?.expected_amount||0):'RM 0.00';
      if(openBtn){openBtn.hidden=!!isOpen;openBtn.disabled=!!isOpen;openBtn.textContent='BUKA PETI / MODAL AWAL';}
      if(inBtn){inBtn.hidden=!isOpen;inBtn.disabled=!isOpen;}
      if(outBtn){outBtn.hidden=!isOpen;outBtn.disabled=!isOpen;}
      if(closeBtn){closeBtn.hidden=!isOpen;closeBtn.disabled=!isOpen;}
      const hint=$('rtCashDrawerHint');if(hint)hint.textContent=isOpen?'Peti tunai sedang aktif. Jangkaan tunai semasa dipaparkan di atas.':'Buka peti sebelum menerima bayaran TUNAI. Modal awal boleh RM0.';
    };
    try{const d=await getDrawer(false);const isOpen=!!d&&d.status==='OPEN';setUi(isOpen,d);return d||null}catch(e){st.textContent='RALAT';st.classList.remove('is-open','is-closed');ex.textContent='—';console.warn('cash drawer',e);return null}
  }
  function installCashButtons(){
    const panel=$('rtCashDrawerPanel');if(!panel||panel.dataset.v49==='1')return;panel.dataset.v49='1';
    panel.innerHTML=`<div class="rt-cash-drawer-head"><div><small>PETI TUNAI</small><div class="rt-cash-drawer-state"><span id="rtCashDrawerStatus">—</span><b id="rtCashDrawerExpected">RM 0.00</b></div></div></div><p id="rtCashDrawerHint">Semak status peti tunai.</p><div class="rt-cash-drawer-actions"><button type="button" id="rtOpenCashDrawerBtn" class="primary">BUKA PETI / MODAL AWAL</button><button type="button" id="rtCashInBtn">MONEY IN</button><button type="button" id="rtCashOutBtn">MONEY OUT</button><button type="button" id="rtCloseCashDrawerBtn" class="danger">CLOSING / KIRA BAKI</button></div>`;
    $('rtOpenCashDrawerBtn').onclick=()=>{openCashModal()};$('rtCashInBtn').onclick=()=>cashMove('CASH_IN').catch(e=>toast('Cash in gagal | '+err(e),'error'));$('rtCashOutBtn').onclick=()=>cashMove('CASH_OUT').catch(e=>toast('Cash out gagal | '+err(e),'error'));$('rtCloseCashDrawerBtn').onclick=()=>closeCash().catch(e=>toast('Tutup peti gagal | '+err(e),'error'));
    const m=cashModal();$('rtCashManageConfirm').onclick=cashConfirm;
    document.querySelectorAll('#rtQuickCash [data-cash]').forEach(b=>b.addEventListener('click',()=>{
      const inp=$('posAmountReceived'); if(!inp)return;
      const t=calcTotals().total; const v=b.dataset.cash==='exact'?t:Number(b.dataset.cash||0);
      inp.value=Math.max(0,v).toFixed(2); inp.dispatchEvent(new Event('input',{bubbles:true}));
    }));
    refreshCash();
  }

  // ---------------- POS CHECKOUT ----------------
  function cart(){return typeof window.rtGetPosCart==='function'?window.rtGetPosCart():(Array.isArray(window.posCart)?window.posCart:[])}
  function isService(i){return !!(i?.service||String(i?.itemType||'').toUpperCase()==='SERVICE')}
  function calcTotals(){const c=cart();const sub=c.reduce((s,i)=>s+Number(i.price||0)*Number(i.qty||1),0);const disc=Math.min(Math.max(0,Number($('posDiscount')?.value||0)),sub);return {sub,disc,total:Math.max(0,sub-disc)}}
  async function checkout(){
    const c=cart();if(!c.length){toast('Troli kosong.','error');return}
    const {sub,disc,total}=calcTotals();const method=String(window.posPayMethod||'CASH').toUpperCase();let received=Number($('posAmountReceived')?.value||0);if(method!=='CASH')received=total;if(method==='CASH'&&received<total){toast('Jumlah diterima tidak mencukupi.','error');return}
    if(method==='CASH'){const d=await getDrawer(true);if(!d){toast('Peti tunai belum OPEN. Buka peti dahulu sebelum bayaran TUNAI.','error');return}}
    const btn=$('btnCheckout'),old=btn?.innerHTML;if(btn){btn.disabled=true;btn.innerHTML='Memproses...'}
    try{
      const activeJob=window.rtActiveJob||null;
      const hasService=c.some(isService);
      // Pure product sale: use the existing database transaction. This is the safest path.
      if(!activeJob&&!hasService){
        const {companyId:cmp}=await ctx();
        const items=[];
        for(const i of c){
          let productId=i.productId||null;
          if(!productId){
            const q=await sb.from('products').select('id').eq('company_id',cmp).eq('sku',String(i.sku||'').trim().toUpperCase()).eq('active',true).limit(1).maybeSingle();
            if(q.error)throw q.error;if(!q.data)throw new Error('Produk tidak dijumpai: '+(i.name||i.sku));productId=q.data.id;
          }
          items.push({product_id:productId,quantity:Number(i.qty||1)});
        }
        const rpc=await sb.rpc('rt_post_pos_sale',{p_customer_id:$('rtPosCustomerSelect')?.value||null,p_payment_method:method==='QR / DUITNOW'?'QR':method,p_amount_received:received,p_items:items});if(rpc.error)throw rpc.error;const row=Array.isArray(rpc.data)?rpc.data[0]:rpc.data;const invNo=row?.invoice_no||'INV';toast(`Invois ${invNo} berjaya.`,'success');const receipt={invoiceNo:invNo,paymentMethod:method,total:Number(row?.total||total),amountPaid:Number(row?.total||total),change:Number(row?.change_amount||Math.max(0,received-total)),items:c.map(x=>({name:x.name,sku:x.sku,qty:x.qty,price:x.price}))};try{window.generateReceiptFromInvoice?.(receipt)}catch(_){}window.rtSetPosCart?.([]);window.posClearCart?.();if($('posDiscount'))$('posDiscount').value='0';if($('posAmountReceived'))$('posAmountReceived').value='';await refreshCash();window.loadPOS?.();return;
      }

      // Job/service POS: ONE database transaction. Never INSERT invoices/items/payment from browser.
      // This avoids RLS failures and prevents partial financial writes.
      const {companyId:cmp,staffId:st}=await ctx();
      if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(st||''))) throw new Error('STAFF CONTEXT | staff.id bukan UUID. Login staff belum dipetakan dengan betul.');
      const jobId=activeJob?.jobCardId;
      if(!jobId) throw new Error('JOB CONTEXT | Job Card tidak dijumpai.');
      const rpcItems=c.map(i=>({
        product_id:i.productId||null,
        job_card_item_id:i.jobCardItemId||null,
        from_job_card:!!i.fromJobCard,
        item_type:isService(i)?'SERVICE':'PART',
        quantity:Number(i.qty||1),
        service_price:isService(i)?Number(i.price||0):null,
        description:i.name||null
      }));
      const rpc=await sb.rpc('rt_post_job_pos_sale',{
        p_job_card_id:jobId,
        p_customer_id:activeJob?.customerId||$('rtPosCustomerSelect')?.value||null,
        p_payment_method:method==='QR / DUITNOW'?'QR':method,
        p_amount_received:received,
        p_discount:disc,
        p_items:rpcItems
      });
      if(rpc.error)throw rpc.error;
      const row=Array.isArray(rpc.data)?rpc.data[0]:rpc.data;
      if(!row?.invoice_no)throw new Error('CHECKOUT | RPC tidak memulangkan invois.');
      const finalTotal=Number(row.total||total), finalChange=Number(row.change_amount||Math.max(0,received-finalTotal));
      toast(`Bayaran berjaya · ${row.invoice_no}`,'success');
      try{window.generateReceiptFromInvoice?.({invoiceNo:row.invoice_no,paymentMethod:method,total:finalTotal,amountPaid:method==='CASH'?received:finalTotal,change:finalChange,items:c.map(x=>({name:x.name,sku:x.sku,qty:x.qty,price:x.price}))})}catch(_){}
      window.rtActiveJob=null;window.rtSetPosCart?.([]);window.posClearCart?.();if($('posDiscount'))$('posDiscount').value='0';if($('posAmountReceived'))$('posAmountReceived').value='';await refreshCash();window.loadPOS?.();window.loadJobCards?.();
    }catch(e){console.error('REV TORQ V36.4.9 CHECKOUT',{activeJob:window.rtActiveJob,method,error:e});toast('Checkout gagal | '+err(e),'error')}
    finally{if(btn){btn.disabled=false;btn.innerHTML=old||'BAYAR / CHECKOUT'}window.rtSyncCashTender?.()}
  }

  // Install last so older inline/legacy handlers cannot overwrite production behavior.
  window.posCheckout=checkout;
  window.rtOpenCashDrawer=openCashModal;
  window.rtCloseCashDrawer=closeCash;
  window.rtRefreshCashDrawer=refreshCash;
  window.rtCashIn=()=>cashMove('CASH_IN');
  window.rtCashOut=()=>cashMove('CASH_OUT');
  window.rtGetCashDrawer=getDrawer;
  window.rtEnsureCashDrawerOpen=async()=>!!(await getDrawer(true)|| (openCashModal(),false));
  window.rtResolveStaffId=async()=>{const s=await staffRow();return s.id};
  window.addEventListener('load',()=>{setTimeout(()=>{installCashButtons();refreshCash()},900);setInterval(()=>{installCashButtons()},1500)});
})();
