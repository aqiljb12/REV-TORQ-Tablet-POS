package com.revtorq.pos;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.provider.Settings;
import android.net.Uri;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.webkit.PermissionRequest;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private static final int CAMERA_REQUEST = 4101;
    private WebView webView;
    private PermissionRequest pendingPermissionRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11, 14, 20));
        getWindow().setNavigationBarColor(Color.rgb(11, 14, 20));
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11, 14, 20));

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();

                // Native APK must hand custom printer links to Android instead of
                // letting WebView try to render rawbt: as a web page.
                if ("rawbt".equals(scheme)) {
                    return openExternalUri(uri, "RawBT belum dipasang atau tidak boleh dibuka.");
                }

                boolean whatsapp = host.equals("wa.me") || host.endsWith("whatsapp.com") || scheme.equals("whatsapp");
                if (whatsapp) {
                    return openExternalUri(uri, "WhatsApp tidak dapat dibuka.");
                }

                // Keep normal appassets/http(s) navigation inside the WebView.
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if ((request.getOrigin() != null) && request.getOrigin().toString().startsWith("https://appassets.androidplatform.net")) {
                        pendingPermissionRequest = request;
                        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                                checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(MainActivity.this,
                                    new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
                        } else {
                            grantCamera(request);
                        }
                    } else {
                        request.deny();
                    }
                });
            }
        });

        // Native bridge used by the embedded POS for printer actions.
        webView.addJavascriptInterface(new NativeBridge(), "RevTorqNative");

        android.webkit.WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setTextZoom(100);

        setContentView(webView);
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html?native=1");
    }

    private boolean openExternalUri(Uri uri, String errorMessage) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            return true;
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
            return true;
        } catch (Exception e) {
            Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
            return true;
        }
    }

    private class NativeBridge {
        @JavascriptInterface
        public boolean isNativeApp() {
            return true;
        }

        @JavascriptInterface
        public void launchRawBt(String rawBtUri) {
            if (rawBtUri == null || !rawBtUri.startsWith("rawbt:")) return;
            runOnUiThread(() -> openExternalUri(
                    Uri.parse(rawBtUri),
                    "RawBT belum dipasang. Pasang RawBT dan pair MPT-II dahulu."
            ));
        }

        @JavascriptInterface
        public void openBluetoothSettings() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Tetapan Bluetooth tidak dapat dibuka.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private void grantCamera(PermissionRequest request) {
        if (request == null) return;
        request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
        pendingPermissionRequest = null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_REQUEST && pendingPermissionRequest != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                grantCamera(pendingPermissionRequest);
            } else {
                pendingPermissionRequest.deny();
                pendingPermissionRequest = null;
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
