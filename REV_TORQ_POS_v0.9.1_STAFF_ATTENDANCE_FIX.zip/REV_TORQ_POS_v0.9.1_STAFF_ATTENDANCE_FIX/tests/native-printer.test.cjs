const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');

test('Android MainActivity intercepts RawBT and exposes native bridge',()=>{
  const s=fs.readFileSync(path.join(root,'app/src/main/java/com/revtorq/pos/MainActivity.java'),'utf8');
  assert.match(s,/"rawbt"\.equals\(scheme\)/);
  assert.match(s,/addJavascriptInterface\(new NativeBridge\(\), "RevTorqNative"\)/);
  assert.match(s,/@JavascriptInterface\s+public void launchRawBt/);
});

test('RawBT JS uses native bridge before URI fallback',()=>{
  const s=fs.readFileSync(path.join(root,'js/rt-rawbt-printer.js'),'utf8');
  const bridge=s.indexOf('window.RevTorqNative.launchRawBt(uri)');
  const fallback=s.indexOf('window.location.href=uri');
  assert.ok(bridge>=0 && fallback>bridge);
  assert.match(s,/st\.mode==='rawbt'/);
});

test('APK printer settings do not advertise browser print as native mode',()=>{
  const s=fs.readFileSync(path.join(root,'index.html'),'utf8');
  assert.match(s,/ANDROID APK \/ RAWBT/);
  assert.match(s,/NATIVE_APK/);
  assert.match(s,/BLUETOOTH SETTINGS/);
});
