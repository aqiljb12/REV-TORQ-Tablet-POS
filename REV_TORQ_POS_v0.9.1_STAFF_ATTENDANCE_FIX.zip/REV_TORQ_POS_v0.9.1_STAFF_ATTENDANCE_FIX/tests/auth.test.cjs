const {test}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const source=fs.readFileSync(path.join(root,'js/supabase-auth.js'),'utf8');
function storage(){const map=new Map();return {getItem:k=>map.get(k)??null,setItem:(k,v)=>map.set(k,String(v)),removeItem:k=>map.delete(k)};}
function harness(options={}){
  const records=options.records||[{id:'staff-uuid',staff_code:'AQIL',auth_user_id:'user-1',active:true,role:'admin',company_id:'company-1',location_id:'location-1'}];
  const calls=[],messages=[],nodes=new Map();let authCallback;
  const node=id=>{
    if(!nodes.has(id))nodes.set(id,{value:'',disabled:false,innerText:'',hidden:false,
      classList:{add(){},remove(){}},style:{setProperty(){}},remove(){this.removed=true;}});
    return nodes.get(id);
  };
  const localStorage=storage(),sessionStorage=storage();
  const state={user:{id:'user-1'},session:options.session!==false,layouts:0,reloads:0};
  const sb={auth:{
    async getUser(){calls.push('getUser');if(options.waitUser)await options.waitUser;return {data:{user:state.user},error:options.userError||null};},
    async getSession(){return {data:{session:state.session?{user:state.user}:null}};},
    async signInWithPassword(p){calls.push(['signIn',p]);state.session=true;return {data:{user:state.user},error:options.loginError||null};},
    async signOut(p){calls.push(['signOut',p]);if(options.logoutError)return {error:Error('offline')};state.session=false;authCallback?.('SIGNED_OUT',null);return {error:null};},
    onAuthStateChange(fn){authCallback=fn;return {data:{subscription:{unsubscribe(){}}}};}
  },async rpc(name,args){calls.push(['rpc',name,args]);if(options.waitRpc)await options.waitRpc;return {data:'staff@example.test',error:null};},
  from(table){calls.push(['from',table]);const filters=[];const q={
    select(){return q;},eq(k,v){filters.push([k,v]);calls.push(['eq',k,v]);return q;},
    limit(n){return Promise.resolve({data:options.ignoreFilters?records:records.filter(row=>filters.every(([k,v])=>row[k]===v)).slice(0,n),error:options.queryError||null});}
  };return q;}};
  const ctx={console,Promise,Set,Object,String,Error,localStorage,sessionStorage,
    document:{getElementById:node},supabaseClient:sb,rtAuthStorageKey:'sb-test-auth-token',
    showToast:(...a)=>messages.push(a),initAppLayout:()=>state.layouts++,
    rtApplySupabaseProfile:(p,u)=>{ctx.currentProfile=p;ctx.currentUser=u;},
    location:{reload:()=>state.reloads++}};
  ctx.window=ctx;vm.createContext(ctx);vm.runInContext(source,ctx);
  return {ctx,node,state,calls,messages,localStorage,sessionStorage,records,
    emit:(e,s)=>authCallback(e,s),async login(){node('loginId').value='AQIL';node('loginPin').value='123456';await ctx.handleLogin({preventDefault(){}});}};
}
test('valid login verifies server user, exact staff UID and profile',async()=>{
  const h=harness();await h.login();assert.equal(h.state.layouts,1);assert.equal(h.ctx.rtHasAdminAccess(),true);
  assert.ok(h.calls.includes('getUser'));assert.ok(h.calls.some(c=>c[0]==='eq'&&c[1]==='auth_user_id'&&c[2]==='user-1'));
  assert.equal(h.node('loginPin').value,'');assert.equal(h.node('btnLogin').disabled,false);
  assert.equal(JSON.parse(h.localStorage.getItem('revtorq_session')).staffUuid,'staff-uuid');
});
for(const [name,changes] of Object.entries({inactive:{active:false},unlinked:{auth_user_id:null},wrong_uid:{auth_user_id:'other'},wrong_code:{staff_code:'OTHER'},removed:{removed_from_active_list:true},missing_company:{company_id:null},unknown_role:{role:'customer'},empty_role:{role:''}})){
  test('reject '+name,async()=>{const base=harness().records[0];const h=harness({records:[{...base,...changes}],ignoreFilters:true});await h.login();assert.equal(h.state.layouts,0);assert.equal(h.ctx.currentProfile,null);assert.equal(h.ctx.rtHasAdminAccess(),false);assert.ok(h.calls.some(c=>c[0]==='signOut'));});
}
test('duplicate active staff mappings are rejected',async()=>{const row=harness().records[0];const h=harness({records:[row,{...row,id:'duplicate'}]});await h.login();assert.equal(h.state.layouts,0);});
test('missing staff never falls back to staff code',async()=>{const h=harness({records:[]});await h.login();assert.equal(h.state.layouts,0);assert.ok(!h.calls.some(c=>c[0]==='eq'&&c[1]==='staff_code'));});
test('forged cached profile, DOM role and override do not grant admin',async()=>{
  const row=harness().records[0];const h=harness({records:[{...row,role:'staff'}]});await h.login();
  h.localStorage.setItem('revtorq_session',JSON.stringify({role:'admin'}));h.sessionStorage.setItem('rt_override_mode','1');h.node('navUserRole').innerText='admin';h.ctx.currentProfile.role='admin';
  assert.equal(h.ctx.rtHasAdminAccess(),false);
});
test('logout clears both profile stores and override, but preserves settings',async()=>{
  const h=harness();await h.login();for(const s of [h.localStorage,h.sessionStorage]){s.setItem('revtorq_session','stale');s.setItem('rt_override_mode','1');}
  h.localStorage.setItem('sb-test-auth-token','secret');h.localStorage.setItem('device-id','keep');await h.ctx.handleLogout();
  for(const s of [h.localStorage,h.sessionStorage]){assert.equal(s.getItem('revtorq_session'),null);assert.equal(s.getItem('rt_override_mode'),null);}
  assert.equal(h.localStorage.getItem('sb-test-auth-token'),null);assert.equal(h.localStorage.getItem('device-id'),'keep');assert.equal(h.ctx.rtHasAdminAccess(),false);
  assert.ok(h.calls.some(c=>c[0]==='signOut'&&c[1].scope==='local'));assert.equal(h.state.reloads,1);
});
test('offline logout clears local token, reloads SDK memory and blocks restore',async()=>{const h=harness({logoutError:true});await h.login();h.localStorage.setItem('sb-test-auth-token','secret');await h.ctx.handleLogout();await h.ctx.restoreSession();assert.equal(h.localStorage.getItem('sb-test-auth-token'),null);assert.equal(h.ctx.currentProfile,null);assert.equal(h.state.layouts,1);assert.equal(h.state.reloads,1);assert.ok(h.sessionStorage.getItem('rt_logout_notice'));});
test('restore uses getUser, not cached admin',async()=>{const row=harness().records[0];const h=harness({records:[{...row,role:'staff'}]});h.localStorage.setItem('revtorq_session',JSON.stringify({role:'admin'}));await h.ctx.restoreSession();assert.equal(h.ctx.currentProfile.role,'staff');assert.equal(h.ctx.rtHasAdminAccess(),false);});
test('revoked user cannot restore',async()=>{const h=harness({userError:Error('revoked')});await h.ctx.restoreSession();assert.equal(h.state.layouts,0);assert.equal(h.ctx.currentProfile,null);});
test('restore callers share a single in-flight operation',async()=>{const h=harness();await Promise.all([h.ctx.restoreSession(),h.ctx.restoreSession()]);assert.equal(h.state.layouts,1);});
test('login cannot reopen app after logout while profile request is pending',async()=>{
  let release;const waitUser=new Promise(r=>release=r);const h=harness({waitUser});const login=h.login();await new Promise(r=>setImmediate(r));await h.ctx.handleLogout();release();await login;assert.equal(h.state.layouts,0);assert.equal(h.ctx.currentProfile,null);assert.equal(h.state.session,false);
});
test('cancelled login never sends credentials after pending RPC completes',async()=>{
  let release;const waitRpc=new Promise(r=>release=r);const h=harness({waitRpc});const login=h.login();await h.ctx.handleLogout();release();await login;assert.ok(!h.calls.some(c=>c[0]==='signIn'));
});
test('external signout clears profile and admin authority',async()=>{const h=harness();await h.login();h.emit('SIGNED_OUT',null);assert.equal(h.ctx.currentProfile,null);assert.equal(h.ctx.rtHasAdminAccess(),false);});
test('bootstrap does not call signup or privileged RPC',async()=>{const h=harness();await h.ctx.setupInitialAdmin();assert.equal(h.calls.length,0);});
test('six digit PIN is enforced before network requests',async()=>{const h=harness();h.node('loginId').value='AQIL';h.node('loginPin').value='abcdef';await h.ctx.handleLogin({preventDefault(){}});assert.equal(h.calls.length,0);});
test('static void modal is hidden, never deleted by auth cleanup',()=>{const h=harness();assert.notEqual(h.node('rtVoidModal').removed,true);});
test('canonical context ignores forged company and UID',async()=>{
  const h=harness();await h.login();vm.runInContext(fs.readFileSync(path.join(root,'js/rt-context-canonical.js'),'utf8'),h.ctx);
  h.ctx.currentProfile.companyId='forged';h.ctx.currentProfile.uid='other';assert.equal(await h.ctx.companyId(),'company-1');assert.equal(await h.ctx.staffUuid(),'staff-uuid');
});
