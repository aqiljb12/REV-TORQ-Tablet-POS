const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(p,'utf8');
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]);}
let scripts=0,refs=0;
for(const base of [root,path.join(root,'WAB_DEPLOY'),path.join(root,'app/src/main/assets'),path.join(root,'UPLOAD_GITHUB/WAB_DEPLOY')]){
  for(const f of walk(path.join(base,'js'))){if(f.endsWith('.js')){new vm.Script(read(f),{filename:f});scripts++;}}
  const html=read(path.join(base,'index.html'));
  let combined='';
  for(const m of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)){
    const src=m[1].match(/\bsrc=["']([^"']+)["']/i)?.[1];
    if(src&&!/^(https?:)?\/\//.test(src))combined+='\n'+read(path.join(base,src.split('?')[0]))+'\n';
    else if(!src){new vm.Script(m[2]);scripts++;combined+='\n'+m[2]+'\n';}
  }
  new vm.Script(combined,{filename:'combined-local-scripts'});
  for(const m of html.matchAll(/\b(?:src|href)=["']([^"']+)["']/g)){
    const target=m[1];if(/^(https?:|data:|#|javascript:|mailto:|tel:|\/\/)/.test(target)||target.includes('${'))continue;
    const clean=target.split(/[?#]/)[0];if(!clean)continue;
    assert.ok(fs.existsSync(path.join(base,clean)),'Missing asset: '+target);refs++;
  }
  assert.ok(!/rt_override_mode['"]\s*,\s*['"]1/.test(html),'Override flag grant found');
  for(const f of ['core.js','supabase-auth.js','supabase-bridge.js','rt-context-canonical.js'])assert.equal(read(path.join(base,'js',f)),read(path.join(root,'js',f)),f+' differs between targets');
  assert.equal(html,read(path.join(root,'index.html')),'HTML copies differ');
}
for(const configPath of ['wrangler.jsonc','UPLOAD_GITHUB/wrangler.jsonc']){
  const config=JSON.parse(read(path.join(root,configPath)));
  assert.equal(config.name,'rev-torq-tablet-pos');
  assert.ok(fs.existsSync(path.join(root,path.dirname(configPath),config.assets.directory,'index.html')));
}
const files=walk(path.join(root,'UPLOAD_GITHUB'));
assert.ok(files.length<100,'Web upload exceeds one 100-file batch');
for(const f of files){
  assert.ok(!/\.(sql|jks|keystore|pem)$|[\\/]\.env/.test(f),'Non-runtime or sensitive file');
  const t=read(f);
  assert.ok(!/sb_secret_[A-Za-z0-9_-]+|-----BEGIN .*PRIVATE KEY-----/.test(t),'Secret found');
  for(const jwt of t.match(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g)||[]){
    const payload=JSON.parse(Buffer.from(jwt.split('.')[1],'base64url'));
    assert.notEqual(payload.role,'service_role','Privileged JWT found');
  }
}
const original=process.argv[2];
if(original){
  const stripScripts=t=>t.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'').trimEnd();
  assert.equal(stripScripts(read(path.join(root,'index.html'))),stripScripts(read(path.join(original,'index.html'))),'HTML layout changed');
  for(const f of walk(path.join(root,'css')))assert.equal(read(f),read(path.join(original,path.relative(root,f))),'CSS changed');
}
console.log(JSON.stringify({status:'PASS',compiledScripts:scripts,checkedLocalReferences:refs,githubFiles:files.length,uiCompared:!!original},null,2));
