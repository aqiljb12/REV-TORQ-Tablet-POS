const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('POS exposes receipt reprint outside admin-only view',()=>{
  const html=read('index.html');
  assert.match(html,/class="rt-reprint-card"/);
  assert.match(html,/Print Semula/);
  assert.match(html,/js\/receipt-reprint\.js\?v=0\.9\.0/);
});

test('reprint uses role-checked RPCs and keeps VOID admin-only',()=>{
  const js=read('js/receipt-reprint.js');
  assert.match(js,/rt_staff_receipt_history/);
  assert.match(js,/rt_staff_receipt_detail/);
  assert.match(js,/rt_log_receipt_reprint/);
  assert.match(js,/isAdmin\(\).*BATAL \/ VOID/s);
  assert.match(js,/SALINAN \/ REPRINT/);
});

test('migration is additive and does not widen invoice RLS',()=>{
  const sql=read('migration_2026_09_13_staff_receipt_reprint.sql');
  assert.match(sql,/create or replace function public\.rt_staff_receipt_history/i);
  assert.match(sql,/create or replace function public\.rt_staff_receipt_detail/i);
  assert.match(sql,/create or replace function public\.rt_log_receipt_reprint/i);
  assert.doesNotMatch(sql,/create\s+policy|drop\s+policy|alter\s+table\s+public\.invoices/i);
});
