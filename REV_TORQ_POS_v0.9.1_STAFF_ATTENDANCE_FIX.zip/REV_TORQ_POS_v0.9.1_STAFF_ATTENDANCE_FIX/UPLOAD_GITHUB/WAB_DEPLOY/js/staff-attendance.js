/* REV TORQ V38.1 — STAFF CLOCK IN / CLOCK OUT
   Simple attendance button using the existing Supabase Auth staff login.
   Resolves the logged-in staff row fresh via auth.uid() (does not rely on
   window.currentProfile shape, since two different login code paths in
   this app populate it slightly differently).
*/
(function () {
  'use strict';

  const state = { row: null, staffId: null, companyId: null, loading: false };

  function sbClient() {
    return window.supabaseClient || window.sb || null;
  }

  async function resolveStaff() {
    const sb = sbClient();
    if (!sb) return null;
    const { data: userData, error: userErr } = await sb.auth.getUser();
    if (userErr || !userData || !userData.user) return null;
    const r = await sb.from('staff')
      .select('id,company_id')
      .eq('auth_user_id', userData.user.id)
      .limit(1)
      .maybeSingle();
    if (r.error || !r.data) return null;
    const staffId = String(r.data.id || '').trim();
    const companyId = String(r.data.company_id || '').trim();
    if (!staffId || !companyId) {
      console.error('ATTENDANCE RESOLVE: staff row missing UUID/company_id', r.data);
      return null;
    }
    return { staffId, companyId };
  }

  function setButtonState(hasOpenSession, sinceLabel) {
    const btn = document.getElementById('rtAttendanceBtn');
    const label = document.getElementById('rtAttendanceLabel');
    if (!btn) return;
    btn.style.display = 'inline-flex';
    btn.classList.remove('bg-emerald-50', 'text-emerald-700', 'border-emerald-200');
    btn.classList.remove('bg-slate-50', 'text-slate-600', 'border-slate-200');
    if (hasOpenSession) {
      btn.classList.add('bg-emerald-50', 'text-emerald-700', 'border-emerald-200');
      if (label) label.textContent = sinceLabel ? `Clock Out (masuk ${sinceLabel})` : 'Clock Out';
    } else {
      btn.classList.add('bg-slate-50', 'text-slate-600', 'border-slate-200');
      if (label) label.textContent = 'Clock In';
    }
  }

  async function refresh() {
    const btn = document.getElementById('rtAttendanceBtn');
    if (!btn) return;
    const info = await resolveStaff();
    if (!info) { btn.style.display = 'none'; return; }
    state.staffId = info.staffId;
    state.companyId = info.companyId;
    const sb = sbClient();
    const r = await sb.from('staff_attendance')
      .select('*')
      .eq('staff_id', info.staffId)
      .is('clock_out', null)
      .order('clock_in', { ascending: false })
      .limit(1)
      .maybeSingle();
    if (r.error) { console.error('ATTENDANCE REFRESH:', r.error); return; }
    state.row = r.data || null;
    if (state.row) {
      const t = new Date(state.row.clock_in).toLocaleTimeString('ms-MY', { hour: '2-digit', minute: '2-digit' });
      setButtonState(true, t);
    } else {
      setButtonState(false, null);
    }
  }

  async function toggle() {
    if (state.loading) return;
    const btn = document.getElementById('rtAttendanceBtn');
    state.loading = true;
    if (btn) btn.disabled = true;
    try {
      const sb = sbClient();
      if (!sb) throw new Error('Supabase belum tersedia.');
      if (!state.staffId) {
        const info = await resolveStaff();
        if (!info) throw new Error('Profil staff tidak dijumpai untuk akaun ini.');
        state.staffId = info.staffId;
        state.companyId = info.companyId;
      }
      if (state.row) {
        const upd = await sb.from('staff_attendance')
          .update({ clock_out: new Date().toISOString() })
          .eq('id', state.row.id)
          .is('clock_out', null)
          .select('*')
          .single();
        if (upd.error) throw upd.error;
        if (typeof window.showToast === 'function') window.showToast('Clock Out berjaya.', 'success');
      } else {
        const ins = await sb.from('staff_attendance')
          .insert({
            company_id: state.companyId,
            staff_id: state.staffId,
            clock_in: new Date().toISOString()
          })
          .select('*')
          .single();
        if (ins.error) throw ins.error;
        if (typeof window.showToast === 'function') window.showToast('Clock In berjaya.', 'success');
      }
    } catch (e) {
      console.error('ATTENDANCE TOGGLE:', e);
      if (typeof window.showToast === 'function') window.showToast('Gagal: ' + (e.message || e), 'error');
      else alert('Gagal: ' + (e.message || e));
    } finally {
      state.loading = false;
      if (btn) btn.disabled = false;
      refresh();
    }
  }

  window.rtAttendanceToggle = toggle;
  window.rtAttendanceRefresh = refresh;

  document.addEventListener('DOMContentLoaded', function () {
    setTimeout(refresh, 1200);
  });
  // Fallback poll in case login happens without calling rtAttendanceRefresh directly.
  setInterval(refresh, 60000);
})();
