// ================= GRN (PURCHASE) =================
        let grnCart = [];
        let grnItemsCache = [];

        async function loadGRN() {
            const tbody = document.querySelector('#tblGRN tbody');
            tbody.innerHTML = '<tr><td colspan="5" class="text-center p-4">Loading...</td></tr>';
            
            // Populate Suppliers for modal
            const sSel = document.getElementById('grnSupplierSelect');
            try {
                const sSnap = await db.collection("suppliers").where("active", "==", true).get();
                sSel.innerHTML = '<option value="">-- Sila Pilih --</option>';
                sSnap.forEach(doc => {
                    const s = doc.data();
                    sSel.innerHTML += `<option value="${s.supplierId}" data-name="${s.company.replace(/'/g, "\\'")}">${s.company}</option>`;
                });
            } catch(e) {}

            // Populate Items for modal
            const iSel = document.getElementById('grnItemSelect');
            try {
                const iSnap = await db.collection("inventory").where("active", "==", true).get();
                iSel.innerHTML = '';
                grnItemsCache = [];
                iSnap.forEach(doc => {
                    const i = doc.data();
                    grnItemsCache.push(i);
                    iSel.innerHTML += `<option value="${i.sku}" data-stock="${Number(i.stock||0)}" data-cost="${Number(i.costPrice||0)}">${i.sku} - ${i.name}</option>`;
                });
            } catch(e) {}

            // Load GRN table
            try {
                const snap = await db.collection("grn").orderBy("createdAt", "desc").limit(50).get();
                let rows = '';
                snap.forEach(doc => {
                    const d = doc.data();
                    rows += `
                        <tr class="hover:bg-gray-800/50">
                            <td class="p-4 font-mono font-bold text-amber-500">${d.grnNo}</td>
                            <td class="p-4 text-xs text-gray-400">${d.createdAt ? new Date(d.createdAt.toDate()).toLocaleDateString('ms-MY') : '-'}</td>
                            <td class="p-4 font-bold text-white">${d.supplierName}</td>
                            <td class="p-4 text-xs font-bold text-green-400">RECEIVED</td>
                            <td class="p-4 text-right font-mono font-bold text-white">${formatMoney(d.total)}</td>
                        </tr>
                    `;
                });
                tbody.innerHTML = rows || '<tr><td colspan="5" class="text-center p-4 text-gray-500">Tiada rekod GRN</td></tr>';
            } catch(e) { tbody.innerHTML = `<tr><td colspan="5" class="text-center p-4 text-red-500">Ralat: ${e.message}</td></tr>`; }
        }

        function grnOnItemChange() {
            const sel = document.getElementById('grnItemSelect');
            const opt = sel && sel.options[sel.selectedIndex];
            const stock = opt ? Number(opt.dataset.stock || 0) : 0;
            const cost = opt ? Number(opt.dataset.cost || 0) : 0;
            const qtyEl = document.getElementById('grnQty');
            const costEl = document.getElementById('grnCost');
            const curEl = document.getElementById('grnCurrentStock');
            const afterEl = document.getElementById('grnAfterStock');
            if (curEl) curEl.innerText = stock;
            if (costEl && (costEl.value === '' || costEl.dataset.auto === 'true')) {
                costEl.value = cost.toFixed(2);
                costEl.dataset.auto = 'true';
            }
            const qty = Number(qtyEl?.value || 0);
            if (afterEl) afterEl.innerText = stock + Math.max(0, qty);
        }

        function grnUpdateAfterStock() {
            const sel = document.getElementById('grnItemSelect');
            const opt = sel && sel.options[sel.selectedIndex];
            const stock = opt ? Number(opt.dataset.stock || 0) : 0;
            const qty = Number(document.getElementById('grnQty')?.value || 0);
            const afterEl = document.getElementById('grnAfterStock');
            if (afterEl) afterEl.innerText = stock + Math.max(0, qty);
        }

        function grnAddItem() {
            const sku = document.getElementById('grnItemSelect').value;
            const qty = parseInt(document.getElementById('grnQty').value);
            const cost = parseFloat(document.getElementById('grnCost').value);

            if(!sku || qty <= 0 || isNaN(cost)) { showToast("Sila masukkan kuantiti & kos yang sah.", "error"); return; }

            const itemDef = grnItemsCache.find(i => i.sku === sku);
            if(!itemDef) return;

            const existing = grnCart.find(i => i.sku === sku);
            if(existing) {
                existing.qty += qty;
                existing.cost = cost; // update to latest cost
            } else {
                grnCart.push({ sku: sku, name: itemDef.name, qty: qty, cost: cost });
            }
            
            document.getElementById('grnQty').value = "1";
            document.getElementById('grnCost').value = "";
            renderGrnCart();
        }

        function grnRemoveItem(sku) {
            grnCart = grnCart.filter(i => i.sku !== sku);
            renderGrnCart();
        }

        function renderGrnCart() {
            const tbody = document.querySelector('#tblGrnCart tbody');
            if(grnCart.length === 0) {
                tbody.innerHTML = '<tr id="grnEmptyRow"><td colspan="5" class="text-center p-4 text-gray-500">Sila tambah item.</td></tr>';
                document.getElementById('grnTotalDisplay').innerText = "RM 0.00";
                return;
            }

            let html = '';
            let total = 0;
            grnCart.forEach(i => {
                const rowT = i.qty * i.cost;
                total += rowT;
                html += `
                    <tr>
                        <td class="p-3 text-sm text-white font-bold"><span class="text-amber-500 font-mono text-xs mr-2">${i.sku}</span> ${i.name}</td>
                        <td class="p-3 text-center font-mono">${i.qty}</td>
                        <td class="p-3 text-right font-mono">${i.cost.toFixed(2)}</td>
                        <td class="p-3 text-right font-mono font-bold">${rowT.toFixed(2)}</td>
                        <td class="p-3 text-center"><button onclick="grnRemoveItem('${i.sku}')" class="text-red-400 hover:text-red-300"><i data-feather="trash-2" class="w-4 h-4 mx-auto"></i></button></td>
                    </tr>
                `;
            });
            tbody.innerHTML = html;
            document.getElementById('grnTotalDisplay').innerText = formatMoney(total);
            feather.replace();
        }

        async function grnSubmitProcess() {
            const sSel = document.getElementById('grnSupplierSelect');
            if(sSel.selectedIndex <= 0) { showToast("Pilih pembekal dahulu.", "error"); return; }
            if(grnCart.length === 0) { showToast("Senarai barang kosong.", "error"); return; }

            const btn = document.getElementById('btnSubmitGrn');
            const origHtml = btn.innerHTML;
            btn.innerHTML = "Memproses...";
            btn.disabled = true;

            const grnNo = "GRN" + new Date().getTime().toString().slice(-8);
            const supName = sSel.options[sSel.selectedIndex].getAttribute('data-name');
            const ref = document.getElementById('grnRef').value.trim();

            let total = 0;
            grnCart.forEach(i => total += (i.qty * i.cost));

            try {
                // TRANSAKSI GRN
                await db.runTransaction(async (transaction) => {
                    // 1. Baca stok
                    const docRefs = [];
                    for (let item of grnCart) {
                        const r = await resolveInventoryRefBySku(item.sku);
                        const d = await transaction.get(r);
                        if (!d.exists) throw new Error(`SKU ${item.sku} tidak wujud.`);
                        docRefs.push({ ref: r, doc: d, item: item });
                    }

                    // 2. Tulis stok baru dan ledger
                    docRefs.forEach(({ref, doc, item}) => {
                        const currentStock = doc.data().stock || 0;
                        const newStock = currentStock + item.qty;
                        
                        transaction.update(ref, { 
                            stock: newStock,
                            costPrice: item.cost // update cost based on latest
                        });

                        const ledgerRef = db.collection('stock_ledger').doc();
                        transaction.set(ledgerRef, {
                            sku: item.sku,
                            itemName: item.name,
                            activity: 'PURCHASE',
                            quantity: item.qty,
                            beforeStock: currentStock,
                            afterStock: newStock,
                            referenceType: 'GRN',
                            referenceId: grnNo,
                            staffId: currentProfile.staffId,
                            staffName: currentProfile.name,
                            timestamp: new Date().toISOString()
                        });
                    });

                    // 3. Simpan Rekod GRN
                    const grnRef = db.collection('grn').doc(grnNo);
                    transaction.set(grnRef, {
                        grnNo: grnNo,
                        supplierId: sSel.value,
                        supplierName: supName,
                        reference: ref,
                        items: grnCart,
                        total: total,
                        status: 'RECEIVED',
                        createdAt: new Date().toISOString(),
                        createdBy: currentProfile.staffId
                    });
                });

                showToast(`Berjaya! Stok dikemaskini (No: ${grnNo})`);
                await logAudit('CREATE_GRN', `Processed GRN ${grnNo} from ${supName}`);
                
                closeModal('grnModal');
                grnCart = [];
                renderGrnCart();
                document.getElementById('grnRef').value = "";
                loadGRN();

            } catch (e) {
                showToast(`Gagal: ${e.message}`, 'error');
            } finally {
                btn.innerHTML = origHtml;
                btn.disabled = false;
            }
        }

        // --- 9. ACCOUNTING, EXPENSES & REMINDERS --- 

        async function saveExpense(e) {
            e.preventDefault();
            const btnId = 'btnSaveExp';
            setOriginalText(btnId);
            toggleLoading(btnId, true);
            try {
                await db.collection("expenses").add({
                    category: document.getElementById('expCategory').value,
                    description: document.getElementById('expDesc').value.trim(),
                    amount: parseFloat(document.getElementById('expAmount').value),
                    createdAt: new Date().toISOString(),
                    createdBy: currentProfile.staffId
                });
                showToast("Perbelanjaan direkodkan.");
                closeModal('expenseModal');
                document.getElementById('expDesc').value = '';
                document.getElementById('expAmount').value = '';
                loadAccounting();
            } catch(e) { showToast(e.message, 'error'); }
            finally { toggleLoading(btnId, false); }
        }

        async function loadReminders() {
            const tbody = document.querySelector('#tblReminders tbody');
            tbody.innerHTML = '<tr><td colspan="5" class="text-center p-4">Loading...</td></tr>';
            try {
                // Populate customers for modal
                const cSel = document.getElementById('remCustomerSelect');
                const cSnap = await db.collection("customers").get();
                cSel.innerHTML = '<option value="">-- Pilih --</option>';
                cSnap.forEach(doc => {
                    const c = doc.data();
                    cSel.innerHTML += `<option value="${c.customerId}" data-name="${c.name.replace(/'/g, "\\'")}">${c.name}</option>`;
                });

                const snap = await db.collection("service_reminders").orderBy("serviceDate").get();
                let rows = '';
                const today = new Date();
                today.setHours(0,0,0,0);

                snap.forEach(doc => {
                    const d = doc.data();
                    const sDate = new Date(d.serviceDate);
                    let status = "AKAN DATANG";
                    let color = "text-green-400";
                    if(sDate < today) { status = "TERLEPAS (OVERDUE)"; color = "text-red-400"; }
                    else if((sDate - today)/(1000*60*60*24) <= 7) { status = "HAMPIR (DUE SOON)"; color = "text-amber-400"; }
                    
                    rows += `
                        <tr class="hover:bg-gray-800/50">
                            <td class="p-4 font-bold text-white">${d.customerName} <br><span class="text-xs font-mono text-amber-500">${d.plateNo}</span></td>
                            <td class="p-4 text-sm">${d.serviceType}</td>
                            <td class="p-4 font-mono">${sDate.toLocaleDateString('ms-MY')}</td>
                            <td class="p-4 text-xs font-bold ${color}">${status}</td>
                            <td class="p-4 text-right">-</td>
                        </tr>
                    `;
                });
                tbody.innerHTML = rows || '<tr><td colspan="5" class="text-center p-4 text-gray-500">Tiada peringatan</td></tr>';
            } catch(e) { tbody.innerHTML = `<tr><td colspan="5" class="text-center p-4 text-red-500">Ralat: ${e.message}</td></tr>`; }
        }

        async function saveReminder(e) {
            e.preventDefault();
            const btnId = 'btnSaveRem';
            setOriginalText(btnId);
            toggleLoading(btnId, true);
            try {
                const cSel = document.getElementById('remCustomerSelect');
                const customerId = cSel?.value;
                const plate = document.getElementById('remPlate').value.trim().toUpperCase();
                const serviceType = document.getElementById('remType').value.trim();
                const dueDate = document.getElementById('remDate').value;
                if(!customerId || !plate || !dueDate) throw new Error('Pelanggan, nombor plat dan tarikh servis diperlukan.');
                const vr = await window.supabaseClient.from('vehicles').select('id').eq('company_id', currentProfile.companyId).eq('customer_id',customerId).eq('plate_no',plate).limit(1).maybeSingle();
                if(vr.error) throw vr.error;
                if(!vr.data) throw new Error('Kenderaan dengan plat '+plate+' tidak dijumpai untuk pelanggan ini.');
                const ins = await window.supabaseClient.from('service_reminders').insert({
                    company_id: currentProfile.companyId,
                    customer_id: customerId,
                    vehicle_id: vr.data.id,
                    due_date: dueDate,
                    reminder_type: serviceType || 'SERVICE',
                    status:'PENDING',
                    created_at:new Date().toISOString(),
                    updated_at:new Date().toISOString()
                });
                if(ins.error) throw ins.error;
                showToast('Peringatan disimpan.');
                closeModal('reminderModal');
                loadReminders();
            } catch(e) { showToast(e.message, 'error'); }
            finally { toggleLoading(btnId, false); }
        }

        