
/* REV TORQ — CASHIER OPENING + DAILY SALES CLOSE
   Uses existing Supabase cash drawer/RPC infrastructure.
*/
(function(){
  'use strict';
  const sb=window.supabaseClient;
  if(!sb)return;
  const $=id=>document.getElementById(id);
  const money=v=>'RM '+Number(v||0).toLocaleString('ms-MY',{minimumFractionDigits:2,maximumFractionDigits:2});
  const toast=(m,t='success')=>{try{window.showToast?.(m,t)}catch(_){alert(m)}};
  const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));

  async function getCtx(){
    const p=window.currentProfile||{};
    let staff=null;
    if(p.uid){
      const r=await sb.from('staff').select('id,company_id,location_id,staff_code,name').eq('auth_user_id',p.uid).eq('active',true).limit(1).maybeSingle();
      if(r.error)throw r.error; staff=r.data;
    }
    if(!staff && p.staffId){
      const r=await sb.from('staff').select('id,company_id,location_id,staff_code,name').eq('staff_code',String(p.staffId).toUpperCase()).eq('active',true).limit(1).maybeSingle();
      if(r.error)throw r.error; staff=r.data;
    }
    if(!staff)throw new Error('Staff aktif tidak dijumpai.');
    return staff;
  }

  function dayBounds(){
    const n=new Date();
    const start=new Date(n.getFullYear(),n.getMonth(),n.getDate());
    const end=new Date(n.getFullYear(),n.getMonth(),n.getDate()+1);
    return {start,end};
  }

  async function invoicesToday(companyId){
    const {start,end}=dayBounds();
    let q=sb.from('invoices').select('id,invoice_no,total,status,created_at').eq('company_id',companyId)
      .gte('created_at',start.toISOString()).lt('created_at',end.toISOString());
    const r=await q;
    if(r.error)throw r.error;
    return (r.data||[]).filter(x=>String(x.status||'PAID').toUpperCase()!=='VOID');
  }

  async function paymentsToday(companyId){
    const {start,end}=dayBounds();
    const r=await sb.from('payments').select('payment_method,amount,created_at').eq('company_id',companyId)
      .gte('created_at',start.toISOString()).lt('created_at',end.toISOString());
    if(r.error)throw r.error;
    const map={CASH:0,QR:0,CARD:0,TRANSFER:0};
    (r.data||[]).forEach(x=>{
      const k=String(x.payment_method||'CASH').toUpperCase();
      const key=k.includes('QR')?'QR':k.includes('CARD')||k.includes('KAD')?'CARD':k.includes('TRANSFER')?'TRANSFER':'CASH';
      map[key]+=Number(x.amount||0);
    });
    return map;
  }

  async function cashMovesToday(companyId,drawerId){
    const {start,end}=dayBounds();
    const r=await sb.from('cash_movements').select('movement_type,amount,created_at').eq('company_id',companyId)
      .eq('cash_drawer_id',drawerId).gte('created_at',start.toISOString()).lt('created_at',end.toISOString());
    if(r.error)throw r.error;
    let cashIn=0,cashOut=0;
    (r.data||[]).forEach(x=>{
      const t=String(x.movement_type||'').toUpperCase();
      if(t==='CASH_IN'||t==='OPENING')cashIn+=Number(x.amount||0);
      if(t==='CASH_OUT')cashOut+=Number(x.amount||0);
    });
    return {cashIn,cashOut};
  }

  async function openDailyBook(){
    let m=$('rtDailyBookModal');
    if(!m){
      m=document.createElement('div');
      m.id='rtDailyBookModal';
      m.className='fixed inset-0 z-[1200] hidden items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4';
      m.innerHTML=`<div class="w-full max-w-2xl max-h-[90vh] overflow-auto rounded-3xl bg-white shadow-2xl">
        <div class="p-6 border-b flex justify-between items-start">
          <div><div class="text-[10px] font-black tracking-[.18em] text-indigo-600">POS / CASHIER</div>
          <h3 class="text-2xl font-black text-slate-900">Tutup Buku Jualan Harian</h3>
          <p id="rtDailyBookDate" class="text-xs text-slate-500 mt-1"></p></div>
          <button id="rtDailyBookX" class="w-10 h-10 rounded-xl bg-slate-100 font-black">×</button>
        </div>
        <div id="rtDailyBookBody" class="p-6"><div class="py-10 text-center text-slate-400 font-bold">Mengira jualan...</div></div>
        <div class="p-4 border-t bg-slate-50 flex gap-3">
          <button id="rtDailyBookCancel" class="flex-1 py-3 rounded-xl border border-slate-300 bg-white font-black">BATAL</button>
          <button id="rtDailyBookClose" class="flex-1 py-3 rounded-xl bg-slate-900 text-white font-black">TUTUP BUKU & KIRA TUNAI</button>
        </div>
      </div>`;
      document.body.appendChild(m);
      const close=()=>{m.classList.add('hidden');m.classList.remove('flex')};
      $('rtDailyBookX').onclick=close;$('rtDailyBookCancel').onclick=close;
      $('rtDailyBookClose').onclick=async()=>{
        try{
          const d=await window.rtGetCashDrawer?.(true);
          if(!d){toast('Peti cashier belum dibuka. Buka Modal Permulaan dahulu.','error');return;}
          if(typeof window.rtCloseCashDrawer==='function'){
            close();
            window.rtCloseCashDrawer();
          }else{
            toast('Fungsi tutup cash drawer belum tersedia.','error');
          }
        }catch(e){toast('Tutup buku gagal | '+(e.message||e),'error')}
      };
    }
    m.classList.remove('hidden');m.classList.add('flex');
    $('rtDailyBookDate').textContent=new Date().toLocaleDateString('ms-MY',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
    $('rtDailyBookBody').innerHTML='<div class="py-10 text-center text-slate-400 font-bold">Mengira jualan...</div>';
    try{
      const c=await getCtx();
      const inv=await invoicesToday(c.company_id);
      const pay=await paymentsToday(c.company_id);
      const d=await window.rtGetCashDrawer?.(true);
      const moves=d?await cashMovesToday(c.company_id,d.id):{cashIn:0,cashOut:0};
      const total=inv.reduce((s,x)=>s+Number(x.total||0),0);
      const opening=Number(d?.opening_float||0);
      const expected=Number(d?.expected_amount||0);
      $('rtDailyBookBody').innerHTML=`
        <div class="grid grid-cols-2 gap-3 mb-4">
          <div class="rounded-2xl bg-slate-50 p-4"><div class="text-[10px] font-black text-slate-500 uppercase">Transaksi</div><div class="text-2xl font-black mt-1">${inv.length}</div></div>
          <div class="rounded-2xl bg-emerald-50 p-4"><div class="text-[10px] font-black text-emerald-700 uppercase">Jualan Hari Ini</div><div class="text-2xl font-black text-emerald-700 mt-1">${money(total)}</div></div>
        </div>
        <div class="rounded-2xl border border-slate-200 overflow-hidden">
          <div class="px-4 py-3 bg-slate-50 font-black text-sm">Pecahan Bayaran</div>
          ${[['CASH','Tunai'],['QR','QR / DuitNow'],['CARD','Kad'],['TRANSFER','Transfer']].map(([k,l])=>`<div class="flex justify-between px-4 py-3 border-t text-sm"><span>${l}</span><b>${money(pay[k])}</b></div>`).join('')}
        </div>
        <div class="mt-4 rounded-2xl border border-slate-200 overflow-hidden">
          <div class="px-4 py-3 bg-slate-50 font-black text-sm">Cashier</div>
          <div class="flex justify-between px-4 py-3 border-t text-sm"><span>Modal permulaan</span><b>${money(opening)}</b></div>
          <div class="flex justify-between px-4 py-3 border-t text-sm"><span>Cash In</span><b>${money(moves.cashIn)}</b></div>
          <div class="flex justify-between px-4 py-3 border-t text-sm"><span>Cash Out</span><b>${money(moves.cashOut)}</b></div>
          <div class="flex justify-between px-4 py-3 border-t text-sm"><span>Jangkaan dalam peti</span><b>${money(expected)}</b></div>
        </div>
        <div class="mt-4 rounded-xl bg-amber-50 border border-amber-200 p-3 text-xs text-amber-800 font-bold">
          Selepas tekan <b>TUTUP BUKU</b>, cashier perlu kira duit fizikal dan masukkan jumlah sebenar. Sistem akan rekod beza Lebih/Kurang.
        </div>`;
    }catch(e){
      $('rtDailyBookBody').innerHTML=`<div class="p-4 rounded-xl bg-rose-50 text-rose-700 font-bold text-sm">Ralat: ${esc(e.message||e)}</div>`;
    }
  }

  function installDailyBook(){
    const panel=$('rtCashDrawerPanel');
    if(!panel||panel.dataset.dailyBook==='1')return;
    panel.dataset.dailyBook='1';
    const b=document.createElement('button');
    b.type='button'; b.id='rtDailyBookBtn';
    b.textContent='TUTUP BUKU HARIAN';
    b.style.cssText='padding:9px 12px;border-radius:10px;font-weight:900;background:#0f172a;color:#fff;border:0';
    b.onclick=openDailyBook;
    panel.appendChild(b);

    // Make the opening action unmistakable for the cashier.
    const openBtn=$('rtOpenCashDrawerBtn');
    if(openBtn) openBtn.textContent='MODAL PERMULAAN';
  }

  window.rtOpenDailyBook=openDailyBook;
  window.addEventListener('load',()=>setTimeout(installDailyBook,1200));
  const observer=new MutationObserver(()=>installDailyBook());
  observer.observe(document.body,{childList:true,subtree:true});
})();
