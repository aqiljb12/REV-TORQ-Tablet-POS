// ================= BACKEND / ADMIN CONTROL CENTER — V38.6.5 =================
// Consolidated admin hub for Job Cards, POS Transactions and Inventory.
// Read-only summary counts only. All actions (edit job card, void invoice,
// adjust stock) reuse existing functions/RPCs — nothing is duplicated here.
(function(){
'use strict';
const sb = () => window.supabaseClient || window.sb;
const profile = () => window.currentProfile || window.currentUserProfile || null;
const companyId = () => profile()?.companyId || null;

function applyCompany(q){
    const c = companyId();
    return c ? q.eq('company_id', c) : q;
}

function money(n){ return 'RM ' + Number(n||0).toFixed(2); }

function todayRangeIso(){
    const start = new Date(); start.setHours(0,0,0,0);
    const end = new Date(); end.setHours(23,59,59,999);
    return { start: start.toISOString(), end: end.toISOString() };
}

async function refreshJobCardCount(){
    const el = document.getElementById('rtBackendJobCount');
    if(!el || !sb()) return;
    try{
        let q = applyCompany(sb().from('job_cards').select('id', { count: 'exact', head: true }));
        q = q.not('status', 'in', '("COMPLETED","CANCELLED")');
        const r = await q;
        if(r.error) throw r.error;
        el.textContent = r.count ?? 0;
    }catch(e){ console.warn('Backend: job card count', e.message); el.textContent = '—'; }
}

async function refreshPosToday(){
    const totalEl = document.getElementById('rtBackendPosTodayTotal');
    const countEl = document.getElementById('rtBackendPosTodayCount');
    if(!totalEl || !sb()) return;
    try{
        const { start, end } = todayRangeIso();
        let q = applyCompany(sb().from('invoices').select('total,status').gte('created_at', start).lte('created_at', end));
        const r = await q;
        if(r.error) throw r.error;
        const rows = (r.data||[]).filter(x => String(x.status||'').toUpperCase() !== 'VOID');
        const total = rows.reduce((s,x)=>s+Number(x.total||0),0);
        totalEl.textContent = money(total);
        if(countEl) countEl.textContent = String(rows.length);
    }catch(e){ console.warn('Backend: pos today', e.message); totalEl.textContent = '—'; }
}

async function refreshLowStock(){
    const el = document.getElementById('rtBackendLowStockCount');
    if(!el || !sb()) return;
    try{
        // Stock quantity lives in stock_balances (per product+location), not on
        // products itself — mirrors js/supabase-bridge.js getStock(). We pull
        // min_stock from products and join balances by product_id in JS to
        // avoid depending on a DB view that may not exist.
        const prodQ = await applyCompany(sb().from('products').select('id,min_stock').eq('active', true));
        if(prodQ.error) throw prodQ.error;
        const products = prodQ.data || [];
        if(!products.length){ el.textContent = '0'; return; }
        const ids = products.map(p=>p.id);
        const balQ = await sb().from('stock_balances').select('product_id,quantity').in('product_id', ids);
        if(balQ.error) throw balQ.error;
        const stockByProduct = new Map();
        (balQ.data||[]).forEach(row=>{
            stockByProduct.set(row.product_id, (stockByProduct.get(row.product_id)||0) + Number(row.quantity||0));
        });
        const low = products.filter(p => (stockByProduct.get(p.id)||0) <= Number(p.min_stock||0)).length;
        el.textContent = low;
    }catch(e){ console.warn('Backend: low stock', e.message); el.textContent = '—'; }
}

async function loadBackendCenter(){
    // Fire independently so one failing query doesn't block the others.
    refreshJobCardCount();
    refreshPosToday();
    refreshLowStock();
    if (typeof feather !== 'undefined') feather.replace();
}

window.loadBackendCenter = loadBackendCenter;
})();
