// ================= JOB CARDS — V36.1 HARDENED =================
(function(){
'use strict';
const sb = window.supabaseClient;
const clean = v => String(v ?? '').trim();
const escJC = v => String(v ?? '').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const moneyJC = n => 'RM ' + Number(n||0).toFixed(2);
const profileJC = () => window.currentProfile || window.currentUserProfile || null;
const companyJC = () => profileJC()?.companyId || null;

async function retry(fn, tries=3){
    let last;
    for(let i=0;i<tries;i++){
        try{return await fn();}
        catch(e){
            last=e;
            if(i<tries-1) await new Promise(r=>setTimeout(r,400*(i+1)));
        }
    }
    throw last;
}

function applyCompany(q){
    const c=companyJC();
    return c ? q.eq('company_id',c) : q;
}

async function queryRows(table, build){
    return retry(async()=>{
        let q=sb.from(table).select('*');
        q=applyCompany(q);
        q=build(q);
        const r=await q;
        if(r.error) throw r.error;
        return r.data||[];
    });
}

async function getJobRows(){
    const jobs=await queryRows('job_cards',q=>q.order('created_at',{ascending:false}));
    if(!jobs.length)return jobs;
    // Paid jobs remain in the database for audit/history, but must disappear from the active Job Card list.
    const c=companyJC();
    let iq=sb.from('invoices').select('job_card_id').eq('payment_status','PAID').eq('status','PAID').not('job_card_id','is',null);
    if(c)iq=iq.eq('company_id',c);
    const ir=await iq;
    if(ir.error){console.warn('REV TORQ paid-job filter',ir.error);return jobs;}
    const paid=new Set((ir.data||[]).map(x=>x.job_card_id).filter(Boolean));
    return jobs.filter(j=>!paid.has(j.id));
}

async function getCustomers(){
    return queryRows('customers',q=>q.order('name',{ascending:true}));
}

async function getStaff(){
    return queryRows('staff',q=>q.eq('active',true));
}

// Job Card inventory picker — never require manual part names.
let jcPartsItems = [];
window.jcPartsItems = jcPartsItems;

function moneyParts(n){ return 'RM ' + Number(n||0).toFixed(2); }
function jcPartEsc(v){ return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m])); }

async function loadJCPartsInventory(){
    const grid=document.getElementById('jcPartsStockGrid'); if(!grid)return;
    grid.innerHTML='<div class="text-xs text-slate-500 p-3">Memuatkan inventory...</div>';
    try{
        const loc=profileJC()?.locationId||null;
        const rows=await retry(async()=>{
            let q=sb.from('products').select('id,sku,name,category,sell_price,cost_price,barcode').eq('active',true);
            q=applyCompany(q); q=q.order('name',{ascending:true});
            const r=await q; if(r.error)throw r.error; return r.data||[];
        });
        let balances=[];
        try{
            let q=sb.from('stock_balances').select('product_id,quantity,location_id');
            if(loc) q=q.eq('location_id',loc);
            const r=await q; if(!r.error)balances=r.data||[];
        }catch(_){}
        const byProduct=new Map();
        balances.forEach(x=>byProduct.set(x.product_id,(byProduct.get(x.product_id)||0)+Number(x.quantity||0)));
        window.jcStockProducts=rows.map(p=>({
            id:p.id,sku:p.sku||p.id,name:p.name||p.sku||'',category:p.category||'',barcode:p.barcode||'',
            stock:Math.max(0,byProduct.get(p.id)||0),price:Number(p.sell_price||0),cost:Number(p.cost_price||0)
        }));
        renderJCPartsStock(window.jcStockProducts);
    }catch(e){ grid.innerHTML='<div class="text-xs text-red-500 p-3">Inventory gagal dimuatkan: '+jcPartEsc(e.message||e)+'</div>'; }
}

function renderJCPartsStock(items){
    const grid=document.getElementById('jcPartsStockGrid'); if(!grid)return;
    if(!items.length){grid.innerHTML='<div class="text-xs text-slate-500 p-3">Tiada barang aktif dalam Inventory.</div>';return;}
    grid.innerHTML=items.slice(0,80).map(p=>`<button type="button" data-sku="${jcPartEsc(p.sku)}" onclick="addJCPart(this.dataset.sku)" class="text-left p-3 rounded-xl border border-slate-200 bg-slate-50 hover:border-indigo-400 hover:bg-indigo-50 ${p.stock<=0?'opacity-50':''}"><div class="text-[9px] text-slate-400 font-mono">${jcPartEsc(p.sku)}</div><div class="text-xs font-bold text-slate-800 truncate">${jcPartEsc(p.name)}</div><div class="flex justify-between mt-1 text-[10px]"><span class="${p.stock<=0?'text-red-500':'text-emerald-600'} font-bold">Stok ${p.stock}</span><span class="text-indigo-700 font-mono font-bold">${moneyParts(p.price)}</span></div></button>`).join('');
}
function filterJCPartsStock(q){ const x=String(q||'').toLowerCase(); renderJCPartsStock((window.jcStockProducts||[]).filter(p=>(p.name+' '+p.sku+' '+p.category+' '+p.barcode).toLowerCase().includes(x))); }
function renderJCParts(){
    const el=document.getElementById('jcPartsItems'); if(!el)return;
    el.innerHTML=jcPartsItems.length?jcPartsItems.map(x=>`<div class="flex items-center justify-between bg-white rounded-xl p-3 text-xs border border-slate-200"><div><b class="text-slate-800">${jcPartEsc(x.name)}</b><span class="text-slate-400 ml-2 font-mono">${jcPartEsc(x.sku)} × ${x.qty}</span></div><div class="flex items-center gap-3"><span class="text-indigo-700 font-mono font-bold">${moneyParts(x.price*x.qty)}</span><button type="button" data-sku="${jcPartEsc(x.sku)}" onclick="removeJCPart(this.dataset.sku)" class="text-red-500 font-bold text-lg">×</button></div></div>`).join(''):'<div class="text-[10px] text-slate-400">Belum ada barang dipilih.</div>';
    const total=jcPartsItems.reduce((s,x)=>s+Number(x.price||0)*Number(x.qty||0),0);
    const cost=document.getElementById('jcEstParts'); if(cost)cost.textContent=moneyParts(total);
    calcJCTotal();
}
function addJCPart(sku){
    const p=(window.jcStockProducts||[]).find(x=>String(x.sku)===String(sku)); if(!p)return;
    if(p.stock<=0){showToast('Stok barang ini habis.','error');return;}
    const ex=jcPartsItems.find(x=>x.sku===p.sku);
    if(ex){if(ex.qty>=p.stock){showToast('Melebihi stok semasa.','error');return;} ex.qty++;}
    else jcPartsItems.push({id:p.id,sku:p.sku,name:p.name,qty:1,price:p.price,cost:p.cost});
    window.jcPartsItems=jcPartsItems; renderJCParts();
}
function removeJCPart(sku){ jcPartsItems=jcPartsItems.filter(x=>x.sku!==String(sku)); window.jcPartsItems=jcPartsItems; renderJCParts(); }
window.filterJCPartsStock=filterJCPartsStock; window.addJCPart=addJCPart; window.removeJCPart=removeJCPart; window.loadJCPartsInventory=loadJCPartsInventory;

async function getVehicles(customerId){
    return queryRows('vehicles',q=>q.eq('customer_id',customerId).eq('active',true).order('plate_no',{ascending:true}));
}

function setJobCardError(message){
    const tbody=document.querySelector('#tblJobCards tbody');
    if(tbody) tbody.innerHTML=`<tr><td colspan="8" class="text-center p-4 text-red-500">Ralat: ${escJC(message)}</td></tr>`;
}

function normalizeJob(row, customerMap, vehicleMap, staffMap){
    const c=customerMap.get(row.customer_id)||{};
    const v=vehicleMap.get(row.vehicle_id)||{};
    const s=staffMap.get(row.assigned_staff_id)||{};
    return {
        ...row,
        id:row.id,
        jobNo:row.job_no,
        customerId:row.customer_id,
        vehicleId:row.vehicle_id,
        assignedStaffId:row.assigned_staff_id,
        assignedStaffUid:row.assigned_staff_id,
        customerName:c.name||row.customer_name||'-',
        plateNo:v.plate_no||row.plate_no||'-',
        vehicleModel:[v.brand,v.model].filter(Boolean).join(' ')||row.vehicle_model||'-',
        assignedStaffName:s.name||s.staff_code||'-',
        createdAt:row.created_at,
        updatedAt:row.updated_at,
        status:row.status||'OPEN',
        total:Number(row.actual_total??row.estimated_total??0),
        partsCost:Number(row.parts_cost??0),
        laborCost:Number(row.labor_cost??0)
    };
}

async function loadJobCards(){
    const tbody=document.querySelector('#tblJobCards tbody');
    if(!tbody)return;
    tbody.innerHTML='<tr><td colspan="8" class="text-center p-4">Loading...</td></tr>';
    try{
        const jobs=await getJobRows();
        const customerIds=[...new Set(jobs.map(x=>x.customer_id).filter(Boolean))];
        const vehicleIds=[...new Set(jobs.map(x=>x.vehicle_id).filter(Boolean))];
        const staffIds=[...new Set(jobs.map(x=>x.assigned_staff_id).filter(Boolean))];

        // Enrichment is best-effort. A broken optional lookup must NOT blank the whole Job Card page.
        const [customers,vehicles,staff]=await Promise.all([
            customerIds.length ? retry(async()=>{let q=applyCompany(sb.from('customers').select('id,name,phone,customer_code'));q=q.in('id',customerIds);const r=await q;if(r.error)throw r.error;return r.data||[];}).catch(()=>[]) : [],
            vehicleIds.length ? retry(async()=>{let q=applyCompany(sb.from('vehicles').select('id,customer_id,plate_no,brand,model'));q=q.in('id',vehicleIds);const r=await q;if(r.error)throw r.error;return r.data||[];}).catch(()=>[]) : [],
            staffIds.length ? retry(async()=>{let q=applyCompany(sb.from('staff').select('id,staff_code,name,role,active'));q=q.in('id',staffIds);const r=await q;if(r.error)throw r.error;return r.data||[];}).catch(()=>[]) : []
        ]);
        const cm=new Map(customers.map(x=>[x.id,x]));
        const vm=new Map(vehicles.map(x=>[x.id,x]));
        const sm=new Map(staff.map(x=>[x.id,x]));
        const rows=jobs.map(x=>normalizeJob(x,cm,vm,sm));

        tbody.innerHTML=rows.map(d=>{
            let color='text-slate-700';
            if(d.status==='COMPLETED'||d.status==='CLOSED')color='text-green-600';
            if(d.status==='CANCELLED')color='text-red-600';
            if(d.status==='WAITING_PARTS')color='text-amber-600';
            if(d.status==='IN_PROGRESS')color='text-blue-600';
            return `<tr class="hover:bg-slate-50">
                <td class="p-4 font-mono font-bold text-indigo-600">${escJC(d.jobNo)}</td>
                <td class="p-4 text-xs">${d.createdAt?new Date(d.createdAt).toLocaleDateString('ms-MY'):'-'}</td>
                <td class="p-4 font-bold text-slate-800">${escJC(d.customerName)}</td>
                <td class="p-4 font-mono"><span class="bg-slate-100 px-2 py-1 rounded border border-slate-200">${escJC(d.plateNo)}</span> <span class="text-xs text-slate-500 ml-1">${escJC(d.vehicleModel)}</span></td>
                <td class="p-4 text-xs">${escJC(d.assignedStaffName)}</td>
                <td class="p-4 font-bold text-xs ${color}">${escJC(d.status)}</td>
                <td class="p-4 font-mono text-right">${moneyJC(d.total)}</td>
                <td class="p-4 text-right"><button onclick="editJobCard('${escJC(d.jobNo)}')" class="text-blue-600 hover:text-blue-800 text-xs font-bold"><i data-feather="edit" class="w-4 h-4 inline"></i></button></td>
            </tr>`;
        }).join('') || '<tr><td colspan="8" class="text-center p-4 text-slate-500">Tiada Job Card</td></tr>';
        if(window.feather)feather.replace();
        if(typeof window.decorateJobRows==='function')window.decorateJobRows();
    }catch(e){
        console.error('REV TORQ loadJobCards',e);
        setJobCardError(e?.message||String(e));
        if(typeof showToast==='function')showToast('Job Card gagal dimuatkan: '+(e?.message||e),'error');
    }
}

async function populateJCSelects(){
    const cSelect=document.getElementById('jcCustomerSelect');
    const sSelect=document.getElementById('jcStaffSelect');
    if(!cSelect||!sSelect)return;
    cSelect.innerHTML='<option value="">Loading pelanggan...</option>';
    sSelect.innerHTML='<option value="">Loading pomen...</option>';
    try{
        const customers=await getCustomers();
        cSelect.innerHTML='<option value="">-- Pilih --</option>';
        customers.forEach(c=>{
            const o=document.createElement('option');
            o.value=c.id;
            o.dataset.name=c.name||'';
            o.textContent=`${c.name||'-'}${c.phone?' ('+c.phone+')':''}`;
            cSelect.appendChild(o);
        });
    }catch(e){
        cSelect.innerHTML='<option value="">-- Gagal muat pelanggan --</option>';
        throw new Error('Pelanggan gagal dimuatkan: '+(e?.message||e));
    }
    try{
        const staff=await getStaff();
        sSelect.innerHTML='<option value="">-- Tiada --</option>';
        staff.filter(s=>String(s.role||'').toLowerCase()==='pomen').forEach(s=>{
            const o=document.createElement('option');
            o.value=s.id;
            o.dataset.authUid=s.auth_user_id||'';
            o.dataset.name=s.name||s.staff_code||'';
            o.textContent=s.name||s.staff_code||'-';
            sSelect.appendChild(o);
        });
    }catch(e){
        sSelect.innerHTML='<option value="">-- Pomen tidak tersedia --</option>';
        // Staff assignment is optional; do not block opening a Job Card.
        console.warn('REV TORQ staff load',e);
    }
}

async function openNewJobCard(){
    document.getElementById('jcIsEdit').value='false';
    document.getElementById('jcIdField').value='';
    document.getElementById('jobCardModalTitle').innerText='Buka Job Card Baru';
    document.getElementById('jcComplaint').value='';
    document.getElementById('jcDiagnosis').value='';
    jcPartsItems=[]; window.jcPartsItems=jcPartsItems;
    renderJCParts();
    document.getElementById('jcEstLabor').value='0';
    document.getElementById('jcEstLabor').value='0';
    document.getElementById('jcStatusSelect').value='OPEN';
    renderInspectionChecklist('jcInspectionChecklist',{});
    calcJCTotal();
    await loadJCPartsInventory();
    try{await populateJCSelects();}catch(e){if(typeof showToast==='function')showToast(e.message,'error');return;}
    document.getElementById('jcVehicleSelect').innerHTML='<option value="">-- Pilih Pelanggan Dahulu --</option>';
    const staffSelect=document.getElementById('jcStaffSelect');
    staffSelect.dataset.lockedForPomen='';
    const p=profileJC();
    if(p && String(p.role).toLowerCase()==='pomen'){
        // currentProfile.staffId is usually staff_code; resolve it to the actual staff UUID.
        const opts=[...staffSelect.options];
        const target=opts.find(o=>o.textContent===p.name)||opts.find(o=>o.value===p.staffId);
        if(target)staffSelect.value=target.value;
        staffSelect.dataset.lockedForPomen='true';
        staffSelect.disabled=true;
    }else staffSelect.disabled=false;
    openModal('jobCardModal');
}

async function loadCustomerVehiclesForJC(customerId){
    const vSelect=document.getElementById('jcVehicleSelect');
    if(!customerId){vSelect.innerHTML='<option value="">-- Pilih Pelanggan Dahulu --</option>';vSelect.disabled=true;return;}
    vSelect.innerHTML='<option value="">Loading...</option>';vSelect.disabled=false;
    try{
        const rows=await getVehicles(customerId);
        vSelect.innerHTML='<option value="">-- Pilih Kenderaan --</option>';
        rows.forEach(v=>{
            const o=document.createElement('option');
            o.value=v.id;o.dataset.plate=v.plate_no||'';o.dataset.model=[v.brand,v.model].filter(Boolean).join(' ');
            o.textContent=`${v.plate_no||'-'} - ${[v.brand,v.model].filter(Boolean).join(' ')||'-'}`;
            vSelect.appendChild(o);
        });
        if(!rows.length)vSelect.innerHTML='<option value="">-- Tiada kenderaan berdaftar --</option>';
    }catch(e){
        vSelect.innerHTML='<option value="">-- Gagal muat kenderaan --</option>';
        if(typeof showToast==='function')showToast('Kenderaan gagal dimuatkan: '+(e?.message||e),'error');
    }
}

async function editJobCard(jobNo){
    document.getElementById('jcIsEdit').value='true';
    document.getElementById('jcIdField').value=jobNo;
    document.getElementById('jobCardModalTitle').innerText='Kemaskini Job Card';
    try{
        let q=applyCompany(sb.from('job_cards').select('*')).eq('job_no',jobNo).limit(1).maybeSingle();
        const r=await retry(async()=>{const x=await q;if(x.error)throw x.error;return x;});
        if(!r.data)throw new Error('Job Card '+jobNo+' tidak dijumpai.');
        const d=r.data;
        let itemRows=[];
        try{
            const ir=await retry(async()=>{let q=sb.from('job_card_items').select('id,product_id,item_type,description,quantity,unit_cost,unit_price').eq('company_id',companyJC()).eq('job_card_id',d.id).eq('item_type','PART').eq('status','ACTIVE');const z=await q;if(z.error)throw z.error;return z;});
            itemRows=ir.data||[];
        }catch(_){}
        await populateJCSelects();
        document.getElementById('jcCustomerSelect').value=d.customer_id||'';
        await loadCustomerVehiclesForJC(d.customer_id);
        document.getElementById('jcVehicleSelect').value=d.vehicle_id||'';
        document.getElementById('jcStaffSelect').value=d.assigned_staff_id||'';
        document.getElementById('jcStaffSelect').disabled=String(profileJC()?.role||'').toLowerCase()==='pomen';
        document.getElementById('jcStatusSelect').value=d.status||'OPEN';
        document.getElementById('jcComplaint').value=d.complaint||'';
        document.getElementById('jcDiagnosis').value=d.diagnosis||'';
        jcPartsItems=itemRows.map(x=>({id:x.product_id,sku:'',name:x.description||'',qty:Number(x.quantity||1),price:Number(x.unit_price||0),cost:Number(x.unit_cost||0)}));
        // Resolve SKU/name for display where possible.
        try{
            const ids=itemRows.map(x=>x.product_id).filter(Boolean);
            if(ids.length){const pr=await sb.from('products').select('id,sku,name,sell_price,cost_price').in('id',ids);if(!pr.error){const pm=new Map((pr.data||[]).map(x=>[x.id,x]));jcPartsItems=jcPartsItems.map(x=>{const p=pm.get(x.id)||{};return {...x,sku:p.sku||'',name:p.name||x.name,price:x.price||Number(p.sell_price||0),cost:x.cost||Number(p.cost_price||0)}})}}
        }catch(_){}
        window.jcPartsItems=jcPartsItems;
        renderInspectionChecklist('jcInspectionChecklist',d.inspection||d.inspection_checklist||{});
        document.getElementById('jcEstLabor').value=Number(d.labor_cost??d.laborCost??0);
        await loadJCPartsInventory();
        renderJCParts();
        openModal('jobCardModal');
    }catch(e){console.error(e);showToast('Job Card gagal dibuka: '+(e?.message||e),'error');}
}

function calcJCTotal(){
    const p=(jcPartsItems||[]).reduce((s,x)=>s+Number(x.price||0)*Number(x.qty||0),0);
    const l=parseFloat(document.getElementById('jcEstLabor').value)||0;
    const cost=document.getElementById('jcEstParts'); if(cost)cost.textContent=moneyJC(p);
    document.getElementById('jcEstTotalLabel').innerText=moneyJC(p+l);
}

async function saveJobCard(e){
    e.preventDefault();
    const btnId='btnSaveJobCard';setOriginalText(btnId);toggleLoading(btnId,true);
    try{
        const cSel=document.getElementById('jcCustomerSelect'),vSel=document.getElementById('jcVehicleSelect'),sSel=document.getElementById('jcStaffSelect');
        if(cSel.selectedIndex<=0||vSel.selectedIndex<=0)throw new Error('Sila pilih pelanggan & kenderaan.');
        const p=profileJC()||{};
        const parts=(jcPartsItems||[]).reduce((sum,x)=>sum+Number(x.price||0)*Number(x.qty||0),0);
        const labor=parseFloat(document.getElementById('jcEstLabor').value)||0;
        const payload={
            customerId:cSel.value,
            vehicleId:vSel.value,
            assignedStaffId:sSel.value||null,
            status:document.getElementById('jcStatusSelect').value,
            complaint:document.getElementById('jcComplaint').value.trim(),
            diagnosis:document.getElementById('jcDiagnosis').value.trim(),
            inspectionChecklist:collectInspectionChecklist('jcInspectionChecklist'),
            partsItems:jcPartsItems.map(x=>({id:x.id||null,sku:x.sku,name:x.name,qty:Number(x.qty||1),price:Number(x.price||0),cost:Number(x.cost||0)})),
            partsCost:parts,laborCost:labor,total:parts+labor,
            updatedAt:new Date().toISOString(),updatedBy:p.staffId||null
        };
        const isEdit=document.getElementById('jcIsEdit').value==='true';
        if(isEdit){
            await db.collection('job_cards').doc(document.getElementById('jcIdField').value).update(payload);
            showToast('Job Card berjaya dikemaskini.','success');
            await logAudit('UPDATE_JOB','Updated JobCard: '+document.getElementById('jcIdField').value);
        }else{
            const jobNo='JOB-'+new Date().toISOString().slice(0,10).replace(/-/g,'')+'-'+Date.now().toString().slice(-4);
            await db.collection('job_cards').doc(jobNo).set({...payload,jobNo,createdAt:new Date().toISOString(),createdBy:p.staffId||null});
            showToast('Job Card '+jobNo+' berjaya disimpan.','success');
            await logAudit('CREATE_JOB','Created JobCard: '+jobNo);
        }
        closeModal('jobCardModal');
        await loadJobCards();
    }catch(e){console.error('REV TORQ saveJobCard',e);showToast(e?.message||String(e),'error');}
    finally{toggleLoading(btnId,false);}
}

window.loadJobCards=loadJobCards;
window.populateJCSelects=populateJCSelects;
window.openNewJobCard=openNewJobCard;
window.editJobCard=editJobCard;
window.loadCustomerVehiclesForJC=loadCustomerVehiclesForJC;
window.calcJCTotal=calcJCTotal;
window.saveJobCard=saveJobCard;
})();
