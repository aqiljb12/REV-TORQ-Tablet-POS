// ================= INVENTORY =================
        function openNewInventory() {
            document.getElementById('invIsEdit').value = "false";
            document.getElementById('invSku').disabled = false;
            document.getElementById('invSku').value = "";
            document.getElementById('invBarcode').value = "";
            document.getElementById('invRackCode').value = "";
            document.getElementById('invName').value = "";
            document.getElementById('invCost').value = "";
            document.getElementById('invPrice').value = "";
            document.getElementById('invStockGroup').style.display = 'grid';
            document.getElementById('invStock').value = "0";
            document.getElementById('invStock').readOnly = false;
            document.getElementById('invMinStock').value = "5";
            document.getElementById('invModalTitle').innerText = "Tambah Inventori Baru";
            if (typeof window.openInventoryPage === 'function') window.openInventoryPage('Tambah Inventori Baru','Daftarkan item, barcode, harga dan stok permulaan.'); else if (typeof openModal === 'function') openModal('inventoryModal');
        }

        async function editInventory(sku) {
            document.getElementById('invIsEdit').value = "true";
            document.getElementById('invSku').value = sku;
            document.getElementById('invSku').disabled = true;
            document.getElementById('invStockGroup').style.display = 'none';
            document.getElementById('invStock').readOnly = true;
            document.getElementById('invModalTitle').innerText = "Kemaskini Inventori";
            try {
                const resolved = await resolveInventoryDocBySku(sku);
                if(resolved.snap.exists) {
                    const d = resolved.snap.data();
                    document.getElementById('invCat').value = d.category || 'SPAREPART';
                    document.getElementById('invName').value = d.name || '';
                    document.getElementById('invBarcode').value = d.barcode || d.barCode || '';
                    document.getElementById('invRackCode').value = d.rackCode || d.rack || '';
                    document.getElementById('invCost').value = d.costPrice ?? d.cost ?? 0;
                    document.getElementById('invPrice').value = d.sellPrice ?? d.price ?? 0;
                    document.getElementById('invMinStock').value = d.minStock ?? 5;
                    document.getElementById('invActive').value = d.active ? 'true' : 'false';
                    if (typeof window.openInventoryPage === 'function') window.openInventoryPage('Kemaskini Inventori','Semak dan kemaskini maklumat item inventori.'); else if (typeof openModal === 'function') openModal('inventoryModal');
                }
            } catch(e) { showToast(e.message, 'error'); }
        }

        async function loadInventory() {
            const tbody = document.querySelector('#tblInventory tbody');
            tbody.innerHTML = '<tr><td colspan="9" class="text-center p-4">Loading...</td></tr>';
            try {
                const snap = await db.collection("inventory").orderBy("sku").get();
                let rows = '';
                snap.forEach(doc => {
                    const d = doc.data();
                    const stock = Number(d.stock || 0);
                    const minStock = Number(d.minStock ?? 5);
                    let stockColor = stock <= minStock ? 'text-red-500 font-bold' : 'text-emerald-600 font-bold';
                    const barcode = d.barcode || d.barCode || '-';
                    const rack = d.rackCode || d.rack || '-';
                    rows += `
                        <tr class="hover:bg-slate-50">
                            <td class="p-4 font-mono font-bold text-indigo-700">${d.sku || doc.id}</td>
                            <td class="p-4 font-bold text-slate-800">${d.name || '-'}</td>
                            <td class="p-4 text-xs font-mono"><span class="bg-slate-100 px-2 py-1 rounded border border-slate-200">${d.category || '-'}</span></td>
                            <td class="p-4 font-mono text-xs text-slate-500">${barcode}</td>
                            <td class="p-4 font-mono text-xs font-bold text-indigo-600">${rack}</td>
                            <td class="p-4 font-mono text-right text-slate-500">${formatMoney(d.costPrice ?? d.cost ?? 0)}</td>
                            <td class="p-4 font-mono text-right font-bold text-slate-800">${formatMoney(d.sellPrice ?? d.price ?? 0)}</td>
                            <td class="p-4 font-mono text-center ${stockColor} text-lg">${stock}</td>
                            <td class="p-4 text-right space-x-1">
                                ${!d.active ? '<span class="text-xs bg-red-50 text-red-500 px-2 py-1 rounded mr-1 border border-red-100">TIDAK AKTIF</span>' : ''}
                                <button onclick="openStockAdjustment('${String(d.sku || doc.id).replace(/'/g, "\\'")}')" class="text-emerald-600 hover:text-emerald-700 text-[11px] font-black px-2 py-1 rounded-lg bg-emerald-50 border border-emerald-100">STOK</button>
                                <button onclick="editInventory('${String(d.sku || doc.id).replace(/'/g, "\\'")}')" class="text-indigo-600 hover:text-indigo-700 text-[11px] font-black px-2 py-1 rounded-lg bg-indigo-50 border border-indigo-100">EDIT</button>
                            </td>
                        </tr>`;
                });
                tbody.innerHTML = rows || '<tr><td colspan="9" class="text-center p-4 text-slate-400">Tiada item inventori</td></tr>';
                if(window.feather) feather.replace();
            } catch(e) { tbody.innerHTML = `<tr><td colspan="9" class="text-center p-4 text-red-500">Ralat: ${e.message}</td></tr>`; }
        }

        async function saveInventory(e) {
            e.preventDefault();
            const btnId = 'btnSaveInv';
            setOriginalText(btnId); toggleLoading(btnId, true);
            const isEdit = document.getElementById('invIsEdit').value === "true";
            const sku = document.getElementById('invSku').value.trim().toUpperCase();
            const barcode = document.getElementById('invBarcode').value.trim();
            const rackCode = document.getElementById('invRackCode').value.trim().toUpperCase();
            const name = document.getElementById('invName').value.trim();
            try {
                if(!sku || !name) throw new Error('SKU dan nama item diperlukan.');
                if(barcode) {
                    const bq = await db.collection('inventory').where('barcode','==',barcode).limit(2).get();
                    const duplicate = bq.docs.find(d => !isEdit || d.id !== sku);
                    if(duplicate) throw new Error(`Barcode ${barcode} sudah digunakan oleh ${duplicate.data().sku || duplicate.id}.`);
                }
                const payload = {
                    name,
                    category: document.getElementById('invCat').value,
                    barcode,
                    rackCode,
                    costPrice: parseFloat(document.getElementById('invCost').value) || 0,
                    sellPrice: parseFloat(document.getElementById('invPrice').value) || 0,
                    minStock: parseInt(document.getElementById('invMinStock').value) || 5,
                    active: document.getElementById('invActive').value === 'true',
                    updatedAt: new Date().toISOString()
                };
                if(isEdit) {
                    const invRef = await resolveInventoryRefBySku(sku);
                    await invRef.update(payload);
                    showToast(`Item ${sku} dikemaskini.`);
                    await logAudit('UPDATE_INVENTORY', `Updated item: ${sku}`);
                } else {
                    const ref = db.collection('inventory').doc(sku);
                    const existing = await ref.get();
                    if(existing.exists) throw new Error('SKU sudah wujud! Sila gunakan SKU lain.');
                    const initialStock = Math.max(0, parseInt(document.getElementById('invStock').value) || 0);
                    await ref.set({sku, ...payload, stock: initialStock, createdAt: new Date().toISOString(), createdBy: currentProfile.staffId});
                    if(initialStock > 0) await db.collection('stock_ledger').add({sku, itemName:name, activity:'OPENING_STOCK', quantity:initialStock, beforeStock:0, afterStock:initialStock, referenceType:'SETUP', referenceId:'INITIAL', staffId:currentProfile.staffId, staffName:currentProfile.name, timestamp:new Date().toISOString()});
                    showToast(`Item ${sku} disimpan.`);
                    await logAudit('CREATE_INVENTORY', `Added item: ${sku}`);
                }
                if (typeof window.closeInventoryPage === 'function') window.closeInventoryPage(); else closeModal('inventoryModal'); loadInventory();
                if(document.getElementById('view-pos') && !document.getElementById('view-pos').classList.contains('hidden') && typeof loadPOS === 'function') loadPOS();
            } catch(error) { showToast(error.message, 'error'); } finally { toggleLoading(btnId, false); }
        }

        // ================= STOCK ADJUSTMENT =================
        async function openStockAdjustment(sku) {
            try {
                const resolved = await resolveInventoryDocBySku(sku);
                if(!resolved.snap.exists) throw new Error('Item tidak ditemui.');
                const d = resolved.snap.data();
                document.getElementById('adjSku').value = d.sku || sku;
                document.getElementById('adjBarcode').value = d.barcode || d.barCode || '';
                document.getElementById('adjItemName').innerText = d.name || sku;
                document.getElementById('adjCurrentStock').innerText = Number(d.stock || 0);
                document.getElementById('adjQty').value = '';
                document.getElementById('adjMode').value = 'IN';
                updateStockAdjustmentPreview();
                openModal('stockAdjustmentModal');
            } catch(e) { showToast(e.message, 'error'); }
        }

        function updateStockAdjustmentPreview() {
            const cur = Number(document.getElementById('adjCurrentStock').innerText || 0);
            const qty = Math.max(0, Number(document.getElementById('adjQty').value || 0));
            const mode = document.getElementById('adjMode').value;
            let next = mode === 'SET' ? qty : (mode === 'OUT' ? cur - qty : cur + qty);
            document.getElementById('adjAfterStock').innerText = Math.max(0, next);
        }

        async function saveStockAdjustment(e) {
            e.preventDefault();
            const sku = document.getElementById('adjSku').value.trim().toUpperCase();
            const qty = Math.max(0, Number(document.getElementById('adjQty').value || 0));
            const mode = document.getElementById('adjMode').value;
            const note = document.getElementById('adjNote').value.trim();
            if(!sku || qty <= 0) { showToast('Masukkan kuantiti yang sah.', 'error'); return; }
            try {
                const ref = await resolveInventoryRefBySku(sku);
                await db.runTransaction(async tx => {
                    const snap = await tx.get(ref);
                    if(!snap.exists) throw new Error('Item tidak ditemui.');
                    const d = snap.data(); const before = Number(d.stock || 0);
                    let after = mode === 'SET' ? qty : (mode === 'OUT' ? before - qty : before + qty);
                    if(after < 0) throw new Error(`Stok tidak mencukupi. Stok semasa: ${before}.`);
                    const delta = after - before;
                    tx.update(ref, {stock: after, updatedAt: new Date().toISOString()});
                    const ledgerRef = db.collection('stock_ledger').doc();
                    tx.set(ledgerRef, {sku:d.sku || sku, itemName:d.name || '', activity: mode === 'IN' ? 'ADJUST_IN' : (mode === 'OUT' ? 'ADJUST_OUT' : 'ADJUST_SET'), quantity:delta, beforeStock:before, afterStock:after, referenceType:'STOCK_ADJUSTMENT', referenceId:ledgerRef.id, note, staffId:currentProfile.staffId, staffName:currentProfile.name, timestamp:new Date().toISOString()});
                });
                showToast(`Stok ${sku} dikemaskini.`);
                await logAudit('ADJUST_STOCK', `Adjusted ${sku}: ${mode} ${qty}${note ? ' - '+note : ''}`);
                closeModal('stockAdjustmentModal'); loadInventory();
                if(typeof loadStockLedger === 'function') loadStockLedger();
                if(typeof loadPOS === 'function') loadPOS();
            } catch(e) { showToast(e.message, 'error'); }
        }

        async function findInventoryByBarcode(barcode) {
            const code = String(barcode || '').trim();
            if(!code) return null;
            const snap = await db.collection('inventory').where('barcode','==',code).limit(1).get();
            return snap.empty ? null : {ref:snap.docs[0].ref, snap:snap.docs[0]};
        }

        async function inventoryBarcodeLookup(value) {
            const code = String(value || '').trim();
            if(!code) return;
            try {
                const found = await findInventoryByBarcode(code);
                if(found) {
                    const d = found.snap.data();
                    openStockAdjustment(d.sku || found.snap.id);
                } else {
                    openNewInventory();
                    document.getElementById('invBarcode').value = code;
                    showToast('Barcode baru. Lengkapkan maklumat item dan simpan.');
                }
            } catch(e) { showToast(e.message,'error'); }
        }

        function startInventoryBarcodeInput() {
            const el=document.getElementById('inventoryBarcodeSearch'); if(el) { el.focus(); el.select(); }
        }

        window.openStockAdjustment = openStockAdjustment;
        window.saveStockAdjustment = saveStockAdjustment;
        window.updateStockAdjustmentPreview = updateStockAdjustmentPreview;
        window.inventoryBarcodeLookup = inventoryBarcodeLookup;

        let inventoryScanStream = null;
        let inventoryScanTimer = null;

        function openInventoryCameraScanner() {
            let m = document.getElementById('inventoryCameraScanner');
            if(!m){
                m = document.createElement('div');
                m.id = 'inventoryCameraScanner';
                m.className = 'fixed inset-0 z-[220] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4';
                m.innerHTML = `<div class="bg-white rounded-3xl w-full max-w-md p-5 shadow-2xl"><div class="flex justify-between items-center mb-4"><div><b class="text-lg text-slate-800">Scan Barcode Inventori</b><p class="text-xs text-slate-500 mt-1">Halakan kamera pada barcode.</p></div><button type="button" id="closeInventoryScanner" class="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 font-bold">✕</button></div><div class="aspect-video bg-slate-900 rounded-2xl overflow-hidden"><video id="inventoryScanVideo" autoplay playsinline class="w-full h-full object-cover"></video></div><p id="inventoryScanMessage" class="text-xs text-slate-500 text-center mt-3">Jika kamera tidak disokong, gunakan scanner USB/Bluetooth pada kotak Scan Barcode.</p><div class="flex gap-2 mt-4"><input id="inventoryCameraManual" class="flex-1 border border-slate-200 bg-slate-50 rounded-xl px-3 py-2.5 font-mono text-sm" placeholder="Masukkan barcode"><button type="button" id="inventoryCameraUse" class="px-4 rounded-xl bg-indigo-600 text-white font-bold text-sm">Guna</button></div></div>`;
                document.body.appendChild(m);
                document.getElementById('closeInventoryScanner').onclick = closeInventoryCameraScanner;
                document.getElementById('inventoryCameraUse').onclick = ()=>{ const v=document.getElementById('inventoryCameraManual').value.trim(); if(v){ closeInventoryCameraScanner(); inventoryBarcodeLookup(v); } };
            }
            m.classList.remove('hidden');
            startInventoryCameraScanner();
        }

        async function startInventoryCameraScanner(){
            const video=document.getElementById('inventoryScanVideo'); const msg=document.getElementById('inventoryScanMessage');
            if(!video)return;
            if(!('BarcodeDetector' in window)){ if(msg)msg.textContent='Kamera barcode tidak disokong pada browser ini. Gunakan scanner USB/Bluetooth atau masukkan barcode manual.'; return; }
            try{
                inventoryScanStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}}});
                video.srcObject=inventoryScanStream;
                const detector=new BarcodeDetector();
                const loop=async()=>{
                    if(!document.getElementById('inventoryCameraScanner'))return;
                    try{ const codes=await detector.detect(video); if(codes.length && codes[0].rawValue){ const code=codes[0].rawValue; closeInventoryCameraScanner(); await inventoryBarcodeLookup(code); return; } }catch(e){}
                    inventoryScanTimer=requestAnimationFrame(loop);
                };
                loop();
            }catch(e){ if(msg)msg.textContent='Akses kamera gagal. Gunakan scanner USB/Bluetooth atau masukkan barcode manual.'; }
        }

        function closeInventoryCameraScanner(){
            if(inventoryScanTimer)cancelAnimationFrame(inventoryScanTimer);
            if(inventoryScanStream)inventoryScanStream.getTracks().forEach(t=>t.stop());
            inventoryScanTimer=null; inventoryScanStream=null;
            document.getElementById('inventoryCameraScanner')?.remove();
        }

        window.openInventoryCameraScanner = openInventoryCameraScanner;
        window.closeInventoryCameraScanner = closeInventoryCameraScanner;

        

// V34.3 SCALE HELPERS: never download the entire inventory collection.
window.rtInventoryPage = async function(pageSize=50, cursor=null){
  if(!window.db) throw new Error('Firebase belum tersedia');
  let q=db.collection('inventory').where('active','==',true).orderBy('sku').limit(Math.min(Number(pageSize)||50,100));
  if(cursor) q=q.startAfter(cursor);
  const snap=await q.get();
  const items=[];
  snap.forEach(d=>items.push({id:d.id,...d.data()}));
  return {items,lastDoc:snap.docs.length?snap.docs[snap.docs.length-1]:null,hasMore:snap.size===Math.min(Number(pageSize)||50,100)};
};

window.rtInventoryFindExact = async function(code){
  const value=String(code||'').trim();
  if(!value) return null;
  const bySku=await db.collection('inventory').where('sku','==',value).limit(1).get();
  if(!bySku.empty) return {id:bySku.docs[0].id,...bySku.docs[0].data()};
  const byBarcode=await db.collection('inventory').where('barcode','==',value).limit(1).get();
  if(!byBarcode.empty) return {id:byBarcode.docs[0].id,...byBarcode.docs[0].data()};
  return null;
};
