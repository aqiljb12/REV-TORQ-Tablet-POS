/* REV TORQ V36.2 STABLE DATA PATH
   Canonical Supabase writes for the workflows that previously fell back to
   the legacy Firestore compatibility API. Loaded last so these handlers win.
*/
(function(){
'use strict';
const sb=window.supabaseClient;
if(!sb) return;
const $=id=>document.getElementById(id);
const profile=()=>window.currentProfile||{};
const toast=(m,t='success')=>window.showToast?window.showToast(m,t):console.log(m);
const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const err=e=>e?.message||e?.details||e?.hint||String(e);

async function companyId(){
  const c=profile().companyId;
  if(c)return c;
  const r=await sb.rpc('get_my_company_id');
  if(r.error)throw r.error;
  if(!r.data)throw new Error('Staff belum dipetakan kepada company.');
  return r.data;
}
async function staffUuid(){
  const p=profile();
  if(p.staffId && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(p.staffId))return p.staffId;
  const q=sb.from('staff').select('id').eq('company_id',await companyId()).eq('active',true);
  if(p.staffId)q.eq('staff_code',String(p.staffId).toUpperCase());
  else if(p.uid)q.eq('auth_user_id',p.uid);
  else throw new Error('Staff login tidak sah.');
  const r=await q.limit(1).maybeSingle();
  if(r.error)throw r.error;
  if(!r.data)throw new Error('Staff login tidak dijumpai.');
  return r.data.id;
}
async function locationId(){
  if(profile().locationId)return profile().locationId;
  const r=await sb.from('locations').select('id').eq('company_id',await companyId()).eq('active',true).order('code').limit(1).maybeSingle();
  if(r.error)throw r.error;
  if(!r.data)throw new Error('Lokasi aktif tidak dijumpai.');
  return r.data.id;
}
async function refresh(name){try{if(typeof window[name]==='function')await window[name]();}catch(e){console.warn('refresh '+name,e)}}

// ---------------- JOB CARD: canonical Supabase only ----------------
window.saveJobCard=async function(e){
  e.preventDefault();
  const btn=$('btnSaveJobCard'); const old=btn?.innerHTML;
   let stage='validate';
  if(btn){btn.disabled=true;btn.innerHTML='Menyimpan...';}
  try{
    const c=$('jcCustomerSelect'),v=$('jcVehicleSelect'),s=$('jcStaffSelect');
    if(!c?.value||!v?.value)throw new Error('Sila pilih pelanggan & kenderaan.');
    stage='resolve staff/company/location';
    const company=await companyId(), staff=await staffUuid(), loc=await locationId();
    const assigned=s?.value||null;
    const selectedParts=Array.isArray(window.jcPartsItems)?window.jcPartsItems:[];
    for(const x of selectedParts){
      if(!x?.id)throw new Error('Barang Inventory tidak mempunyai product_id yang sah.');
      const qty=Number(x.qty||0), price=Number(x.price||0);
      if(qty<=0)throw new Error('Kuantiti barang tidak sah.');
      if(price<0)throw new Error('Harga jual barang tidak sah.');
    }
    const parts=selectedParts.reduce((sum,x)=>sum+Number(x.price||0)*Number(x.qty||1),0);
    const labor=Number($('jcEstLabor')?.value||0);
    const payload={
      company_id:company,location_id:loc,customer_id:c.value,vehicle_id:v.value,
      assigned_staff_id:assigned||null,status:$('jcStatusSelect')?.value||'OPEN',
      complaint:$('jcComplaint')?.value?.trim()||null,
      diagnosis:$('jcDiagnosis')?.value?.trim()||null,
      inspection:typeof collectInspectionChecklist==='function'?collectInspectionChecklist('jcInspectionChecklist'):null,
      estimated_total:parts+labor,actual_total:parts+labor,updated_by:staff,updated_at:new Date().toISOString()
    };
    const editing=$('jcIsEdit')?.value==='true';
    if(editing){
      const jobNo=$('jcIdField')?.value;
      if(!jobNo)throw new Error('No Job Card tidak sah.');
      stage='update job_cards';
      const r=await sb.from('job_cards').update(payload).eq('company_id',company).eq('job_no',jobNo).select('id,job_no').single();
      if(r.error)throw r.error;
      // Replace the Job Card PART rows from the Inventory picker. No free-text part field.
      stage='delete old job_card_items';
      const del=await sb.from('job_card_items').delete().eq('company_id',company).eq('job_card_id',r.data.id).eq('item_type','PART');
      if(del.error)throw del.error;
      if(selectedParts.length){
        const rows=selectedParts.map(x=>({
          id:crypto.randomUUID(),company_id:company,job_card_id:r.data.id,product_id:x.id||null,item_type:'PART',
          description:String(x.name||x.sku||'').trim(),quantity:Number(x.qty||1),unit_cost:Number(x.cost||0),unit_price:Number(x.price||0),
          discount:0,staff_id:staff,status:'ACTIVE',notes:null,created_by:staff,created_at:new Date().toISOString(),updated_at:new Date().toISOString()
        }));
        stage='insert job_card_items';
        const ir=await sb.from('job_card_items').insert(rows).select('id,quantity,unit_price,line_total');
        if(ir.error)throw ir.error;
        const expected=rows.reduce((sum,x)=>sum+Number(x.quantity||0)*Number(x.unit_price||0),0);
        const actual=(ir.data||[]).reduce((sum,x)=>sum+Number(x.line_total||0),0);
        if(Math.abs(actual-expected)>0.005)throw new Error(`Jumlah item Job Card tidak sepadan. DB=${actual.toFixed(2)} | Dijangka=${expected.toFixed(2)}`);
      }
      toast('Job Card '+r.data.job_no+' berjaya dikemaskini.');
    }else{
      const jobNo='JOB-'+new Date().toISOString().slice(0,10).replace(/-/g,'')+'-'+Math.random().toString(36).slice(2,6).toUpperCase();
      stage='insert job_cards';
      const r=await sb.from('job_cards').insert({...payload,id:crypto.randomUUID(),job_no:jobNo,created_by:staff,opened_at:new Date().toISOString(),source:'WALK_IN'}).select('id,job_no').single();
      if(r.error)throw r.error;
      if(selectedParts.length){
        const rows=selectedParts.map(x=>({
          id:crypto.randomUUID(),company_id:company,job_card_id:r.data.id,product_id:x.id||null,item_type:'PART',
          description:String(x.name||x.sku||'').trim(),quantity:Number(x.qty||1),unit_cost:Number(x.cost||0),unit_price:Number(x.price||0),
          discount:0,staff_id:staff,status:'ACTIVE',notes:null,created_by:staff,created_at:new Date().toISOString(),updated_at:new Date().toISOString()
        }));
        stage='insert job_card_items';
        const ir=await sb.from('job_card_items').insert(rows).select('id,quantity,unit_price,line_total');
        if(ir.error)throw ir.error;
        const expected=rows.reduce((sum,x)=>sum+Number(x.quantity||0)*Number(x.unit_price||0),0);
        const actual=(ir.data||[]).reduce((sum,x)=>sum+Number(x.line_total||0),0);
        if(Math.abs(actual-expected)>0.005)throw new Error(`Jumlah item Job Card tidak sepadan. DB=${actual.toFixed(2)} | Dijangka=${expected.toFixed(2)}`);
      }
      toast('Job Card '+r.data.job_no+' berjaya disimpan.');
    }
    closeModal('jobCardModal');
    await refresh('loadJobCards');
  }catch(e){
    console.error('REV TORQ Job Card save',{stage,error:e});
    toast(`Job Card gagal | ACTION: ${stage} | ${err(e)}`,'error');
  }
  finally{if(btn){btn.disabled=false;btn.innerHTML=old||'Simpan';}}
};

// ---------------- INVENTORY: canonical Supabase only ----------------
window.saveInventory=async function(e){
  e.preventDefault();
  const btn=$('btnSaveInv');const old=btn?.innerHTML;if(btn){btn.disabled=true;btn.innerHTML='Menyimpan...';}
  try{
    const company=await companyId(), staff=await staffUuid(), loc=await locationId();
    const sku=String($('invSku')?.value||'').trim().toUpperCase();
    const name=String($('invName')?.value||'').trim();
    if(!sku||!name)throw new Error('SKU dan nama item diperlukan.');
    const category=$('invCat')?.value||null, barcode=String($('invBarcode')?.value||'').trim()||null;
    const rack=String($('invRackCode')?.value||'').trim().toUpperCase()||null;
    const cost=Number($('invCost')?.value||0), price=Number($('invPrice')?.value||0), minStock=Number($('invMinStock')?.value||0);
    const active=$('invActive')?.value==='true'; const editing=$('invIsEdit')?.value==='true';
    if(cost<0||price<0||minStock<0)throw new Error('Nilai harga/stok tidak sah.');
    if(barcode){
      let bq=sb.from('products').select('id,sku').eq('company_id',company).eq('barcode',barcode).limit(1).maybeSingle();
      const br=await bq;if(br.error)throw br.error;
      if(br.data && (!editing || br.data.sku!==sku))throw new Error('Barcode '+barcode+' sudah digunakan oleh '+br.data.sku+'.');
    }
    let product;
    if(editing){
      const r=await sb.from('products').update({name,category,barcode,rack_location:rack,cost_price:cost,sell_price:price,min_stock:minStock,active,updated_at:new Date().toISOString()}).eq('company_id',company).eq('sku',sku).select('id,sku').single();
      if(r.error)throw r.error; product=r.data;
    }else{
      const r=await sb.from('products').insert({company_id:company,sku,name,category,barcode,rack_location:rack,cost_price:cost,sell_price:price,min_stock:minStock,active,unit:'pcs'}).select('id,sku').single();
      if(r.error)throw r.error; product=r.data;
      const opening=Math.max(0,Number($('invStock')?.value||0));
      // Do not write stock_balances directly from the browser: production RLS intentionally
      // exposes stock balances as read-only. The ledger RPC is the canonical writer.
      if(opening>0){
        const mv=await sb.rpc('post_stock_movement',{p_company_id:company,p_location_id:loc,p_product_id:product.id,p_movement_type:'OPENING',p_quantity:opening,p_unit_cost:cost,p_reference_type:'PRODUCT_SETUP',p_reference_id:null,p_staff_id:staff,p_device_id:null,p_transaction_id:crypto.randomUUID()});
        if(mv.error)throw mv.error;
      }
    }
    toast('Item '+product.sku+' berjaya '+(editing?'dikemaskini.':'disimpan.'));
    if(typeof window.closeInventoryPage==='function') window.closeInventoryPage(); else closeModal('inventoryModal');
    await refresh('loadInventory'); await refresh('loadPOS');
  }catch(e){console.error('V36.2 saveInventory',e);toast('Inventori gagal: '+err(e),'error');}
  finally{if(btn){btn.disabled=false;btn.innerHTML=old||'Simpan';}}
};

// ---------------- STOCK ADJUSTMENT: canonical ledger/RPC ----------------
window.openStockAdjustment=async function(sku){
  try{
    const company=await companyId(),loc=await locationId();
    const r=await sb.from('products').select('id,sku,name,barcode').eq('company_id',company).eq('sku',String(sku).trim().toUpperCase()).maybeSingle();
    if(r.error)throw r.error;if(!r.data)throw new Error('Item tidak ditemui.');
    const st=await sb.from('stock_balances').select('quantity').eq('product_id',r.data.id).eq('location_id',loc).maybeSingle();
    if(st.error)throw st.error;
    $('adjSku').value=r.data.sku;$('adjBarcode').value=r.data.barcode||'';$('adjItemName').innerText=r.data.name||r.data.sku;
    $('adjCurrentStock').innerText=Number(st.data?.quantity||0);$('adjQty').value='';$('adjMode').value='IN';updateStockAdjustmentPreview();openModal('stockAdjustmentModal');
  }catch(e){toast('Stok gagal dibuka: '+err(e),'error');}
};
window.saveStockAdjustment=async function(e){
  e.preventDefault();
  try{
    const company=await companyId(),staff=await staffUuid(),loc=await locationId();
    const sku=String($('adjSku')?.value||'').trim().toUpperCase(),qty=Math.max(0,Number($('adjQty')?.value||0)),mode=$('adjMode')?.value,note=String($('adjNote')?.value||'').trim();
    if(!sku||qty<=0)throw new Error('Masukkan kuantiti yang sah.');
    const p=await sb.from('products').select('id,name,cost_price').eq('company_id',company).eq('sku',sku).single();if(p.error)throw p.error;
    const cur=await sb.from('stock_balances').select('quantity').eq('product_id',p.data.id).eq('location_id',loc).maybeSingle();if(cur.error)throw cur.error;
    const before=Number(cur.data?.quantity||0);let delta=mode==='SET'?qty-before:(mode==='OUT'?-qty:qty);if(before+delta<0)throw new Error('Stok tidak mencukupi. Stok semasa: '+before+'.');
    if(delta===0){toast('Tiada perubahan stok.','info');return;}
    const type=delta>0?'ADJUSTMENT_IN':'ADJUSTMENT_OUT';
    const mv=await sb.rpc('post_stock_movement',{p_company_id:company,p_location_id:loc,p_product_id:p.data.id,p_movement_type:type,p_quantity:Math.abs(delta),p_unit_cost:Number(p.data.cost_price||0),p_reference_type:'STOCK_ADJUSTMENT',p_reference_id:null,p_staff_id:staff,p_device_id:null,p_transaction_id:crypto.randomUUID()});
    if(mv.error)throw mv.error;
    toast('Stok '+sku+' dikemaskini.');closeModal('stockAdjustmentModal');await refresh('loadInventory');await refresh('loadStockLedger');await refresh('loadPOS');
  }catch(e){console.error('V36.2 saveStockAdjustment',e);toast('Stok gagal: '+err(e),'error');}
};

// Canonical product lookup. Known barcode -> stock adjustment for that item.
// Unknown barcode -> start the new-item flow with the scanned code pre-filled,
// so scanning an item that isn't in the system yet still gets it registered.
window.inventoryBarcodeLookup=async function(value){
  const code=String(value||'').trim();if(!code)return;
  try{
    const r=await sb.from('products').select('sku,name').eq('company_id',await companyId()).eq('barcode',code).maybeSingle();
    if(r.error)throw r.error;
    if(r.data){ openStockAdjustment(r.data.sku); return; }
    if(typeof window.openNewInventory==='function') window.openNewInventory();
    const input=$('invBarcode');
    if(input){
      input.value=code; input.setAttribute('value',code);
      input.dispatchEvent(new Event('input',{bubbles:true}));
      input.dispatchEvent(new Event('change',{bubbles:true}));
    }
    toast('Barcode baru. Lengkapkan maklumat item dan simpan.','info');
  }catch(e){toast('Barcode gagal: '+err(e),'error');}
};

window.RT_STABLE_V362=true;
})();
