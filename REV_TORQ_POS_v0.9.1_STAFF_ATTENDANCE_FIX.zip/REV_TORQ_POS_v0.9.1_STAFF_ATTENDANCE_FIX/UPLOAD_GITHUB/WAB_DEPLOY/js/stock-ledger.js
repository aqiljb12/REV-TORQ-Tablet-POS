// ================= STOCK LEDGER =================
        async function loadStockLedger() {
            const tbody = document.querySelector('#tblStockLedger tbody');
            tbody.innerHTML = '<tr><td colspan="8" class="text-center p-4">Loading...</td></tr>';
            try {
                const snap = await db.collection("stock_ledger").orderBy("timestamp", "desc").limit(100).get();
                let rows = '';
                snap.forEach(doc => {
                    const d = doc.data();
                    let actColor = 'text-gray-400';
                    let qtyColor = 'text-gray-400';
                    if(d.activity === 'SALE') { actColor = 'text-red-400'; qtyColor = 'text-red-400'; }
                    if(d.activity === 'PURCHASE') { actColor = 'text-green-400'; qtyColor = 'text-green-400'; }
                    
                    rows += `
                        <tr class="hover:bg-gray-800/50">
                            <td class="p-4 text-xs font-mono text-gray-400">${d.timestamp ? new Date(d.timestamp.toDate()).toLocaleString('ms-MY') : '-'}</td>
                            <td class="p-4 font-bold text-white text-sm"><span class="text-amber-500 font-mono">${d.sku}</span><br>${d.itemName}</td>
                            <td class="p-4 font-bold text-xs ${actColor}">${d.activity}</td>
                            <td class="p-4 font-mono text-right text-gray-500">${d.beforeStock}</td>
                            <td class="p-4 font-mono text-right font-bold ${qtyColor}">${d.quantity > 0 ? '+'+d.quantity : d.quantity}</td>
                            <td class="p-4 font-mono text-right font-bold text-white">${d.afterStock}</td>
                            <td class="p-4 text-xs font-mono text-gray-500">${d.referenceId}</td>
                            <td class="p-4 text-xs">${d.staffName}</td>
                        </tr>
                    `;
                });
                tbody.innerHTML = rows || '<tr><td colspan="8" class="text-center p-4 text-gray-500">Tiada rekod lejar</td></tr>';
            } catch(e) { tbody.innerHTML = `<tr><td colspan="8" class="text-center p-4 text-red-500">Ralat: ${e.message}</td></tr>`; }
        }

        