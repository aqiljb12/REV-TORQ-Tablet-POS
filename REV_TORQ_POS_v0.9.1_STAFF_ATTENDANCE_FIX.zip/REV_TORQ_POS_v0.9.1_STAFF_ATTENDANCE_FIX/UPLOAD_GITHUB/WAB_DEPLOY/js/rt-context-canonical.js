/* v0.8.6: context comes from a verified Auth user and its exact staff row.
   No staff-code fallback, cached role or cached company used as authority. */
(function(){
'use strict';
const sb=window.supabaseClient;
if(!sb)return;
let pending=null, generation=0;
window.rtResetStaffContext=()=>{++generation;pending=null;};
async function resolveStaff(){
  if(pending)return pending;
  const ticket=generation;
  const request=(async()=>{
    if(typeof window.rtResolveVerifiedContext!=='function')throw new Error('Modul login belum tersedia.');
    const row=await window.rtResolveVerifiedContext();
    if(ticket!==generation)throw new Error('Sesi telah berubah. Sila cuba semula.');
    return row;
  })();
  pending=request;
  try{return await request;}finally{if(pending===request)pending=null;}
}
async function resolveLocation(staff){
  if(staff.location_id)return staff.location_id;
  const r=await sb.from('locations').select('id').eq('company_id',staff.company_id)
    .eq('active',true).order('code').limit(1).maybeSingle();
  if(r.error)throw r.error;
  if(!r.data?.id)throw new Error('Lokasi bengkel aktif tidak dijumpai.');
  return r.data.id;
}
window.rtResolveStaffContext=resolveStaff;
window.companyId=async()=>(await resolveStaff()).company_id;
window.staffUuid=async()=>(await resolveStaff()).id;
window.locationId=async()=>resolveLocation(await resolveStaff());
window.rtContext=async()=>{
  const staff=await resolveStaff();
  return {staff,staffId:staff.id,companyId:staff.company_id,locationId:await resolveLocation(staff)};
};
})();
