// ================= SUPPLIERS =================
        function openNewSupplier() {
            document.getElementById('supIsEdit').value = "false";
            document.getElementById('supIdField').value = "";
            document.getElementById('supModalTitle').innerText = "Daftar Pembekal";
            document.getElementById('supName').value = "";
            document.getElementById('supPhone').value = "";
            document.getElementById('supContact').value = "";
            document.getElementById('supAddress').value = "";
            openModal('supplierModal');
        }

        async function editSupplier(id) {
            document.getElementById('supIsEdit').value = "true";
            document.getElementById('supIdField').value = id;
            document.getElementById('supModalTitle').innerText = "Kemaskini Pembekal";
            try {
                const doc = await db.collection("suppliers").doc(id).get();
                if(doc.exists) {
                    const d = doc.data();
                    document.getElementById('supName').value = d.company;
                    document.getElementById('supPhone').value = d.phone;
                    document.getElementById('supContact').value = d.contactPerson;
                    document.getElementById('supAddress').value = d.address;
                    document.getElementById('supActive').value = d.active ? 'true' : 'false';
                    openModal('supplierModal');
                }
            } catch(e) { showToast(e.message, 'error'); }
        }

        async function loadSuppliers() {
            const tbody = document.querySelector('#tblSuppliers tbody');
            tbody.innerHTML = '<tr><td colspan="5" class="text-center p-4">Loading...</td></tr>';
            try {
                const snap = await db.collection("suppliers").limit(100).get();
                let rows = '';
                snap.forEach(doc => {
                    const d = doc.data();
                    rows += `
                        <tr class="hover:bg-gray-800/50">
                            <td class="p-4 font-bold text-white">${d.company}</td>
                            <td class="p-4 font-mono">${d.phone}</td>
                            <td class="p-4 text-sm">${d.contactPerson}</td>
                            <td class="p-4 font-bold text-xs ${d.active ? 'text-green-400' : 'text-red-400'}">${d.active ? 'AKTIF' : 'TIDAK AKTIF'}</td>
                            <td class="p-4 text-right">
                                <button onclick="editSupplier('${d.supplierId}')" class="text-amber-400 hover:text-amber-300 text-xs font-bold"><i data-feather="edit" class="w-4 h-4 inline"></i> KEMASKINI</button>
                            </td>
                        </tr>
                    `;
                });
                tbody.innerHTML = rows || '<tr><td colspan="5" class="text-center p-4 text-gray-500">Tiada pembekal</td></tr>';
                feather.replace();
            } catch(e) { tbody.innerHTML = `<tr><td colspan="5" class="text-center p-4 text-red-500">Ralat: ${e.message}</td></tr>`; }
        }

        async function saveSupplier(e) {
            e.preventDefault();
            const btnId = 'btnSaveSupplier';
            setOriginalText(btnId);
            toggleLoading(btnId, true);

            const isEdit = document.getElementById('supIsEdit').value === "true";
            
            try {
                if (isEdit) {
                    const sid = document.getElementById('supIdField').value;
                    await db.collection("suppliers").doc(sid).update({
                        company: document.getElementById('supName').value.trim(),
                        phone: document.getElementById('supPhone').value.trim(),
                        contactPerson: document.getElementById('supContact').value.trim(),
                        address: document.getElementById('supAddress').value.trim(),
                        active: document.getElementById('supActive').value === 'true',
                        updatedAt: new Date().toISOString()
                    });
                    showToast("Pembekal dikemaskini.");
                    await logAudit('UPDATE_SUPPLIER', `Updated supplier: ${sid}`);
                } else {
                    const sid = "SUP-" + new Date().getTime().toString().slice(-6);
                    await db.collection("suppliers").doc(sid).set({
                        supplierId: sid,
                        company: document.getElementById('supName').value.trim(),
                        phone: document.getElementById('supPhone').value.trim(),
                        contactPerson: document.getElementById('supContact').value.trim(),
                        address: document.getElementById('supAddress').value.trim(),
                        active: document.getElementById('supActive').value === 'true',
                        createdAt: new Date().toISOString(),
                        createdBy: currentProfile.staffId
                    });
                    showToast("Pembekal ditambah.");
                    await logAudit('CREATE_SUPPLIER', `Added supplier: ${sid}`);
                }
                
                closeModal('supplierModal');
                loadSuppliers();
            } catch (error) { showToast(error.message, 'error'); } 
            finally { toggleLoading(btnId, false); }
        }

        