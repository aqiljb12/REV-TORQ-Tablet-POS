/* REV TORQ V36.4.4 - Labour/Service POS item
   Labour is a charge, NOT an inventory product and never creates stock movement. */
(function(){
  'use strict';
  const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const money=v=>'RM '+Number(v||0).toFixed(2);

  function injectStyle(){
    if(document.getElementById('rtLabourStyle')) return;
    const s=document.createElement('style'); s.id='rtLabourStyle';
    s.textContent=`
      .rt-labour-cat{display:flex!important;align-items:center;justify-content:center;gap:8px;background:#5b6678!important;color:#fff!important;border:1px solid #687487!important}
      .rt-labour-cat.active-cat{background:#dc3d37!important;border-color:#dc3d37!important}
      #rtLabourModal{position:fixed;inset:0;z-index:500;background:rgba(5,12,25,.72);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;padding:16px}
      #rtLabourModal.hidden{display:none}
      .rt-labour-box{width:min(520px,100%);background:#fff;border-radius:22px;box-shadow:0 24px 70px rgba(0,0,0,.3);overflow:hidden}
      .rt-labour-option{border:1px solid #d8dee8;background:#f8fafc;border-radius:14px;padding:13px 14px;text-align:left;font-weight:800;color:#1e293b}
      .rt-labour-option.selected{border-color:#dc3d37;background:#fff1f0;color:#b42318}
      .rt-labour-input{width:100%;border:1px solid #cbd5e1;border-radius:13px;padding:13px 14px;font-size:18px;font-weight:800;outline:none}
      .rt-labour-input:focus{border-color:#dc3d37;box-shadow:0 0 0 3px rgba(220,61,55,.12)}
    `;
    document.head.appendChild(s);
  }

  function modal(){
    let m=document.getElementById('rtLabourModal'); if(m)return m;
    m=document.createElement('div'); m.id='rtLabourModal'; m.className='hidden';
    m.innerHTML=`<div class="rt-labour-box">
      <div style="padding:18px 20px;border-bottom:1px solid #e2e8f0;display:flex;justify-content:space-between;align-items:center">
        <div><div style="font-size:18px;font-weight:900;color:#0f172a">LABOUR / SERVICE</div><div style="font-size:12px;color:#64748b;margin-top:3px">Caj kerja — bukan stok inventory</div></div>
        <button type="button" id="rtLabourClose" style="width:38px;height:38px;border-radius:11px;border:0;background:#f1f5f9;font-weight:900;font-size:18px">×</button>
      </div>
      <div style="padding:18px 20px">
        <div style="font-size:11px;font-weight:900;color:#64748b;text-transform:uppercase;margin-bottom:9px">Pilih jenis caj</div>
        <div id="rtLabourOptions" style="display:grid;grid-template-columns:1fr 1fr;gap:9px">
          <button type="button" class="rt-labour-option selected" data-service="Labour Service">Labour Service</button>
          <button type="button" class="rt-labour-option" data-service="Upah Kerja">Upah Kerja</button>
          <button type="button" class="rt-labour-option" data-service="Pemeriksaan / Diagnosis">Pemeriksaan / Diagnosis</button>
          <button type="button" class="rt-labour-option" data-service="Caj Lain-lain">Caj Lain-lain</button>
        </div>
        <label style="display:block;font-size:11px;font-weight:900;color:#64748b;text-transform:uppercase;margin:18px 0 7px">Nama caj</label>
        <input id="rtLabourName" class="rt-labour-input" value="Labour Service" maxlength="80">
        <label style="display:block;font-size:11px;font-weight:900;color:#64748b;text-transform:uppercase;margin:15px 0 7px">Harga / Caj (RM)</label>
        <input id="rtLabourPrice" class="rt-labour-input" type="number" min="0" step="0.01" inputmode="decimal" placeholder="Contoh: 50.00">
        <div style="font-size:11px;color:#64748b;margin-top:8px">Harga dimasukkan manual. Tiada pengurangan stok.</div>
      </div>
      <div style="padding:14px 20px;background:#f8fafc;border-top:1px solid #e2e8f0;display:flex;gap:9px">
        <button type="button" id="rtLabourCancel" style="flex:1;padding:13px;border-radius:12px;border:1px solid #cbd5e1;background:#fff;font-weight:900;color:#475569">BATAL</button>
        <button type="button" id="rtLabourAdd" style="flex:1;padding:13px;border-radius:12px;border:0;background:#dc3d37;color:#fff;font-weight:900">TAMBAH KE CART</button>
      </div>
    </div>`;
    document.body.appendChild(m);
    m.querySelector('#rtLabourClose').onclick=close;
    m.querySelector('#rtLabourCancel').onclick=close;
    m.addEventListener('click',e=>{if(e.target===m)close()});
    m.querySelectorAll('.rt-labour-option').forEach(b=>b.onclick=()=>{
      m.querySelectorAll('.rt-labour-option').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');
      m.querySelector('#rtLabourName').value=b.dataset.service||'Labour Service';
    });
    m.querySelector('#rtLabourAdd').onclick=()=>{
      const name=String(m.querySelector('#rtLabourName').value||'').trim()||'Labour Service';
      const price=Number(m.querySelector('#rtLabourPrice').value||0);
      if(!Number.isFinite(price)||price<0){window.showToast?.('Harga labour tidak sah.','error');return}
      if(price===0 && !confirm('Harga labour RM0.00. Tambah juga?'))return;
      add(name,price);close();
    };
    return m;
  }
  function close(){const m=document.getElementById('rtLabourModal');if(m)m.classList.add('hidden')}
  function open(){injectStyle();const m=modal();m.classList.remove('hidden');setTimeout(()=>m.querySelector('#rtLabourPrice')?.focus(),60)}
  function add(name,price){
    const get=window.rtGetPosCart; const set=window.rtSetPosCart;
    if(typeof get!=='function'||typeof set!=='function'){window.showToast?.('POS cart belum tersedia.','error');return}
    const cart=get().slice();
    const sku='SERVICE-'+Date.now().toString(36).toUpperCase();
    cart.push({sku,name,price:Number(price),qty:1,maxStock:999999,itemType:'SERVICE',service:true,productId:null});
    set(cart);
    window.showToast?.(`${name} ${money(price)} ditambah ke cart.`,'success');
  }
  function ensureButton(){
    const bar=document.getElementById('rtCatBar'); if(!bar)return;
    if(bar.querySelector('[data-rt-labour]'))return;
    const b=document.createElement('button'); b.type='button';b.className='rt-cat rt-labour-cat';b.dataset.rtLabour='1';
    b.innerHTML='<i data-feather="tool"></i><span>LABOUR</span>';b.onclick=open;bar.appendChild(b);
    window.feather?.replace();
  }
  function watch(){
    injectStyle();ensureButton();
    const bar=document.getElementById('rtCatBar');
    if(bar){new MutationObserver(()=>setTimeout(ensureButton,0)).observe(bar,{childList:true});}
    setInterval(ensureButton,1000);
  }

  window.rtOpenLabourCharge=open;
  window.rtAddLabourCharge=add;
  window.rtIsServiceItem=i=>!!(i?.service||String(i?.itemType||'').toUpperCase()==='SERVICE');
  window.addEventListener('load',()=>setTimeout(watch,500));

  // Checkout is owned exclusively by js/v36-4-9-pos-cash-canonical.js.
  // Do not install a second delayed checkout handler here; it previously overwrote
  // the canonical handler ~800ms after page load and could pass staff_code (AQIL)
  // into UUID foreign-key paths. Labour UI/cart helpers remain active above.

})();
