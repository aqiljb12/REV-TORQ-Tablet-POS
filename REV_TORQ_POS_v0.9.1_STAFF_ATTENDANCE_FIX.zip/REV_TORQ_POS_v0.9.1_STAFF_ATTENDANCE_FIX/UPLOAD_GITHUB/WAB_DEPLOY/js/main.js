// --- APP INITIALIZATION ---
document.addEventListener("DOMContentLoaded", () => {
    try {
        if (typeof window.startDashboardRealtime === "function") {
            window.startDashboardRealtime();
        }
    } catch(e) {
        console.warn("Dashboard startup:", e);
    }

    if (typeof feather !== "undefined") {
        feather.replace();
    }

    try {
        if (typeof window.restoreSession === "function") {
            window.restoreSession();
        }
    } catch(e) {
        console.warn("Session restore:", e);
    }

    setTimeout(() => {
        try {
            if (typeof window.startDashboardRealtime === "function") {
                window.startDashboardRealtime();
            }
        } catch(e) {
            console.warn("Dashboard realtime:", e);
        }
    }, 500);
});

// V15 public state bridge (safe for classic-script modules)
try { window.db = db; } catch (_) {}
try { window.currentProfile = currentProfile; window.currentUser = currentUser; } catch (_) {}
