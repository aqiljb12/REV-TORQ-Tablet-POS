/* REV TORQ — POS LITE / NIAGAWAN-INSPIRED UX
   V36.4.12
   IMPORTANT: payment_method belongs to `payments`, NOT `invoices`.
   This module never selects a non-existent invoices.payment_method column.
*/
(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  const money=v=>'RM '+Number(v||0).toLocaleString('ms-MY',{minimumFractionDigits:2,maximumFractionDigits:2});
  const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  const sb=window.supabaseClient;
  let active='in';
  let reportMonth=new Date();
  const isAdmin=()=>['owner','super_admin','admin'].includes(String((window.currentProfile||{}).role||'').toLowerCase());

  function ensure(){
    const view=$('view-pos'); if(!view || $('rtPosLiteBar')) return;
    if(!window.currentProfile)return;
    const bar=document.createElement('div');
    bar.id='rtPosLiteBar';
    bar.className='rt-pos-lite-bar';
    bar.innerHTML=`<button data-tab="in" class="active"><span>＄</span><b>Money In</b></button>${isAdmin()?'<button data-tab="out"><span>▣</span><b>Money Out</b></button><button data-tab="report"><span>▤</span><b>Report</b></button>':''}`;
    view.appendChild(bar);
    bar.querySelectorAll('button').forEach(b=>b.onclick=()=>switchTab(b.dataset.tab));
    const panel=document.createElement('div');
    panel.id='rtPosLitePanel'; panel.className='rt-pos-lite-panel hidden'; view.appendChild(panel);
    render();
  }

  function switchTab(tab){
    if((tab==='out'||tab==='report')&&!isAdmin()){
      if(typeof window.showToast==='function')window.showToast('Money Out & Report hanya untuk Admin / Owner.','error');
      return;
    }
    active=tab;
    const view=$('view-pos'); if(!view)return;
    view.classList.toggle('rt-lite-mode',tab!=='in');
    document.querySelectorAll('#rtPosLiteBar button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
    $('rtPosLitePanel')?.classList.toggle('hidden',tab==='in');
    view.querySelector('.rt-pos-topbar')?.classList.toggle('rt-lite-hidden',tab!=='in');
    view.querySelector('.rt-pos-workspace')?.classList.toggle('rt-lite-hidden',tab!=='in');
    render();
  }

  async function getContext(){
    const p=window.currentProfile||{};
    let company=p.companyId||p.company_id||null;
    if(!company && sb && p.uid){
      const r=await sb.from('staff').select('company_id').eq('auth_user_id',p.uid).eq('active',true).limit(1).maybeSingle();
      if(r.error)throw r.error;
      company=r.data?.company_id||null;
    }
    if(!company)throw new Error('Syarikat aktif tidak dapat dikenal pasti. Sila log masuk semula.');
    return {company};
  }

  // invoices schema intentionally excludes payment_method.
  async function loadInvoices(company){
    if(!sb||!company)return [];
    const r=await sb.from('invoices').select('id,invoice_no,job_card_id,total,status,created_at').eq('company_id',company).order('created_at',{ascending:false}).limit(1000);
    if(r.error)throw r.error;
    return r.data||[];
  }

  // Payment method is stored in the payments table.
  async function loadPayments(company){
    if(!sb||!company)return [];
    const r=await sb.from('payments').select('id,invoice_id,payment_method,amount,created_at').eq('company_id',company).order('created_at',{ascending:false}).limit(2000);
    if(r.error)throw r.error;
    return r.data||[];
  }

  async function loadStockCOGS(company){
    if(!sb||!company)return [];
    const r=await sb.from('stock_movements')
      .select('quantity,unit_cost,reference_id,product_id,created_at,movement_type')
      .eq('company_id',company).eq('movement_type','SALE')
      .order('created_at',{ascending:false}).limit(10000);
    if(r.error)throw r.error;
    return r.data||[];
  }

  async function loadInvoiceItems(invoiceIds){
    if(!sb||!invoiceIds.length)return [];
    const r=await sb.from('invoice_items')
      .select('invoice_id,product_id,job_item_type,description,quantity,unit_cost,unit_price,discount,line_total')
      .in('invoice_id',invoiceIds).limit(10000);
    if(r.error){
      // Current schema does not expose unit_cost on invoice_items; keep compatibility.
      const fallback=await sb.from('invoice_items')
        .select('invoice_id,product_id,job_item_type,description,quantity,unit_price,discount,line_total')
        .in('invoice_id',invoiceIds).limit(10000);
      if(fallback.error)throw r.error;
      return fallback.data||[];
    }
    return r.data||[];
  }

  async function loadJobItems(jobIds){
    if(!sb||!jobIds.length)return [];
    const r=await sb.from('job_card_items')
      .select('job_card_id,product_id,item_type,description,quantity,unit_cost,unit_price,line_total,status')
      .in('job_card_id',jobIds).limit(10000);
    if(r.error)throw r.error;
    return r.data||[];
  }

  async function loadExpenses(company){
    if(!sb||!company)return [];
    const r=await sb.from('expenses').select('id,expense_no,category,description,amount,payment_method,reference_no,remark,expense_date,created_at').eq('company_id',company).order('created_at',{ascending:false}).limit(1000);
    if(r.error){
      // Older deployments may not have optional description/reference/remark columns.
      const fallback=await sb.from('expenses').select('id,expense_no,category,amount,payment_method,expense_date,created_at').eq('company_id',company).order('created_at',{ascending:false}).limit(1000);
      if(fallback.error)throw r.error;
      return fallback.data||[];
    }
    return r.data||[];
  }

  function parseDate(v){const d=new Date(v);return Number.isNaN(d.getTime())?null:d;}
  function inMonth(v,year,month){const d=parseDate(v);return !!d&&d.getFullYear()===year&&d.getMonth()===month;}
  function isVoid(x){return String(x?.status||'PAID').toUpperCase()==='VOID';}
  function monthLabel(d=reportMonth){return d.toLocaleDateString('ms-MY',{month:'long',year:'numeric'});}
  function shiftMonth(delta){reportMonth=new Date(reportMonth.getFullYear(),reportMonth.getMonth()+delta,1);}

  function render(){
    ensurePanel();
    if(active==='in'){ $('rtPosLitePanel').innerHTML=''; return; }
    if(active==='out')renderOut();
    if(active==='report')renderReport();
  }
  function ensurePanel(){const p=$('rtPosLitePanel');if(p)p.classList.remove('hidden');}

  function renderOut(){
    const p=$('rtPosLitePanel');
    p.innerHTML=`<div class="rt-lite-card rt-cashout-only">
      <div class="rt-lite-head"><div><small>CASH DRAWER</small><h2>Money Out</h2><p style="margin-top:6px;color:#64748b;font-size:13px">Rekod tunai yang benar-benar keluar dari peti. Perbelanjaan akaun penuh diurus dalam aplikasi Accounting.</p></div><button id="rtLiteOutHistory">Sejarah</button></div>
      <div class="rt-lite-section">
        <label>Jumlah Keluar (RM)<input id="rtCashOutAmount" type="number" min="0.01" step="0.01" inputmode="decimal" placeholder="0.00"></label>
        <label>Sebab<select id="rtCashOutReason"><option value="Petty Cash">Petty Cash</option><option value="Belian Kecemasan">Belian Kecemasan</option><option value="Petrol / Pengangkutan">Petrol / Pengangkutan</option><option value="Refund Customer">Refund Customer</option><option value="Bank In / Deposit">Bank In / Deposit</option><option value="Lain-lain">Lain-lain</option></select></label>
        <label>Nota<textarea id="rtCashOutNote" placeholder="Contoh: beli cable tie kecemasan"></textarea></label>
        <div id="rtCashOutStaff" style="margin:10px 0;color:#64748b;font-size:12px">Direkod oleh staff yang sedang login.</div>
        <button id="rtCashOutSave" class="rt-lite-save">SIMPAN CASH OUT</button>
      </div>
      <div style="margin-top:14px;padding:14px;border-radius:14px;background:#f8fafc;color:#64748b;font-size:12px;line-height:1.55"><b style="color:#0f172a">Nota:</b> Money Out ini hanya mengurangkan tunai dalam Cash Drawer. Ia bukan modul Expenses / P&amp;L / Supplier Bill.</div>
    </div>`;
    p.querySelector('#rtLiteOutHistory').onclick=()=>cashOutHistory();
    p.querySelector('#rtCashOutSave').onclick=()=>saveCashOut();
  }

  async function saveCashOut(){
    const amount=Number($('rtCashOutAmount')?.value||0);
    const reason=String($('rtCashOutReason')?.value||'Lain-lain').trim();
    const note=String($('rtCashOutNote')?.value||'').trim();
    if(amount<=0){alert('Masukkan jumlah Cash Out.');return;}
    const btn=$('rtCashOutSave'); btn.disabled=true; btn.textContent='MENYIMPAN...';
    try{
      const c=await getContext();
      const dr=await sb.from('cash_drawers').select('id,status,expected_amount').eq('company_id',c.company).eq('drawer_code','MAIN').eq('status','OPEN').limit(1).maybeSingle();
      if(dr.error)throw dr.error;
      if(!dr.data)throw new Error('Peti tunai belum OPEN. Buka peti dahulu.');
      const fullReason=note?`${reason} — ${note}`:reason;
      const r=await sb.rpc('rt_cash_move',{p_type:'CASH_OUT',p_amount:amount,p_reason:fullReason});
      if(r.error)throw r.error;
      $('rtCashOutAmount').value=''; $('rtCashOutNote').value='';
      alert(`Cash Out ${money(amount)} berjaya direkod.`);
      try{window.dispatchEvent(new Event('focus'));}catch(_){ }
    }catch(e){alert('Gagal simpan Cash Out: '+(e.message||e));}
    finally{btn.disabled=false;btn.textContent='SIMPAN CASH OUT';}
  }

  async function cashOutHistory(){
    let m=$('rtLiteExpenseHistory');if(m)m.remove();
    m=document.createElement('div');m.id='rtLiteExpenseHistory';m.className='rt-lite-modal';
    m.innerHTML=`<div class="rt-lite-modal-box rt-lite-history-box"><div class="rt-lite-modal-head"><h3>Sejarah Cash Out</h3><button id="rtLiteHistX">×</button></div><div id="rtLiteHistBody" class="rt-lite-history-body">Memuatkan...</div></div>`;
    document.body.appendChild(m);$('rtLiteHistX').onclick=()=>m.remove();
    try{
      const c=await getContext();
      const r=await sb.from('cash_movements').select('created_at,amount,reason,movement_type').eq('company_id',c.company).eq('movement_type','CASH_OUT').order('created_at',{ascending:false}).limit(100);
      if(r.error)throw r.error;
      const html=(r.data||[]).map(x=>`<div class="rt-lite-history-row"><div><b>${esc(x.reason||'Cash Out')}</b><small>${esc(new Date(x.created_at).toLocaleString('ms-MY'))}</small></div><strong>${money(x.amount)}</strong></div>`).join('');
      $('rtLiteHistBody').innerHTML=html||'<div class="empty">Tiada rekod Cash Out.</div>';
    }catch(e){$('rtLiteHistBody').innerHTML=`<div class="rt-lite-error">${esc(e.message||e)}</div>`;}
  }

  function openSupplierPurchase(){
    // Use the existing GRN workflow so supplier purchases actually update stock.
    if(typeof window.openModal==='function' && $('grnModal')){
      try{window.openModal('grnModal');}catch(_){$('grnModal').classList.remove('hidden');$('grnModal').classList.add('flex');}
      try{window.loadGRN?.();}catch(_){ }
      return;
    }
    alert('Modul GRN belum tersedia. Buka menu Inventory > GRN.');
  }

  function expenseModal(category){
    let m=$('rtLiteExpenseModal');if(m)m.remove();
    m=document.createElement('div');m.id='rtLiteExpenseModal';m.className='rt-lite-modal';
    const today=new Date().toLocaleDateString('en-GB');
    m.innerHTML=`<div class="rt-lite-modal-box"><div class="rt-lite-modal-head"><h3>${esc(category)}</h3><button id="rtLiteExX">×</button></div>
      <label>Tarikh<input id="rtLiteExDate" value="${today}"></label>
      <label>Total<input id="rtLiteExAmount" type="number" step="0.01" min="0" placeholder="0.00"></label>
      <label>Payment Method<select id="rtLiteExMethod"><option value="Bank">Bank</option><option value="Cash">Cash</option><option value="QR">QR</option><option value="Card">Card</option></select></label>
      <label>Remark<textarea id="rtLiteExRemark" placeholder="Contoh: Bil elektrik September"></textarea></label>
      <button id="rtLiteExSave" class="rt-lite-save">SAVE</button></div>`;
    document.body.appendChild(m);
    $('rtLiteExX').onclick=()=>m.remove();
    $('rtLiteExSave').onclick=async()=>{
      const amount=Number($('rtLiteExAmount').value||0);if(amount<=0){alert('Masukkan jumlah.');return;}
      const btn=$('rtLiteExSave');btn.disabled=true;btn.textContent='SAVING...';
      try{
        const c=await getContext();
        const raw=$('rtLiteExDate').value.trim().split('/');
        if(raw.length!==3)throw new Error('Tarikh mesti DD/MM/YYYY.');
        const iso=`${raw[2]}-${raw[1].padStart(2,'0')}-${raw[0].padStart(2,'0')}`;
        const payload={company_id:c.company,category,amount,payment_method:$('rtLiteExMethod').value,expense_date:iso,remark:$('rtLiteExRemark').value.trim()||null};
        let r=await sb.from('expenses').insert(payload).select('id').single();
        if(r.error){
          // Keep compatibility with installations where `remark` is not present.
          const fallback={company_id:c.company,category,amount,payment_method:$('rtLiteExMethod').value,expense_date:iso};
          r=await sb.from('expenses').insert(fallback).select('id').single();
        }
        if(r.error)throw r.error;
        m.remove();alert('Perbelanjaan disimpan.');
      }catch(e){btn.disabled=false;btn.textContent='SAVE';alert('Gagal simpan: '+(e.message||e));}
    };
  }

  async function expenseHistory(){
    let m=$('rtLiteExpenseHistory');if(m)m.remove();
    m=document.createElement('div');m.id='rtLiteExpenseHistory';m.className='rt-lite-modal';
    m.innerHTML=`<div class="rt-lite-modal-box rt-lite-history-box"><div class="rt-lite-modal-head"><h3>Sejarah Money Out</h3><button id="rtLiteHistX">×</button></div><div id="rtLiteHistBody" class="rt-lite-history-body">Memuatkan...</div></div>`;
    document.body.appendChild(m);$('rtLiteHistX').onclick=()=>m.remove();
    try{
      const c=await getContext(),rows=await loadExpenses(c.company);
      const html=rows.slice(0,100).map(x=>`<div class="rt-lite-history-row"><div><b>${esc(x.category||'Expense')}</b><small>${esc(x.expense_date||x.created_at||'')}</small></div><strong>${money(x.amount)}</strong></div>`).join('');
      $('rtLiteHistBody').innerHTML=html||'<div class="empty">Tiada rekod.</div>';
    }catch(e){$('rtLiteHistBody').innerHTML=`<div class="rt-lite-error">${esc(e.message||e)}</div>`;}
  }

  async function renderReport(){
    const p=$('rtPosLitePanel');
    p.innerHTML=`<div class="rt-lite-card"><div class="rt-lite-tabs"><button data-r="daily" class="active">Daily Sale</button><button data-r="pnl">Profit & Loss</button><button data-r="einvoice">e-Invoice</button></div><div class="rt-lite-month"><button id="rtRepPrev">‹</button><strong id="rtRepMonth">${monthLabel()}</strong><button id="rtRepNext">›</button></div><div id="rtLiteReportBody"><div class="rt-lite-loading">Memuatkan laporan...</div></div></div>`;
    p.querySelectorAll('.rt-lite-tabs button').forEach(b=>b.onclick=()=>{p.querySelectorAll('.rt-lite-tabs button').forEach(x=>x.classList.remove('active'));b.classList.add('active');reportData(b.dataset.r)});
    $('rtRepPrev').onclick=()=>{shiftMonth(-1);renderReport();};
    $('rtRepNext').onclick=()=>{shiftMonth(1);renderReport();};
    await reportData('daily');
  }

  async function reportData(type){
    const body=$('rtLiteReportBody');if(!body)return;
    body.innerHTML='<div class="rt-lite-loading">Memuatkan data...</div>';
    try{
      if(!isAdmin()){
        body.innerHTML='<div class="rt-lite-error"><b>Akses Admin sahaja</b><div>Laporan kewangan tidak tersedia untuk akaun POS.</div></div>';
        return;
      }
      const c=await getContext();
      const [inv,exp,pay,moves]=await Promise.all([loadInvoices(c.company),loadExpenses(c.company),loadPayments(c.company),loadStockCOGS(c.company)]);
      const y=reportMonth.getFullYear(),mo=reportMonth.getMonth();
      const monthInv=inv.filter(x=>inMonth(x.created_at,y,mo)&&!isVoid(x));
      const monthExp=exp.filter(x=>inMonth(x.expense_date||x.created_at,y,mo));
      const monthPay=pay.filter(x=>inMonth(x.created_at,y,mo));
      const invoiceIds=[...new Set(monthInv.map(x=>String(x.id)).filter(Boolean))];
      const jobIds=[...new Set(monthInv.map(x=>x.job_card_id).filter(Boolean).map(String))];
      const [invoiceItems,jobItems]=await Promise.all([loadInvoiceItems(invoiceIds),loadJobItems(jobIds)]);

      // Historical COGS priority:
      // 1) stock SALE movement + unit_cost recorded at the time of sale;
      // 2) for job invoices where a stock SALE row is absent, use job_card_items.unit_cost;
      // 3) service/labour-only lines carry RM0 COGS here; their operating costs belong in Expenses.
      const moveMap=new Map();
      moves.filter(x=>invoiceIds.includes(String(x.reference_id))).forEach(x=>{
        const key=String(x.reference_id)+'|'+String(x.product_id||'');
        moveMap.set(key,(moveMap.get(key)||0)+Math.abs(Number(x.quantity||0))*Number(x.unit_cost||0));
      });
      const jobMap=new Map();
      jobItems.forEach(x=>{
        if(!x.product_id)return;
        const key=String(x.job_card_id)+'|'+String(x.product_id);
        jobMap.set(key,(jobMap.get(key)||0)+Math.abs(Number(x.quantity||0))*Number(x.unit_cost||0));
      });
      const invoiceJobMap=new Map(monthInv.filter(x=>x.job_card_id).map(x=>[String(x.id),String(x.job_card_id)]));
      let cogs=0;
      const missingCogsInvoices=[];
      monthInv.forEach(invRow=>{
        const rows=invoiceItems.filter(x=>String(x.invoice_id)===String(invRow.id));
        let invoiceCogs=0,hasProduct=false,missingProductCost=false;
        rows.forEach(item=>{
          if(!item.product_id)return;
          hasProduct=true;
          const key=String(invRow.id)+'|'+String(item.product_id);
          if(moveMap.has(key)){
            invoiceCogs+=moveMap.get(key);
          }else{
            const jobId=invoiceJobMap.get(String(invRow.id));
            const jk=jobId?jobId+'|'+String(item.product_id):null;
            if(jk&&jobMap.has(jk)) invoiceCogs+=jobMap.get(jk);
            else missingProductCost=true;
          }
        });
        if(hasProduct&&missingProductCost)missingCogsInvoices.push(String(invRow.invoice_no||invRow.id));
        cogs+=invoiceCogs;
      });
      const sale=monthInv.reduce((s,x)=>s+Number(x.total||0),0);
      const expense=monthExp.reduce((s,x)=>s+Number(x.amount||0),0);
      const grossProfit=sale-cogs;
      const netProfit=grossProfit-expense;
      const paymentMap={CASH:0,QR:0,CARD:0,TRANSFER:0};
      monthPay.forEach(x=>{const raw=String(x.payment_method||'CASH').toUpperCase();const k=raw.includes('QR')?'QR':raw.includes('CARD')||raw.includes('KAD')?'CARD':raw.includes('TRANSFER')||raw.includes('BANK')?'TRANSFER':'CASH';paymentMap[k]+=Number(x.amount||0);});
      if(type==='daily'){
        const by={};monthInv.forEach(x=>{const d=parseDate(x.created_at);if(!d)return;const key=d.toLocaleDateString('en-GB',{day:'2-digit',month:'2-digit'});by[key]=(by[key]||0)+Number(x.total||0)});
        body.innerHTML=`<div class="rt-lite-summary"><div><small>${esc(monthLabel())}</small><b>In ${money(sale)}</b></div></div>
          <div class="rt-lite-list"><h3>Monthly Summary</h3>${Object.entries(by).sort((a,b)=>b[0].localeCompare(a[0])).map(([d,v])=>`<div><span>${esc(d)}</span><b>${money(v)}</b><span>›</span></div>`).join('')||'<div class="empty">Tiada jualan.</div>'}</div>
          <div class="rt-lite-list"><h3>Payment Summary</h3><div><span>Tunai</span><b>${money(paymentMap.CASH)}</b></div><div><span>QR / DuitNow</span><b>${money(paymentMap.QR)}</b></div><div><span>Kad</span><b>${money(paymentMap.CARD)}</b></div><div><span>Bank / Transfer</span><b>${money(paymentMap.TRANSFER)}</b></div></div>
          <button class="rt-lite-report-btn" onclick="window.print()">PRINT / PDF REPORT</button>`;
      }else if(type==='pnl'){
        const completeness=missingCogsInvoices.length===0;
        body.innerHTML=`<div class="rt-lite-summary triple"><div><small>Sales</small><b>${money(sale)}</b></div><div><small>Gross Profit</small><b>${money(grossProfit)}</b></div><div><small>Net Profit</small><b>${money(netProfit)}</b></div></div>
          <div class="rt-lite-list"><h3>Profit & Loss</h3><div><span>Sales</span><b>${money(sale)}</b></div><div><span>Cost of Sales (COGS)</span><b>${money(cogs)}</b></div><div><span>Gross Profit</span><b>${money(grossProfit)}</b></div><div><span>Operating Expenses</span><b>${money(expense)}</b></div><div class="net"><span>Net Profit / (Loss)</span><b>${money(netProfit)}</b></div><div><span>Gross Margin</span><b>${sale?((grossProfit/sale)*100).toFixed(1)+'%':'0.0%'}</b></div><div><span>Net Margin</span><b>${sale?((netProfit/sale)*100).toFixed(1)+'%':'0.0%'}</b></div></div>
          <div class="${completeness?'rt-lite-note':'rt-lite-error'}"><b>${completeness?'COGS lengkap':'COGS belum lengkap'}</b><div>${completeness?'Kos barang diambil daripada rekod stock SALE + unit_cost pada masa jualan.':'Ada '+missingCogsInvoices.length+' invois yang tiada stock SALE movement. Net Profit ditanda sebagai anggaran sehingga kos jualan direkodkan.'}</div></div>`;
      }else{
        // No fake e-Invoice API submission is performed here. This is a report of local invoice records.
        body.innerHTML=`<div class="rt-lite-list"><h3>e-Invoice Report</h3><div><span>Unconsolidated / Belum Hantar</span><b>${monthInv.length}</b><span>›</span></div><div><span>Consolidated</span><b>0</b><span>›</span></div></div><div class="rt-lite-list"><h3>Status</h3><div><span>Success</span><b>0</b><span>›</span></div><div><span>Fail</span><b>0</b><span>›</span></div><p class="rt-lite-note">e-Invoice submission belum diaktifkan; angka di atas tidak mendakwa rekod telah dihantar ke LHDN.</p></div>`;
      }
    }catch(e){
      console.error('REV TORQ POS Lite report',e);
      body.innerHTML=`<div class="rt-lite-error"><b>Ralat laporan</b><div>${esc(e.message||e)}</div></div>`;
    }
  }

  window.rtPosLiteSwitch=switchTab;
  window.addEventListener('load',()=>setTimeout(ensure,1000));
  const mo=new MutationObserver(()=>{if($('view-pos')&&!$('rtPosLiteBar'))ensure()});
  mo.observe(document.body,{childList:true,subtree:true});
})();
