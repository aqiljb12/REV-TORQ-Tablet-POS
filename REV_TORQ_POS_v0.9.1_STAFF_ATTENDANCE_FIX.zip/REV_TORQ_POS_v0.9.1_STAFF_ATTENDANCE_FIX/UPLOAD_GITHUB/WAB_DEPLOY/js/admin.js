// ================= STAFF & SETTINGS =================
        let staffListMode = 'active';

        function setStaffListMode(mode) {
            staffListMode = mode === 'all' ? 'all' : 'active';
            const activeBtn = document.getElementById('staffFilterActive');
            const allBtn = document.getElementById('staffFilterAll');
            if (activeBtn && allBtn) {
                activeBtn.className = staffListMode === 'active'
                    ? 'px-3 py-2 rounded-lg bg-indigo-600 text-white text-xs font-bold'
                    : 'px-3 py-2 rounded-lg bg-slate-100 text-slate-600 text-xs font-bold';
                allBtn.className = staffListMode === 'all'
                    ? 'px-3 py-2 rounded-lg bg-indigo-600 text-white text-xs font-bold'
                    : 'px-3 py-2 rounded-lg bg-slate-100 text-slate-600 text-xs font-bold';
            }
            loadStaff();
        }

        async function loadStaff() {
            const tbody = document.querySelector('#tblStaff tbody');
            if (!tbody) return;
            tbody.innerHTML = '<tr><td colspan="5" class="text-center p-4">Loading...</td></tr>';
            try {
                const snap = await db.collection("staff").orderBy("staffId").limit(200).get();
                let rows = '';
                let visibleCount = 0;
                snap.forEach(doc => {
                    const raw = doc.data() || {};
                    const entries = Object.entries(raw);
                    const normKey = k => String(k).replace(/^\uFEFF/, '').trim().toLowerCase();
                    const getField = wanted => {
                        if (raw[wanted] !== undefined) return raw[wanted];
                        const hit = entries.find(([k]) => normKey(k) === normKey(wanted));
                        return hit ? hit[1] : undefined;
                    };
                    const activeRaw = getField('active');
                    const active = activeRaw === true || activeRaw === 'true';
                    const directoryVisibleRaw = getField('directoryVisible');
                    // Legacy staff without this field remain visible. Once an admin
                    // uses BUANG, the profile stays in Firestore for history/audit
                    // but disappears from the staff-management list.
                    const directoryVisible = directoryVisibleRaw !== false && directoryVisibleRaw !== 'false';
                    if (!directoryVisible) return;
                    if (staffListMode === 'active' && !active) return;

                    const staffId = String(getField('staffId') || doc.id || '').trim().toUpperCase();
                    const name = String(getField('name') || staffId).trim();
                    const role = String(getField('role') || '').trim().toUpperCase();
                    const uid = String(getField('uid') || doc.id).trim();
                    const statusLabel = active ? 'AKTIF' : 'BERHENTI';
                    visibleCount++;
                    if (typeof dbgLog === 'function') dbgLog(`STAFF LIST: ${staffId} | active=${String(activeRaw)} (${typeof activeRaw}) | uid=${uid}`);
                    rows += `
                        <tr class="hover:bg-slate-50">
                            <td class="p-4 font-mono font-bold text-indigo-600">${staffId}</td>
                            <td class="p-4 font-bold text-slate-800">${name}</td>
                            <td class="p-4 text-xs uppercase text-slate-600">${role}</td>
                            <td class="p-4 text-xs font-bold ${active ? 'text-green-600' : 'text-red-500'}">${statusLabel}</td>
                            <td class="p-4 text-right">
                                <button onclick="editStaff('${uid}')" class="text-blue-600 hover:text-blue-800 text-xs font-bold mr-3"><i data-feather="edit" class="w-4 h-4 inline"></i> KEMASKINI</button>
                                ${active
                                    ? `<button onclick="deactivateStaff('${uid}','${staffId.replace(/'/g, "\\'")}')" class="text-red-600 hover:text-red-800 text-xs font-bold mr-3"><i data-feather="user-x" class="w-4 h-4 inline"></i> BERHENTI</button>`
                                    : `<button onclick="reactivateStaff('${uid}','${staffId.replace(/'/g, "\\'")}')" class="text-green-600 hover:text-green-800 text-xs font-bold mr-3"><i data-feather="user-check" class="w-4 h-4 inline"></i> AKTIFKAN</button>`
                                }
                                ${!active
                                    ? `<button onclick="removeStaffFromList('${uid}','${staffId.replace(/'/g, "\\'")}')" class="text-slate-600 hover:text-slate-900 text-xs font-bold mr-3"><i data-feather="eye-off" class="w-4 h-4 inline"></i> BUANG</button>`
                                    : ''
                                }
                                <button onclick="resetPIN('${uid}')" class="text-amber-600 hover:text-amber-800 text-xs font-bold"><i data-feather="key" class="w-4 h-4 inline"></i> RESET PIN</button>
                            </td>
                        </tr>
                    `;
                });
                if (!visibleCount) {
                    rows = `<tr><td colspan="5" class="text-center p-8 text-slate-400 text-sm">${staffListMode === 'active' ? 'Tiada staf aktif.' : 'Tiada rekod staf.'}</td></tr>`;
                }
                tbody.innerHTML = rows;
                feather.replace();
            } catch(e) {
                tbody.innerHTML = `<tr><td colspan="5" class="text-center p-4 text-red-500">Ralat: ${e.message}</td></tr>`;
            }
        }

        async function deactivateStaff(uid, staffId) {
            if (!confirm(`Tamatkan akses ${staffId}? Staf akan hilang daripada senarai aktif tetapi rekod lama kekal.`)) return;
            try {
                await db.collection('staff').doc(uid).update({
                    active: false,
                    employmentStatus: 'berhenti',
                    deactivatedAt: new Date().toISOString(),
                    deactivatedBy: (window.currentUser?.id || window.currentProfile?.uid),
                    updatedAt: new Date().toISOString(),
                    updatedBy: (window.currentUser?.id || window.currentProfile?.uid)
                });
                showToast(`${staffId} telah dinyahaktifkan.`, 'success');
                try { await logAudit('DEACTIVATE_STAFF', `Deactivated staff: ${staffId}`); } catch (_) {}
                await loadStaff();
            } catch(e) {
                showToast(e.message || 'Gagal nyahaktifkan staf.', 'error');
            }
        }

        async function removeStaffFromList(uid, staffId) {
            if (!confirm(`Buang ${staffId} daripada senarai staf?\n\nRekod staf, transaksi POS, job card dan sejarah TIDAK akan dipadam. Akaun kekal disekat kerana status masih tidak aktif.`)) return;
            try {
                const currentUser = window.currentUser;
                if (!currentUser) throw new Error('Sesi Admin telah tamat. Sila login semula.');
                await db.collection('staff').doc(uid).update({
                    active: false,
                    employmentStatus: 'berhenti',
                    directoryVisible: false,
                    archivedFromStaffList: true,
                    archivedAt: new Date().toISOString(),
                    archivedBy: currentUser.uid,
                    updatedAt: new Date().toISOString(),
                    updatedBy: currentUser.uid
                });
                showToast(`${staffId} dibuang daripada senarai. Rekod masih disimpan.`, 'success');
                try { await logAudit('ARCHIVE_STAFF_FROM_LIST', `Removed staff from list: ${staffId}; records retained.`); } catch (_) {}
                await loadStaff();
            } catch (e) {
                showToast(e.message || 'Gagal buang staf daripada senarai.', 'error');
            }
        }

        async function reactivateStaff(uid, staffId) {
            if (!confirm(`Aktifkan semula ${staffId}?`)) return;
            try {
                await db.collection('staff').doc(uid).update({
                    active: true,
                    employmentStatus: 'aktif',
                    reactivatedAt: new Date().toISOString(),
                    reactivatedBy: (window.currentUser?.id || window.currentProfile?.uid),
                    updatedAt: new Date().toISOString(),
                    updatedBy: (window.currentUser?.id || window.currentProfile?.uid)
                });
                showToast(`${staffId} telah diaktifkan semula.`, 'success');
                try { await logAudit('REACTIVATE_STAFF', `Reactivated staff: ${staffId}`); } catch (_) {}
                await loadStaff();
            } catch(e) {
                showToast(e.message || 'Gagal aktifkan semula staf.', 'error');
            }
        }

        function openNewStaff() {
            document.getElementById('staffIsEdit').value = "false";
            document.getElementById('staffUidField').value = "";
            document.getElementById('staffIdField').value = "";
            document.getElementById('staffIdField').disabled = false;
            document.getElementById('staffName').value = "";
            document.getElementById('staffPin').value = "";
            document.getElementById('staffModalTitle').innerText = "Daftar Staf Baru";
            
            // Show PIN field for new staff
            document.getElementById('staffPinWrap').style.display = 'block';
            document.getElementById('staffPin').required = true;

            openModal('staffModal');
        }

        async function editStaff(uid) {
            document.getElementById('staffIsEdit').value = "true";
            document.getElementById('staffUidField').value = uid;
            document.getElementById('staffIdField').disabled = true; // ID cannot be changed
            document.getElementById('staffPinWrap').style.display = 'none'; // Pin is handled via Reset PIN
            document.getElementById('staffPin').required = false;
            document.getElementById('staffModalTitle').innerText = "Kemaskini Staf";

            try {
                const doc = await db.collection("staff").doc(uid).get();
                if(doc.exists) {
                    const d = doc.data();
                    document.getElementById('staffIdField').value = d.staffId;
                    document.getElementById('staffName').value = d.name;
                    document.getElementById('staffRole').value = d.role;
                    document.getElementById('staffStatus').value = d.active ? 'true' : 'false';
                    openModal('staffModal');
                }
            } catch(e) { showToast(e.message, 'error'); }
        }

        async function saveStaff(e) {
            e.preventDefault();
            const btnId = 'btnSaveStaff';
            setOriginalText(btnId);
            toggleLoading(btnId, true);

            const isEdit = document.getElementById('staffIsEdit').value === "true";
            const staffId = document.getElementById('staffIdField').value.trim().toUpperCase();
            const name = document.getElementById('staffName').value.trim();
            const role = String(document.getElementById('staffRole').value || 'pos').trim().toLowerCase();
            const active = document.getElementById('staffStatus').value === "true";

            try {
                if (!staffId || !/^[A-Z0-9_-]{2,30}$/.test(staffId)) {
                    throw new Error("ID staf mesti 2-30 aksara: A-Z, 0-9, _ atau -.");
                }
                if (!name) throw new Error("Nama penuh wajib diisi.");

                // IMPORTANT:
                // Firebase primary Auth session belongs to the currently logged-in
                // admin. Staff creation uses a SECONDARY Auth app so creating a new
                // user never replaces AQIL's admin session.
                const primaryUser = window.currentUser;
                if (!primaryUser) throw new Error("Sesi Admin telah tamat. Sila login semula.");

                // Verify the current caller is actually an active admin before doing
                // any Auth creation. Prefer the already-resolved login profile because
                // it has already passed the application's staff resolver. Only fall
                // back to a direct Firestore read when that profile is unavailable.
                const ADMIN_ROLES = ["owner", "admin", "administrator", "super_admin", "superadmin"];
                let adminData = (window.currentProfile && typeof window.currentProfile === 'object')
                    ? { ...window.currentProfile }
                    : null;

                const normaliseAdmin = (data) => {
                    const raw = data || {};
                    const entries = Object.entries(raw);
                    const normKey = k => String(k).replace(/^\uFEFF/, '').trim().toLowerCase();
                    const getField = wanted => {
                        if (raw[wanted] !== undefined) return raw[wanted];
                        const hit = entries.find(([k]) => normKey(k) === normKey(wanted));
                        return hit ? hit[1] : undefined;
                    };
                    const roleRaw = getField('role');
                    const activeRaw = getField('active');
                    return {
                        role: String(roleRaw ?? '').trim().toLowerCase(),
                        active: activeRaw === true || activeRaw === 'true',
                        activeRaw,
                        staffId: String(getField('staffId') ?? '').trim().toUpperCase(),
                        uid: String(getField('uid') ?? '').trim(),
                        raw
                    };
                };

                let admin = normaliseAdmin(adminData);

                // If the in-memory profile is missing/incomplete, read the canonical
                // staff/{AUTH UID} document and normalise field names (including
                // accidental whitespace/BOM/case differences).
                if (!admin.active || !ADMIN_ROLES.includes(admin.role)) {
                    // Resolve the canonical admin profile from Supabase first.
                    // Do NOT call the legacy bridge with an undefined UID: in this
                    // app primaryUser may expose `id` instead of Firebase-style `uid`.
                    const supaForAdmin = window.supabaseClient;
                    let adminAuthUid = String(primaryUser?.uid || primaryUser?.id || '').trim();
                    if (supaForAdmin) {
                        try {
                            const au = await supaForAdmin.auth.getUser();
                            if (au?.data?.user?.id) adminAuthUid = String(au.data.user.id).trim();
                        } catch (_) {}
                    }
                    if (!adminAuthUid) {
                        throw new Error("UID admin tidak dijumpai dalam sesi. Sila logout/login semula.");
                    }

                    if (supaForAdmin) {
                        const ar = await supaForAdmin.from('staff')
                            .select('id,company_id,location_id,staff_code,name,email,role,active,auth_user_id')
                            .eq('auth_user_id', adminAuthUid)
                            .maybeSingle();
                        if (!ar.error && ar.data) {
                            admin = normaliseAdmin({
                                ...ar.data,
                                staffId: ar.data.staff_code,
                                uid: ar.data.auth_user_id
                            });
                        }
                    }

                    // Legacy fallback is allowed only with a real UID.
                    if (!admin.active || !ADMIN_ROLES.includes(admin.role)) {
                        const adminSnap = await db.collection("staff").doc(adminAuthUid).get();
                        if (!adminSnap.exists) {
                            throw new Error(`Profil admin tidak wujud untuk UID ${adminAuthUid}.`);
                        }
                        admin = normaliseAdmin(adminSnap.data());
                    }
                }

                if (!admin.active || !ADMIN_ROLES.includes(admin.role)) {
                    throw new Error(
                        `Akaun semasa bukan admin aktif. UID=${primaryUser.uid}; ` +
                        `staff=${admin.staffId || '(kosong)'}; role=${admin.role || '(kosong)'}; ` +
                        `active=${String(admin.activeRaw)}. Jika Console menunjukkan active=true, ` +
                        `pastikan website menggunakan build V34.3 dan refresh cache.`
                    );
                }

                if (isEdit) {
                    const uid = document.getElementById('staffUidField').value.trim();
                    if (!uid) throw new Error("UID staff tidak sah.");

                    const editUpdate = {
                        staffId,
                        name,
                        role,
                        active,
                        employmentStatus: active ? 'aktif' : 'berhenti',
                        updatedAt: new Date().toISOString(),
                        updatedBy: primaryUser.uid
                    };
                    if (!active) {
                        editUpdate.deactivatedAt = new Date().toISOString();
                        editUpdate.deactivatedBy = primaryUser.uid;
                    }
                    await db.collection("staff").doc(uid).update(editUpdate);

                    showToast(`Staff ${staffId} berjaya dikemaskini.`, 'success');
                    await logAudit('UPDATE_STAFF', `Updated staff: ${staffId}`);
                } else {
                    const pin = document.getElementById('staffPin').value.trim();
                    if (!/^\d{6}$/.test(pin)) throw new Error("PIN mesti tepat 6 digit.");

                    // Staff ID is dynamic. Nothing here is hard-coded to MIDA/AQIL.
                    const duplicate = await db.collection("staff")
                        .where("staffId", "==", staffId)
                        .limit(1).get();
                    if (!duplicate.empty) {
                        throw new Error(`ID staf ${staffId} sudah wujud.`);
                    }

                    // Auth email is global across the whole WABTOQ platform, while
                    // staff_code is only unique inside a company. Keep the existing
                    // login format for compatibility, but never use an existing Auth
                    // account as the credential for a newly-created staff profile.
                    const email = `${staffId.toLowerCase()}@revtorq.internal`;
                    const supa = window.supabaseClient;
                    if(!supa) throw new Error('Supabase belum tersedia.');
                    // Use a non-persisting secondary Auth client so creating a staff account
                    // never replaces the Owner/Admin browser session.
                    const authClient = window.supabase.createClient(
                        'https://cnvgwzugqdsavaxrwokm.supabase.co',
                        'sb_publishable_jKkWbpvOvbayvyh6KtzK3w_wUjxPClx',
                        {auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}}
                    );
                    let credential;
                    const ar = await authClient.auth.signUp({email,password:pin});
                    if (ar.error) {
                        // IMPORTANT: never fall back to signInWithPassword here. If the
                        // Auth email already exists, it may belong to another company.
                        // Signing into it with the new admin's PIN could accidentally
                        // bind that existing Auth identity to a second staff row.
                        if (/already registered|already exists/i.test(ar.error.message || '')) {
                            throw new Error(
                                `ID staf ${staffId} sudah digunakan dalam sistem. Sila pilih ID staf lain.`
                            );
                        }
                        throw ar.error;
                    }
                    credential = ar.data?.user;
                    if(!credential) throw new Error('Akaun Auth staff tidak berjaya dicipta.');

                    try {
                        // Resolve canonical company/location from the authenticated
                        // admin's Supabase staff row. Do not trust a legacy/incomplete
                        // currentProfile object for UUID foreign keys.
                        // Resolve the caller by STAFF CODE, not auth_user_id.
                        // The POS has two auth/session compatibility layers; one exposes
                        // user.id while the legacy layer exposes uid. Staff code is the
                        // canonical value already known to the logged-in admin and avoids
                        // ever sending an undefined/non-UUID into PostgREST.
                        const callerStaffCode = String(
                            window.currentProfile?.staffId ||
                            window.currentUser?.staffId ||
                            primaryUser?.staffId ||
                            ''
                        ).trim().toUpperCase();
                        if(!callerStaffCode) throw new Error('ID Staff admin tidak dijumpai dalam sesi. Sila logout/login semula.');

                        const {data:callerStaff,error:callerStaffError}=await supa
                            .from('staff')
                            .select('id,company_id,location_id,role,active,auth_user_id')
                            .eq('staff_code',callerStaffCode)
                            .maybeSingle();
                        if(callerStaffError) throw callerStaffError;
                        if(!callerStaff?.company_id) throw new Error(`Staff admin ${callerStaffCode} tidak mempunyai Company ID. Semak rekod public.staff.`);
                        if(!callerStaff.active) throw new Error('Akaun admin tidak aktif.');

                        const newAuthUid=String(credential?.id||'').trim();
                        if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(newAuthUid))
                            throw new Error('UUID Auth staff baharu tidak sah. Akaun Auth tidak berjaya dipadankan.');

                        await supa.from('staff').insert({
                            company_id: callerStaff.company_id,
                            location_id: callerStaff.location_id || null,
                            auth_user_id: newAuthUid,
                            staff_code: staffId,
                            name: name,
                            email: email,
                            role: role.toLowerCase(),
                            active: active,
                            removed_from_active_list: !active,
                            joined_at: new Date().toISOString().slice(0,10),
                            created_at: new Date().toISOString(),
                            updated_at: new Date().toISOString()
                        }).select('id').single().then(r=>{if(r.error)throw r.error;});
                        showToast(`Staff ${staffId} berjaya didaftarkan.`, 'success');
                        await logAudit('CREATE_STAFF', `Created staff: ${staffId}`);
                    } catch (dbError) {
                        throw new Error(`Auth staff berjaya dicipta tetapi profil staff gagal disimpan: ${dbError.message||dbError}`);
                    }
                    await loadStaff();
                }

                closeModal('staffModal');
                await loadStaff();
            } catch (error) {
                console.error("saveStaff:", error);
                showToast(error.message || "Operasi staff gagal.", 'error');
                if (typeof showErrorPanel === 'function') showErrorPanel(error.message || "Operasi staff gagal.");
            } finally {
                toggleLoading(btnId, false);
            }
        }

        async function resetPIN(uid) {
            const newPin = prompt("Sila masukkan 6 digit PIN baru:");
            if (!newPin) return;
            if (!/^\d{6}$/.test(newPin)) {
                showToast("Sila masukkan tepat 6 digit nombor.", 'error');
                return;
            }

            try {
                // Password reset is intentionally handled by Firebase's
                // password-reset flow in the browser. We cannot change another
                // user's password using the current admin client session.
                const snap = await db.collection("staff").doc(uid).get();
                if (!snap.exists) throw new Error("Profil staff tidak wujud.");
                const email = String((snap.data() || {}).authEmail || '').trim();
                if (!email) throw new Error("Staff ini tiada authEmail.");

                const ok = confirm(`Hantar pautan reset PIN ke ${email}?`);
                if (!ok) return;

                await window.supabaseClient.auth.resetPasswordForEmail(email);
                showToast(`Pautan reset PIN dihantar ke ${email}.`, 'success');
                await logAudit('RESET_PIN_REQUEST', `Password reset requested for uid: ${uid}`);
            } catch(e) {
                showToast(e.message || "Reset PIN gagal.", 'error');
            }
        }


        // Explicit globals for HTML onclick handlers.
        window.openNewStaff = openNewStaff;
        window.editStaff = editStaff;
        window.resetPIN = resetPIN;
        window.saveStaff = saveStaff;

        async function loadAccounting() {
            try {
                const invSnap = await db.collection("invoices").get();
                let rev = 0;
                invSnap.forEach(doc => {
                    const x = doc.data() || {};
                    if (String(x.status || 'PAID').toUpperCase() !== 'VOID') rev += Number(x.total || 0);
                });
                document.getElementById('accRevenue').innerText = formatMoney(rev);
                
                const expSnap = await db.collection("expenses").get();
                let exp = 0;
                let expRows = '';
                expSnap.forEach(doc => {
                    const d = doc.data();
                    exp += (d.amount || 0);
                    expRows += `
                        <tr class="hover:bg-gray-800/50">
                            <td class="p-4 text-xs text-gray-400">${d.createdAt ? new Date(d.createdAt.toDate()).toLocaleDateString('ms-MY') : '-'}</td>
                            <td class="p-4 text-xs font-bold">${d.category}</td>
                            <td class="p-4 text-white">${d.description}</td>
                            <td class="p-4 font-mono text-right text-red-400 font-bold">${formatMoney(d.amount)}</td>
                            <td class="p-4 text-xs">${d.createdBy}</td>
                        </tr>
                    `;
                });
                
                document.getElementById('accExpenses').innerText = formatMoney(exp);
                const net = rev - exp;
                const netEl = document.getElementById('accNet');
                netEl.innerText = formatMoney(net);
                netEl.className = net >= 0 ? "text-3xl font-bold text-white" : "text-3xl font-bold text-red-500";

                document.querySelector('#tblExpenses tbody').innerHTML = expRows || '<tr><td colspan="5" class="text-center p-4 text-gray-500">Tiada rekod</td></tr>';
            } catch (e) { console.error(e); }
        }

        async function loadAudit() {
            const tbody = document.querySelector('#tblAudit tbody');
            tbody.innerHTML = '<tr><td colspan="4" class="text-center p-4">Loading...</td></tr>';
            try {
                const snap = await db.collection("audit_logs").orderBy("timestamp", "desc").limit(100).get();
                let rows = '';
                snap.forEach(doc => {
                    const d = doc.data();
                    rows += `
                        <tr class="hover:bg-gray-800/50">
                            <td class="p-4 text-xs font-mono text-gray-400">${d.timestamp ? new Date(d.timestamp.toDate()).toLocaleString('ms-MY') : '-'}</td>
                            <td class="p-4 font-mono font-bold text-amber-500">${d.staffId}</td>
                            <td class="p-4 text-xs font-bold uppercase">${d.action}</td>
                            <td class="p-4 text-gray-300 text-sm">${d.details}</td>
                        </tr>
                    `;
                });
                tbody.innerHTML = rows || '<tr><td colspan="4" class="text-center p-4 text-gray-500">Tiada log</td></tr>';
            } catch(e) { tbody.innerHTML = `<tr><td colspan="4" class="text-center p-4 text-red-500">Ralat: ${e.message}</td></tr>`; }
        }

        async function exportToExcel(btn) {
            const origHTML = btn.innerHTML;
            btn.innerHTML = 'Memuat turun...';
            btn.disabled = true;

            try {
                const wb = XLSX.utils.book_new();

                const collections = [
                    { name: "customers", sheet: "Pelanggan" },
                    { name: "vehicles", sheet: "Kenderaan" },
                    { name: "inventory", sheet: "Inventori" },
                    { name: "stock_ledger", sheet: "LejarStok" },
                    { name: "invoices", sheet: "Invois" },
                    { name: "job_cards", sheet: "JobCard" },
                    { name: "grn", sheet: "GRN" },
                    { name: "expenses", sheet: "Perbelanjaan" },
                    { name: "staff", sheet: "Staf" }
                ];

                for (let c of collections) {
                    const snap = await db.collection(c.name).get();
                    const data = [];
                    snap.forEach(doc => {
                        let d = doc.data();
                        // Sanitization
                        if(d.pinHash) delete d.pinHash; 
                        if(d.createdAt && d.createdAt.toDate) d.createdAt = d.createdAt.toDate().toLocaleString();
                        if(d.timestamp && d.timestamp.toDate) d.timestamp = d.timestamp.toDate().toLocaleString();
                        if(d.updatedAt && d.updatedAt.toDate) d.updatedAt = d.updatedAt.toDate().toLocaleString();
                        // Convert complex objects to string for excel
                        if(d.items) d.items = JSON.stringify(d.items);
                        data.push(d);
                    });
                    if (data.length > 0) {
                        const ws = XLSX.utils.json_to_sheet(data);
                        XLSX.utils.book_append_sheet(wb, ws, c.sheet);
                    }
                }

                XLSX.writeFile(wb, `REV_TORQ_Export_${new Date().getTime()}.xlsx`);
                showToast("Laporan berjaya dieksport", 'success');
                await logAudit('EXPORT_DATA', 'Exported full Excel report');

            } catch (e) {
                showToast(`Gagal mengeksport: ${e.message}`, 'error');
            } finally {
                btn.innerHTML = origHTML;
                btn.disabled = false;
            }
        }

        async function loadSettings() {
            try {
                const doc = await db.collection("settings").doc("workshop").get();
                if(doc.exists) {
                    const d = doc.data();
                    document.getElementById('setWName').value = d.workshopName || '';
                    document.getElementById('setWReg').value = d.regNo || '';
                    document.getElementById('setWPhone').value = d.phone || '';
                    document.getElementById('setWAddress').value = d.address || '';
                    window.rtWorkshopProfile = {...d};
                }
            } catch(e) { console.error(e); }
        }

        async function saveSettings(e) {
            e.preventDefault();
            const btnId = 'btnSaveSettings';
            setOriginalText(btnId);
            toggleLoading(btnId, true);
            try {
                await db.collection("settings").doc("workshop").set({
                    workshopName: document.getElementById('setWName').value,
                    regNo: document.getElementById('setWReg').value,
                    phone: document.getElementById('setWPhone').value,
                    address: document.getElementById('setWAddress').value,
                    updatedAt: new Date().toISOString(),
                    updatedBy: currentProfile.staffId
                });
                window.rtWorkshopProfile = {
                    workshopName: document.getElementById('setWName').value,
                    regNo: document.getElementById('setWReg').value,
                    phone: document.getElementById('setWPhone').value,
                    address: document.getElementById('setWAddress').value
                };
                showToast("Tetapan disimpan.");
                await logAudit('UPDATE_SETTINGS', `Updated workshop settings`);
            } catch(e) { showToast(e.message, 'error'); }
            finally { toggleLoading(btnId, false); }
        }

        