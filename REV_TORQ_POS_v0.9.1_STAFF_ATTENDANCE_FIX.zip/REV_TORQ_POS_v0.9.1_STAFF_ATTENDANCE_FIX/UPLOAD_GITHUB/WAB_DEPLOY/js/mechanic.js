// ================= MY JOBS (POMEN) =================
        let pendingJobCustomerId = null;
        window.rtGetPendingJobCustomerId=()=>pendingJobCustomerId;
        window.rtClearPendingJobCustomer=()=>{pendingJobCustomerId=null;};
        let myJobPartsItems = [];

        function openCustomerFromJob() {
            pendingJobCustomerId = 'JOB';
            openNewCustomer();
        }

        async function loadJobCustomersForPomen() {
            const sel = document.getElementById('jcCustomerSelect');
            if (!sel) return;
            const current = sel.value;
            sel.innerHTML = '<option value="">-- Pilih Pelanggan --</option>';
            const snap = await db.collection('customers').orderBy('name').get();
            snap.forEach(doc => {
                const c = doc.data();
                sel.innerHTML += `<option value="${c.customerId || doc.id}" data-name="${String(c.name||'').replace(/"/g,'&quot;')}">${c.name} (${c.phone||'-'})</option>`;
            });
            if (current) sel.value = current;
        }

        async function loadPomenStock() {
            const tbody = document.querySelector('#tblPomenStock tbody');
            if (!tbody) return;
            tbody.innerHTML = '<tr><td colspan="5" class="text-center p-4">Loading...</td></tr>';
            try {
                const snap = await db.collection('inventory').where('active','==',true).get();
                let rows='';
                snap.forEach(doc=>{ const d=doc.data(); const stock=Number(d.stock||0); const price=Number(d.sellPrice ?? d.price ?? 0); const low=stock <= Number(d.minStock||5); rows += `<tr class="hover:bg-gray-800/50"><td class="p-3 font-mono text-amber-500 font-bold">${d.sku||doc.id}</td><td class="p-3 font-bold">${d.name||'-'}</td><td class="p-3 text-xs text-gray-400">${d.category||'-'}</td><td class="p-3 text-center font-mono font-bold ${low?'text-red-400':'text-white'}">${stock}</td><td class="p-3 text-right font-mono font-bold text-green-400">${formatMoney(price)}</td></tr>`; });
                tbody.innerHTML=rows || '<tr><td colspan="5" class="text-center p-4 text-gray-500">Tiada stok aktif</td></tr>';
            } catch(e){ tbody.innerHTML=`<tr><td colspan="5" class="text-center p-4 text-red-500">Ralat: ${e.message}</td></tr>`; }
        }

        async function loadJobPartsInventory() {
            const grid=document.getElementById('mjPartsStockGrid'); if(!grid) return;
            grid.innerHTML='<div class="text-xs text-gray-500 p-3">Loading stok...</div>';
            try {
                const snap=await db.collection('inventory').where('active','==',true).get();
                window.mjStockProducts=[]; snap.forEach(doc=>{ const d=doc.data(); window.mjStockProducts.push({sku:d.sku||doc.id,name:d.name||'',category:d.category||'',stock:Number(d.stock||0),price:Number(d.sellPrice ?? d.price ?? 0)}); });
                renderJobPartsStock(window.mjStockProducts);
            } catch(e){ grid.innerHTML=`<div class="text-xs text-red-400 p-3">Ralat stok: ${e.message}</div>`; }
        }

        function renderJobPartsStock(items){
            const grid=document.getElementById('mjPartsStockGrid'); if(!grid) return;
            if(!items.length){ grid.innerHTML='<div class="text-xs text-gray-500 p-3">Tiada item.</div>'; return; }
            grid.innerHTML=items.map(p=>`<button type="button" data-sku="${String(p.sku).replace(/&/g,"&amp;").replace(/"/g,"&quot;")}" onclick="addMyJobPart(this.dataset.sku)" class="text-left p-2 rounded-lg border border-gray-800 bg-gray-950/50 hover:border-amber-500 ${p.stock<=0?'opacity-50':''}"><div class="text-[10px] text-gray-500">${p.sku}</div><div class="text-xs font-bold text-white truncate">${p.name}</div><div class="flex justify-between mt-1 text-[10px]"><span class="${p.stock<=0?'text-red-400':'text-gray-400'}">Stok ${p.stock}</span><span class="text-amber-400 font-mono">${formatMoney(p.price)}</span></div></button>`).join('');
        }

        function filterMyJobStock(q){ const x=(q||'').toLowerCase(); renderJobPartsStock((window.mjStockProducts||[]).filter(p=>(p.name+' '+p.sku+' '+p.category).toLowerCase().includes(x))); }

        function addMyJobPart(sku){
            const p=(window.mjStockProducts||[]).find(x=>x.sku===sku); if(!p) return;
            if(p.stock<=0){ showToast('Stok item ini habis.','error'); return; }
            const ex=myJobPartsItems.find(x=>x.sku===sku);
            if(ex){ if(ex.qty>=p.stock){ showToast('Melebihi stok semasa.','error'); return;} ex.qty++; }
            else myJobPartsItems.push({sku:p.sku,name:p.name,qty:1,price:p.price});
            renderMyJobParts();
        }
        function removeMyJobPart(sku){ myJobPartsItems=myJobPartsItems.filter(x=>x.sku!==sku); renderMyJobParts(); }
        function renderMyJobParts(){ const el=document.getElementById('mjPartsItems'); if(!el) return; el.innerHTML=myJobPartsItems.length?myJobPartsItems.map(x=>`<div class="flex items-center justify-between bg-gray-900 rounded p-2 text-xs border border-gray-800"><div><b class="text-white">${x.name}</b><span class="text-gray-500 ml-2">${x.sku} × ${x.qty}</span></div><div class="flex items-center gap-2"><span class="text-amber-400 font-mono">${formatMoney(x.price*x.qty)}</span><button type="button" data-sku="${String(x.sku).replace(/&/g,"&amp;").replace(/"/g,"&quot;")}" onclick="removeMyJobPart(this.dataset.sku)" class="text-red-400">×</button></div></div>`).join(''):'<div class="text-[10px] text-gray-500">Belum ada barang ditambah.</div>'; }

        async function loadMyJobs() {
            const tbody = document.querySelector('#tblMyJobs tbody');
            tbody.innerHTML = '<tr><td colspan="5" class="text-center p-4">Loading...</td></tr>';
            
            try {
                // Support both the current schema (assignedStaffId) and the older schema (assignedStaffUid).
                // This prevents existing Job Cards from disappearing from the Pomen screen.
                const [snapById, snapByUid] = await Promise.all([
                    db.collection("job_cards")
                        .where("assignedStaffId", "==", currentProfile.uid)
                        .where("status", "in", ["OPEN", "IN_PROGRESS", "WAITING_PARTS"])
                        .get(),
                    db.collection("job_cards")
                        .where("assignedStaffUid", "==", currentProfile.uid)
                        .where("status", "in", ["OPEN", "IN_PROGRESS", "WAITING_PARTS"])
                        .get()
                ]);

                const docsById = new Map();
                snapById.forEach(doc => docsById.set(doc.id, doc));
                snapByUid.forEach(doc => docsById.set(doc.id, doc));
                
                let rows = '';
                docsById.forEach(doc => {
                    const d = doc.data();
                    let color = 'text-white';
                    if(d.status === 'WAITING_PARTS') color = 'text-amber-400';
                    if(d.status === 'IN_PROGRESS') color = 'text-blue-400';

                    rows += `
                        <tr class="hover:bg-gray-800/50">
                            <td class="p-4 font-mono font-bold text-amber-500">${d.jobNo}</td>
                            <td class="p-4 font-mono"><span class="bg-gray-800 px-2 py-1 rounded border border-gray-700">${d.plateNo}</span> <span class="text-xs text-gray-400 block mt-1">${d.vehicleModel}</span></td>
                            <td class="p-4 text-xs"><strong class="text-white block">Aduan:</strong> ${d.complaint}</td>
                            <td class="p-4 font-bold text-xs ${color}">${d.status}</td>
                            <td class="p-4 text-right">
                                <button onclick="openMyJobUpdate('${d.jobNo}')" class="bg-blue-600 hover:bg-blue-500 text-white px-3 py-1 rounded text-xs font-bold shadow-lg">UPDATE</button>
                            </td>
                        </tr>
                    `;
                });
                tbody.innerHTML = rows || '<tr><td colspan="5" class="text-center p-4 text-gray-500">Tiada tugasan aktif untuk anda.</td></tr>';
            } catch(e) { tbody.innerHTML = `<tr><td colspan="5" class="text-center p-4 text-red-500">Ralat: ${e.message}</td></tr>`; }
        }

        async function openMyJobUpdate(jobNo) {
            try {
                const doc = await db.collection('job_cards').doc(jobNo).get();
                if (!doc.exists) throw new Error('Job Card tidak dijumpai.');
                const d = doc.data();
                document.getElementById('mjJobId').value = jobNo;
                document.getElementById('mjJobNo').innerText = jobNo;
                document.getElementById('mjStatus').value = d.status === 'OPEN' ? 'IN_PROGRESS' : d.status;
                document.getElementById('mjNotes').value = d.diagnosis || '';
                renderInspectionChecklist('mjInspectionChecklist', d.inspectionChecklist || {});
                myJobPartsItems = Array.isArray(d.partsItems) ? d.partsItems : [];
                renderMyJobParts();
                await loadJobPartsInventory();
                openModal('myJobModal');
            } catch(e) { showToast(e.message, 'error'); }
        }

        async function saveMyJobStatus() {
            const btnId = 'btnSaveMyJob';
            setOriginalText(btnId);
            toggleLoading(btnId, true);

            const jobNo = document.getElementById('mjJobId').value;
            const status = document.getElementById('mjStatus').value;
            const notes = document.getElementById('mjNotes').value;
            const partsUsedNotes = document.getElementById('mjParts').value;
            const inspectionChecklist = collectInspectionChecklist('mjInspectionChecklist');
            const partsItems = myJobPartsItems.slice();
            const partsCost = partsItems.reduce((sum,x)=>sum + (Number(x.price||0)*Number(x.qty||0)),0);
            const combinedPartsNotes = [partsUsedNotes, ...partsItems.map(x=>`${x.name} (${x.sku}) x${x.qty} @ RM ${Number(x.price||0).toFixed(2)}`)].filter(Boolean).join(' | ');

            try {
                const jobSnap = await db.collection("job_cards").doc(jobNo).get();
                const laborCost = jobSnap.exists ? Number(jobSnap.data().laborCost ?? jobSnap.data().estLabor ?? 0) : 0;
                await db.collection("job_cards").doc(jobNo).update({
                    status: status,
                    diagnosis: notes,
                    partsUsedNotes: combinedPartsNotes,
                    partsItems,
                    partsCost,
                    total: partsCost + laborCost,
                    inspectionChecklist,
                    updatedAt: new Date().toISOString()
                });
                showToast("Status dikemaskini.");
                await logAudit('JOB_STATUS_CHANGE', `Updated job ${jobNo} to ${status}`);
                closeModal('myJobModal');
                loadMyJobs();
            } catch (e) { showToast(e.message, 'error'); } 
            finally { toggleLoading(btnId, false); }
        }

        