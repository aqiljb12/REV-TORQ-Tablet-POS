/* v0.8.6: one auth flow for WAB and APK. RLS/RPC remains authoritative. */
(function(){
'use strict';
const sb=window.supabaseClient;
const clean=v=>String(v??'').trim();
const roles=new Set(['owner','super_admin','admin','pos','staff','cashier','pomen','mechanic','stor']);
const aliases={administrator:'admin',superadmin:'super_admin','super admin':'super_admin'};
let busy=false, epoch=0, restoring=null, verified=null;
const el=id=>document.getElementById(id);
const toast=(message,type)=>{if(typeof window.showToast==='function')window.showToast(message,type);};
function roleOf(value){const r=clean(value).toLowerCase();return aliases[r]||r;}
function clearProfile(){
  verified=null;
  for(const storage of [localStorage,sessionStorage]){
    for(const key of ['revtorq_session','rt_override_mode','rt_auth_token'])storage.removeItem(key);
  }
  window.currentProfile=null;window.currentUser=null;
  if(typeof window.rtApplySupabaseProfile==='function')window.rtApplySupabaseProfile(null,null);
  if(typeof window.rtResetStaffContext==='function')window.rtResetStaffContext();
  if(typeof window.rtClearAuthUI==='function')window.rtClearAuthUI();
  el('appContainer')?.classList.add('hidden');
  el('loginScreen')?.classList.remove('hidden');
  if(el('loginPin'))el('loginPin').value='';
  el('rtAdminOverrideModal')?.remove();
  const modal=el('rtVoidModal');
  if(modal){modal.classList.add('hidden');modal.classList.remove('flex');modal.style.setProperty('display','none','important');}
}
async function revokeLocalSession(){
  sessionStorage.setItem('rt_auth_locked','1');
  let error=null;
  try{const r=await sb.auth.signOut({scope:'local'});error=r.error||null;}catch(e){error=e;}
  // Clear only this project's SDK token keys even if the network is unavailable.
  const key=window.rtAuthStorageKey;
  if(key)for(const suffix of ['', '-code-verifier', '-user'])localStorage.removeItem(key+suffix);
  clearProfile();
  return error;
}
async function verifiedStaff(expectedCode){
  const r=await sb.auth.getUser();
  if(r.error)throw r.error;
  const user=r.data?.user;
  if(!user?.id)throw new Error('Sesi login tidak sah. Sila login semula.');
  const result=await sb.from('staff')
    .select('id,staff_code,name,role,company_id,location_id,active,removed_from_active_list,auth_user_id')
    .eq('auth_user_id',user.id).eq('active',true).limit(2);
  if(result.error)throw result.error;
  const rows=result.data||[];
  if(rows.length!==1)throw new Error('Akaun mesti dipadankan kepada tepat satu staff aktif. Hubungi admin.');
  const staff=rows[0];
  if(staff.auth_user_id!==user.id || staff.active!==true || staff.removed_from_active_list===true)
    throw new Error('Pemadanan akaun staff tidak sah atau staff telah dinyahaktifkan.');
  if(!staff.id || !clean(staff.staff_code) || !staff.company_id)
    throw new Error('Profil staff belum lengkap. Hubungi admin.');
  if(expectedCode && clean(staff.staff_code).toUpperCase()!==clean(expectedCode).toUpperCase())
    throw new Error('Staff ID tidak sepadan dengan akaun yang disahkan.');
  if(!roles.has(roleOf(staff.role)))throw new Error('Peranan staff tidak dibenarkan untuk POS.');
  return {user,staff};
}
function applyProfile({user,staff}){
  const profile={uid:user.id,staffId:staff.staff_code,staffUuid:staff.id,
    name:staff.name||staff.staff_code,role:roleOf(staff.role),
    companyId:staff.company_id,locationId:staff.location_id||null};
  verified=Object.freeze({...profile});
  window.currentProfile=profile;window.currentUser=user;
  if(typeof window.rtApplySupabaseProfile==='function')window.rtApplySupabaseProfile(profile,user);
  // Display cache only, never used to establish identity or role.
  localStorage.setItem('revtorq_session',JSON.stringify(profile));
  return profile;
}
window.rtGetVerifiedStaff=verifiedStaff;
window.rtResolveVerifiedContext=async function(){
  if(sessionStorage.getItem('rt_auth_locked')==='1')throw new Error('Sila login semula.');
  const ticket=epoch;
  try{
    const pair=await verifiedStaff();
    if(ticket!==epoch)throw new Error('Sesi telah berubah. Cuba semula.');
    applyProfile(pair);
    return pair.staff;
  }catch(e){
    if(ticket===epoch){++epoch;clearProfile();}
    throw e;
  }
};
window.rtHasAdminAccess=()=>!!verified && verified.uid===window.currentUser?.id &&
  ['owner','super_admin','admin'].includes(verified.role);
async function displayApp(pair){
  applyProfile(pair);
  if(typeof window.initAppLayout==='function')window.initAppLayout();
  else{el('loginScreen')?.classList.add('hidden');el('appContainer')?.classList.remove('hidden');}
  try{
    if(['owner','super_admin','admin'].includes(roleOf(pair.staff.role)) && typeof window.loadDashboard==='function')await window.loadDashboard();
    if(typeof window.rtAttendanceRefresh==='function')await window.rtAttendanceRefresh();
  }catch(_){toast('Login berjaya, tetapi sebahagian data belum dapat dimuatkan.','info');}
}
window.handleLogin=async function(e){
  e?.preventDefault();
  if(busy)return;
  const staffId=clean(el('loginId')?.value).toUpperCase();
  const pin=clean(el('loginPin')?.value);
  if(!staffId || !/^\d{6}$/.test(pin)){toast('ID staff dan PIN 6 digit diperlukan.','error');return;}
  busy=true;const ticket=++epoch;
  if(el('btnLogin'))el('btnLogin').disabled=true;
  clearProfile();
  try{
    const r=await sb.rpc('get_staff_login_email',{p_staff_id:staffId});
    if(ticket!==epoch)return;
    if(r.error || !clean(r.data))throw new Error('ID staff atau PIN tidak sah.');
    const a=await sb.auth.signInWithPassword({email:clean(r.data),password:pin});
    if(ticket!==epoch){await revokeLocalSession();return;}
    if(a.error)throw new Error('ID staff atau PIN tidak sah.');
    const pair=await verifiedStaff(staffId);
    if(ticket!==epoch){await revokeLocalSession();return;}
    sessionStorage.removeItem('rt_auth_locked');
    await displayApp(pair);
    if(ticket===epoch)toast('Login berjaya.','success');
  }catch(err){
    if(ticket===epoch){await revokeLocalSession();toast('Login gagal: '+err.message,'error');}
  }finally{
    busy=false;
    if(el('btnLogin'))el('btnLogin').disabled=false;
    if(el('loginPin'))el('loginPin').value='';
  }
};
window.handleLogout=async function(){
  ++epoch;clearProfile();
  const error=await revokeLocalSession();
  if(error)sessionStorage.setItem('rt_logout_notice','Sesi tempatan dibersihkan. Pembatalan sesi di pelayan belum disahkan kerana ralat rangkaian.');
  // Reload also discards SDK in-memory credentials after an offline signout.
  location.reload();
};
window.restoreSession=function(){
  if(restoring)return restoring;
  if(busy)return Promise.resolve();
  if(sessionStorage.getItem('rt_auth_locked')==='1'){clearProfile();return Promise.resolve();}
  const ticket=epoch;
  restoring=(async()=>{
    try{
      const r=await sb.auth.getSession();
      if(ticket!==epoch || busy)return;
      if(r.error)throw r.error;
      if(!r.data?.session){clearProfile();return;}
      const pair=await verifiedStaff();
      if(ticket===epoch && !busy)await displayApp(pair);
    }catch(_){
      if(ticket===epoch && !busy){await revokeLocalSession();toast('Sesi tidak dapat disahkan. Sila login semula.','error');}
    }
  })().finally(()=>{restoring=null;});
  return restoring;
};
window.setupInitialAdmin=async function(){
  // Production browser must not provision an owner anonymously.
  toast('Setup owner dari browser dinyahaktifkan. Gunakan akaun owner sedia ada; akaun baharu memerlukan semakan admin database.','info');
};
window.testSupabase=async()=>{
  const r=await sb.auth.getSession();
  if(typeof window.dbgLog==='function')window.dbgLog('Supabase Auth: '+(r.error?'ERROR':r.data?.session?'SESSION EXISTS':'NO SESSION'));
};
window.testSupabaseDB=async()=>{
  const r=await sb.from('companies').select('id').limit(1);
  if(r.error)throw r.error;
  if(typeof window.dbgLog==='function')window.dbgLog('Supabase DB: CONNECTED');
};
clearProfile();
const logoutNotice=sessionStorage.getItem('rt_logout_notice');
if(logoutNotice){sessionStorage.removeItem('rt_logout_notice');toast(logoutNotice,'info');}
sb.auth.onAuthStateChange((event,session)=>{
  // No awaited Auth calls inside this callback (SDK lock).
  if(event==='SIGNED_OUT'){
    ++epoch;clearProfile();
  }else if(verified && session?.user?.id && session.user.id!==verified.uid){
    ++epoch;clearProfile();
  }
});
// main.js calls restoreSession once on DOMContentLoaded.
})();
