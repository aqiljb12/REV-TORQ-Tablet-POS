/* REV TORQ v0.7.7 — DUAL CLIENT (WAB + APK)
   Purpose:
   - APK and browser WAB may run at the same time against the same Supabase production database.
   - Keep each client identity/session local to its own browser/WebView.
   - Do NOT create a second database or duplicate company/location records.
   - Cash drawer remains the canonical shared MAIN drawer because current production RPC
     rt_cash_move / rt_cash_close do not accept a drawer_code parameter.
*/
(function(){
  'use strict';
  const isNative = new URLSearchParams(location.search).get('native') === '1' ||
    location.hostname === 'appassets.androidplatform.net';
  const CLIENT_KIND = isNative ? 'APK' : 'WAB';
  const KEY = `rt_client_device_id_${CLIENT_KIND.toLowerCase()}_v077`;

  function makeId(){
    const uuid = (globalThis.crypto && crypto.randomUUID) ? crypto.randomUUID() :
      (Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));
    return `REV-${CLIENT_KIND}-${uuid}`;
  }
  let id = localStorage.getItem(KEY);
  if(!id){ id = makeId(); localStorage.setItem(KEY,id); }

  window.rtClient = Object.freeze({
    kind: CLIENT_KIND,
    isNative,
    deviceId: id,
    sharedDatabase: true,
    cashDrawerCode: 'MAIN'
  });

  // Compatibility: canonical modules may ask rtNetwork for a device id.
  window.addEventListener('load',()=>{
    try{
      if(window.rtNetwork && typeof window.rtNetwork.getDeviceId === 'function'){
        window.rtClient.legacyDeviceId = window.rtNetwork.getDeviceId();
      }
    }catch(_){ }
  });

  // When returning to the app/browser, refresh whichever canonical data loaders exist.
  // This lets a sale/stock change made on WAB appear on APK and vice versa without
  // requiring a full app restart. Calls are throttled to avoid hammering Supabase.
  let lastRefresh = 0;
  async function refreshSharedState(){
    const now=Date.now();
    if(now-lastRefresh<5000 || navigator.onLine===false) return;
    lastRefresh=now;
    const fns=['rtRefreshCashDrawer','loadPOS','loadInventory','loadJobCards'];
    for(const name of fns){
      try{ if(typeof window[name]==='function') await window[name](); }catch(e){ console.debug('dual refresh',name,e); }
    }
  }
  window.rtRefreshSharedState = refreshSharedState;
  window.addEventListener('focus',()=>setTimeout(refreshSharedState,250));
  window.addEventListener('online',()=>setTimeout(refreshSharedState,500));
  document.addEventListener('visibilitychange',()=>{ if(!document.hidden) setTimeout(refreshSharedState,250); });
})();
