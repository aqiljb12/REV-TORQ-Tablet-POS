/* REV TORQ V36.4.9.11 — UI EVENT RECOVERY
   Purpose: guarantee navigation/touch controls remain callable after legacy
   modules are removed/overridden. No database writes. */
(function(){
  'use strict';
  function byId(id){return document.getElementById(id)}
  function safe(fn){try{fn()}catch(e){console.warn('UI recovery:',e)}}

  function expose(){
    // Explicit public bindings for classic scripts.
    ['switchView','toggleSidebar','openModal','closeModal','initAppLayout'].forEach(k=>{
      if(typeof window[k]==='function') return;
      try{
        if(k==='switchView' && typeof switchView==='function') window.switchView=switchView;
        if(k==='toggleSidebar' && typeof toggleSidebar==='function') window.toggleSidebar=toggleSidebar;
        if(k==='openModal' && typeof openModal==='function') window.openModal=openModal;
        if(k==='closeModal' && typeof closeModal==='function') window.closeModal=closeModal;
        if(k==='initAppLayout' && typeof initAppLayout==='function') window.initAppLayout=initAppLayout;
      }catch(_){ }
    });
  }

  function navRecovery(){
    const nav=byId('mainNav');
    if(!nav || nav.dataset.rtUiRecovery==='1') return;
    nav.dataset.rtUiRecovery='1';
    nav.addEventListener('click',function(e){
      const btn=e.target.closest('button[data-view],button[id^="nav-"]');
      if(!btn) return;
      const view=btn.dataset.view || btn.id.replace(/^nav-/,'');
      if(!view || typeof window.switchView!=='function') return;
      // Capture-safe fallback: the inline onclick may have been stripped by
      // a browser/webview optimizer, so invoke the public API directly.
      e.preventDefault();
      e.stopPropagation();
      safe(()=>window.switchView(view));
    },true);
  }

  function sidebarRecovery(){
    const side=byId('sidebar'), overlay=byId('sidebarOverlay');
    if(!side) return;
    const btn=side.querySelector('button.md\\:hidden[onclick*="toggleSidebar"], button[onclick*="toggleSidebar"]');
    if(btn && !btn.dataset.rtBound){btn.dataset.rtBound='1';btn.addEventListener('click',e=>{e.preventDefault();safe(()=>window.toggleSidebar?.())})}
    if(overlay) overlay.addEventListener('click',()=>safe(()=>window.toggleSidebar?.()));
  }

  function clearStaleUiLocks(){
    // These are only startup guards. A real modal can re-open itself afterward.
    const app=byId('appContainer');
    if(!app || app.classList.contains('hidden')) return;
    ['debugPanel','sidebarOverlay','modalOverlay'].forEach(id=>{
      const el=byId(id); if(el && !el.dataset.rtKeepOpen) el.classList.add('hidden');
    });
    document.body.style.pointerEvents='';
    if(app) app.style.pointerEvents='auto';
  }

  function bindTouch(){
    const app=byId('appContainer');
    if(!app)return;
    app.style.pointerEvents='auto';
    document.querySelectorAll('#mainNav button,#sidebar button,button').forEach(b=>{
      if(b.disabled) return;
      if(!b.style.pointerEvents)b.style.pointerEvents='auto';
    });
  }

  function boot(){
    expose();navRecovery();sidebarRecovery();clearStaleUiLocks();bindTouch();
    // Rebind after navigation rebuilds the sidebar.
    setTimeout(()=>{expose();navRecovery();sidebarRecovery();clearStaleUiLocks();bindTouch()},500);
    setTimeout(()=>{expose();navRecovery();sidebarRecovery();bindTouch()},1500);
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true});
  else boot();
  window.addEventListener('load',boot);
})();
