/* REV TORQ V38.6.13 - Inventory dedicated page */
(function(){
  'use strict';

  function $(id){return document.getElementById(id);}

  function mountInventoryForm(){
    const host=$('rtInventoryFormHost'), modal=$('inventoryModal');
    if(!host||!modal||modal.parentElement===host) return;
    host.appendChild(modal);
    modal.classList.remove('hidden');
    modal.classList.add('rt-inventory-form-page');
    modal.style.display='block';
    const form=modal.querySelector('form');
    if(form) form.classList.add('rt-inventory-form');
    const close=modal.querySelector('button[onclick*="closeModal(\'inventoryModal\')"]');
    if(close) close.setAttribute('onclick','closeInventoryPage()');
    if(window.feather) try{feather.replace();}catch(_){}
  }

  function applyPendingBarcode(){
    const val=String(window.rtPendingInventoryBarcode||'').trim();
    const el=$('invBarcode');
    if(!val||!el)return false;
    el.value=val;
    el.defaultValue=val;
    el.setAttribute('value',val);
    try{el.dispatchEvent(new Event('input',{bubbles:true}));}catch(_){}
    try{el.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){}
    return true;
  }

  function openInventoryPage(title,subtitle){
    mountInventoryForm();
    if (typeof window.rtApplyActiveView === 'function') {
      window.rtApplyActiveView('inventory-form');
    } else {
      document.querySelectorAll('.view-section').forEach(v=>{v.hidden=true;v.classList.add('hidden');v.style.setProperty('display','none','important');});
      const view=$('view-inventory-form');
      if(view){view.hidden=false;view.removeAttribute('hidden');view.classList.remove('hidden');view.style.setProperty('display','block','important');}
    }
    if($('rtInvPageTitle')) $('rtInvPageTitle').textContent=title||'Tambah Inventori Baru';
    if($('rtInvPageSubtitle')) $('rtInvPageSubtitle').textContent=subtitle||'Daftarkan item, barcode, harga dan stok permulaan.';
    applyPendingBarcode();
    [0,25,75,150,300,600,1000].forEach(ms=>setTimeout(applyPendingBarcode,ms));
    window.scrollTo({top:0,behavior:'instant'});
    if(window.feather) try{feather.replace();}catch(_){}
  }

  window.closeInventoryPage=function(){
    const modal=$('inventoryModal');
    if(modal){
      modal.classList.add('hidden');
      modal.style.display='none';
    }
    const view=$('view-inventory-form');
    if(view) view.classList.add('hidden');
    try{window.switchView('inventory');}catch(_){
      const inv=$('view-inventory'); if(inv) inv.classList.remove('hidden');
    }
    window.scrollTo({top:0,behavior:'instant'});
    if(window.feather) try{feather.replace();}catch(_){}
  };

  
  // Route inventory add/edit actions to the dedicated page.
  function installInventoryRoutes(){
    if(window.__rtInventoryPageRoutesInstalled) return;
    window.__rtInventoryPageRoutesInstalled=true;

    const oldOpen=window.openNewInventory;
    if(typeof oldOpen==='function'){
      window.__rtOriginalOpenNewInventory=oldOpen;
      window.openNewInventory=function(){
        oldOpen.apply(this,arguments);
        openInventoryPage('Tambah Inventori Baru','Daftarkan item, barcode, harga dan stok permulaan.');
      };
    }

    const oldEdit=window.editInventory;
    if(typeof oldEdit==='function'){
      window.__rtOriginalEditInventory=oldEdit;
      window.editInventory=async function(sku){
        await oldEdit.apply(this,arguments);
        openInventoryPage('Kemaskini Inventori','Semak dan kemaskini maklumat item inventori.');
      };
    }
  }
  window.openInventoryPage=openInventoryPage;
  window.closeInventoryPage=window.closeInventoryPage;
  document.addEventListener('DOMContentLoaded', function(){
    mountInventoryForm();
    installInventoryRoutes();
  });
  setTimeout(installInventoryRoutes, 0);
  setTimeout(installInventoryRoutes, 250);

})();