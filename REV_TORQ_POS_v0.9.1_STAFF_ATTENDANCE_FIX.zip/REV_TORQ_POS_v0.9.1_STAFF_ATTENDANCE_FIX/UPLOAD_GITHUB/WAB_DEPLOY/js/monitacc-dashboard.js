/* REV TORQ — Monitacc-style mobile dashboard + admin P&L
   Additive module. Uses Supabase RPC for financial figures. */
(function(){
  'use strict';
  const sb=window.supabaseClient;
  const money=n=>'RM '+Number(n||0).toLocaleString('ms-MY',{minimumFractionDigits:2,maximumFractionDigits:2});
  const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  const admin=()=>['owner','admin','super_admin','manager'].includes(String(window.currentProfile?.role||'').toLowerCase());
  let period='ALL';
  let lastData=null;

  function localISO(d){
    const x=new Date(d); const y=x.getFullYear(); const m=String(x.getMonth()+1).padStart(2,'0'); const day=String(x.getDate()).padStart(2,'0');
    return `${y}-${m}-${day}`;
  }
  function rangeFor(mode){
    const now=new Date(); const end=new Date(now.getFullYear(),now.getMonth(),now.getDate());
    let start=new Date(end);
    if(mode==='TODAY') start=new Date(end);
    else if(mode==='WEEK'){ const day=end.getDay(); const diff=(day+6)%7; start.setDate(end.getDate()-diff); }
    else if(mode==='MONTH') start=new Date(end.getFullYear(),end.getMonth(),1);
    else if(mode==='YEAR') start=new Date(end.getFullYear(),0,1);
    else start=new Date(end.getFullYear(),0,1);
    return {start:localISO(start),end:localISO(end)};
  }

  async function rpcData(){
    if(!admin()) throw new Error('Akses Admin sahaja.');
    const r=rangeFor(period);
    const res=await sb.rpc('rt_admin_dashboard',{p_start:r.start,p_end:r.end});
    if(res.error) throw res.error;
    return res.data||{};
  }

  function skeleton(){
    return `<div class="rtm-shell">
      <div class="rtm-hero"><div><div class="rtm-kicker">REV TORQ • WORKSHOP ERP</div><h1>Selamat kembali, ${esc(window.currentProfile?.name||'AQIL')}</h1><p>Pantauan bengkel dalam satu skrin.</p></div><button class="rtm-icon" onclick="window.rtLoadAdminDashboard()" aria-label="Refresh">↻</button></div>
      <div class="rtm-net"><div><span>UNTUNG BERSIH</span><strong id="rtmNet">RM 0.00</strong><small id="rtmPeriod">Hari ini</small></div><div class="rtm-net-icon">↗</div></div>
      <div class="rtm-tabs" id="rtmTabs">
        <button data-p="ALL" class="active">SEMUA</button><button data-p="TODAY">HARIAN</button><button data-p="WEEK">MINGGUAN</button><button data-p="MONTH">BULANAN</button><button data-p="YEAR">TAHUNAN</button>
      </div>
      <div class="rtm-kpis">
        <article><span class="rtm-ico in">↗</span><small>DUIT MASUK</small><b id="rtmSales">RM 0.00</b></article>
        <article><span class="rtm-ico out">↘</span><small>DUIT KELUAR</small><b id="rtmExpenses">RM 0.00</b></article>
        <article><span class="rtm-ico cash">$</span><small>BAKI TUNAI</small><b id="rtmCash">RM 0.00</b></article>
        <article><span class="rtm-ico rec">▤</span><small>BIL. REKOD</small><b id="rtmTx">0</b></article>
      </div>
      <div class="rtm-section-head"><div><h2>Prestasi Bengkel</h2><p>Operasi dan kewangan tempoh dipilih.</p></div><button onclick="window.switchView('reports')">Lihat P&L →</button></div>
      <div class="rtm-profit-card"><div><span>JUALAN</span><b id="rtmGrossSales">RM 0.00</b></div><div><span>COGS</span><b id="rtmCogs">RM 0.00</b></div><div><span>GROSS PROFIT</span><b id="rtmGross">RM 0.00</b></div></div>
      <div class="rtm-section-head"><div><h2>Operasi Bengkel</h2><p>Ringkasan yang perlu tindakan.</p></div></div>
      <div class="rtm-ops"><button onclick="window.switchView('jobcard')"><b id="rtmJobs">0</b><span>Job Aktif</span></button><button onclick="window.switchView('customers')"><b id="rtmCustomers">0</b><span>Pelanggan</span></button><button onclick="window.switchView('inventory')"><b id="rtmLow">0</b><span>Stok Rendah</span></button></div>
      <div class="rtm-section-head"><div><h2>Transaksi Terkini</h2><p>Jualan dan belanja terbaru.</p></div></div>
      <div id="rtmRecent" class="rtm-list"><div class="rtm-empty">Memuatkan...</div></div>
    </div>`;
  }

  function inject(){
    const v=document.getElementById('view-dashboard'); if(!v)return;
    v.innerHTML=skeleton();
    document.querySelectorAll('.rtm-tabs button').forEach(b=>b.addEventListener('click',()=>{period=b.dataset.p||'ALL';document.querySelectorAll('.rtm-tabs button').forEach(x=>x.classList.toggle('active',x===b));load();}));
  }

  async function recent(){
    const out=[];
    const [inv,exp]=await Promise.all([
      sb.from('invoices').select('id,invoice_no,total,status,created_at').eq('status','PAID').is('voided_at',null).order('created_at',{ascending:false}).limit(8),
      sb.from('expenses').select('id,expense_no,category,description,amount,created_at').order('created_at',{ascending:false}).limit(8)
    ]);
    if(!inv.error)(inv.data||[]).forEach(x=>out.push({date:x.created_at,type:'in',title:x.invoice_no||'Jualan POS',desc:'Jualan',amount:x.total,status:x.status}));
    if(!exp.error)(exp.data||[]).forEach(x=>out.push({date:x.created_at,type:'out',title:x.expense_no||x.category||'Belanja',desc:x.description||x.category||'Perbelanjaan',amount:x.amount,status:'EXPENSE'}));
    out.sort((a,b)=>new Date(b.date)-new Date(a.date));
    return out.slice(0,8);
  }

  async function load(){
    const ids=['rtmNet','rtmSales','rtmExpenses','rtmCash','rtmTx','rtmGrossSales','rtmCogs','rtmGross','rtmJobs','rtmCustomers','rtmLow'];
    ids.forEach(id=>{const e=document.getElementById(id);if(e)e.classList.add('rtm-loading');});
    try{
      const d=await rpcData(); lastData=d;
      const set=(id,val)=>{const e=document.getElementById(id);if(e){e.textContent=val;e.classList.remove('rtm-loading');}};
      set('rtmNet',money(d.net_profit)); set('rtmSales',money(d.sales)); set('rtmExpenses',money(d.expenses)); set('rtmCash',money(d.cash_expected)); set('rtmTx',Number(d.transactions||0));
      set('rtmGrossSales',money(d.sales)); set('rtmCogs',money(d.cogs)); set('rtmGross',money(d.gross_profit)); set('rtmJobs',Number(d.active_jobs||0)); set('rtmCustomers',Number(d.customers||0)); set('rtmLow',Number(d.low_stock||0));
      const labels={ALL:'Tahun semasa',TODAY:'Hari ini',WEEK:'Minggu ini',MONTH:'Bulan ini',YEAR:'Tahun ini'}; const p=document.getElementById('rtmPeriod');if(p)p.textContent=labels[period]||labels.ALL;
      const list=document.getElementById('rtmRecent'); if(list){const rows=await recent();list.innerHTML=rows.length?rows.map(x=>`<div class="rtm-row"><span class="rtm-row-icon ${x.type}">${x.type==='in'?'↗':'↘'}</span><div><b>${esc(x.title)}</b><small>${esc(x.desc)} · ${new Date(x.date).toLocaleString('ms-MY',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}</small></div><strong class="${x.type==='in'?'in':'out'}">${x.type==='in'?'+':'−'} ${money(x.amount)}</strong></div>`).join(''):'<div class="rtm-empty">Belum ada transaksi.</div>';}
    }catch(e){
      console.error(e); const v=document.getElementById('view-dashboard'); if(v)v.innerHTML=`<div class="rtm-error"><b>Dashboard gagal dimuatkan</b><span>${esc(e.message||e)}</span><button onclick="window.rtLoadAdminDashboard()">Cuba semula</button></div>`;
    }
  }

  async function loadAdminDashboard(){inject();await load();}
  // V38.6.10: Do NOT replace the main REV TORQ dashboard with the legacy
  // Monitacc mobile dashboard. The commercial dashboard in index.html is the
  // canonical dashboard for desktop, tablet and phone.
  window.rtLoadAdminDashboard=loadAdminDashboard;

  function reports(){
    const v=document.getElementById('view-reports');if(!v)return;
    v.innerHTML=`<div class="rt-report-shell"><div class="rt-report-head"><div><div class="rtm-kicker">ADMIN • FINANCIAL REPORT</div><h1>Profit & Loss</h1><p>Kiraan berdasarkan Sales − COGS − Expenses.</p></div><button class="rtm-icon" onclick="window.rtLoadReports()">↻</button></div><div class="rt-report-filters"><button data-p="ALL" class="active">SEMUA</button><button data-p="TODAY">HARIAN</button><button data-p="MONTH">BULANAN</button><button data-p="YEAR">TAHUNAN</button></div><div class="rt-pnl-grid"><article><small>SALES</small><b id="rSales">RM 0.00</b></article><article><small>COGS</small><b id="rCogs">RM 0.00</b></article><article><small>GROSS PROFIT</small><b id="rGross">RM 0.00</b></article><article><small>EXPENSES</small><b id="rExp">RM 0.00</b></article><article class="net"><small>NET PROFIT / LOSS</small><b id="rNet">RM 0.00</b></article></div><div class="rt-pnl-breakdown"><div><span>Sales</span><b id="rbSales">RM 0.00</b></div><div><span>− Cost of Sales</span><b id="rbCogs">RM 0.00</b></div><div class="line"><span>Gross Profit</span><b id="rbGross">RM 0.00</b></div><div><span>− Operating Expenses</span><b id="rbExp">RM 0.00</b></div><div class="line total"><span>Net Profit / Loss</span><b id="rbNet">RM 0.00</b></div></div><div class="rt-report-note">COGS mengambil kos sejarah daripada <code>stock_movements.unit_cost</code>. Transaksi VOID tidak dikira.</div></div>`;
    document.querySelectorAll('.rt-report-filters button').forEach(b=>b.addEventListener('click',()=>{period=b.dataset.p||'ALL';document.querySelectorAll('.rt-report-filters button').forEach(x=>x.classList.toggle('active',x===b));loadReportData();}));
    loadReportData();
  }
  async function loadReportData(){
    try{const d=await rpcData();const set=(id,val)=>{const e=document.getElementById(id);if(e)e.textContent=val;};set('rSales',money(d.sales));set('rCogs',money(d.cogs));set('rGross',money(d.gross_profit));set('rExp',money(d.expenses));set('rNet',money(d.net_profit));set('rbSales',money(d.sales));set('rbCogs',money(d.cogs));set('rbGross',money(d.gross_profit));set('rbExp',money(d.expenses));set('rbNet',money(d.net_profit));}
    catch(e){const v=document.querySelector('.rt-report-shell');if(v)v.insertAdjacentHTML('beforeend',`<div class="rtm-error"><b>Gagal memuat P&L</b><span>${esc(e.message||e)}</span></div>`);}
  }
  window.rtLoadReports=reports;
  const oldReports=window.loadAccounting;
  window.addEventListener('load',()=>{
    setTimeout(()=>{
      // V38.6.10: dashboard injection intentionally disabled.
      // Keep this module for admin financial reports / P&L only.
      // The canonical dashboard is rendered by index.html + js/dashboard.js.
      // Add an admin-only Override shortcut to the existing POS history modal.
      if(admin()){
        const nav=document.getElementById('mainNav');
        if(nav && !document.getElementById('nav-override')){
          const b=document.createElement('button');b.id='nav-override';b.type='button';b.className='w-full flex items-center gap-3 px-4 py-3 text-gray-400 hover:text-white hover:bg-gray-800/50 rounded-xl transition-all text-sm font-medium';b.innerHTML='<i data-feather="shield" class="w-4 h-4"></i> Override / Audit';b.onclick=()=>window.rtOpenPosHistory?.(true);nav.appendChild(b);if(window.feather)feather.replace();
        }
      }
    },1200);
  });
})();
