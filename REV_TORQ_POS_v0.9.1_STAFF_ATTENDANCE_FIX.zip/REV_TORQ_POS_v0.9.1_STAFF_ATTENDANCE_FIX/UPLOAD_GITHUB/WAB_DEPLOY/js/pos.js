// ================= POS & TRANSACTIONS =================
        let posCart = [];
        let posPayMethod = 'CASH';
        let allProducts = [];

// Production hardening bridge: expose POS cart safely without changing legacy lexical state.
window.rtGetPosCart = () => posCart;
window.rtSetPosCart = (v) => { posCart = Array.isArray(v) ? v : []; renderCart(); };
window.rtRenderPosCart = renderCart;

        async function loadPOS() {
            // V34.3: POS opens immediately and inventory loading is lightweight.
            // Avoid composite-index dependency for the initial POS screen.
            try {
                if (!window.db) throw new Error("Firebase belum tersedia.");
                allProducts = [];
                window.posProducts = [];

                let snap;
                try {
                    snap = await db.collection("inventory")
                        .orderBy("sku")
                        .limit(50)
                        .get();
                } catch (firstErr) {
                    console.warn("POS indexed query fallback:", firstErr);
                    snap = await db.collection("inventory").limit(50).get();
                }

                snap.forEach(doc => {
                    const d = doc.data() || {};
                    if (d.active === false) return;
                    allProducts.push({
                        ...d,
                        sku: String(d.sku || doc.id),
                        name: String(d.name || doc.id),
                        category: String(d.category || "Lain-lain"),
                        price: Number(d.sellPrice ?? d.price ?? 0),
                        cost: Number(d.cost || 0)
                    });
                });

                window.posProducts = allProducts.slice();
                renderPosGrid(allProducts);
            } catch (e) {
                console.error("Error loading POS inventory", e);
                window.posProducts = [];
                try { renderPosGrid([]); } catch (_) {}
                try {
                    showToast("POS dibuka, tetapi inventori belum dapat dimuat. Semak internet/Supabase.", "error");
                } catch (_) {}
            }
        }

        function posFilterProducts(query) {
            const q = query.toLowerCase();
            const filtered = allProducts.filter(p => p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q) || String(p.barcode || '').toLowerCase().includes(q) || String(p.rackCode || '').toLowerCase().includes(q) || p.category.toLowerCase().includes(q));
            renderPosGrid(filtered);
        }

        function renderPosGrid(products) {
            // The enhanced POS UI is additive. Always route through it when available,
            // including calls from the original app.js lexical scope.
            if (typeof window.rtRenderEnhanced === 'function') {
                window.posProducts = (products || allProducts || []).slice();
                window.rtRenderEnhanced(products || window.posProducts);
                return;
            }
            const grid = document.getElementById('posProductGrid');
            if (!grid) return;
            let html = '';
            products.forEach(p => {
                const isLow = p.stock <= (p.minStock || 5);
                html += `
                    <div class="glass-panel p-4 rounded-xl border ${isLow ? 'border-red-900/50' : 'border-gray-800'} cursor-pointer hover:border-amber-500 transition-colors group flex flex-col" onclick="posAddToCart('${p.sku}', '${p.name.replace(/'/g, "\\'")}', ${p.sellPrice}, ${p.stock})">
                        <span class="text-[10px] text-gray-500 font-bold tracking-wider mb-1">${p.category}</span>
                        <h4 class="text-sm font-bold text-white leading-tight mb-2 flex-1 group-hover:text-amber-500 transition-colors">${p.name}</h4>
                        <div class="flex justify-between items-end mt-auto">
                            <span class="text-lg font-black text-amber-500 font-mono">RM ${Number(p.price ?? p.sellPrice ?? 0).toFixed(2)}</span>
                            <span class="text-xs font-mono font-bold px-2 py-1 rounded bg-gray-900 ${isLow ? 'text-red-400' : 'text-gray-400'}">Stok: ${p.stock}</span>
                        </div>
                    </div>
                `;
            });
            grid.innerHTML = html;
        }

        function posAddToCart(sku, name, price, maxStock) {
            const source = allProducts.find(i => String(i.sku) === String(sku)) || (window.posProducts || []).find(i => String(i.sku) === String(sku));
            if (source) {
                name = source.name;
                price = Number(source.price ?? source.sellPrice ?? 0);
                maxStock = Number(source.stock ?? 0);
            }
            if (Number(maxStock) <= 0) {
                showToast("Stok habis!", "error");
                return;
            }
            const exist = posCart.find(i => i.sku === sku);
            if (exist) {
                if(exist.qty >= Number(maxStock)) { showToast("Melebihi had stok!", "error"); return; }
                exist.qty++;
            } else {
                posCart.push({ sku, name: name || sku, price: Number(price || 0), qty: 1, maxStock: Number(maxStock) });
            }
            renderCart();
        }

        function posUpdateQty(sku, delta) {
            const item = posCart.find(i => i.sku === sku);
            if(!item) return;
            item.qty += delta;
            if(item.qty > item.maxStock) {
                item.qty = item.maxStock;
                showToast("Melebihi had stok!", "error");
            }
            if(item.qty <= 0) {
                posCart = posCart.filter(i => i.sku !== sku);
            }
            renderCart();
        }

        function posClearCart() { posCart = []; renderCart(); }

        function renderCart() {
            const list = document.getElementById('posCartList');
            const count = document.getElementById('rtCartCount');
            if (!list) return;
            if(count) count.textContent = posCart.reduce((n,i)=>n+Number(i.qty||0),0);
            if (posCart.length === 0) {
                list.innerHTML = '<div class="rt-cart-empty">Troli kosong</div>';
                posCalculateTotal();
                if(window.feather) feather.replace();
                return;
            }
            list.innerHTML = posCart.map((item,idx) => {
                const total=Number(item.qty||0)*Number(item.price||0);
                return `<div class="rt-cart-row">
                  <span>${idx+1}</span>
                  <div><div class="item-title">${String(item.name||item.sku)}</div><div class="item-sub">${String(item.sku||'')}</div></div>
                  <div class="rt-qty"><button onclick="posUpdateQty('${String(item.sku).replace(/'/g,"\\'")}',-1)">−</button><span>${item.qty}</span><button onclick="posUpdateQty('${String(item.sku).replace(/'/g,"\\'")}',1)">+</button></div>
                  <div class="rt-cart-price">${formatMoney(item.price)}</div>
                  <div class="discount">0.00</div>
                  <div class="rt-cart-total">${formatMoney(total)}</div>
                  <button class="rt-cart-remove" onclick="posUpdateQty('${String(item.sku).replace(/'/g,"\\'")}',-${Number(item.qty||1)})">×</button>
                </div>`;
            }).join('');
            posCalculateTotal();
            if(window.feather) feather.replace();
        }

        function posCalculateTotal() {
            let sub = 0;
            posCart.forEach(i => sub += (i.qty * i.price));
            const disc = parseFloat(document.getElementById('posDiscount').value) || 0;
            const total = sub - disc;
            
            document.getElementById('posSubtotal').innerText = formatMoney(sub);
            document.getElementById('posTotal').innerText = formatMoney(total > 0 ? total : 0);

            const received = parseFloat(document.getElementById('posAmountReceived').value) || 0;
            const change = received - (total > 0 ? total : 0);
            const changeEl = document.getElementById('posChange');
            changeEl.innerText = formatMoney(change);
            changeEl.className = change >= 0 ? "font-mono text-green-400 font-bold" : "font-mono text-red-400 font-bold";
        }

        function posSetPaymentMethod(method) {
            posPayMethod = method;
            document.querySelectorAll('.pos-pay-btn').forEach(b => {
                b.classList.remove('bg-amber-500', 'text-gray-950', 'border-amber-500', 'font-bold');
                b.classList.add('bg-gray-800', 'text-white', 'border-gray-700');
            });
            const btn = document.getElementById('btnPay' + method);
            btn.classList.add('bg-amber-500', 'text-gray-950', 'border-amber-500', 'font-bold');
            btn.classList.remove('bg-gray-800', 'text-white', 'border-gray-700');
        }


        // ============================================================
        // REV TORQ V37 — LOYALTY → POS VOUCHER BRIDGE
        // Server-side validation/redeem via Supabase RPC.
        // Voucher discount replaces manual POS discount while applied.
        // ============================================================
        let rtPosVoucher = null;
        let rtPosManualDiscountBeforeVoucher = null;

        function rtPosSelectedCustomerId() {
            const sel = document.getElementById('rtPosCustomerSelect');
            return sel && sel.value ? String(sel.value) : null;
        }

        function rtPosSetVoucherMessage(text, ok=false) {
            const el = document.getElementById('rtPosVoucherMessage');
            if (!el) return;
            el.textContent = text || '';
            el.className = ok
                ? 'text-[10px] font-bold text-emerald-600 mt-1'
                : 'text-[10px] font-bold text-slate-500 mt-1';
        }

        function rtPosUpdateVoucherUI() {
            const code = document.getElementById('rtPosVoucherCode');
            const apply = document.getElementById('rtPosVoucherApply');
            const remove = document.getElementById('rtPosVoucherRemove');
            const disc = document.getElementById('posDiscount');
            const badge = document.getElementById('rtPosVoucherBadge');
            if (code) code.value = rtPosVoucher?.code || code.value || '';
            if (apply) apply.classList.toggle('hidden', !!rtPosVoucher);
            if (remove) remove.classList.toggle('hidden', !rtPosVoucher);
            if (disc) {
                disc.readOnly = !!rtPosVoucher;
                disc.classList.toggle('bg-emerald-50', !!rtPosVoucher);
            }
            if (badge) badge.textContent = rtPosVoucher
                ? `${rtPosVoucher.reward_name || 'Voucher'} · -RM ${Number(rtPosVoucher.discount_applied||0).toFixed(2)}`
                : '';
            posCalculateTotal();
        }

        async function rtPosValidateVoucher(showToastOnError=true) {
            const codeEl = document.getElementById('rtPosVoucherCode');
            const code = String(codeEl?.value || '').trim();
            const customerId = rtPosSelectedCustomerId();
            if (!code) {
                if (showToastOnError) showToast('Masukkan kod voucher.', 'error');
                return null;
            }
            if (!customerId) {
                if (showToastOnError) showToast('Pilih customer dahulu. Voucher loyalty bukan untuk walk-in.', 'error');
                rtPosSetVoucherMessage('Pilih customer dahulu.');
                return null;
            }
            if (!window.supabaseRpc) {
                if (showToastOnError) showToast('Supabase RPC belum tersedia.', 'error');
                return null;
            }

            try {
                const result = await window.supabaseRpc('rt_validate_loyalty_voucher', {
                    p_code: code,
                    p_customer_id: customerId
                });
                if (!result?.valid) {
                    const reasons = {
                        NOT_FOUND:'Voucher tidak dijumpai.',
                        CUSTOMER_MISMATCH:'Voucher bukan milik customer ini.',
                        EXPIRED:'Voucher sudah tamat tempoh.',
                        REDEEMED:'Voucher sudah digunakan.'
                    };
                    throw new Error(reasons[result?.reason] || `Voucher tidak sah (${result?.reason || 'UNKNOWN'}).`);
                }

                let subtotal = 0;
                (window.rtGetPosCart ? window.rtGetPosCart() : []).forEach(i => {
                    subtotal += Number(i.qty || 0) * Number(i.price || 0);
                });

                if (subtotal < Number(result.minimum_spend || 0)) {
                    throw new Error(`Minimum belian voucher RM ${Number(result.minimum_spend||0).toFixed(2)}.`);
                }

                let allowed = 0;
                if (String(result.reward_type).toUpperCase() === 'PERCENT_DISCOUNT') {
                    allowed = subtotal * (Number(result.discount_value||0) / 100);
                    if (result.max_discount != null) allowed = Math.min(allowed, Number(result.max_discount));
                } else if (String(result.reward_type).toUpperCase() === 'FIXED_DISCOUNT') {
                    allowed = Math.min(Number(result.discount_value||0), subtotal);
                }

                if (allowed <= 0) {
                    throw new Error('Voucher ini tidak mempunyai nilai diskaun untuk order ini.');
                }

                rtPosManualDiscountBeforeVoucher = document.getElementById('posDiscount')?.value || '0';
                rtPosVoucher = {
                    code,
                    voucher_id: result.voucher_id,
                    customer_id: result.customer_id,
                    reward_name: result.reward_name,
                    reward_type: result.reward_type,
                    discount_applied: Number(allowed.toFixed(2)),
                    expires_at: result.expires_at
                };
                const disc = document.getElementById('posDiscount');
                if (disc) disc.value = rtPosVoucher.discount_applied.toFixed(2);
                rtPosSetVoucherMessage(`✓ ${result.reward_name || 'Voucher sah'} · Diskaun RM ${rtPosVoucher.discount_applied.toFixed(2)}`, true);
                rtPosUpdateVoucherUI();
                showToast('Voucher berjaya digunakan.', 'success');
                return rtPosVoucher;
            } catch (e) {
                rtPosVoucher = null;
                rtPosUpdateVoucherUI();
                rtPosSetVoucherMessage(e.message || 'Voucher tidak sah.');
                if (showToastOnError) showToast(e.message || 'Voucher tidak sah.', 'error');
                return null;
            }
        }

        function rtPosRemoveVoucher() {
            rtPosVoucher = null;
            const disc = document.getElementById('posDiscount');
            if (disc) {
                disc.value = rtPosManualDiscountBeforeVoucher ?? '0';
                disc.readOnly = false;
                disc.classList.remove('bg-emerald-50');
            }
            rtPosManualDiscountBeforeVoucher = null;
            const code = document.getElementById('rtPosVoucherCode');
            if (code) code.value = '';
            rtPosSetVoucherMessage('');
            rtPosUpdateVoucherUI();
        }

        async function rtPosRedeemVoucher(invoiceId, discountApplied) {
            if (!rtPosVoucher) return null;
            if (!invoiceId) throw new Error('Invoice ID untuk redeem voucher tidak dijumpai.');
            return await window.supabaseRpc('rt_redeem_loyalty_voucher', {
                p_code: rtPosVoucher.code,
                p_invoice_id: invoiceId,
                p_discount_applied: Number(discountApplied || 0)
            });
        }

        async function rtPosRollbackFirestoreSale(invNo) {
            if (!invNo) throw new Error('Nombor invois untuk rollback tidak dijumpai.');
            const invRef = db.collection("invoices").doc(invNo);
            const snap = await invRef.get();
            if (!snap.exists) return;
            const inv = snap.data() || {};
            const items = Array.isArray(inv.items) ? inv.items : [];

            await db.runTransaction(async (transaction) => {
                const refs = [];
                for (const item of items) {
                    const ref = await resolveInventoryRefBySku(item.sku);
                    const doc = await transaction.get(ref);
                    if (!doc.exists) throw new Error(`Rollback gagal: SKU ${item.sku} tidak wujud.`);
                    refs.push({ref,doc,item});
                }

                refs.forEach(({ref,doc,item}) => {
                    const before = Number(doc.data().stock || 0);
                    const qty = Number(item.qty || item.quantity || 0);
                    const after = before + qty;
                    transaction.update(ref, {stock: after});
                    const ledgerRef = db.collection('stock_ledger').doc();
                    transaction.set(ledgerRef, {
                        sku: item.sku,
                        itemName: item.name,
                        activity: 'SALE_ROLLBACK',
                        quantity: qty,
                        beforeStock: before,
                        afterStock: after,
                        referenceType: 'INVOICE_ROLLBACK',
                        referenceId: invNo,
                        staffId: currentProfile.staffId,
                        staffName: currentProfile.name,
                        reason: 'Loyalty voucher redemption failed',
                        timestamp: new Date().toISOString()
                    });
                });

                transaction.delete(invRef);
            });
        }

        async function posCheckout() {
            if (posCart.length === 0) { showToast("Troli kosong!", "error"); return; }

            // Loyalty voucher must be revalidated against the current customer/cart
            // immediately before checkout so staff cannot redeem a stale/foreign code.
            if (rtPosVoucher) {
                const currentCustomer = rtPosSelectedCustomerId();
                if (!currentCustomer || currentCustomer !== String(rtPosVoucher.customer_id)) {
                    rtPosRemoveVoucher();
                    showToast("Customer berubah. Sila semak semula voucher.", "error");
                    return;
                }
                const rechecked = await rtPosValidateVoucher(false);
                if (!rechecked) return;
            }

            let sub = 0;
            posCart.forEach(i => sub += (i.qty * i.price));
            const disc = parseFloat(document.getElementById('posDiscount').value) || 0;
            const total = sub - disc;
            let received = parseFloat(document.getElementById('posAmountReceived').value) || 0;
            // Non-cash methods are paid in full; the received amount is the actual amount paid.
            if (posPayMethod !== 'CASH') received = total;

            if (posPayMethod === 'CASH' && received < total) {
                showToast("Jumlah diterima tidak mencukupi!", "error"); return;
            }

            const btn = document.getElementById('btnCheckout');
            const origHtml = btn.innerHTML;
            btn.innerHTML = `<div class="loader mr-2"></div> Memproses...`;
            btn.disabled = true;

            const invNo = "INV" + new Date().getTime().toString().slice(-8);

            try {
                // FIRESTORE TRANSACTION FOR STOCK SAFETY
                await db.runTransaction(async (transaction) => {
                    // 1. Read all required stock docs
                    const docRefs = [];
                    for (let item of posCart) {
                        // Resolve legacy records whose Firestore document ID differs from SKU.
                        const ref = await resolveInventoryRefBySku(item.sku);
                        const doc = await transaction.get(ref);
                        if (!doc.exists) throw new Error(`SKU ${item.sku} tidak wujud dalam pangkalan data.`);
                        docRefs.push({ ref, doc, item });
                    }

                    // 2. Validate stock for all
                    docRefs.forEach(({doc, item}) => {
                        const currentStock = doc.data().stock || 0;
                        if (currentStock < item.qty) {
                            throw new Error(`Stok tidak mencukupi untuk ${item.name}. (Ada: ${currentStock}, Nak: ${item.qty})`);
                        }
                    });

                    // 3. Write updates and ledger
                    docRefs.forEach(({ref, doc, item}) => {
                        const currentStock = doc.data().stock || 0;
                        const newStock = currentStock - item.qty;
                        
                        transaction.update(ref, { stock: newStock });

                        const ledgerRef = db.collection('stock_ledger').doc();
                        transaction.set(ledgerRef, {
                            sku: item.sku,
                            itemName: item.name,
                            activity: 'SALE',
                            quantity: -item.qty,
                            beforeStock: currentStock,
                            afterStock: newStock,
                            referenceType: 'INVOICE',
                            referenceId: invNo,
                            staffId: currentProfile.staffId,
                            staffName: currentProfile.name,
                            timestamp: new Date().toISOString()
                        });
                    });

                    // 4. Create Invoice
                    const invRef = db.collection("invoices").doc(invNo);
                    const customerSelect = document.getElementById('rtPosCustomerSelect');
                    const customerOption = customerSelect && customerSelect.value
                        ? customerSelect.options[customerSelect.selectedIndex] : null;
                    const saleCustomer = customerOption ? {
                        customerId: customerSelect.value,
                        customerDocId: customerOption.dataset.docid || null,
                        customerName: customerOption.dataset.name || '',
                        customerPhone: customerOption.dataset.phone || ''
                    } : {
                        customerId: null, customerDocId: null, customerName: 'Walk-in', customerPhone: ''
                    };
                    transaction.set(invRef, {
                        invoiceNo: invNo,
                        customerId: saleCustomer.customerId,
                        customerDocId: saleCustomer.customerDocId,
                        customerName: saleCustomer.customerName,
                        customerPhone: saleCustomer.customerPhone,
                        items: posCart,
                        subtotal: sub,
                        discount: disc,
                        total: total,
                        paymentMethod: posPayMethod,
                        amountPaid: received,
                        balance: Math.max(0, received - total),
                        status: 'PAID',
                        createdAt: new Date().toISOString(),
                        createdBy: currentProfile.staffId
                    });
                });

                await logAudit('CREATE_INVOICE', `Processed POS sale: ${invNo} (Total: ${total})`);
                
                const savedInvoice = await db.collection("invoices").doc(invNo).get();
                if (!savedInvoice.exists) throw new Error("Invois berjaya disimpan tetapi tidak dapat dibaca semula.");

                // Redeem only after the paid invoice exists. The database RPC verifies
                // customer, company, expiry, minimum spend and allowed discount again.
                if (rtPosVoucher) {
                    try {
                        await rtPosRedeemVoucher(savedInvoice.ref.id, disc);
                        await logAudit('REDEEM_LOYALTY_VOUCHER', `Voucher ${rtPosVoucher.code} redeemed on ${invNo}`);
                    } catch (voucherErr) {
                        console.error('LOYALTY VOUCHER REDEEM:', voucherErr);
                        try {
                            await rtPosRollbackFirestoreSale(invNo);
                            await logAudit('ROLLBACK_INVOICE', `Rolled back ${invNo}: loyalty voucher redemption failed`);
                            rtPosRemoveVoucher();
                            throw new Error(`Voucher gagal ditebus. Invois ${invNo} telah dibatalkan dan stok dipulihkan. Sila cuba semula tanpa voucher atau semak konfigurasi voucher.`);
                        } catch (rollbackErr) {
                            if (String(rollbackErr.message||'').startsWith('Voucher gagal ditebus.')) throw rollbackErr;
                            throw new Error(`CRITICAL: Voucher gagal ditebus DAN rollback invois gagal. Jangan ulang transaksi ${invNo}; semak POS/Firestore segera. ${rollbackErr.message}`);
                        }
                    }
                }

                showToast(`Invois ${invNo} berjaya dicetak.`);
                const saved = savedInvoice.data();
                await generateReceiptFromInvoice({...saved, voucherCode: rtPosVoucher?.code || null});
                
                // Reset UI
                posClearCart();
                document.getElementById('posDiscount').value = "0";
                document.getElementById('posAmountReceived').value = "";
                const posCustomer = document.getElementById('rtPosCustomerSelect');
                if (posCustomer) posCustomer.value = "";
                rtPosVoucher = null;
                rtPosManualDiscountBeforeVoucher = null;
                rtPosUpdateVoucherUI();
                rtPosSetVoucherMessage('');
                loadPOS(); // reload products to reflect new stock

            } catch (e) {
                showToast(`Gagal: ${e.message}`, 'error');
            } finally {
                btn.innerHTML = origHtml;
                btn.disabled = false;
            }
        }

        async function generateReceiptFromInvoice(inv) {
            let shop = window.rtWorkshopProfile || {};
            try {
                if (window.db && typeof db.collection === 'function') {
                    const snap = await db.collection('settings').doc('workshop').get();
                    if (snap && snap.exists) {
                        shop = {...shop, ...(snap.data() || {})};
                        window.rtWorkshopProfile = shop;
                    }
                }
            } catch (e) { console.warn('Receipt shop profile load failed', e); }

            const items = Array.isArray(inv.items) ? inv.items : [];
            const sub = Number(inv.subtotal ?? (items.reduce((sum,i)=>sum + Number(i.price || i.sellPrice || 0) * Number(i.qty || i.quantity || 0),0)));
            const disc = Number(inv.discount || 0);
            const total = Number(inv.total || 0);
            const method = String(inv.paymentMethod || inv.method || 'CASH').toUpperCase();
            const received = Number(inv.amountPaid ?? inv.amountReceived ?? inv.paid ?? total);
            const balance = Math.max(0, Number(inv.change ?? inv.balance ?? (received - total)));
            const invNo = inv.invoiceNo || inv.invNo || inv.id || '-';
            const rtReceiptDate = (value) => {
                try {
                    if (!value) return new Date();
                    if (value instanceof Date && !Number.isNaN(value.getTime())) return value;
                    if (typeof value?.toDate === 'function') {
                        const d = value.toDate();
                        if (d instanceof Date && !Number.isNaN(d.getTime())) return d;
                    }
                    if (typeof value === 'object' && Number.isFinite(Number(value.seconds))) {
                        const d = new Date(Number(value.seconds) * 1000);
                        if (!Number.isNaN(d.getTime())) return d;
                    }
                    const d = new Date(value);
                    return Number.isNaN(d.getTime()) ? new Date() : d;
                } catch (_) { return new Date(); }
            };
            const created = rtReceiptDate(inv.createdAt || inv.created_at);

            let itemHtml = '';
            items.forEach(i => {
                const price = Number(i.price || i.sellPrice || 0);
                const qty = Number(i.qty || i.quantity || 0);
                itemHtml += `<div class="flex justify-between mt-1">
                    <div class="flex-1 truncate pr-2">${i.name || i.itemName || i.sku || '-'}</div>
                    <div class="w-8 text-right">${qty}</div>
                    <div class="w-16 text-right">${(price * qty).toFixed(2)}</div>
                </div>`;
            });

            const html = `
                <div class="text-center border-b border-black pb-2 mb-2 font-bold uppercase text-lg">${shop.workshopName || 'REV TORQ WORKSHOP'}</div>
                 <div class="text-center text-[10px] mb-4 border-b border-black pb-2">
                     ${(shop.address || '').replace(/</g,'&lt;').replace(/>/g,'&gt;').split(String.fromCharCode(10)).join('<br>') || 'Alamat bengkel belum ditetapkan'}<br>
                     Tel: ${shop.phone || '-'}<br>
                     SSM / No. Pendaftaran: ${shop.regNo || '-'}
                 </div>
                <div class="mb-2 text-[10px]">
                    <div>No: ${invNo}</div>
                    <div>Tarikh: ${created.toLocaleString('ms-MY')}</div>
                    <div>Juruwang: ${inv.createdBy || currentProfile.staffId}</div>
                </div>
                <div class="border-t border-b border-black py-1 font-bold flex justify-between uppercase">
                    <div class="flex-1">Item</div><div class="w-8 text-right">Qty</div><div class="w-16 text-right">Total</div>
                </div>
                <div class="py-2 border-b border-black">${itemHtml}</div>
                <div class="mt-2 text-right">
                    <div class="flex justify-end"><span class="w-20 inline-block">Subtotal:</span><span class="w-16 inline-block">RM ${sub.toFixed(2)}</span></div>
                    <div class="flex justify-end"><span class="w-20 inline-block">Diskaun:</span><span class="w-16 inline-block">RM ${disc.toFixed(2)}</span></div>
                    <div class="flex justify-end font-bold text-sm mt-1"><span class="w-20 inline-block">JUMLAH:</span><span class="w-16 inline-block border-t border-black">RM ${total.toFixed(2)}</span></div>
                </div>
                <div class="mt-2 border-t border-black pt-1">
                    <div class="flex justify-end"><span class="w-20 inline-block">Kaedah:</span><span class="w-16 inline-block font-bold">${method}</span></div>
                    <div class="flex justify-end"><span class="w-20 inline-block">Dibayar:</span><span class="w-16 inline-block">RM ${received.toFixed(2)}</span></div>
                    <div class="flex justify-end"><span class="w-20 inline-block">Baki:</span><span class="w-16 inline-block">RM ${balance.toFixed(2)}</span></div>
                </div>
                <div class="text-center text-[10px] mt-6 italic">Terima kasih kerana berurusan dengan kami.</div>
            `;
            document.getElementById('printArea').innerHTML = html;

            const shareLines = [
                String(shop.workshopName || 'REV TORQ WORKSHOP'),
                `Resit: ${invNo}`,
                `Tarikh: ${created.toLocaleString('ms-MY')}`,
                '',
                ...items.map(i => {
                    const price = Number(i.price || i.sellPrice || 0);
                    const qty = Number(i.qty || i.quantity || 0);
                    const name = i.name || i.itemName || i.sku || '-';
                    return `${name} x${qty} = RM ${(price * qty).toFixed(2)}`;
                }),
                '',
                `Subtotal: RM ${sub.toFixed(2)}`,
                disc > 0 ? `Diskaun: RM ${disc.toFixed(2)}` : null,
                `JUMLAH: RM ${total.toFixed(2)}`,
                `Kaedah: ${method}`,
                `Dibayar: RM ${received.toFixed(2)}`,
                `Baki: RM ${balance.toFixed(2)}`,
                '',
                'Terima kasih kerana berurusan dengan kami.'
            ].filter(v => v !== null);
            window.__rtLastReceiptText = shareLines.join('\n');
            openModal('receiptModal');
        }

        function rtShareReceiptWhatsApp() {
            const text = String(window.__rtLastReceiptText || '').trim();
            if (!text) {
                if (typeof showToast === 'function') showToast('Resit belum tersedia untuk dikongsi.', 'error');
                return;
            }
            const url = 'https://wa.me/?text=' + encodeURIComponent(text);
            const isNative = location.hostname === 'appassets.androidplatform.net' || /(?:^|[?&])native=1(?:&|$)/.test(location.search);
            if (isNative) {
                location.href = url;
                return;
            }
            const popup = window.open(url, '_blank', 'noopener,noreferrer');
            if (!popup) location.href = url;
        }

// Public APIs used by inline UI/history layers.
window.generateReceiptFromInvoice = generateReceiptFromInvoice;
window.rtShareReceiptWhatsApp = rtShareReceiptWhatsApp;
window.loadPOS = loadPOS;
window.rtPosApplyVoucher = rtPosValidateVoucher;
        window.rtPosRemoveVoucher = rtPosRemoveVoucher;
        window.posAddToCart = posAddToCart;
window.posUpdateQty = posUpdateQty;
window.posClearCart = posClearCart;
window.posCalculateTotal = posCalculateTotal;
window.posSetPaymentMethod = posSetPaymentMethod;
