/* REV TORQ V36.4.6 — Job Card -> POS payment flow
   Completed Job Cards are selected for payment, then settled through POS.
   Extra parts/labour are added in POS. No direct payment modal from Job Card.
*/
(function(){
  'use strict';
  const sb=window.supabaseClient;
  if(!sb)return;
  const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  const num=v=>Number.isFinite(Number(v))?Number(v):0;
  const money=v=>'RM '+num(v).toFixed(2);
  const profile=()=>window.currentProfile||window.currentUserProfile||{};
  const company=()=>profile().companyId||null;
  const toast=(m,t='info')=>window.showToast?.(m,t);

  async function loadJob(jobNo){
    const c=company();
    if(!c)throw new Error('Company context tidak dijumpai.');
    // IMPORTANT: production job_cards does not have labor_cost. Labour is derived
    // from the Job Card total after the actual PART rows are loaded.
    const jr=await sb.from('job_cards').select('id,job_no,company_id,location_id,customer_id,vehicle_id,status,estimated_total,actual_total,created_at').eq('company_id',c).eq('job_no',jobNo).limit(1).maybeSingle();
    if(jr.error)throw jr.error;
    if(!jr.data)throw new Error(`Job Card ${jobNo} tidak dijumpai.`);
    const j=jr.data, status=String(j.status||'').toUpperCase();
    if(status!=='COMPLETED')throw new Error(`Job ${jobNo} belum siap dibayar (status: ${j.status||'-'}).`);
    const paid=await sb.from('invoices').select('id').eq('company_id',c).eq('job_card_id',j.id).eq('status','PAID').eq('payment_status','PAID').limit(1).maybeSingle();
    if(paid.error)throw paid.error;
    if(paid.data)throw new Error(`Job ${jobNo} sudah dibayar. Invoice sedia ada tidak boleh dibayar sekali lagi.`);
    // Only select columns confirmed by the production schema. Do not request
    // legacy/non-schema columns such as description or labor_cost.
    const ir=await sb.from('job_card_items').select('id,product_id,item_type,quantity,unit_price,line_total').eq('company_id',c).eq('job_card_id',j.id).order('id',{ascending:true});
    if(ir.error)throw ir.error;
    const rawItems=ir.data||[];
    const productIds=[...new Set(rawItems.map(x=>x.product_id).filter(Boolean))];
    let productMap=new Map();
    if(productIds.length){
      const pr=await sb.from('products').select('id,sku,name,sell_price').eq('company_id',c).in('id',productIds);
      if(pr.error)throw pr.error;
      productMap=new Map((pr.data||[]).map(x=>[x.id,x]));
    }
    const items=rawItems.map(x=>({...x,description:productMap.get(x.product_id)?.name||productMap.get(x.product_id)?.sku||'Part'}));
    const parts=items.filter(x=>String(x.item_type||'PART').toUpperCase()==='PART');
    const services=items.filter(x=>String(x.item_type||'').toUpperCase()!=='PART');
    const partTotal=parts.reduce((s,x)=>s+num(x.line_total??num(x.quantity)*num(x.unit_price)),0);
    const serviceTotal=services.reduce((s,x)=>s+num(x.line_total??num(x.quantity)*num(x.unit_price)),0);
    const jobTotal=Math.max(0,num(j.actual_total??j.estimated_total));
    // Job Card labour is not an inventory row and is not stored in job_cards.labor_cost.
    // Derive it from the persisted Job Card total after PART/SERVICE rows.
    const labor=Math.max(0,jobTotal-partTotal-serviceTotal);
    const cr=j.customer_id?await sb.from('customers').select('name,phone').eq('company_id',c).eq('id',j.customer_id).maybeSingle():{data:null,error:null};
    if(cr.error)throw cr.error;
    const vr=j.vehicle_id?await sb.from('vehicles').select('plate_no,brand,model').eq('company_id',c).eq('id',j.vehicle_id).maybeSingle():{data:null,error:null};
    if(vr.error)throw vr.error;
    return {j,parts,services,labor,jobTotal,customer:cr.data||{},vehicle:vr.data||{}};
  }

  function clearActiveJob(){
    window.rtActiveJob=null;
    const el=document.getElementById('rtCurrentJob'); if(el)el.textContent='JUALAN BIASA';
    const h=document.getElementById('rtJobContext'); if(h)h.remove();
  }

  function showJobContext(data){
    const cart=document.getElementById('posCartList')?.parentElement;
    if(!cart)return;
    let h=document.getElementById('rtJobContext');
    if(!h){
      h=document.createElement('div');h.id='rtJobContext';
      h.className='mx-3 mt-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs';
      cart.parentElement?.insertBefore(h,cart);
    }
    h.innerHTML=`<div class="flex items-center justify-between gap-2"><div><b class="text-red-700">JOB CARD</b><div class="font-black text-slate-900">${esc(data.j.job_no)}</div><div class="text-slate-500">${esc(data.customer.name||'Walk-in')} · ${esc(data.vehicle.plate_no||'-')}</div></div><button type="button" id="rtClearJobContext" class="px-2.5 py-1.5 rounded-lg bg-white border border-red-200 text-red-700 font-black">BATAL JOB</button></div>`;
    h.querySelector('#rtClearJobContext').onclick=()=>{clearActiveJob();window.posClearCart?.();};
  }

  async function selectJobIntoPOS(jobNo){
    try{
      const data=await loadJob(jobNo);
      const cart=[];
      for(const x of data.parts){
        cart.push({sku:'JOBPART-'+x.id,name:x.description||'Part',price:num(x.unit_price),qty:num(x.quantity)||1,maxStock:999999,itemType:'PART',productId:x.product_id||null,fromJobCard:true,jobCardItemId:x.id});
      }
      for(const x of data.services){
        cart.push({sku:'JOBSERVICE-'+x.id,name:x.description||'Service',price:num(x.unit_price),qty:num(x.quantity)||1,maxStock:999999,itemType:'SERVICE',service:true,productId:x.product_id||null,fromJobCard:true,jobCardItemId:x.id});
      }
      if(data.labor>0 && !data.services.some(x=>/labour|upah|kerja/i.test(String(x.description||'')))){
        cart.push({sku:'JOBLABOUR-'+data.j.id,name:'Labour',price:data.labor,qty:1,maxStock:999999,itemType:'SERVICE',service:true,productId:null,fromJobCard:false,jobCardId:null,servicePrice:data.labor});
      }
      window.rtActiveJob={jobCardId:data.j.id,jobNo:data.j.job_no,customerId:data.j.customer_id||null,vehicleId:data.j.vehicle_id||null,locationId:data.j.location_id||null};
      if(typeof window.rtSetPosCart==='function')window.rtSetPosCart(cart); else throw new Error('POS cart belum tersedia.');
      const jobEl=document.getElementById('rtCurrentJob');if(jobEl)jobEl.textContent=data.j.job_no;
      const customer=document.getElementById('rtPosCustomerSelect');if(customer&&data.j.customer_id)customer.value=data.j.customer_id;
      showJobContext(data);
      if(typeof window.switchView==='function')window.switchView('pos');
      setTimeout(()=>{showJobContext(data);window.rtRenderPosCart?.();},150);
      toast(`Job ${data.j.job_no} dimasukkan ke POS. Tambah barang/labour jika perlu.`, 'success');
    }catch(e){console.error('REV TORQ selectJobIntoPOS',e);toast('Buka Job ke POS gagal | '+(e.message||e),'error');}
  }

  async function openJobPickerPOS(){
    let m=document.getElementById('rtJobPicker365');
    if(!m){
      m=document.createElement('div');m.id='rtJobPicker365';m.className='fixed inset-0 z-[260] bg-slate-900/70 backdrop-blur-sm hidden items-center justify-center p-4';
      m.innerHTML=`<div class="bg-white rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden"><div class="p-5 border-b flex justify-between items-center"><div><div class="text-[10px] font-black tracking-widest text-red-600">JOB CARD</div><h3 class="text-xl font-black">Pilih Job Untuk Bayaran</h3></div><button type="button" id="rtJobPickerCloseV46" class="w-9 h-9 rounded-xl bg-slate-100">✕</button></div><div id="rtJobPickerBodyV46" class="p-4 max-h-[70vh] overflow-auto"></div></div>`;
      document.body.appendChild(m);m.querySelector('#rtJobPickerCloseV46').onclick=()=>{m.classList.add('hidden');m.classList.remove('flex')};
    }
    m.classList.remove('hidden');m.classList.add('flex');
    const body=m.querySelector('#rtJobPickerBodyV46');body.innerHTML='<div class="p-8 text-center text-slate-500">Memuatkan Job Card...</div>';
    try{
      const c=company();if(!c)throw new Error('Company context tidak dijumpai.');
      const r=await sb.from('job_cards').select('id,job_no,customer_id,vehicle_id,status,actual_total,estimated_total,created_at').eq('company_id',c).eq('status','COMPLETED').order('created_at',{ascending:false}).limit(100);
      if(r.error)throw r.error;
      let jobs=r.data||[];
      if(jobs.length){
        const paidQ=await sb.from('invoices').select('job_card_id').eq('company_id',c).eq('status','PAID').eq('payment_status','PAID').not('job_card_id','is',null);
        if(paidQ.error)throw paidQ.error;
        const paidIds=new Set((paidQ.data||[]).map(x=>x.job_card_id).filter(Boolean));
        jobs=jobs.filter(x=>!paidIds.has(x.id));
      }
      if(!jobs.length){body.innerHTML='<div class="p-8 text-center text-slate-500">Tiada Job Card yang siap untuk dibayar.</div>';return;}
      const ids=[...new Set(jobs.map(x=>x.customer_id).filter(Boolean))];let cm=new Map();
      if(ids.length){const cr=await sb.from('customers').select('id,name').eq('company_id',c).in('id',ids);if(cr.error)throw cr.error;cm=new Map((cr.data||[]).map(x=>[x.id,x]));}
      body.innerHTML=jobs.map(x=>`<div class="flex items-center justify-between gap-3 p-4 mb-2 rounded-2xl border border-slate-200 bg-slate-50"><div><div class="font-black text-indigo-700">${esc(x.job_no)}</div><div class="text-sm font-bold text-slate-800">${esc(cm.get(x.customer_id)?.name||'Walk-in')}</div><div class="text-xs text-slate-500">${new Date(x.created_at).toLocaleDateString('ms-MY')} · ${money(x.actual_total??x.estimated_total)}</div></div><button type="button" data-job="${esc(x.job_no)}" class="rt-picker-pay-v46 px-4 py-2.5 rounded-xl bg-emerald-600 text-white font-black text-xs">PILIH</button></div>`).join('');
      body.querySelectorAll('.rt-picker-pay-v46').forEach(b=>b.onclick=async()=>{m.classList.add('hidden');m.classList.remove('flex');await selectJobIntoPOS(b.dataset.job)});
    }catch(e){console.error('REV TORQ openJobPickerPOS',e);body.innerHTML=`<div class="p-8 text-center text-red-600 font-bold">Gagal memuatkan Job Card: ${esc(e.message||e)}</div>`;}
  }

  function openPayMenu(){
    if(typeof window.switchView==='function')window.switchView('pos');
    setTimeout(()=>{
      if(typeof window.rtOpenJobPicker==='function')window.rtOpenJobPicker();
      else toast('Pemilih Job Card belum tersedia.','error');
    },250);
  }

  // Job Card action becomes a POS hand-off, not direct payment.
  window.decorateJobRows=function(){
    document.querySelectorAll('#tblJobCards tbody tr').forEach(tr=>{
      const status=String(tr.children?.[5]?.textContent||'').trim().toUpperCase();
      const job=String(tr.children?.[0]?.textContent||'').trim();
      if(!job||!['COMPLETED','READY','DONE'].includes(status))return;
      const actions=tr.lastElementChild; if(!actions)return;
      const old=actions.querySelector('.rt-direct-job-pay'); if(old)old.remove();
      if(actions.querySelector('.rt-job-pos'))return;
      const b=document.createElement('button');b.type='button';b.className='rt-job-pos ml-2 px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-black';b.textContent='PILIH POS';b.onclick=()=>selectJobIntoPOS(job);actions.appendChild(b);
    });
  };

  // Existing payment entry points now hand off to POS.
  window.rtOpenJobPayment=selectJobIntoPOS;
  window.openJobPayment=selectJobIntoPOS;
  window.rtOpenPayMenu=openPayMenu;
  window.rtOpenJobPicker=openJobPickerPOS;
  window.rtSelectJobIntoPOS=selectJobIntoPOS;

  window.addEventListener('load',()=>setTimeout(()=>{
    const btn=document.getElementById('rtPickJobBtn');
    if(btn){btn.onclick=()=>window.rtOpenJobPicker?.();btn.textContent='Pilih';}
    const oldClear=window.posClearCart;
    if(typeof oldClear==='function' && !oldClear.__rtJobWrapped){
      const wrapped=function(){clearActiveJob();return oldClear.apply(this,arguments)};wrapped.__rtJobWrapped=true;window.posClearCart=wrapped;
    }
    decorateJobRows();
  },1000));
  setInterval(()=>{try{decorateJobRows()}catch(_){}},1200);
})();
