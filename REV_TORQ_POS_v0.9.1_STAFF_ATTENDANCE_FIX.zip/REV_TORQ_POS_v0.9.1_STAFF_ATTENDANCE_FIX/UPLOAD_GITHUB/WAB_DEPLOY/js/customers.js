// ================= CUSTOMERS & VEHICLES =================
        function openNewCustomer() {
            document.getElementById('custIsEdit').value = "false";
            document.getElementById('custIdField').value = "";
            document.getElementById('customerModalTitle').innerText = "Daftar Pelanggan";
            document.getElementById('custName').value = "";
            document.getElementById('custPhone').value = "";
            document.getElementById('custInitialVehicleGroup').style.display = 'block';
            document.getElementById('custInitPlat').value = "";
            document.getElementById('custInitModel').value = "";
            openModal('customerModal');
        }

        async function editCustomer(id) {
            document.getElementById('custIsEdit').value = "true";
            document.getElementById('custIdField').value = id;
            document.getElementById('customerModalTitle').innerText = "Kemaskini Pelanggan";
            document.getElementById('custInitialVehicleGroup').style.display = 'none'; // hide initial vehicle section for edit
            try {
                const doc = await db.collection("customers").doc(id).get();
                if(doc.exists) {
                    const d = doc.data();
                    document.getElementById('custName').value = d.name;
                    document.getElementById('custPhone').value = d.phone;
                    openModal('customerModal');
                }
            } catch(e) { showToast(e.message, 'error'); }
        }

        async function loadCustomers() {
            const tbody = document.querySelector('#tblCustomers tbody');
            tbody.innerHTML = '<tr><td colspan="5" class="text-center p-4">Loading...</td></tr>';
            
            try {
                const snap = await db.collection("customers").orderBy("createdAt", "desc").get();
                let rows = '';
                
                for (const doc of snap.docs) {
                    const d = doc.data();
                    // Fetch vehicles for this customer
                    const vSnap = await db.collection("vehicles").where("customerId", "==", d.customerId).get();
                    let vHtml = '';
                    vSnap.forEach(vDoc => {
                        const v = vDoc.data();
                        vHtml += `<span class="inline-block bg-gray-800 text-xs px-2 py-1 rounded mr-1 mb-1 font-mono border border-gray-700">${v.plateNo} - ${v.model}</span>`;
                    });
                    if(!vHtml) vHtml = `<span class="text-xs text-gray-500">Tiada kenderaan</span>`;

                    rows += `
                        <tr class="hover:bg-gray-800/50">
                            <td class="p-4 text-xs font-mono text-gray-400">${d.customerId}</td>
                            <td class="p-4 font-bold text-white">${d.name}</td>
                            <td class="p-4 font-mono">${d.phone}</td>
                            <td class="p-4 max-w-[200px]">${vHtml}</td>
                            <td class="p-4 text-right">
                                <button onclick="editCustomer('${d.customerId}')" class="text-amber-400 hover:text-amber-300 mr-3 text-xs font-bold"><i data-feather="edit" class="w-4 h-4 inline"></i> KEMASKINI</button>
                                <button onclick="openAddVehicle('${d.customerId}')" class="text-blue-400 hover:text-blue-300 text-xs font-bold"><i data-feather="plus-circle" class="w-4 h-4 inline"></i> KENDERAAN</button>
                            </td>
                        </tr>
                    `;
                }
                tbody.innerHTML = rows || '<tr><td colspan="5" class="text-center p-4 text-gray-500">Tiada rekod</td></tr>';
                feather.replace();
            } catch (e) {
                tbody.innerHTML = `<tr><td colspan="5" class="text-center p-4 text-red-500">Ralat: ${e.message}</td></tr>`;
            }
        }

        async function saveCustomer(e) {
            e.preventDefault();
            const btnId = 'btnSaveCustomer';
            setOriginalText(btnId);
            toggleLoading(btnId, true);

            const isEdit = document.getElementById('custIsEdit').value === "true";
            const name = document.getElementById('custName').value.trim();
            const phone = document.getElementById('custPhone').value.trim();
            let createdCustomerId = document.getElementById('custIdField').value || null;
            
            try {
                if (isEdit) {
                    const custId = document.getElementById('custIdField').value;
                    await db.collection("customers").doc(custId).update({
                        name: name,
                        phone: phone,
                        updatedAt: new Date().toISOString()
                    });
                    showToast(`Pelanggan ${name} dikemaskini.`);
                    await logAudit('UPDATE_CUSTOMER', `Updated customer: ${custId}`);
                } else {
                    const initPlat = document.getElementById('custInitPlat').value.trim().toUpperCase();
                    const initModel = document.getElementById('custInitModel').value.trim();
                    const custId = "CUST-" + new Date().getTime().toString().slice(-6);
                    createdCustomerId = custId;
                    
                    await db.collection("customers").doc(custId).set({
                        customerId: custId,
                        name: name,
                        phone: phone,
                        createdAt: new Date().toISOString(),
                        createdBy: currentProfile.staffId
                    });

                    // Add initial vehicle if provided
                    if(initPlat && initModel) {
                        const vId = "V-" + new Date().getTime();
                        await db.collection("vehicles").doc(vId).set({
                            vehicleId: vId,
                            customerId: custId,
                            plateNo: initPlat,
                            model: initModel,
                            createdAt: new Date().toISOString()
                        });
                    }

                    showToast(`Pelanggan ${name} didaftarkan.`);
                    await logAudit('CREATE_CUSTOMER', `Created customer: ${custId}`);
                }
                closeModal('customerModal');
                await loadCustomers();
                if (pendingJobCustomerId === 'JOB') {
                    pendingJobCustomerId = null;
                    await populateJCSelects();
                    document.getElementById('jcCustomerSelect').value = createdCustomerId;
                    await loadCustomerVehiclesForJC(createdCustomerId);
                    openModal('jobCardModal');
                }
            } catch (e) {
                showToast(e.message, 'error');
            } finally {
                toggleLoading(btnId, false);
            }
        }

        function openAddVehicle(customerId) {
            document.getElementById('vehCustomerId').value = customerId;
            document.getElementById('vehPlate').value = '';
            document.getElementById('vehModel').value = '';
            openModal('vehicleModal');
        }

        async function saveVehicle(e) {
            e.preventDefault();
            const btnId = 'btnSaveVehicle';
            setOriginalText(btnId);
            toggleLoading(btnId, true);

            const cid = document.getElementById('vehCustomerId').value;
            const plate = document.getElementById('vehPlate').value.trim().toUpperCase();
            const model = document.getElementById('vehModel').value.trim();

            try {
                const vId = "V-" + new Date().getTime();
                await db.collection("vehicles").doc(vId).set({
                    vehicleId: vId,
                    customerId: cid,
                    plateNo: plate,
                    model: model,
                    createdAt: new Date().toISOString()
                });
                showToast("Kenderaan baru ditambah.");
                await logAudit('CREATE_VEHICLE', `Added vehicle ${plate} to customer ${cid}`);
                closeModal('vehicleModal');
                loadCustomers();
            } catch (e) { showToast(e.message, 'error'); } 
            finally { toggleLoading(btnId, false); }
        }

        