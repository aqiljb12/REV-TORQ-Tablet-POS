// ================= DASHBOARD V0.7.9 =================
// REV TORQ canonical dashboard — real production data only.
(function(){
'use strict';
const $=id=>document.getElementById(id);
const sb=()=>window.sb||window.supabaseClient;
const esc=v=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const money=v=>'RM '+Number(v||0).toLocaleString('ms-MY',{minimumFractionDigits:2,maximumFractionDigits:2});
const set=(id,v)=>{const e=$(id);if(e)e.textContent=v};
const toDate=v=>{if(!v)return null;if(typeof v.toDate==='function')return v.toDate();if(v.seconds)return new Date(v.seconds*1000);const d=new Date(v);return Number.isNaN(d.getTime())?null:d};
const errText=e=>[e?.code,e?.message,e?.details,e?.hint].filter(Boolean).join(' | ')||String(e||'Unknown error');
const isJwtFuture=e=>String(e?.code||'').toUpperCase()==='PGRST303'||/jwt issued at future/i.test(String(e?.message||''));

async function refreshSessionOnce(){try{const c=sb();if(!c?.auth)return false;const r=await c.auth.refreshSession();return !r.error&&!!r.data?.session}catch(_){return false}}
async function ctx(){
  let companyId=window.currentProfile?.companyId||window.currentProfile?.company_id||null, locationId=null;
  try{if(typeof window.companyId==='function')companyId=companyId||await window.companyId()}catch(_){}
  try{if(typeof window.locationId==='function')locationId=await window.locationId()}catch(_){}
  if(!companyId) throw new Error('Company tidak dijumpai untuk sesi ini.');
  if(!locationId){const r=await sb().from('locations').select('id').eq('company_id',companyId).eq('active',true).order('code',{ascending:true}).limit(1).maybeSingle();if(!r.error)locationId=r.data?.id||null}
  return {companyId,locationId};
}
function localRange(offset=0){const n=new Date(),s=new Date(n.getFullYear(),n.getMonth(),n.getDate()+offset),e=new Date(n.getFullYear(),n.getMonth(),n.getDate()+offset+1);return [s.toISOString(),e.toISOString()]}
function weekRange(){const n=new Date(),s=new Date(n.getFullYear(),n.getMonth(),n.getDate()-6),e=new Date(n.getFullYear(),n.getMonth(),n.getDate()+1);return [s.toISOString(),e.toISOString()]}
async function count(table,companyId,mut){let q=sb().from(table).select('id',{count:'exact',head:true}).eq('company_id',companyId);if(mut)q=mut(q);const r=await q;if(r.error)throw r.error;return Number(r.count||0)}
async function paidInvoices(companyId,start,end,limit=5000){let q=sb().from('invoices').select('id,invoice_no,total,status,payment_status,created_at').eq('company_id',companyId).neq('status','VOID').eq('payment_status','PAID').gte('created_at',start).lt('created_at',end).order('created_at',{ascending:false}).limit(limit);const r=await q;if(r.error)throw r.error;return r.data||[]}
async function methods(invoiceIds,companyId){const m=new Map();if(!invoiceIds.length)return m;const r=await sb().from('payments').select('invoice_id,payment_method,created_at').eq('company_id',companyId).in('invoice_id',invoiceIds).order('created_at',{ascending:true});if(r.error)throw r.error;(r.data||[]).forEach(p=>{const a=m.get(p.invoice_id)||[];if(p.payment_method&&!a.includes(p.payment_method))a.push(p.payment_method);m.set(p.invoice_id,a)});return m}
async function lowStock(companyId,locationId){
  const p=await sb().from('products').select('id,name,sku,min_stock').eq('company_id',companyId).eq('active',true);if(p.error)throw p.error;
  let q=sb().from('stock_balances').select('product_id,quantity,reserved_quantity');if(locationId)q=q.eq('location_id',locationId);const b=await q;if(b.error)throw b.error;
  const bm=new Map((b.data||[]).map(x=>[x.product_id,Number(x.quantity||0)-Number(x.reserved_quantity||0)]));
  const rows=(p.data||[]).map(x=>({...x,available:bm.get(x.id)??0})).filter(x=>x.available<=Number(x.min_stock||0)).sort((a,b)=>a.available-b.available);
  return rows;
}
async function reminders(companyId){
  let r=await sb().from('service_reminders').select('id,customer_id,vehicle_id,due_date,due_mileage,reminder_type,status').eq('company_id',companyId).neq('status','DONE').order('due_date',{ascending:true}).limit(5);if(r.error)throw r.error;
  const rows=r.data||[], cids=[...new Set(rows.map(x=>x.customer_id).filter(Boolean))], vids=[...new Set(rows.map(x=>x.vehicle_id).filter(Boolean))], cm=new Map(), vm=new Map();
  if(cids.length){const c=await sb().from('customers').select('id,name,phone').in('id',cids);if(c.error)throw c.error;(c.data||[]).forEach(x=>cm.set(x.id,x))}
  if(vids.length){const v=await sb().from('vehicles').select('id,plate_no,brand,model').in('id',vids);if(v.error)throw v.error;(v.data||[]).forEach(x=>vm.set(x.id,x))}
  return rows.map(x=>({...x,customer:cm.get(x.customer_id)||{},vehicle:vm.get(x.vehicle_id)||{}}));
}
async function todayBookings(companyId){
  const [s,e]=localRange();
  // preferred_date may be date/timestamp depending on old migration. Try ISO range first, then YYYY-MM-DD.
  let q=sb().from('bookings').select('id,status,preferred_date,preferred_time').eq('company_id',companyId).gte('preferred_date',s).lt('preferred_date',e).limit(500);let r=await q;
  if(r.error){const day=new Date().toLocaleDateString('en-CA');r=await sb().from('bookings').select('id,status,preferred_date,preferred_time').eq('company_id',companyId).eq('preferred_date',day).limit(500)}
  if(r.error) return [];
  return (r.data||[]).filter(x=>!['CANCELLED','CANCELED','REJECTED'].includes(String(x.status||'').toUpperCase()));
}
async function drawer(companyId,locationId){let q=sb().from('cash_drawers').select('id,status,drawer_code,opening_float,opened_at,updated_at').eq('company_id',companyId).eq('status','OPEN').order('opened_at',{ascending:false}).limit(1);if(locationId)q=q.eq('location_id',locationId);const r=await q;if(r.error)return null;return r.data?.[0]||null}

function renderSales(rows,map){const el=$('dashRecentSales');if(!el)return;if(!rows.length){el.innerHTML='<div class="rt-empty">Belum ada jualan berbayar hari ini.</div>';return}el.innerHTML=rows.slice(0,8).map(x=>{const d=toDate(x.created_at), method=(map.get(x.id)||[]).join(' + ')||'—';return `<div class="rt-sale-item"><div><b>${esc(x.invoice_no||x.id)}</b><span>${d?d.toLocaleTimeString('ms-MY',{hour:'2-digit',minute:'2-digit'}):'—'} · ${esc(method)}</span></div><strong>${money(x.total)}</strong></div>`}).join('')}
function renderReminders(rows){const el=$('dashReminders');if(!el)return;if(!rows.length){el.innerHTML='<div class="rt-empty">Tiada peringatan aktif.</div>';return}el.innerHTML=rows.map(x=>{const d=toDate(x.due_date);return `<div class="rt-reminder-item"><div><b>${esc(x.vehicle?.plate_no||'-')}</b><span>${esc(x.customer?.name||'Pelanggan')} · ${esc(x.reminder_type||'Servis')}</span></div><strong>${d?d.toLocaleDateString('ms-MY'):'-'}</strong></div>`}).join('')}
function renderChart(rows){const bars=$('dashSalesBars'),labels=$('dashSalesLabels');if(!bars||!labels)return;const n=new Date(),days=[];for(let i=6;i>=0;i--){const d=new Date(n.getFullYear(),n.getMonth(),n.getDate()-i);days.push({key:`${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`,label:d.toLocaleDateString('ms-MY',{weekday:'short'}),total:0})}const idx=new Map(days.map((x,i)=>[x.key,i]));rows.forEach(inv=>{const d=toDate(inv.created_at);if(!d)return;const i=idx.get(`${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`);if(i!==undefined)days[i].total+=Number(inv.total||0)});const max=Math.max(...days.map(x=>x.total),1);bars.innerHTML=days.map(x=>`<div class="rt-bar-wrap" title="${esc(x.label)}: ${money(x.total)}"><span>${x.total?money(x.total).replace('RM ',''):''}</span><i style="height:${Math.max(x.total?10:3,(x.total/max)*100).toFixed(1)}%"></i></div>`).join('');labels.innerHTML=days.map(x=>`<span>${esc(x.label)}</span>`).join('');set('dashSalesPeriod','7 Hari')}
function renderFocus({bookings,activeJobs,lowStockRows,drawer}){set('dashBookingToday',bookings.length);set('dashFocusJobs',activeJobs);set('dashFocusStock',lowStockRows.length);set('dashFocusDrawer',drawer?'OPEN':'CLOSED');const d=$('dashFocusDrawer');if(d){d.classList.toggle('is-open',!!drawer);d.classList.toggle('is-closed',!drawer)}}
function renderSystem(drawer){set('dashDbStatus','CONNECTED');set('dashDrawerStatus',drawer?'OPEN':'CLOSED');set('dashWorkshopStatus','LIVE');const s=$('dashDbStatus');if(s)s.classList.add('ok')}

async function loadInner(){
  const client=sb();if(!client)throw new Error('Supabase belum sedia.');const {companyId,locationId}=await ctx();const [ts,te]=localRange(),[ws,we]=weekRange();
  const [customerCount,activeJobs,todayInv,weekInv,stockRows,rem,bookings,openDrawer]=await Promise.all([
    count('customers',companyId,q=>q.eq('active',true)),
    count('job_cards',companyId,q=>q.in('status',['OPEN','IN_PROGRESS','WAITING_PARTS'])),
    paidInvoices(companyId,ts,te,2000), paidInvoices(companyId,ws,we,10000), lowStock(companyId,locationId), reminders(companyId), todayBookings(companyId), drawer(companyId,locationId)
  ]);
  const pm=await methods(todayInv.slice(0,8).map(x=>x.id),companyId), sales=todayInv.reduce((a,x)=>a+Number(x.total||0),0);
  set('dashTodaySales',money(sales));set('dashTodayTransactions',todayInv.length.toLocaleString('ms-MY'));set('dashActiveJobs',activeJobs.toLocaleString('ms-MY'));set('dashTotalCustomers',customerCount.toLocaleString('ms-MY'));set('dashLowStock',stockRows.length.toLocaleString('ms-MY'));
  renderSales(todayInv,pm);renderReminders(rem);renderChart(weekInv);renderFocus({bookings,activeJobs,lowStockRows:stockRows,drawer:openDrawer});renderSystem(openDrawer);
  set('dashLastUpdated','Dikemas kini '+new Date().toLocaleTimeString('ms-MY',{hour:'2-digit',minute:'2-digit'}));
}
window.loadDashboard=async function(){try{await loadInner()}catch(e){if(isJwtFuture(e)&&await refreshSessionOnce()){try{return await loadInner()}catch(e2){e=e2}}console.error('Dashboard error:',e);set('dashDbStatus','ERROR');const el=$('dashRecentSales');if(el)el.innerHTML=`<div class="rt-empty rt-error">Dashboard error: ${esc(errText(e))}</div>`}};
let started=false,interval=null;window.startDashboardRealtime=function(){if(started)return;started=true;interval=setInterval(()=>{if(document.visibilityState==='visible')window.loadDashboard()},30000);window.addEventListener('focus',()=>window.loadDashboard());document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')window.loadDashboard()})};
window.RT_DASH_DEBOUNCE=window.RT_DASH_DEBOUNCE||{timer:null};window.rtDebouncedDashboard=function(fn,ms){clearTimeout(window.RT_DASH_DEBOUNCE.timer);window.RT_DASH_DEBOUNCE.timer=setTimeout(()=>{try{fn()}catch(e){console.warn('Dashboard refresh:',e)}},ms||350)};
})();
