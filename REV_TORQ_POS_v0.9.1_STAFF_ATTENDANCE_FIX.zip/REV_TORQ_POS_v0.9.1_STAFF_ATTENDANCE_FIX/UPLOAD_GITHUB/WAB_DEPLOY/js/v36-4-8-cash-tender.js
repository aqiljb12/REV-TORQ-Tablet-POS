/* REV TORQ V36.4.8 — POS CASH TENDER UI
   Restores visible CASH received/change controls. Does not alter DB schema. */
(function(){
  'use strict';
  function money(v){const n=Number(v);return 'RM '+(Number.isFinite(n)?n:0).toFixed(2)}
  function total(){
    const cart=typeof window.rtGetPosCart==='function'?window.rtGetPosCart():[];
    const sub=cart.reduce((s,i)=>s+(Number(i.qty)||0)*(Number(i.price)||0),0);
    const disc=Math.min(Math.max(0,Number(document.getElementById('posDiscount')?.value||0)),sub);
    return Math.max(0,sub-disc);
  }
  function syncCashUI(){
    const t=total(), method=String(window.posPayMethod||'CASH').toUpperCase();
    const box=document.getElementById('rtCashTenderBox');
    const inp=document.getElementById('posAmountReceived');
    const due=document.getElementById('rtCashDue');
    const ttl=document.getElementById('rtCashTotal');
    const rec=document.getElementById('rtCashReceived');
    const ch=document.getElementById('posChange');
    if(due)due.textContent=money(t);if(ttl)ttl.textContent=money(t);
    if(method==='CASH'){
      if(box)box.style.display='block';
      if(inp && (inp.value==='' || Number(inp.value)===0)) inp.value=t.toFixed(2);
    }else{
      if(box)box.style.display='none';
      if(inp)inp.value=t.toFixed(2);
    }
    const r=Number(inp?.value||0), change=r-t;
    if(rec)rec.textContent=money(r);
    if(ch){ch.textContent=money(Math.max(0,change));ch.style.color=change>=0?'#16a34a':'#dc2626'}
    const checkout=document.getElementById('btnCheckout');
    if(checkout){
      checkout.disabled=!(t>0 && (method!=='CASH' || r>=t));
      checkout.title=checkout.disabled&&method==='CASH'?'Masukkan jumlah diterima yang mencukupi.':'';
    }
  }
  const originalSet=window.posSetPaymentMethod;
  window.posSetPaymentMethod=function(method){
    if(typeof originalSet==='function')originalSet(method);
    window.posPayMethod=method;
    syncCashUI();
  };
  const originalCalc=window.posCalculateTotal;
  window.posCalculateTotal=function(){
    if(typeof originalCalc==='function')originalCalc();
    syncCashUI();
  };
  window.rtSyncCashTender=syncCashUI;
  window.addEventListener('load',()=>{
    setTimeout(()=>{
      const inp=document.getElementById('posAmountReceived');
      inp?.addEventListener('input',syncCashUI);
      document.getElementById('posDiscount')?.addEventListener('input',syncCashUI);
      document.getElementById('posDiscount')?.addEventListener('change',syncCashUI);
      syncCashUI();
    },900);
  });
})();


/* REV TORQ v0.8.2 — canonical payment selector visual/state sync */
(function(){
  'use strict';
  const previous=window.posSetPaymentMethod;
  window.posSetPaymentMethod=function(method){
    method=String(method||'CASH').toUpperCase();
    if(typeof previous==='function') previous(method);
    window.posPayMethod=method;
    document.querySelectorAll('.pos-pay-btn').forEach(function(btn){
      btn.classList.toggle('active-method', btn.id==='btnPay'+method);
      btn.setAttribute('aria-pressed', btn.id==='btnPay'+method ? 'true':'false');
    });
    const cashBox=document.getElementById('rtCashTenderBox');
    if(cashBox) cashBox.style.display=method==='CASH'?'block':'none';
    if(typeof window.rtSyncCashTender==='function') window.rtSyncCashTender();
  };
  window.addEventListener('load',function(){setTimeout(function(){
    const selected=String(window.posPayMethod||'CASH').toUpperCase();
    document.querySelectorAll('.pos-pay-btn').forEach(function(btn){btn.classList.toggle('active-method',btn.id==='btnPay'+selected);});
  },1000)});
})();
