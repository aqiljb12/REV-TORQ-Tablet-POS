/*
 * REV TORQ V38.6.8 - Android Bluetooth thermal printer bridge via RawBT
 * RawBT receives raw ESC/POS bytes through rawbt:base64,<BASE64>.
 */
(function(){
  'use strict';
  const KEY='rt_printer_settings_v33';
  const DEFAULTS={mode:'auto',name:'',autoPrint:true,autoDrawer:true,paper:'80mm'};

  function isNativeApp(){
    try{
      return !!(window.RevTorqNative && typeof window.RevTorqNative.isNativeApp==='function' && window.RevTorqNative.isNativeApp());
    }catch(_){
      return new URLSearchParams(location.search||'').get('native')==='1';
    }
  }
  function settings(){
    try{
      const st=Object.assign({},DEFAULTS,JSON.parse(localStorage.getItem(KEY)||'{}'));
      // Browser print is not a valid thermal-printer path inside the native APK.
      if(isNativeApp() && st.mode==='browser') st.mode='rawbt';
      return st;
    }catch(_){return {...DEFAULTS};}
  }
  function isAndroid(){return /Android/i.test(navigator.userAgent||'') || isNativeApp();}
  function canUse(){
    const st=settings();
    return isAndroid() && (st.mode==='auto'||st.mode==='bluetooth'||st.mode==='rawbt');
  }
  function clean(v){
    return String(v??'')
      .replace(/\u00a0/g,' ')
      .replace(/[−–—]/g,'-')
      .replace(/[•·]/g,'-')
      .replace(/[✓✔]/g,'OK')
      .replace(/[×✕]/g,'x')
      .replace(/[\u2018\u2019]/g,"'")
      .replace(/[\u201c\u201d]/g,'"')
      .replace(/[^\x00-\x7F]/g,'');
  }
  function ascii(s){
    const t=clean(s), b=new Uint8Array(t.length);
    for(let i=0;i<t.length;i++) b[i]=t.charCodeAt(i)&255;
    return b;
  }
  function concat(){
    let n=0; for(const a of arguments)n+=a.length;
    const out=new Uint8Array(n); let p=0;
    for(const a of arguments){out.set(a,p);p+=a.length;}
    return out;
  }
  function b64(bytes){
    let bin='', chunk=0x8000;
    for(let i=0;i<bytes.length;i+=chunk)
      bin+=String.fromCharCode.apply(null,bytes.subarray(i,Math.min(i+chunk,bytes.length)));
    return btoa(bin);
  }
  function receiptBytes(area){
    const width=(settings().paper||'80mm')==='58mm'?32:48;
    const lines=clean(area.innerText||area.textContent||'')
      .split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
    const wrapped=[];
    for(let line of lines){
      while(line.length>width){wrapped.push(line.slice(0,width));line=line.slice(width);}
      if(line)wrapped.push(line);
    }
    const ESC=27,GS=29;
    const out=[new Uint8Array([ESC,64]),new Uint8Array([ESC,97,1]),
      ascii((wrapped[0]||'REV TORQ PERFORMANCE')+'\n'),
      new Uint8Array([ESC,97,0])];
    for(let i=1;i<wrapped.length;i++)out.push(ascii(wrapped[i]+'\n'));
    out.push(ascii('\n'),new Uint8Array([ESC,100,4]),new Uint8Array([GS,86,1]));
    return concat.apply(null,out);
  }
  function testBytes(){
    const ESC=27,GS=29;
    const shop=clean((window.rtWorkshopProfile||{}).workshopName||'REV TORQ PERFORMANCE');
    return concat(
      new Uint8Array([ESC,64]),new Uint8Array([ESC,97,1]),
      ascii(shop+'\n'),ascii('MPT-II DIRECT PRINT TEST\n'),
      new Uint8Array([ESC,97,0]),ascii('------------------------------\n'),
      ascii('Bluetooth / ESC-POS OK\n'),
      ascii(new Date().toLocaleString('ms-MY')+'\n'),
      ascii('------------------------------\n'),
      new Uint8Array([ESC,100,4]),new Uint8Array([GS,86,1])
    );
  }
  function launch(bytes){
    const uri='rawbt:base64,'+b64(bytes);

    // APK path: hand the RawBT URI to Android through the native bridge.
    // This prevents WebView from showing "Webpage not available" for rawbt:.
    try{
      if(window.RevTorqNative && typeof window.RevTorqNative.launchRawBt==='function'){
        window.RevTorqNative.launchRawBt(uri);
        return true;
      }
    }catch(e){
      console.warn('Native RawBT bridge failed, falling back to URI:',e);
    }

    // Browser/PWA path: Android may still dispatch the custom URI externally.
    window.location.href=uri;
    return true;
  }
  async function printReceipt(area){
    if(!canUse())return false;
    launch(receiptBytes(area));
    try{showToast('Resit dihantar ke MPT-II.','success');}catch(_){}
    return true;
  }
  async function testPrint(){
    if(!canUse())throw new Error('Direct Android print memerlukan Android + RawBT. Sila install dan sambung MPT-II dalam RawBT.');
    launch(testBytes());
    try{showToast('Test print dihantar ke MPT-II.','success');}catch(_){}
    return true;
  }
  function hexBytes(hex){
    const cleanHex=String(hex||'').replace(/[^0-9a-f]/gi,'');
    const out=new Uint8Array(Math.floor(cleanHex.length/2));
    for(let i=0;i<out.length;i++) out[i]=parseInt(cleanHex.slice(i*2,i*2+2),16);
    return out;
  }
  async function kickDrawer(hex){
    if(!canUse())throw new Error('Direct drawer memerlukan APK Android + RawBT.');
    const st=settings();
    const bytes=concat(new Uint8Array([27,64]),hexBytes(hex||st.drawerCommand||'1B700019FA'),new Uint8Array([10]));
    launch(bytes);
    try{showToast('Arahan peti dihantar melalui RawBT.','success');}catch(_){}
    return true;
  }
  function isAutoPrintEnabled(){return canUse()&&!!settings().autoPrint;}
  window.rtRawBtPrinter={canUse,printReceipt,testPrint,kickDrawer,isAutoPrintEnabled,receiptBytes,testBytes,isNativeApp};
})();
