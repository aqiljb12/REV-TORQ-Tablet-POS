/* REV TORQ V35.8 - SUPABASE COMPATIBILITY BRIDGE
   Legacy collection API -> real PostgreSQL/Supabase schema.
   Supports old UI field names while keeping UUID-backed database records.
*/
(function(){
'use strict';
const SUPABASE_URL='https://cnvgwzugqdsavaxrwokm.supabase.co';
const SUPABASE_KEY='sb_publishable_jKkWbpvOvbayvyh6KtzK3w_wUjxPClx';
const rtFetch=async(input,init={})=>{
  let last;
  for(let attempt=0;attempt<3;attempt++){
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),15000);
    try{
      const opts={...init,signal:controller.signal};
      return await fetch(input,opts);
    }catch(e){
      last=e;
      if(attempt<2) await new Promise(r=>setTimeout(r,500*(attempt+1)));
    }finally{clearTimeout(timer)}
  }
  throw last;
};
// Preserve the SDK's existing project-specific storage key for upgrades.
const storageKey='sb-'+new URL(SUPABASE_URL).hostname.split('.')[0]+'-auth-token';
window.rtAuthStorageKey=storageKey;
const sb=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY,{
  auth:{storageKey,persistSession:true,autoRefreshToken:true,detectSessionInUrl:false},
  global:{fetch:rtFetch}
});
window.supabaseClient=sb; window.sb=sb;

const map={
 inventory:'products',products:'products',stock_ledger:'stock_movements',stock_movements:'stock_movements',
 settings:'app_settings',system_settings:'app_settings',audit_logs:'audit_logs',customers:'customers',vehicles:'vehicles',
 bookings:'bookings',job_cards:'job_cards',jobs:'job_cards',job_card_items:'job_card_items',
 invoices:'invoices',invoice_items:'invoice_items',payments:'payments',cash_drawers:'cash_drawers',cash_movements:'cash_movements',
 staff:'staff',suppliers:'suppliers',locations:'locations',companies:'companies',expenses:'expenses',grn:'grn',
 service_reminders:'service_reminders',reminders:'service_reminders'
};
const fields={
 inventory:{sku:'sku',name:'name',barcode:'barcode',category:'category',brand:'brand',unit:'unit',costPrice:'cost_price',sellPrice:'sell_price',minStock:'min_stock',active:'active',rackCode:'rack_location',notes:'notes',createdAt:'created_at',updatedAt:'updated_at'},
 products:{sku:'sku',name:'name',barcode:'barcode',category:'category',brand:'brand',unit:'unit',costPrice:'cost_price',sellPrice:'sell_price',minStock:'min_stock',active:'active',rackCode:'rack_location',notes:'notes',createdAt:'created_at',updatedAt:'updated_at'},
 customers:{customerId:'id',name:'name',phone:'phone',email:'email',address:'address',notes:'notes',active:'active',createdAt:'created_at',updatedAt:'updated_at'},
 vehicles:{vehicleId:'id',customerId:'customer_id',plateNo:'plate_no',brand:'brand',model:'model',variant:'variant',year:'year',engineCc:'engine_cc',mileage:'mileage',vin:'vin',notes:'notes',active:'active',createdAt:'created_at',updatedAt:'updated_at'},
 bookings:{bookingNo:'booking_no',customerId:'customer_id',vehicleId:'vehicle_id',customerName:'customer_name',customerPhone:'customer_phone',vehiclePlate:'vehicle_plate',requestedService:'requested_service',preferredDate:'preferred_date',preferredTime:'preferred_time',notes:'notes',source:'source',status:'status',createdAt:'created_at',updatedAt:'updated_at'},
 job_cards:{jobNo:'job_no',bookingId:'booking_id',customerId:'customer_id',vehicleId:'vehicle_id',assignedStaffId:'assigned_staff_id',status:'status',complaint:'complaint',diagnosis:'diagnosis',inspection:'inspection',inspectionChecklist:'inspection',mileageIn:'mileage_in',mileageOut:'mileage_out',estimatedTotal:'estimated_total',actualTotal:'actual_total',total:'actual_total',openedAt:'opened_at',completedAt:'completed_at',createdBy:'created_by',updatedBy:'updated_by',createdAt:'created_at',updatedAt:'updated_at'},
 staff:{staffId:'staff_code',staffCode:'staff_code',name:'name',phone:'phone',email:'email',authEmail:'email',role:'role',active:'active',removedFromActiveList:'removed_from_active_list',uid:'auth_user_id',createdAt:'created_at',updatedAt:'updated_at'},
 suppliers:{supplierId:'id',supplierCode:'supplier_code',name:'name',company:'name',phone:'phone',email:'email',address:'address',registrationNo:'registration_no',active:'active',createdAt:'created_at',updatedAt:'updated_at'},
 invoices:{invoiceNo:'invoice_no',customerId:'customer_id',vehicleId:'vehicle_id',jobCardId:'job_card_id',staffId:'staff_id',deviceId:'device_id',subtotal:'subtotal',discount:'discount',tax:'tax',total:'total',status:'status',paymentStatus:'payment_status',createdAt:'created_at',updatedAt:'updated_at',voidedAt:'voided_at',voidedBy:'voided_by',voidReason:'void_reason'},
 invoice_items:{invoiceId:'invoice_id',productId:'product_id',jobItemType:'job_item_type',description:'description',quantity:'quantity',unitPrice:'unit_price',discount:'discount',lineTotal:'line_total'},
 payments:{companyId:'company_id',invoiceId:'invoice_id',transactionId:'transaction_id',paymentMethod:'payment_method',amount:'amount',referenceNo:'reference_no',staffId:'staff_id',deviceId:'device_id',createdAt:'created_at'},
 cash_drawers:{companyId:'company_id',locationId:'location_id',deviceId:'device_id',drawerCode:'drawer_code',status:'status',openedBy:'opened_by',openedAt:'opened_at',openingFloat:'opening_float',closedBy:'closed_by',closedAt:'closed_at',expectedCash:'expected_amount',actualCash:'actual_amount',closingCash:'actual_amount',difference:'difference'},
 cash_movements:{companyId:'company_id',cashDrawerId:'cash_drawer_id',transactionId:'transaction_id',movementType:'movement_type',type:'movement_type',amount:'amount',referenceType:'reference_type',referenceId:'reference_id',reason:'reason',staffId:'staff_id',deviceId:'device_id',createdAt:'created_at',timestamp:'created_at'},
 stock_ledger:{companyId:'company_id',locationId:'location_id',productId:'product_id',transactionId:'transaction_id',activity:'movement_type',movementType:'movement_type',quantity:'quantity',unitCost:'unit_cost',referenceType:'reference_type',referenceId:'reference_id',staffId:'staff_id',deviceId:'device_id',timestamp:'created_at',createdAt:'created_at'},
 stock_movements:{companyId:'company_id',locationId:'location_id',productId:'product_id',transactionId:'transaction_id',movementType:'movement_type',quantity:'quantity',unitCost:'unit_cost',referenceType:'reference_type',referenceId:'reference_id',staffId:'staff_id',deviceId:'device_id',createdAt:'created_at'},
 expenses:{expenseNo:'expense_no',companyId:'company_id',locationId:'location_id',category:'category',description:'description',amount:'amount',paymentMethod:'payment_method',referenceNo:'reference_no',staffId:'staff_id',createdAt:'created_at'},
 grn:{grnNo:'grn_no',companyId:'company_id',locationId:'location_id',purchaseOrderId:'purchase_order_id',supplierId:'supplier_id',status:'status',createdBy:'created_by',createdAt:'created_at'},
 service_reminders:{customerId:'customer_id',vehicleId:'vehicle_id',lastJobCardId:'last_job_card_id',serviceDate:'due_date',reminderDate:'due_date',dueDate:'due_date',dueMileage:'due_mileage',serviceType:'reminder_type',reminderType:'reminder_type',status:'status',createdAt:'created_at',updatedAt:'updated_at'},
 reminders:{customerId:'customer_id',vehicleId:'vehicle_id',lastJobCardId:'last_job_card_id',serviceDate:'due_date',reminderDate:'due_date',dueDate:'due_date',dueMileage:'due_mileage',serviceType:'reminder_type',reminderType:'reminder_type',status:'status',createdAt:'created_at',updatedAt:'updated_at'},
 audit_logs:{companyId:'company_id',locationId:'location_id',transactionId:'transaction_id',staffId:'staff_id',action:'action',entityType:'entity_type',entityId:'entity_id',beforeData:'before_data',afterData:'after_data',metadata:'metadata',timestamp:'created_at',createdAt:'created_at'}
};
const natural={inventory:'sku',products:'sku',customers:'customer_code',job_cards:'job_no',jobs:'job_no',invoices:'invoice_no',suppliers:'supplier_code',grn:'grn_no',bookings:'booking_no'};
const companyScoped=new Set(['products','inventory','customers','vehicles','bookings','job_cards','jobs','invoices','payments','cash_drawers','cash_movements','stock_ledger','stock_movements','staff','suppliers','expenses','grn','service_reminders','audit_logs']);
const isUuid=v=>/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(v||''));
const companyId=()=>window.currentProfile?.companyId||null;
async function defaultLocation(){
 let q=sb.from('locations').select('id').eq('active',true);const c=companyId();if(c)q=q.eq('company_id',c);const r=await q.order('code').limit(1).maybeSingle();if(r.error)throw r.error;return r.data?.id||null;
}
function mapField(c,k){return fields[c]?.[k]||k}
async function resolveStaffUuid(value){
 const v=String(value||'').trim();
 if(!v)return null;
 if(isUuid(v))return v;
 const r=await sb.from('staff').select('id').eq('staff_code',v.toUpperCase()).limit(1).maybeSingle();
 if(r.error)throw r.error;
 return r.data?.id||null;
}
async function normalizePayload(collection,data){
 const d={...data};const m=fields[collection]||{};
 for(const [legacy,dbcol] of Object.entries(m)) if(d[legacy]!==undefined&&d[dbcol]===undefined)d[dbcol]=d[legacy];
 const remove=['customerId','customerDocId','vehicleId','jobNo','staffId','staffName','uid','authProvider','createdAt','updatedAt','createdBy','createdByName','plateNo','sellPrice','costPrice','minStock','rackCode','invoiceNo','paymentMethod','amountPaid','amountReceived','balance','items','customerName','customerPhone','assignedStaffId','assignedStaffUid','assignedStaffName','vehicleModel','partsUsedNotes','partsNotes','partsCost','laborCost','inspectionChecklist','employmentStatus','directoryVisible','archivedFromStaffList','deactivatedAt','deactivatedBy','reactivatedAt','reactivatedBy','contactPerson','role','details','stock'];
 remove.forEach(k=>delete d[k]);
 if(collection==='customers'&&data.customerId&&!isUuid(data.customerId))d.customer_code=data.customerId;
 if(collection==='job_cards'&&data.jobNo)d.job_no=data.jobNo;
 if(collection==='invoices'&&data.invoiceNo)d.invoice_no=data.invoiceNo;
 if(collection==='suppliers'&&data.supplierId&&!isUuid(data.supplierId))d.supplier_code=data.supplierId;
 if(collection==='grn'&&data.grnNo)d.grn_no=data.grnNo;
 if(collection==='bookings'&&data.bookingNo)d.booking_no=data.bookingNo;
 if(collection==='stock_ledger'||collection==='stock_movements'){
   let mt=d.movement_type||d.activity||'ADJUSTMENT_IN';
   const aliases={OPENING_STOCK:'OPENING',ADJUST_IN:'ADJUSTMENT_IN',ADJUST_OUT:'ADJUSTMENT_OUT',ADJUST_SET:'ADJUSTMENT_IN',PURCHASE:'PURCHASE',GRN:'GRN',SALE:'SALE'};
   d.movement_type=aliases[mt]||mt;
   if(!['OPENING','PURCHASE','GRN','SALE','JOB_USAGE','RETURN','ADJUSTMENT_IN','ADJUSTMENT_OUT','TRANSFER_IN','TRANSFER_OUT','VOID_REVERSAL'].includes(d.movement_type))d.movement_type='ADJUSTMENT_IN';
   d.transaction_id=isUuid(d.transaction_id)?d.transaction_id:crypto.randomUUID();
   if(d.reference_id&&!isUuid(d.reference_id))delete d.reference_id;
   if(d.quantity===undefined&&d.qtyChange!==undefined)d.quantity=Number(d.qtyChange||0);
   delete d.activity; delete d.beforeStock; delete d.afterStock; delete d.note;
 }
 if(collection==='service_reminders'){
   if(data.serviceDate)d.due_date=data.serviceDate;
   if(data.serviceType)d.reminder_type=data.serviceType;
   if(data.reminderDate)d.due_date=data.reminderDate;
 }
 if(collection==='expenses' && !d.expense_no)d.expense_no='EXP-'+Date.now().toString().slice(-10);
 if(companyId()&&companyScoped.has(collection)&&d.company_id===undefined)d.company_id=companyId();
 if((collection==='products'||collection==='inventory')&&d.sell_price===undefined&&data.price!==undefined)d.sell_price=data.price;
 if((collection==='products'||collection==='inventory')&&d.cost_price===undefined&&data.cost!==undefined)d.cost_price=data.cost;
 if(collection==='staff'&&d.auth_user_id===undefined&&data.uid)d.auth_user_id=data.uid;
 if((collection==='audit_logs'||collection==='payments'||collection==='cash_movements'||collection==='stock_movements')&&d.staff_id){d.staff_id=await resolveStaffUuid(d.staff_id);if(!d.staff_id)delete d.staff_id;}
 if((collection==='job_cards'||collection==='expenses'||collection==='grn')&&d.created_by){d.created_by=await resolveStaffUuid(d.created_by);if(!d.created_by)delete d.created_by;}
 if(collection==='job_cards'&&d.updated_by){d.updated_by=await resolveStaffUuid(d.updated_by);if(!d.updated_by)delete d.updated_by;}
 if(collection==='stock_movements' || collection==='stock_ledger'){
   if(!d.location_id)d.location_id=await defaultLocation();
   if(!d.location_id)throw new Error('Lokasi aktif tidak dijumpai.');
   if(!d.company_id)d.company_id=companyId();
 }
 if(collection==='audit_logs'&&!d.company_id)d.company_id=companyId();
 if(collection==='settings'||collection==='system_settings'){
   const setting={company_id:companyId(),location_id:d.location_id||await defaultLocation(),setting_key:data.settingKey||data.key||'workshop',setting_value:{...data}};
   delete setting.setting_value.id; delete setting.setting_value.company_id; delete setting.setting_value.location_id;
   return setting;
 }
 return d;
}
async function resolveRow(collection,id){
 const table=map[collection]||collection;
 if(collection==='staff'&&isUuid(id)){
   return {id,query:(async()=>{const byId=await sb.from('staff').select('*').eq('id',id).maybeSingle();if(byId.error)throw byId.error;if(byId.data)return byId;return sb.from('staff').select('*').eq('auth_user_id',id).maybeSingle();})()};
 }
 if(collection==='settings'||collection==='system_settings'){
   return {id,query:sb.from('app_settings').select('*').eq('company_id',companyId()).eq('setting_key',id).limit(1).maybeSingle()};
 }
 if(isUuid(id))return {id,query:sb.from(table).select('*').eq('id',id).maybeSingle()};
 const nk=natural[collection];
 if(nk)return {id,query:sb.from(table).select('*').eq(nk,id).limit(1).maybeSingle()};
 return {id,query:sb.from(table).select('*').eq('id',id).maybeSingle()};
}
const cache={customers:new Map(),vehicles:new Map(),staff:new Map()};
async function legacyRow(collection,row){
 if(!row)return row;const out={...row};const m=fields[collection]||{};
 for(const [a,b] of Object.entries(m))if(out[a]===undefined)out[a]=row[b];
 if(collection==='inventory'||collection==='products'){out.stock=await getStock(row.id);out.sellPrice=Number(row.sell_price||0);out.costPrice=Number(row.cost_price||0);out.minStock=Number(row.min_stock||0);out.rackCode=row.rack_location||'';}
 if(collection==='customers'){out.id=row.id;out.customerId=row.id;out.createdAt=row.created_at;out.updatedAt=row.updated_at;}
 if(collection==='vehicles'){out.id=row.id;out.vehicleId=row.id;out.createdAt=row.created_at;out.updatedAt=row.updated_at;}
 if(collection==='staff'){out.id=row.id;out.staffId=row.staff_code;out.uid=row.auth_user_id;out.authEmail=row.email;}
 if(collection==='job_cards'){
   out.id=row.id;out.jobNo=row.job_no;out.customerId=row.customer_id;out.vehicleId=row.vehicle_id;out.assignedStaffId=row.assigned_staff_id;out.assignedStaffUid=row.assigned_staff_id;out.createdAt=row.created_at;out.updatedAt=row.updated_at;out.total=Number(row.actual_total||row.estimated_total||0);out.partsCost=0;out.laborCost=0;
   if(row.customer_id&&!cache.customers.has(row.customer_id)){const r=await sb.from('customers').select('name,phone').eq('id',row.customer_id).maybeSingle();cache.customers.set(row.customer_id,r.data||{});}const c=cache.customers.get(row.customer_id)||{};out.customerName=c.name||'-';
   if(row.vehicle_id&&!cache.vehicles.has(row.vehicle_id)){const r=await sb.from('vehicles').select('plate_no,model,brand').eq('id',row.vehicle_id).maybeSingle();cache.vehicles.set(row.vehicle_id,r.data||{});}const v=cache.vehicles.get(row.vehicle_id)||{};out.plateNo=v.plate_no||'-';out.vehicleModel=[v.brand,v.model].filter(Boolean).join(' ')||'-';
   if(row.assigned_staff_id&&!cache.staff.has(row.assigned_staff_id)){const r=await sb.from('staff').select('name,staff_code').eq('id',row.assigned_staff_id).maybeSingle();cache.staff.set(row.assigned_staff_id,r.data||{});}const s=cache.staff.get(row.assigned_staff_id)||{};out.assignedStaffName=s.name||s.staff_code||'-';
 }
 if(collection==='invoices'){out.invoiceNo=row.invoice_no;out.createdAt=row.created_at;out.paymentMethod=out.paymentMethod||null;out.amountPaid=out.amountPaid||row.total;out.balance=0;}
 if(collection==='cash_drawers'){out.openingFloat=row.opening_float;out.expectedCash=row.expected_amount;out.actualCash=row.actual_amount;out.closingCash=row.actual_amount;}
 if(collection==='cash_movements'){out.type=row.movement_type;out.timestamp=row.created_at;out.referenceId=row.reference_id;}
 if(collection==='stock_ledger'||collection==='stock_movements'){out.activity=row.movement_type;out.timestamp=row.created_at;}
 if(collection==='expenses'){out.expenseNo=row.expense_no;out.createdAt=row.created_at;}
 if(collection==='suppliers'){out.supplierId=row.id;out.company=row.name;out.createdAt=row.created_at;}
 if(collection==='grn'){out.grnNo=row.grn_no;out.createdAt=row.created_at;}
 if(collection==='service_reminders'){
   out.serviceDate=row.due_date;out.reminderDate=row.due_date;out.serviceType=row.reminder_type;out.createdAt=row.created_at;
   if(row.customer_id&&!cache.customers.has(row.customer_id)){const r=await sb.from('customers').select('name,phone').eq('id',row.customer_id).maybeSingle();cache.customers.set(row.customer_id,r.data||{});} const c=cache.customers.get(row.customer_id)||{};out.customerName=c.name||'-';out.customerPhone=c.phone||'';
   if(row.vehicle_id&&!cache.vehicles.has(row.vehicle_id)){const r=await sb.from('vehicles').select('plate_no,brand,model').eq('id',row.vehicle_id).maybeSingle();cache.vehicles.set(row.vehicle_id,r.data||{});} const v=cache.vehicles.get(row.vehicle_id)||{};out.plateNo=v.plate_no||'-';out.vehicleModel=[v.brand,v.model].filter(Boolean).join(' ');
 }
 if(collection==='audit_logs'){out.timestamp=row.created_at;out.createdAt=row.created_at;}
 if(collection==='settings'||collection==='system_settings'){Object.assign(out,row.setting_value||{});out.id=row.id;out.settingKey=row.setting_key;out.createdAt=row.updated_at;out.updatedAt=row.updated_at;}
 return out;
}
async function getStock(productId,locationId){
 let loc=locationId||await defaultLocation();if(!loc)return 0;const r=await sb.from('stock_balances').select('quantity').eq('product_id',productId).eq('location_id',loc).maybeSingle();if(r.error)return 0;return Number(r.data?.quantity||0);
}
async function writeStock(productId,quantity,locationId){
 const loc=locationId||await defaultLocation();if(!loc)throw new Error('Lokasi aktif tidak dijumpai.');const r=await sb.from('stock_balances').upsert({product_id:productId,location_id:loc,quantity:Number(quantity),reserved_quantity:0,updated_at:new Date().toISOString()},{onConflict:'product_id'});if(r.error)throw r.error;
}
class Doc{
 constructor(collection,id){this.collection=collection;this.table=map[collection]||collection;this.id=id}
 async get(){const rr=await resolveRow(this.collection,this.id);const r=await rr.query;if(r.error)throw r.error;const row=r.data?await legacyRow(this.collection,r.data):null;return {exists:!!row,id:row?.id||this.id,data:()=>row,ref:{id:row?.id||this.id}}}
 async set(data,opts={}){return this._write(data,true,opts)}
 async update(data){return this._write(data,false,{merge:false})}
 async _write(data,insert,opts){
   const payload=await normalizePayload(this.collection,data);const nk=natural[this.collection];let targetId=isUuid(this.id)?this.id:null;
   if(targetId)payload.id=targetId;
   if(!insert&&!targetId&&nk){const q=await sb.from(this.table).select('id').eq(nk,this.id).limit(1).maybeSingle();if(q.error)throw q.error;if(!q.data)throw new Error(`${this.collection} ${this.id} tidak dijumpai.`);targetId=q.data.id;}
   if(targetId)payload.id=targetId;
   let r;
   if((this.collection==='settings'||this.collection==='system_settings')){
     r=await sb.from('app_settings').upsert(payload,{onConflict:'company_id,location_id,setting_key'}).select('id').single();
   }else if(insert||opts.merge){
     r=await sb.from(this.table).upsert(payload,{onConflict:'id'}).select('id').single();
   }else{
     r=await sb.from(this.table).update(payload).eq('id',targetId||this.id).select('id').maybeSingle();
   }
   if(r.error)throw r.error;
   const actualId=targetId||payload.id||r.data?.id;
   if((this.collection==='inventory'||this.collection==='products')&&data.stock!==undefined&&actualId)await writeStock(actualId,data.stock);
   return r;
 }
 async delete(){const rr=await resolveRow(this.collection,this.id);const r=await rr.query;if(r.error)throw r.error;if(!r.data)return {error:null};const d=await sb.from(this.table).delete().eq('id',r.data.id);if(d.error)throw d.error;return d;}
}
class Query{
 constructor(collection){this.collection=collection;this.table=map[collection]||collection;this.filters=[];this.order=null;this.max=null;this.cursor=null;this.offset=0}
 where(f,op,v){this.filters.push([f,op,v]);return this}
 orderBy(f,d='asc'){this.order=[f,d];return this}
 limit(n){this.max=n;return this}
 startAfter(doc){this.cursor=doc;return this}
 onSnapshot(next,error){let dead=false;const run=async()=>{if(dead)return;try{const snap=await this.get();next&&next(snap);}catch(e){error&&error(e);}};run();const t=setInterval(run,15000);return ()=>{dead=true;clearInterval(t)}}
 async get(){
   let q=sb.from(this.table).select('*');
   if(companyId()&&!['companies','locations'].includes(this.collection))q=q.eq('company_id',companyId());
   for(const [f,op,v] of this.filters){const c=mapField(this.collection,f);if(op==='==')q=q.eq(c,v);else if(op==='!=')q=q.neq(c,v);else if(op==='>')q=q.gt(c,v);else if(op==='>=')q=q.gte(c,v);else if(op==='<')q=q.lt(c,v);else if(op==='<=' )q=q.lte(c,v);else if(op==='in')q=q.in(c,v);else if(op==='not-in')q=q.not(c,'in',`(${(v||[]).map(x=>`"${String(x).replace(/"/g,'\\"')}"`).join(',')})`);else if(op==='array-contains')q=q.contains(c,[v]);}
   if(this.order){const [f,d]=this.order;q=q.order(mapField(this.collection,f),{ascending:d!=='desc'})}
   if(this.cursor&&this.order){const [f,d]=this.order;const row=this.cursor.data?this.cursor.data():this.cursor;const val=row?.[f]??row?.[mapField(this.collection,f)];if(val!==undefined)q=d==='desc'?q.lt(mapField(this.collection,f),val):q.gt(mapField(this.collection,f),val);}
   if(this.offset)q=q.range(this.offset,(this.offset+(this.max||100))-1);else if(this.max)q=q.limit(this.max);
   const r=await q;if(r.error)throw r.error;const rows=r.data||[];const docs=[];for(const row of rows){const legacy=await legacyRow(this.collection,row);docs.push({exists:true,id:row.id,data:()=>legacy,ref:{id:row.id}})}return {empty:docs.length===0,docs,size:docs.length,forEach:fn=>docs.forEach(fn)};
 }
}
class Collection extends Query{
 constructor(c){super(c)}
 doc(id){return new Doc(this.collection,id)}
 async add(data){const payload=await normalizePayload(this.collection,data);const r=await sb.from(this.table).insert(payload).select('id').single();if(r.error)throw r.error;return {id:r.data.id}}
}
class Tx{constructor(){this.ops=[]}async get(ref){return ref.get()}update(ref,data){this.ops.push(()=>ref.update(data));return this}set(ref,data,opts){this.ops.push(()=>ref.set(data,opts));return this}delete(ref){this.ops.push(()=>ref.delete());return this}async commit(){for(const op of this.ops)await op()}}
window.db={collection:n=>new Collection(n),doc:path=>{const p=String(path).split('/');return new Doc(p[0],p[1])},runTransaction:async fn=>{const tx=new Tx();const result=await fn(tx);await tx.commit();return result},batch:()=>new Tx()};
window.supabaseRpc=async(name,args)=>{const r=await sb.rpc(name,args);if(r.error)throw r.error;return r.data};
window.getSupabaseSession=()=>sb.auth.getSession();window.supabaseSignOut=()=>sb.auth.signOut();window.rtSupabaseReady=true;
window.testSupabase=async()=>{const r=await sb.auth.getSession();if(window.dbgLog)dbgLog('Supabase: CONNECTED | session='+(r.data.session?'YES':'NO'))};
window.testSupabaseDB=async()=>{const r=await sb.from('companies').select('id').limit(1);if(r.error)throw r.error;if(window.dbgLog)dbgLog('PostgreSQL: CONNECTED')};
})();
