/* REV TORQ v0.9.0 — operational receipt history / staff reprint
   Staff POS users can reprint receipts without entering ADMIN ONLY.
   VOID remains admin-only. Receipt data is exposed only through role-checked RPCs.
*/
(function(){
'use strict';
const PAGE=20;
let rows=[];
let offset=0;
let hasMore=true;
let loading=false;
let search='';
let searchTimer=null;

const legacyPrint=window.rtPrintReceipt;
const legacyReceipt=window.generateReceiptFromInvoice;

function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function num(v){const n=Number(v);return Number.isFinite(n)?n:0;}
function money(v){return 'RM '+num(v).toFixed(2);}
function date(v){const d=v?new Date(v):null;return d&&!Number.isNaN(d.getTime())?d:null;}
function toast(msg,type='info'){try{window.showToast?.(msg,type);}catch(_){}}
function currentStaff(){
  const p=window.currentProfile||{};
  return p.name||p.staffId||p.staff_code||'Staff';
}
function isAdmin(){return window.rtIsAdmin?.()===true || window.rtHasAdminAccess?.()===true;}

function showModal(){
  const m=document.getElementById('rtPosHistoryModal');
  if(!m)return false;
  if(m.parentElement!==document.body)document.body.appendChild(m);
  m.style.zIndex='99999';
  m.classList.remove('hidden');m.classList.add('flex');m.style.setProperty('display','flex','important');
  return true;
}
function closeModal(){
  const m=document.getElementById('rtPosHistoryModal');
  if(m){m.classList.add('hidden');m.classList.remove('flex');m.style.setProperty('display','none','important');}
}

function normalize(r){
  return {
    id:r.id,
    invoiceNo:r.invoice_no||r.invoiceNo||r.id,
    total:num(r.total),
    status:r.status||'PAID',
    paymentStatus:r.payment_status||r.paymentStatus||'',
    createdAt:r.created_at||r.createdAt,
    customerName:r.customer_name||r.customerName||'Walk-in',
    customerPhone:r.customer_phone||r.customerPhone||'',
    vehiclePlate:r.vehicle_plate||r.vehiclePlate||'',
    paymentMethod:r.payment_method||r.paymentMethod||'-',
    amountPaid:num(r.amount_paid??r.amountPaid??r.total),
    staffName:r.staff_name||r.staffName||'',
    staffCode:r.staff_code||r.staffCode||''
  };
}

function render(){
  const el=document.getElementById('rtHistoryList');if(!el)return;
  if(!rows.length){el.innerHTML='<div class="text-center py-10 text-slate-400 text-sm">Tiada rekod jualan dijumpai.</div>';return;}
  el.innerHTML=rows.map(r=>{
    const isVoid=String(r.status||'').toUpperCase()==='VOID';
    const dt=date(r.createdAt)?.toLocaleString('ms-MY')||'-';
    const who=[r.customerName||'Walk-in',r.customerPhone,r.vehiclePlate].filter(Boolean).join(' · ');
    const staff=r.staffName||r.staffCode||'-';
    return `<div class="p-4 rounded-2xl border ${isVoid?'border-rose-200 bg-rose-50':'border-slate-200 bg-slate-50'} flex flex-col md:flex-row md:items-center gap-3">
      <div class="min-w-0 flex-1">
        <div class="font-black text-sm text-slate-800">${esc(r.invoiceNo)}</div>
        <div class="text-xs text-slate-500 mt-1">${esc(who)} · ${esc(dt)}</div>
        <div class="text-[11px] text-slate-500 mt-1">${esc(r.paymentMethod)} · ${money(r.amountPaid)} · Juruwang ${esc(staff)}</div>
      </div>
      <div class="flex items-center gap-2 flex-wrap justify-end">
        <span class="font-black ${isVoid?'text-rose-600':'text-indigo-700'}">${money(r.total)}</span>
        ${isVoid
          ? '<span class="px-2 py-1 rounded-lg bg-rose-100 text-rose-600 text-[10px] font-black">VOID</span>'
          : `<button type="button" onclick="window.rtReprintInvoice('${esc(r.id)}')" class="px-3 py-2 rounded-xl bg-indigo-600 text-white text-xs font-black">PRINT SEMULA</button>`}
        ${isAdmin()&&!isVoid?`<button type="button" onclick="window.rtAskVoidInvoice('${esc(r.id)}')" class="px-3 py-2 rounded-xl bg-rose-600 text-white text-xs font-black">BATAL / VOID</button>`:''}
      </div>
    </div>`;
  }).join('')+(hasMore?'<button type="button" onclick="window.rtLoadMoreHistory()" class="w-full py-3 rounded-2xl bg-slate-900 text-white text-sm font-black mt-2">MUAT LAGI</button>':'<div class="text-center py-3 text-xs text-slate-400">Semua rekod yang sepadan telah dipaparkan.</div>');
}

async function load(reset=true){
  const list=document.getElementById('rtHistoryList');
  if(!showModal()||!list)return;
  if(loading)return;
  if(reset){rows=[];offset=0;hasMore=true;}
  if(!hasMore)return;
  if(typeof window.supabaseRpc!=='function'){
    list.innerHTML='<div class="p-4 rounded-xl bg-red-50 text-red-600 text-sm">Supabase RPC belum tersedia.</div>';
    return;
  }
  loading=true;
  if(reset)list.innerHTML='<div class="text-center py-8 text-slate-400 text-sm">Memuatkan resit...</div>';
  try{
    const data=await window.supabaseRpc('rt_staff_receipt_history',{p_search:search||null,p_limit:PAGE,p_offset:offset});
    const page=Array.isArray(data)?data.map(normalize):[];
    rows=reset?page:rows.concat(page);
    offset=rows.length;
    hasMore=page.length===PAGE;
    render();
  }catch(e){
    console.error('Receipt history RPC failed',e);
    list.innerHTML=`<div class="p-4 rounded-xl bg-red-50 text-red-600 text-sm">Gagal buka sejarah resit: ${esc(e?.message||e)}</div>`;
  }finally{loading=false;}
}

function filter(){
  const q=String(document.getElementById('rtHistorySearch')?.value||'').trim();
  clearTimeout(searchTimer);
  searchTimer=setTimeout(()=>{search=q;load(true);},320);
}

async function reprint(id){
  if(!id)return;
  try{
    if(typeof window.supabaseRpc!=='function')throw new Error('Supabase RPC belum tersedia.');
    const inv=await window.supabaseRpc('rt_staff_receipt_detail',{p_invoice_id:id});
    if(!inv)throw new Error('Invoice tidak dijumpai.');
    if(String(inv.status||'').toUpperCase()==='VOID'){
      toast('Invoice VOID tidak boleh dicetak sebagai jualan sah.','error');return;
    }
    inv.__rtReprint=true;
    inv.__rtReprintAt=new Date().toISOString();
    inv.__rtReprintedBy=currentStaff();
    inv.__rtReprintInvoiceId=id;
    closeModal();
    if(typeof window.generateReceiptFromInvoice!=='function')throw new Error('Renderer receipt tidak tersedia.');
    await window.generateReceiptFromInvoice(inv);
  }catch(e){
    console.error('Receipt reprint failed',e);
    toast('Gagal buka resit: '+(e?.message||e),'error');
  }
}

if(typeof legacyReceipt==='function'){
  window.generateReceiptFromInvoice=async function(inv){
    await legacyReceipt(inv);
    if(!inv?.__rtReprint){window.__rtReprintContext=null;return;}
    const area=document.getElementById('printArea');
    if(!area)return;
    const when=date(inv.__rtReprintAt)||new Date();
    const by=inv.__rtReprintedBy||currentStaff();
    const badge=`<div class="rt-reprint-stamp"><b>SALINAN / REPRINT</b><span>Dicetak semula: ${esc(when.toLocaleString('ms-MY'))}</span><span>Oleh: ${esc(by)}</span></div>`;
    area.insertAdjacentHTML('afterbegin',badge);
    window.__rtReprintContext={invoiceId:inv.__rtReprintInvoiceId||inv.id,invoiceNo:inv.invoiceNo||inv.invNo||inv.id};
    const current=String(window.__rtLastReceiptText||'').trim();
    window.__rtLastReceiptText=['SALINAN / REPRINT',`Dicetak semula: ${when.toLocaleString('ms-MY')}`,`Oleh: ${by}`,'',current].join('\n');
  };
}

if(typeof legacyPrint==='function'){
  window.rtPrintReceipt=async function(opts={}){
    const ok=await legacyPrint(opts);
    const ctx=window.__rtReprintContext;
    if(ok&&ctx?.invoiceId&&typeof window.supabaseRpc==='function'){
      try{
        const source=(location.hostname==='appassets.androidplatform.net'||window.RevTorqNative)?'APK':'WEB';
        const logged=await window.supabaseRpc('rt_log_receipt_reprint',{p_invoice_id:ctx.invoiceId,p_source:source});
        if(logged?.reprint_count)toast(`Print semula direkod (#${logged.reprint_count}).`,'success');
      }catch(e){console.warn('Reprint audit log failed',e);}
    }
    return ok;
  };
}

window.rtOpenPosHistory=function(reset=true){if(reset)search=String(document.getElementById('rtHistorySearch')?.value||'').trim();return load(reset);};
window.rtClosePosHistory=closeModal;
window.rtFilterPosHistory=filter;
window.rtLoadMoreHistory=()=>load(false);
window.rtReprintInvoice=reprint;
})();
