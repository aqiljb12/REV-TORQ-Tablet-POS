/* REV TORQ V38.6.17 - Canonical Inventory list/search/edit
   The production inventory writer uses Supabase `products` + stock_balances.
   The old inventory.js reader still queried the retired `inventory` collection.
*/
(function(){
'use strict';
const $=id=>document.getElementById(id);
function esc(v){
  return String(v??'').replace(/[&<>"']/g,function(c){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c];});
}
async function getCompany(){
  if(typeof window.companyId==='function')return await window.companyId();
  const p=window.currentProfile||{};
  return p.companyId||p.company_id||null;
}
async function getLocation(){
  if(typeof window.locationId==='function')return await window.locationId();
  const p=window.currentProfile||{};
  return p.locationId||p.location_id||null;
}

window.loadInventory=async function(){
  const tbody=document.querySelector('#tblInventory tbody');
  if(!tbody)return;
  tbody.innerHTML='<tr><td colspan="9" class="text-center p-6 text-slate-400">Memuatkan inventori...</td></tr>';
  try{
    const company=await getCompany(), location=await getLocation();
    if(!company)throw new Error('Company tidak dijumpai.');
    const pr=await sb.from('products')
      .select('id,sku,name,category,barcode,rack_location,cost_price,sell_price,min_stock,active,unit')
      .eq('company_id',company)
      .order('sku',{ascending:true});
    if(pr.error)throw pr.error;

    let balances=[];
    if(location && pr.data?.length){
      const ids=pr.data.map(x=>x.id);
      const br=await sb.from('stock_balances').select('product_id,quantity').eq('location_id',location).in('product_id',ids);
      if(br.error)throw br.error;
      balances=br.data||[];
    }
    const stockMap={}; balances.forEach(x=>stockMap[x.product_id]=Number(x.quantity||0));

    const rows=(pr.data||[]).map(d=>{
      const stock=Number(stockMap[d.id]||0), min=Number(d.min_stock??5);
      const stockClass=stock<=min?'text-red-500 font-bold':'text-emerald-600 font-bold';
      return `<tr class="hover:bg-slate-50 border-b border-slate-100">
        <td class="p-4 font-mono font-bold text-indigo-700">${esc(d.sku||'-')}</td>
        <td class="p-4 font-bold text-slate-800">${esc(d.name||'-')}</td>
        <td class="p-4 text-xs font-mono"><span class="bg-slate-100 px-2 py-1 rounded border border-slate-200">${esc(d.category||'-')}</span></td>
        <td class="p-4 font-mono text-xs text-slate-500">${esc(d.barcode||'-')}</td>
        <td class="p-4 font-mono text-xs font-bold text-indigo-600">${esc(d.rack_location||'-')}</td>
        <td class="p-4 font-mono text-right text-slate-500">${typeof formatMoney==='function'?formatMoney(d.cost_price||0):Number(d.cost_price||0).toFixed(2)}</td>
        <td class="p-4 font-mono text-right font-bold text-slate-800">${typeof formatMoney==='function'?formatMoney(d.sell_price||0):Number(d.sell_price||0).toFixed(2)}</td>
        <td class="p-4 font-mono text-center ${stockClass} text-lg">${stock}</td>
        <td class="p-4 text-right space-x-1">
          ${d.active===false?'<span class="text-xs bg-red-50 text-red-500 px-2 py-1 rounded mr-1 border border-red-100">TIDAK AKTIF</span>':''}
          <button onclick="window.openStockAdjustment('${esc(d.sku)}')" class="text-emerald-600 text-[11px] font-black px-2 py-1 rounded-lg bg-emerald-50 border border-emerald-100">STOK</button>
          <button onclick="window.editInventory('${esc(d.sku)}')" class="text-indigo-600 text-[11px] font-black px-2 py-1 rounded-lg bg-indigo-50 border border-indigo-100">EDIT</button>
        </td>
      </tr>`;
    }).join('');
    tbody.innerHTML=rows||'<tr><td colspan="9" class="text-center p-8 text-slate-400">Tiada item inventori</td></tr>';
    try{if(window.feather)feather.replace();}catch(_){}
  }catch(e){
    console.error('loadInventory canonical',e);
    tbody.innerHTML='<tr><td colspan="9" class="text-center p-6 text-red-500">Ralat: '+esc(e.message||e)+'</td></tr>';
  }
};

window.inventoryBarcodeLookup=async function(value){
  const code=String(value||'').trim();
  if(!code)return;
  try{
    const company=await getCompany();
    const r=await sb.from('products').select('id,sku,name,barcode').eq('company_id',company).eq('barcode',code).limit(1).maybeSingle();
    if(r.error)throw r.error;
    if(r.data){
      if(typeof window.openStockAdjustment==='function') window.openStockAdjustment(r.data.sku);
    }else{
      window.openNewInventory();
      const el=$('invBarcode'); if(el){el.value=code;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}
      if(typeof showToast==='function')showToast('Barcode baru. Lengkapkan maklumat item dan simpan.');
    }
  }catch(e){console.error('inventoryBarcodeLookup',e);if(typeof showToast==='function')showToast(e.message||String(e),'error');}
};

window.editInventory=async function(sku){
  try{
    const company=await getCompany();
    const r=await sb.from('products').select('id,sku,name,category,barcode,rack_location,cost_price,sell_price,min_stock,active').eq('company_id',company).eq('sku',String(sku).trim().toUpperCase()).maybeSingle();
    if(r.error)throw r.error;if(!r.data)throw new Error('Item tidak ditemui.');
    const d=r.data;
    $('invIsEdit').value='true';$('invSku').value=d.sku;$('invSku').disabled=true;
    $('invCat').value=d.category||'SPAREPART';$('invName').value=d.name||'';
    $('invBarcode').value=d.barcode||'';$('invRackCode').value=d.rack_location||'';
    $('invCost').value=d.cost_price??0;$('invPrice').value=d.sell_price??0;$('invMinStock').value=d.min_stock??5;
    $('invActive').value=d.active===false?'false':'true';
    $('invStockGroup').style.display='none';$('invStock').readOnly=true;
    if(typeof window.openInventoryPage==='function')window.openInventoryPage('Kemaskini Inventori','Semak dan kemaskini maklumat item inventori.');
  }catch(e){console.error('editInventory canonical',e);if(typeof showToast==='function')showToast(e.message||String(e),'error');}
};

// Inventory is loaded by the app router when the Inventory page is opened.
// Do not auto-query before Supabase auth/session context has been restored.
})();