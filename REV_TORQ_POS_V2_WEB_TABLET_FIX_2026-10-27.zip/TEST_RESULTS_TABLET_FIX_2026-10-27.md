# Verification — tablet fixes on the 2026-10-27 build

## What was wrong (found on your ZIP before any change)
- iPad 1024×768 and 1180×820: with the cash box (Diterima) or the search box focused, the new "BETULKAN INPUT" bar covered the middle of BAYAR; the tap went to "⌫ PADAM 1". Portrait: the right end of BAYAR. It also covered SIMPAN SEBUT HARGA (Sebut Harga) and parts of the Job Card form.
- One-tap BUANG kept only the last removed line for UNDO.
- customers.js, stable-fixes.js, rt-override.js, rt-polish.css had changed without a new `?v=`; rt-offline.js still reported version 2026-10-06-offline2.
- "+ RESTOK" 28 px, "⚙ SET POINT BELIAN" 29 px, bar buttons 33 px, Staf / Pembekal links 17 px.

## Automated (after the fix)
**Node:** tests shipped in the ZIP **116 passed, 0 failed, 2 skipped** (the two that need the separate Customer PWA folder). SQL self-checks on a throw-away Postgres: 27/27, 80/80, 44/44, 103/103.
With my older regression tests added: 222 / 225 (2 skipped as above; 1 is the old "root / APK assets / WAB_DEPLOY identical" check — no Android folder in a web build).
New `tests/tablet-fix.test.cjs` (6): skip list, placement rules, UNDO list (2 removals → 2 undos, max 10, cleared with the cart / order switch), every changed file has a new `?v=` and the two BUILD values match, finger sizes only on touch screens, customer list without `window`.

**Browser (Chromium, simulated backend), new tablet suite: 192 / 192** on iPad 1024×768, iPad Air 1180×820, iPad portrait 820×1180, laptop 1366×768 and 1366×657 (mouse), phone 390×844:
- search box and Diterima: no bar, BAYAR free; typing Diterima then one tap on BAYAR completes the sale
- Disk RM: bar shown, fully on screen, not on the field, never on BAYAR / cash / payment buttons, at most the edge (≤ 15%) of a small POS button and under a third of anything; PADAM 1 / KOSONGKAN / TUTUP work; 40 px buttons on touch
- keyboard (simulated by shrinking the visible area): the bar moves above it
- two BUANG taps → "(+1 lagi)", two UNDO taps → both lines back; BUANG / UNDO 40 px on touch
- customer dialog: bar not on the phone box and on no button of the dialog; the search results under the search box stay free
- Sebut Harga: SIMPAN SEBUT HARGA / SIMPAN SEMENTARA / BATAL never covered while typing (name or price), one tap saves
- Job Card form: no button / part in the list has its middle covered
- Inventori "+ RESTOK", Staf KEMASKINI / BERHENTI / RESET PIN, Pembekal KEMASKINI, "⚙ SET POINT BELIAN": 40 px+ on touch
- Diagnostik version = service worker version; no page errors

**Regression (same build):** POS audit fixes 113/113, add motorcycle 72/72, cart room 182/182, receipt PDF + points 57/57, Pesanan serentak 88/88, Gantung 31/31, POS 56/56, WhatsApp 15/15, Papan Bengkel 25/25, Carian pantas 25/25, Pesan stok 28/28, Booking 28/28, full names 63/63, tidy-ups 26/26, Override + audit 109/109, offline / fast 59/59, Sebut Harga 216/216, customer list, scanner overlay, job-checkout heal, job part, native bridge: unchanged.
Tests that described the old behaviour were updated on purpose: two-tap BUANG → one tap + UNDO; "typing 0 keeps the quantity" → "0 + Done removes the line, UNDO brings it back" (your ZIP's own design); fixed version strings.

## Not verified
- A real iPad keyboard, rotation and share sheet (keyboard only simulated).
- The new Supabase features in your ZIP (customer link code, purchase points, cost / margin, inventory control, AI invoice scan) on your real database — not touched by this fix.
