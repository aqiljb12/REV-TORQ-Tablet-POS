# REV TORQ POS — Pembetulan salah key-in (2026-10-27)

Pembetulan ini berdasarkan ZIP Dashboard Laju 2026-10-21.

## Baharu
- Troli belum dibayar: `BUANG` sekali tekan terus buang item. `UNDO / PULIHKAN` untuk tambah semula item terakhir. Ini tidak memadam stok atau transaksi.
- Kuantiti dalam troli: taip `0` dan tekan Done/Enter untuk buang baris; kosong sementara tidak akan membuang item secara tidak sengaja.
- Apabila fokus dalam medan tulisan/nombor di POS, muncul toolbar `⌫ PADAM 1`, `✕ KOSONGKAN`, `TUTUP`. Berguna jika Backspace keyboard tablet/laptop bermasalah.
- Admin/Owner: butang `ARKIB` pada baris inventori dan pelanggan terus ke Override dengan carian rekod, jika fungsi Override sudah dipasang.
- `EDIT` kekal untuk betulkan nama, nombor telefon, harga dan sebagainya.

## Keselamatan data
- Inventori/pelanggan yang sudah disimpan tidak dipadam terus; guna `ARKIB` melalui Override dengan pengesahan PIN dan sebab. Ini melindungi rekod pembayaran, stok dan servis.
- Transaksi yang sudah dibayar perlu `VOID` melalui sejarah jualan dan Override; bukan padam resit.
- Arkib item mungkin ditolak oleh pelayan jika stok masih ada atau sedang digunakan dalam job terbuka; laraskan stok dengan kaedah yang diaudit dahulu.
- Bagi pelanggan dengan motosikal aktif, arkib motosikal dahulu jika betul-betul tersalah daftar dan pelayan benarkan.

## Deploy
- Gunakan fail ZIP ini untuk menggantikan deploy POS sahaja.
- Tiada SQL baharu untuk perubahan ini, tetapi Archive memerlukan `migration_2026_10_05_override_audit.sql` terpasang. Customer Link / Purchase Points masih perlukan migrasi asal masing-masing.
- Uji pada iPad dan PC: edit input, padam troli, undo, edit inventory dan butang Arkib admin.
- Data production tidak diubah ketika membina ZIP ini.
