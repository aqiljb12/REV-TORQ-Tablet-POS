-- REV TORQ POS ↔ Customer PWA: explicit, secure claim of an existing workshop profile.
-- Apply ONCE to project wabtoq BEFORE deploying PWA/POS updated ZIPs.
-- Non-destructive install: adds an isolated token table and 2 RPCs; does not merge any records on install.
-- Redemption (only by a legitimate signed-in PWA customer holding a staff-issued code)
-- moves the POS-linked workshop history atomically to an existing web customer ID, or
-- links the original POS ID directly if no customer web profile exists yet.

begin;

create table if not exists public.rt_customer_claim_codes (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id),
  customer_id uuid not null references public.customers(id),
  code_hash text not null unique,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null,
  redeemed_at timestamptz,
  issued_by_staff_id uuid
);
create index if not exists rt_customer_claim_codes_customer_idx
  on public.rt_customer_claim_codes(customer_id, created_at desc);
alter table public.rt_customer_claim_codes enable row level security;
-- Claim secrets are never exposed over PostgREST as table rows.
revoke all on table public.rt_customer_claim_codes from public, anon, authenticated;

create or replace function public.rt_pos_issue_customer_claim_code(p_customer_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  v_staff record;
  v_c public.customers%rowtype;
  v_raw text;
  v_print text;
  v_hash text;
  v_exp timestamptz := now() + interval '7 days';
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into v_staff from public.rt_staff_context() limit 1;
  if v_staff.staff_id is null then raise exception 'STAFF_REQUIRED'; end if;
  if lower(coalesce(v_staff.role, '')) not in
    ('owner','admin','super_admin','manager','cashier','pos')
  then raise exception 'POS_ROLE_NOT_ALLOWED'; end if;

  select * into v_c from public.customers
   where id = p_customer_id and company_id = v_staff.company_id and active = true
   for update;
  if v_c.id is null then raise exception 'CUSTOMER_NOT_FOUND'; end if;
  if v_c.auth_user_id is not null then raise exception 'CUSTOMER_ALREADY_LINKED'; end if;

  -- Only one active claim code per record. New issue invalidates the previous one.
  update public.rt_customer_claim_codes
    set redeemed_at = now()
    where customer_id = v_c.id and redeemed_at is null;

  -- 80 random bits; server stores SHA-256 hash only; plaintext is shown once to POS staff.
  v_raw := upper(encode(extensions.gen_random_bytes(10), 'hex'));
  v_print := 'RTQ-' || substr(v_raw,1,4) || '-' || substr(v_raw,5,4) || '-'
                      || substr(v_raw,9,4) || '-' || substr(v_raw,13,4) || '-'
                      || substr(v_raw,17,4);
  v_hash := encode(extensions.digest(convert_to('RTQ'||v_raw,'UTF8'),'sha256'),'hex');
  insert into public.rt_customer_claim_codes(company_id,customer_id,code_hash,expires_at,issued_by_staff_id)
    values(v_c.company_id,v_c.id,v_hash,v_exp,v_staff.staff_id);
  return jsonb_build_object('code',v_print,'expires_at',v_exp);
end;
$function$;

create or replace function public.rt_customer_redeem_claim_code(p_code text)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  v_uid uuid := auth.uid();
  v_clean text;
  v_hash text;
  v_claim public.rt_customer_claim_codes%rowtype;
  v_pos public.customers%rowtype;
  v_web public.customers%rowtype;
  v_web_count integer;
  v_prev_points integer := 0;
  v_merge boolean := false;
  v_vehicles integer := 0;
begin
  if v_uid is null then raise exception 'AUTH_REQUIRED'; end if;
  v_clean := regexp_replace(upper(coalesce(p_code,'')),'[^A-Z0-9]','','g');
  if length(v_clean) <> 23 or left(v_clean,3) <> 'RTQ'
     or substring(v_clean,4) !~ '^[A-F0-9]{20}$'
  then raise exception 'CLAIM_CODE_INVALID'; end if;
  v_hash := encode(extensions.digest(convert_to(v_clean,'UTF8'),'sha256'),'hex');

  select * into v_claim from public.rt_customer_claim_codes
    where code_hash=v_hash and redeemed_at is null and expires_at>now()
    for update;
  if v_claim.id is null then raise exception 'CLAIM_CODE_INVALID_OR_EXPIRED'; end if;
  select * into v_pos from public.customers
    where id=v_claim.customer_id and company_id=v_claim.company_id and active=true
    for update;
  if v_pos.id is null then raise exception 'CUSTOMER_UNAVAILABLE'; end if;
  if v_pos.auth_user_id is not null and v_pos.auth_user_id<>v_uid
  then raise exception 'CUSTOMER_ALREADY_LINKED'; end if;

  select count(*) into v_web_count from public.customers
    where company_id=v_pos.company_id and auth_user_id=v_uid and active=true;
  if v_web_count>1 then raise exception 'MULTIPLE_WEB_PROFILES_NEED_ADMIN'; end if;
  select * into v_web from public.customers
    where company_id=v_pos.company_id and auth_user_id=v_uid and active=true
    limit 1 for update;

  if v_web.id is null then
    -- New web signup: preserve original POS id, bikes, jobs, invoice and loyalty point IDs.
    update public.customers
       set auth_user_id=v_uid, updated_at=now()
       where id=v_pos.id;
    update public.rt_customer_claim_codes set redeemed_at=now() where id=v_claim.id;
    return jsonb_build_object('customer_id',v_pos.id,'linked',true,'merged',false);
  end if;

  if v_web.id=v_pos.id then
    update public.rt_customer_claim_codes set redeemed_at=now() where id=v_claim.id;
    return jsonb_build_object('customer_id',v_web.id,'linked',true,'merged',false);
  end if;

  -- Existing web signup: keep current web ID as canonical. Preserve ALL POS history.
  -- Prevent changing a different customer's identity if pre-existing records disagree.
  if v_web.phone_normalized is not null and v_pos.phone_normalized is not null
      and v_web.phone_normalized <> v_pos.phone_normalized
  then raise exception 'PHONE_MISMATCH_NEEDS_ADMIN'; end if;
  -- Unexpected competing profiles sharing this phone need a human identity review.
  if (select count(*) from public.customers
        where company_id=v_pos.company_id and active=true
          and phone_normalized=v_pos.phone_normalized)>2
  then raise exception 'PHONE_DUPLICATE_NEEDS_ADMIN'; end if;

  -- Move all workshop-linked records. Every update runs in this single transaction;
  -- any unique/FK error rolls back the WHOLE merge, protecting existing invoices/points.
  update public.vehicles set customer_id=v_web.id where customer_id=v_pos.id;
  get diagnostics v_vehicles = row_count;
  update public.bookings set customer_id=v_web.id where customer_id=v_pos.id;
  update public.job_cards set customer_id=v_web.id where customer_id=v_pos.id;
  update public.invoices set customer_id=v_web.id where customer_id=v_pos.id;
  update public.quotations set customer_id=v_web.id where customer_id=v_pos.id;
  update public.service_reminders set customer_id=v_web.id where customer_id=v_pos.id;
  update public.dyno_bookings set customer_id=v_web.id where customer_id=v_pos.id;
  update public.dyno_sessions set customer_id=v_web.id where customer_id=v_pos.id;
  update public.notifications set customer_id=v_web.id where customer_id=v_pos.id;
  update public.promo_claims set customer_id=v_web.id where customer_id=v_pos.id;
  update public.promo_redemptions set customer_id=v_web.id where customer_id=v_pos.id;
  update public.loyalty_transactions set customer_id=v_web.id where customer_id=v_pos.id;
  update public.loyalty_vouchers set customer_id=v_web.id where customer_id=v_pos.id;
  update public.loyalty_spins set customer_id=v_web.id where customer_id=v_pos.id;
  update public.service_feedback set customer_id=v_web.id where customer_id=v_pos.id;
  update public.push_subscriptions set customer_id=v_web.id where customer_id=v_pos.id;
  update public.rider_benefits set customer_id=v_web.id where customer_id=v_pos.id;
  update public.customer_rider_profiles set customer_id=v_web.id where customer_id=v_pos.id;
  update public.customer_referrals set referrer_customer_id=v_web.id where referrer_customer_id=v_pos.id;
  update public.customer_referrals set referred_customer_id=v_web.id where referred_customer_id=v_pos.id;
  update public.customer_referral_codes set customer_id=v_web.id where customer_id=v_pos.id;

  -- Preserve paid/earned points on both profiles, without duplicate loyalty_accounts PKs.
  select coalesce(balance,0) into v_prev_points from public.loyalty_accounts
    where customer_id=v_pos.id for update;
  if found then
    insert into public.loyalty_accounts(company_id,customer_id,balance)
    values(v_pos.company_id,v_web.id,v_prev_points)
    on conflict(customer_id) do update
        set balance=public.loyalty_accounts.balance+excluded.balance, updated_at=now();
    delete from public.loyalty_accounts where customer_id=v_pos.id;
  end if;

  -- Archive only the redundant profile (not invoices, bike records or activity).
  update public.customers set active=false,updated_at=now() where id=v_pos.id;
  update public.customers set
     phone=coalesce(nullif(v_web.phone,''),v_pos.phone),
     name=coalesce(nullif(v_web.name,''),v_pos.name),
     updated_at=now()
     where id=v_web.id;
  update public.rt_customer_claim_codes set redeemed_at=now()
    where customer_id=v_pos.id and redeemed_at is null;
  v_merge:=true;
  return jsonb_build_object('customer_id',v_web.id,'linked',true,'merged',v_merge,
                            'moved_vehicles',v_vehicles,'points_added',v_prev_points);
exception when unique_violation or foreign_key_violation then
  raise exception 'MERGE_CONFLICT_NEEDS_ADMIN';
end;
$function$;

-- SECURITY DEFINER only via authorized RPC, not an open table API.
revoke all on function public.rt_pos_issue_customer_claim_code(uuid) from public, anon, authenticated;
revoke all on function public.rt_customer_redeem_claim_code(text) from public, anon, authenticated;
grant execute on function public.rt_pos_issue_customer_claim_code(uuid) to authenticated;
grant execute on function public.rt_customer_redeem_claim_code(text) to authenticated;

commit;
