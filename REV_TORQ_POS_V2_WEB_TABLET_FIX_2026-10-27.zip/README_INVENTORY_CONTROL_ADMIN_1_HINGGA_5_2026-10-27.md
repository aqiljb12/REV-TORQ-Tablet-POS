# REV TORQ POS — Inventory Control (1 hingga 5)

## Lokasi
Dalam **Admin POS sedia ada → INVENTORI → ⚙ INVENTORY CONTROL**. Bukan aplikasi/website berasingan. Pengguna mesti login sebagai Owner/Admin (verified Auth). Butang tidak dipaparkan kepada staff biasa. Semakan keselamatan utama juga dibuat dalam fungsi SQL.

## PASANG (penting)
1. Buat backup Supabase `wabtoq` (Dashboard → Database → Backups) dahulu. POS mempunyai transaksi & rekod lama; jangan import CSV untuk overwrite terus.
2. Dalam Supabase SQL Editor, jalankan **`migration_2026_10_27_admin_inventory_control.sql`** (fail baharu). Ini menambah fungsi dan rekod terimaan/alias baharu tetapi **tidak mengubah stok, nama, SKU, kos, invoice atau data produk lama secara automatik**.
3. Jika modul-modul terdahulu belum dipasang, migrasi Customer Link/Purchase Points/Delete Duplicate adalah **berasingan**. Jangan jalankan fail setup lama yang menyusun semula data secara automatik; semak keperluan dahulu.
4. Deploy keseluruhan kandungan ZIP sebagai satu tapak POS, menggantikan build web sebelum ini. Pastikan `index.html`, `js/rt-admin-inventory-control.js` dan `css/rt-admin-inventory-control.css` dikirim bersama. Tidak perlu cipta projek baru.
5. Login Admin; buka **Inventori** → **INVENTORY CONTROL**. Semak Ringkasan, kemudian **Master Barang → BACKUP CSV** dahulu. CSV berguna sebagai salinan semakan, bukan pengganti backup database.

## Fungsi 1 — Kemas Master Barang
- Lihat isu nama huruf bercampur, kategori tersalah, nama sama, kos/harga, SKU lama/ruang, jenama/rak tidak ditetapkan.
- Semua nama dipaparkan dalam HURUF BESAR apabila diedit. Tekan `KEMASKAN HURUF BESAR` untuk memohon perubahan kepada rekod yang berkenaan (satu-per-satu secara berjejak; ralat ditunjuk). Semak terlebih dahulu dan **jangan tekan** tanpa backup.
- EDIT boleh kemas nama, kategori, brand, unit, rak, kos dan harga. Stok tidak berubah.
- SKU lama **tidak** ditukar secara auto. Tekan `CADANG SKU STANDARD BARU` pada item pilihan sahaja. Apabila disimpan, kod lama dicatat sebagai alias supaya carian kod lama pada kotak carian POS dapat dipadankan (selepas login dan sambungan rangkaian). Barcode pembekal tidak diubah. Label yang mencetak SKU lama boleh perlu dicetak semula.
- Sistem DB menolak pendaftaran produk baharu dengan nama+kategori sama (diabaikan apabila hanya mengedit medan lain), termasuk pendaftaran dari jalan kod lama.
- SKU untuk barang **baharu**: butang `JANA SKU BARU MENGIKUT KATEGORI` dalam form inventory. Meminta nombor dari pelayan, bukan mengubah SKU lama. OEM SKU boleh dikekalkan apabila sesuai.

## Fungsi 2 — Kos & Unit
- Senaraikan harga jual RM0, kos RM0, jual lebih rendah daripada kos, kategori SERVIS serta produk unit kotak.
- Semak **kos per unit yang dijual**. Contoh: satu kotak palam pencucuh 10 biji kos RM100 → kos per biji RM10, bukan RM100.
- Menukar `unit` TIDAK membahagikan/mendarab stok secara automatik. Jika stok asal direkod sebagai kotak tetapi mahu jadi biji, semak kiraan fizikal dan pelarasan dahulu.
- Kos transaksi lama tidak ditulis semula.

## Fungsi 3 & 4 — Audit Stok Fizikal dan Pelarasan
- Klik **EXPORT SENARAI KIRAAN** untuk kertas kiraan. Lajur kiraan fizikal sengaja dibiarkan kosong.
- Kira barang sebenar di rak, masukkan kuantiti fizikal dalam Admin POS. Nilai 0 dibenarkan jika benar-benar kosong.
- POS tunjuk baki semasa dan perbezaan (+/-). Admin mesti masukkan sebab ≥8 aksara dan sahkan sekali lagi.
- Pelayan mengunci baki semasa dan **menolak** jika jualan/stok berubah sementara Admin membuat kiraan. Refresh dan kira semula.
- Setiap pelarasan melalui fungsi ledger rasmi `post_stock_movement`, menyimpan `ADJUSTMENT_IN` / `ADJUSTMENT_OUT` dan audit log. **Tiada DELETE sejarah stok.**
- Servis seperti `SERVICE CVT FULL` bukan stok fizikal: stok SERVIS boleh ditetapkan kepada **0 sahaja** selepas disahkan Admin; rekod adjustment disimpan.
- Adalah lebih baik buat kiraan di luar waktu sibuk, atau hentikan pergerakan rak semasa item tertentu dikira.

## Fungsi 5 — Barang Sampai
- Pilih pembekal sedia ada, masukkan **No. DO/Invois**, scan/cari item existing, kemudian isi qty dan kos unit untuk setiap baris.
- Semak jumlah, tekan `SAHKAN STOK MASUK`. Pelayan tambah stok melalui `post_stock_movement` jenis `PURCHASE` dengan snapshot kos, rekod receipt dan lines, serta audit.
- DO yang sama untuk pembekal yang sama **disekat** pada DB walaupun dua peranti submit serentak.
- Jika DO tersalah key-in: pilih `BATAL TERIMAAN`, taip semula DO, masukkan sebab dan sahkan. Pelayan **menolak semula seluruh kuantiti** dengan ledger reversal **jika semua item masih cukup stok**. Kalau stok sudah habis/dijual, reversal penuh akan gagal; semak dahulu sejarah jualan dan buat pelarasan yang sesuai — jangan buang transaksi.
- Untuk DO yang dibatalkan dan mahu rekod penerimaan benar semula, gunakan DO sama setelah status lama REVERSED (audit lama kekal).
- Barang baru tiada dalam master: daftar melalui Inventory terlebih dahulu, jangan automatik cipta item tanpa semak duplikat.
- Harga kos pada resit menerima snapshot sebenar **tidak terus menukar kos Master produk**. Semak kos master melalui tab Kos & Unit jika sesuai.

## Perkara yang disengajakan
- **Tiada pembersihan automatik atas 210 rekod**; admin memilih setiap perubahan atau klik pukal dengan pengesahan.
- **Tiada pindahan stok automatik antara dua SKU duplikat**. Bandingkan barang fizikal & pergerakan, kemudian arkib barang yang salah melalui Override apabila perlu.
- Existing POS / Customer Link / Purchase Points / Print / Dashboard Laju / Padam Duplikat dikekalkan daripada ZIP input.
- Migrasi baharu mewujudkan jadual transaksi tambahan untuk penerimaan stok; tidak menimpa `grn` yang telah wujud.

## Status ujian
- Validasi sintaks JavaScript dan ujian integrasi/statik automatik sahaja. Chrome headless gagal melengkapkan ujian UI dalam persekitaran semasa. **Ujian SQL pada production, urus niaga sebenar dan paparan iPad/Android belum disahkan.**
- Jalankan ujian pada produk sementara dengan stok kecil, rekod sebelum/selepas, dan perhatikan rekonsiliasi ledger selepas migrasi + deploy. Jangan cuba pada stok mahal sebagai ujian pertama.
