const fs=require('fs'),path=require('path'),assert=require('assert'),child=require('child_process');
const root=path.join(__dirname,'..'),ui=fs.readFileSync(path.join(root,'js/rt-admin-inventory-control.js'),'utf8'),canon=fs.readFileSync(path.join(root,'js/inventory-canonical-list.js'),'utf8'),sql=fs.readFileSync(path.join(root,'migration_2026_10_27_admin_quick_restock.sql'),'utf8'),html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const checks={
 'JS syntax':child.spawnSync(process.execPath,['--check',path.join(root,'js/rt-admin-inventory-control.js')]).status===0,
 'Inventory list JS syntax':child.spawnSync(process.execPath,['--check',path.join(root,'js/inventory-canonical-list.js')]).status===0,
 'Restock button directly in inventory':canon.includes('data-rt-quick-restock'),
 'Click handler connected':canon.includes('window.rtOpenQuickRestock?.('),
 'Quick restock public action':ui.includes('window.rtOpenQuickRestock=openQuickRestock'),
 'Stock receipt type PURCHASE':sql.includes("'PURCHASE',p_quantity"),
 'Product ID existing':ui.includes('s.products.find(x=>x.id===s.quickProductId)'),
 'Admin-only RPC verifies auth':sql.includes('public.rt_inv_admin_context()'),
 'DO and supplier not required for fast restock':!sql.includes('p_supplier_id')&&!sql.includes('p_reference_no'),
 'No opening stock use':!sql.includes("'OPENING'")&&!ui.includes('OPENING'),
 'Cannot restock SERVIS':sql.includes("p.category='SERVIS'"),
 'Prevents replay via unique request_id':sql.includes('unique(company_id,request_id)')&&sql.includes('on conflict(company_id,request_id) do nothing'),
 'No silent historical changes':!sql.match(/delete from public\.(products|stock_balances|stock_movements)/i)&&!sql.includes('update public.products'),
 'No direct client ledger writes':!ui.includes(".from('stock_movements').insert"),
 'Original inventory control preserved':html.includes('rt-admin-inventory-control.js')&&html.includes('rt-purchase-points.js'),
 'Correct cache busting':html.includes('20261027-quickrestock2')
};
Object.entries(checks).forEach(([label,ok])=>{assert(ok,label)});console.log(`${Object.keys(checks).length}/${Object.keys(checks).length} quick restock static checks pass`);
