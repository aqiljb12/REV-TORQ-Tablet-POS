const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const root=path.resolve(__dirname,'..');const read=s=>fs.readFileSync(path.join(root,s),'utf8');
test('New admin purchase points module is loaded on the current POS',()=>{
 const index=read('index.html');assert.match(index,/js\/rt-purchase-points\.js\?v=20261021-purchase1/);
 const js=read('js/rt-purchase-points.js');
 for(const keyword of ['rt_pos_get_purchase_loyalty_rules','rt_pos_save_purchase_loyalty_rule','rtPurchaseSettingsButton','p_rm_per_point','p_enabled'])assert.ok(js.includes(keyword),keyword);
 assert.match(js,/\['owner','super_admin','admin'\]/);
});
test('SQL creates protected settings RPC and retail-only trigger, does not replace service trigger',()=>{
 const sql=read('migration_2026_10_21_pos_purchase_points_settings.sql');
 for(const keyword of ['ENABLE ROW LEVEL SECURITY','REVOKE ALL ON TABLE','SECURITY DEFINER','rt_staff_context()','auth.uid()','new.job_card_id IS NOT NULL','invoice-purchase-loyalty:',"'POS_PURCHASE'",'rt_award_purchase_loyalty_on_paid_invoice','POS_PURCHASE_REVERSAL','REFERENCES public.companies'])assert.ok(sql.toLowerCase().includes(keyword.toLowerCase()),keyword);
 assert.doesNotMatch(sql,/drop trigger if exists trg_rt_award_spend_loyalty/i);
 assert.doesNotMatch(sql,/create or replace function public\.rt_award_spend_loyalty_on_paid_invoice/i);
 assert.match(sql,/VALUES\(s\.company_id,k,v_rate,v_enabled,now\(\)\)/);
 assert.match(sql,/v\.category,v\.rate,false/);
});
test('discount allocation and idempotency are present',()=>{
 const sql=read('migration_2026_10_21_pos_purchase_points_settings.sql');
 assert.match(sql,/v_discount\*\(v_line\.gross_eligible\/v_subtotal\)/);
 assert.match(sql,/floor\(round\(v_after_discount,2\)\/v_line\.rm_per_point\)/);
 assert.match(sql,/invoice-purchase-reversal:/);
 assert.match(sql,/invoice-purchase-loyalty:/);
});
