"""Browser test for the Dashboard (Playwright + Chromium).

    python3 tests/dashboard-ui.test.py            # run all checks
    SHOT_DIR=/tmp/shots python3 tests/dashboard-ui.test.py   # also save screenshots

The real app (index.html, the real supabase-js client) talks to a small in-memory
stand-in for the Supabase REST API, so nothing touches a real database. Checks:
numbers on every card, Booking hari ini uses today's Malaysia date, Stok rendah equals
Inventori > PESAN STOK (also with more than 1000 products), requests per refresh,
flash / new-sale highlight, first-load and refresh errors, Reduce Motion, iPad press
listener, no horizontal scroll at iPad / phone sizes, and no JavaScript errors.
Set CHROMIUM_PATH if Playwright cannot find Chromium by itself.
"""
import json, os, re, sys, threading, time
from datetime import datetime, timedelta, timezone
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MYT = timezone(timedelta(hours=8))
SHOT_DIR = os.environ.get('SHOT_DIR')
FAILS = []


def check(cond, msg):
    print(('PASS ' if cond else 'FAIL ') + msg, flush=True)
    if not cond:
        FAILS.append(msg)


def rm(v):  # same text as the page: RM 1,234.50
    return 'RM ' + f'{v:,.2f}'


def iso(dt):
    return dt.astimezone(timezone.utc).isoformat(timespec='microseconds')


# ---------------------------------------------------------------- data
def build(big=False):
    now = datetime.now(MYT)
    day0 = now.replace(hour=0, minute=0, second=0, microsecond=0)
    today = day0.strftime('%Y-%m-%d')
    db = {k: [] for k in ['invoices', 'payments', 'products', 'stock_balances', 'service_reminders', 'customers',
                          'vehicles', 'bookings', 'cash_drawers', 'locations', 'job_cards']}
    db['locations'] = [{'id': 'loc1', 'company_id': 'co1', 'active': True, 'code': 'A'}]
    amounts = [45, 120, 380, 65, 210, 890, 32.5, 150]
    n = 0
    for d, c in [(0, 6), (1, 9), (2, 4), (3, 11), (4, 7), (5, 3), (6, 8)]:
        for i in range(c):
            n += 1
            if d == 0:   # today: spread between midnight and now
                span = max(120, (now - day0).total_seconds() - 120)
                t = day0 + timedelta(seconds=span * (i + 1) / (c + 1))
            else:
                t = day0 - timedelta(days=d) + timedelta(hours=9 + i % 10, minutes=(n * 13) % 60)
            inv_id = f'00000000-0000-4000-8000-{n:012d}'
            db['invoices'].append({'id': inv_id, 'company_id': 'co1', 'invoice_no': f'INV-2610-{n:03d}', 'total': amounts[n % 8],
                                   'status': 'PAID', 'payment_status': 'PAID', 'created_at': iso(t)})
            db['payments'].append({'invoice_id': inv_id, 'company_id': 'co1', 'payment_method': ['CASH', 'QR', 'CARD', 'CASH'][n % 4], 'created_at': iso(t)})
    # must NOT count: a voided and an unpaid invoice today, another company's sale
    db['invoices'] += [
        {'id': 'void-1', 'company_id': 'co1', 'invoice_no': 'INV-VOID', 'total': 999, 'status': 'VOID', 'payment_status': 'PAID', 'created_at': iso(day0 + timedelta(minutes=5))},
        {'id': 'unpaid-1', 'company_id': 'co1', 'invoice_no': 'INV-UNPAID', 'total': 777, 'status': 'OPEN', 'payment_status': 'UNPAID', 'created_at': iso(day0 + timedelta(minutes=6))},
        {'id': 'other-1', 'company_id': 'co2', 'invoice_no': 'INV-OTHER', 'total': 555, 'status': 'PAID', 'payment_status': 'PAID', 'created_at': iso(day0 + timedelta(minutes=7))},
    ]
    db['customers'] = [{'id': f'c{i}', 'company_id': 'co1', 'name': f'Pelanggan {i}', 'phone': '01', 'active': True} for i in range(4, 249)]
    db['customers'] += [{'id': 'c1', 'company_id': 'co1', 'name': 'Ahmad Faizal', 'phone': '0123', 'active': True},
                        {'id': 'c2', 'company_id': 'co1', 'name': 'Siti Nur', 'phone': '0124', 'active': True},
                        {'id': 'c3', 'company_id': 'co1', 'name': 'Kumar Raj', 'phone': '0125', 'active': True},
                        {'id': 'cx', 'company_id': 'co1', 'name': 'Tidak aktif', 'phone': '0', 'active': False}]
    db['vehicles'] = [{'id': 'v1', 'plate_no': 'JQB 4521', 'brand': 'Yamaha', 'model': 'Y15ZR'},
                      {'id': 'v2', 'plate_no': 'WXY 889', 'brand': 'Honda', 'model': 'RS150'},
                      {'id': 'v3', 'plate_no': 'BMK 12', 'brand': 'Kawasaki', 'model': 'Z250'}]
    dd = lambda k: (day0 + timedelta(days=k)).strftime('%Y-%m-%d')
    db['service_reminders'] = [
        {'id': 'r1', 'company_id': 'co1', 'customer_id': 'c1', 'vehicle_id': 'v1', 'due_date': dd(-1), 'reminder_type': 'Tukar Minyak', 'status': 'PENDING'},
        {'id': 'r2', 'company_id': 'co1', 'customer_id': 'c2', 'vehicle_id': 'v2', 'due_date': dd(2), 'reminder_type': 'Servis Penuh', 'status': 'PENDING'},
        {'id': 'r3', 'company_id': 'co1', 'customer_id': 'c3', 'vehicle_id': 'v3', 'due_date': dd(6), 'reminder_type': 'Brek', 'status': 'PENDING'},
        {'id': 'r4', 'company_id': 'co1', 'customer_id': 'c3', 'vehicle_id': 'v3', 'due_date': dd(-9), 'reminder_type': 'Siap', 'status': 'DONE'}]
    db['bookings'] = ([{'id': f'b{i}', 'company_id': 'co1', 'status': s, 'preferred_date': today, 'preferred_time': '10:00'}
                       for i, s in enumerate(['CONFIRMED', 'CONFIRMED', 'NEW', 'CANCELLED'])]
                      + [{'id': f'y{i}', 'company_id': 'co1', 'status': 'CONFIRMED', 'preferred_date': dd(-1), 'preferred_time': '11:00'} for i in range(5)]
                      + [{'id': f't{i}', 'company_id': 'co1', 'status': 'NEW', 'preferred_date': dd(1), 'preferred_time': '09:00'} for i in range(2)])
    db['cash_drawers'] = [{'id': 'd1', 'company_id': 'co1', 'location_id': 'loc1', 'status': 'OPEN', 'drawer_code': 'D1', 'opening_float': 200, 'opened_at': iso(day0 + timedelta(hours=9))}]
    jobs = ['IN_PROGRESS'] * 3 + ['OPEN'] * 2 + ['WAITING_PARTS'] + ['COMPLETED'] * 2 + ['CANCELLED']
    db['job_cards'] = [{'id': f'j{i}', 'company_id': 'co1', 'status': s, 'created_at': iso(day0)} for i, s in enumerate(jobs)]
    if not big:
        prods = [('p1', 'Motul 7100 10W40 1L', 'MT7100', 10, 3, True), ('p2', 'Brake Pad Brembo Y15', 'BRY15', 5, 0, True),
                 ('p3', 'Spark Plug NGK CPR8', 'NGK8', 20, 50, True), ('p4', 'Chain Kit DID 428', 'DID428', 4, 2, True),
                 ('p5', 'Tayar Michelin Pilot Street 70/90-17', 'MC7090', 6, 12, True), ('p6', 'Air Filter Y15ZR', 'AFY15', 5, 1, True),
                 ('p7', 'Coolant Motul 1L', 'MCOOL', None, 4, True),      # no minimum set -> 5 -> low
                 ('p8', 'Cable Clutch RS150', 'CCRS', 3, 3, True),
                 ('p9', 'Item lama (tidak aktif)', 'OLD1', 5, 0, False),  # inactive -> not counted
                 ('p10', 'Sticker REV TORQ', 'STK1', 0, 0, True)]          # min 0, stock 0 -> habis
        for pid, name, sku, mn, q, act in prods:
            db['products'].append({'id': pid, 'company_id': 'co1', 'name': name, 'sku': sku, 'min_stock': mn, 'active': act})
            db['stock_balances'].append({'product_id': pid, 'location_id': 'loc1', 'quantity': q, 'reserved_quantity': 1 if pid == 'p3' else 0})
    else:
        for i in range(2600):
            pid = f'b{i:05d}'
            mn = [None, 0, 3, 10][i % 4]
            act = False if i % 13 == 0 else (None if i % 17 == 0 else True)
            db['products'].append({'id': pid, 'company_id': 'co1', 'name': f'Barang {i:04d}', 'sku': f'SKU-{i:05d}', 'min_stock': mn, 'active': act})
            if i % 11:   # every 11th product has no stock row at all
                db['stock_balances'].append({'product_id': pid, 'location_id': 'loc1', 'quantity': i % 7, 'reserved_quantity': i % 2})
            db['stock_balances'].append({'product_id': pid, 'location_id': 'loc2', 'quantity': 100, 'reserved_quantity': 0})
    return db


def expected(db):
    now = datetime.now(MYT)
    day0 = now.replace(hour=0, minute=0, second=0, microsecond=0)
    paid = [x for x in db['invoices'] if x['company_id'] == 'co1' and x['status'] != 'VOID' and x['payment_status'] == 'PAID']
    today = [x for x in paid if datetime.fromisoformat(x['created_at']) >= day0]
    qty = {b['product_id']: b['quantity'] for b in db['stock_balances'] if b['location_id'] == 'loc1'}
    low = []
    for p in db['products']:
        if p['active'] is False:
            continue
        mn = 5 if p['min_stock'] is None else p['min_stock']
        st = qty.get(p['id'], 0)
        if st <= mn:
            low.append((p, st))
    return {'sales': sum(x['total'] for x in today), 'tx': len(today), 'low': len(low), 'out': sum(1 for _, s in low if s <= 0)}


# ---------------------------------------------------------------- tiny PostgREST stand-in
def _parse_ts(s):
    return datetime.fromisoformat(s.replace('Z', '+00:00'))


def _pair(v, arg):
    if isinstance(v, bool):
        return v, arg.lower() == 'true'
    if isinstance(v, (int, float)):
        return float(v), float(arg)
    if isinstance(v, str):
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}', v) and len(arg) > 10:
            return v, arg[:10]   # DATE column vs timestamp text: Postgres keeps the date part as written
        if re.match(r'\d{4}-\d{2}-\d{2}T', v) and re.match(r'\d{4}-\d{2}-\d{2}T', arg):
            return _parse_ts(v), _parse_ts(arg)
    return v, arg


def _match(v, spec):
    neg = spec.startswith('not.')
    if neg:
        spec = spec[4:]
    op, _, arg = spec.partition('.')
    if op == 'is':
        a = arg.lower()
        res = (v is None) if a == 'null' else (v is (a == 'true'))
    elif v is None:
        return False   # SQL: comparing with NULL is never true
    elif op == 'in':
        items = [x.strip().strip('"') for x in arg.strip('()').split(',') if x.strip()]
        res = any(_pair(v, x)[0] == _pair(v, x)[1] for x in items)
    else:
        a, b = _pair(v, arg)
        res = {'eq': a == b, 'neq': a != b, 'gt': a > b, 'gte': a >= b, 'lt': a < b, 'lte': a <= b}.get(op, True)
    return (not res) if neg else res


class Rest:
    def __init__(self, db):
        self.db, self.log, self.fail = db, [], set()

    def handle(self, route, request):
        u = urlparse(request.url)
        table = re.search(r'/rest/v1/([^/?]+)', u.path).group(1)
        self.log.append((request.method, table))
        if table in self.fail:
            return route.fulfill(status=500, content_type='application/json', body=json.dumps({'code': 'XX000', 'message': 'simulated failure'}))
        if request.method not in ('GET', 'HEAD'):
            return route.fulfill(status=200, content_type='application/json', body='[]')
        qs = parse_qs(u.query, keep_blank_values=True)
        rows = list(self.db.get(table, []))
        for key, vals in qs.items():
            if key in ('select', 'order', 'limit', 'offset', 'or', 'and'):
                continue
            for v in vals:
                rows = [r for r in rows if _match(r.get(key), v)]
        total = len(rows)
        if 'order' in qs:
            for part in reversed(qs['order'][0].split(',')):
                col, _, rest = part.partition('.')
                desc = rest.startswith('desc')
                present = [r for r in rows if r.get(col) is not None]
                nulls = [r for r in rows if r.get(col) is None]
                present.sort(key=lambda r: r.get(col), reverse=desc)
                rows = (nulls + present) if desc else (present + nulls)
        off = int(qs.get('offset', ['0'])[0])
        rows = rows[off:]
        if 'limit' in qs:
            rows = rows[:int(qs['limit'][0])]
        rows = rows[:1000]   # like Supabase: at most 1000 rows per request
        sel = qs.get('select', ['*'])[0]
        if sel != '*':
            cols = [c.strip() for c in sel.split(',')]
            rows = [{c: r.get(c) for c in cols} for r in rows]
        headers = {'content-type': 'application/json', 'access-control-allow-origin': '*', 'access-control-expose-headers': 'Content-Range'}
        if 'count=exact' in request.headers.get('prefer', ''):
            headers['content-range'] = f'{off}-{off + len(rows) - 1}/{total}' if rows else f'*/{total}'
        if 'vnd.pgrst.object' in request.headers.get('accept', ''):
            if len(rows) != 1:
                return route.fulfill(status=406, content_type='application/json', body=json.dumps({'code': 'PGRST116', 'message': 'not one row'}))
            body = json.dumps(rows[0])
        else:
            body = json.dumps(rows)
        route.fulfill(status=200, headers=headers, body='' if request.method == 'HEAD' else body)

    def count(self, table=None):
        return sum(1 for _, t in self.log if table is None or t == table)


# ---------------------------------------------------------------- browser helpers
def serve():
    class Quiet(SimpleHTTPRequestHandler):
        def log_message(self, *a, **k):
            pass
    handler = partial(Quiet, directory=ROOT)
    srv = ThreadingHTTPServer(('127.0.0.1', 0), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f'http://127.0.0.1:{srv.server_address[1]}'


def boot(browser, base, rest, width=1180, height=820, reduce=False):
    ctx = browser.new_context(viewport={'width': width, 'height': height}, timezone_id='Asia/Kuala_Lumpur', locale='ms-MY',
                              reduced_motion='reduce' if reduce else 'no-preference', has_touch=True)
    page = ctx.new_page()
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.route(re.compile(r'.*/rest/v1/.*'), rest.handle)
    page.route(re.compile(r'.*/(auth|realtime|storage|functions)/v1/.*'), lambda r, q: r.fulfill(status=401, content_type='application/json', body='{}'))
    page.goto(base + '/index.html', wait_until='load')
    page.wait_for_function('typeof window.loadDashboard==="function"&&typeof window.switchView==="function"')
    time.sleep(0.8)   # let the app finish its own start-up (session restore etc.)
    page.evaluate("""()=>{
      const st=document.createElement('style');st.textContent='#loginScreen{display:none!important}#appContainer{display:flex!important}';document.head.appendChild(st);
      document.getElementById('appContainer').classList.remove('hidden');
      window.currentProfile={uid:'u1',staffId:'OWNER',staffUuid:'s1',name:'Aqil Owner',role:'owner',companyId:'co1',locationId:'loc1'};
      window.companyId=async()=>'co1';window.locationId=async()=>'loc1';
    }""")
    return ctx, page, errors


def open_dashboard(page):
    """Opens the dashboard; returns (skeleton shown at open, text frames of the sales KPI)."""
    skel = page.evaluate("""()=>{
      const el=document.getElementById('dashTodaySales');window.__frames=[];const t0=performance.now();window.__openAt=t0;
      (function rec(){window.__frames.push(el.textContent);if(performance.now()-t0<1600)requestAnimationFrame(rec)})();
      window.switchView('dashboard');
      return document.getElementById('view-dashboard').classList.contains('is-skeleton');
    }""")
    page.wait_for_function("()=>{const v=document.getElementById('view-dashboard');return !v.classList.contains('is-skeleton')&&!v.classList.contains('is-loading')}", timeout=10000)
    time.sleep(1.8)
    return skel, page.evaluate('()=>window.__frames')


def wait_idle(page):
    page.wait_for_function("()=>!document.getElementById('view-dashboard').classList.contains('is-loading')", timeout=10000)
    time.sleep(0.15)


def text(page, el_id):
    return page.evaluate(f"()=>document.getElementById('{el_id}').textContent.trim()")


def main():
    srv, base = serve()
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH') or None, args=['--no-sandbox'])

        # ---------------------------------------------------------- 1. first open (iPad landscape)
        db = build()
        exp = expected(db)
        rest = Rest(db)
        ctx, page, errors = boot(browser, base, rest)
        # ---------------------------------------------------------- 0. the app stays quiet while idle (POS screen)
        page.evaluate("()=>window.switchView('pos')")
        time.sleep(2.5)
        page.evaluate("()=>{window.__m=0;new MutationObserver(r=>{window.__m+=r.length}).observe(document.body,{childList:true,subtree:true,attributes:true})}")
        wins, seen = [], 0
        for _ in range(3):
            time.sleep(5)
            m = page.evaluate('()=>window.__m')
            wins.append(m - seen)
            seen = m
        check(max(wins) < 400 and wins[-1] <= wins[0] * 2 + 100, f'idle POS screen: {wins} DOM changes per 5 s, not growing (before the fix: tens of thousands and rising)')
        sb_btn = page.evaluate("()=>{const b=document.getElementById('rtScanBtn');return b?[b.textContent.trim(),b.dataset.rtBound,typeof b.onclick==='function'&&b.onclick.name]:null}")
        check(sb_btn is not None and sb_btn[0] == 'SCAN BARCODE / SKU' and sb_btn[1] == '1' and sb_btn[2] == 'rtOpenPOSScanner', f'POS SCAN button still labelled and wired to the scanner ({sb_btn})')
        time.sleep(0.5)   # the app's own start-up work is finished before the owner opens the dashboard
        page.evaluate("()=>{window.__lt=[];try{new PerformanceObserver(l=>l.getEntries().forEach(e=>window.__lt.push([e.startTime,Math.round(e.duration)]))).observe({type:'longtask'})}catch(_){}}")
        rest.log.clear()
        skel, frames = open_dashboard(page)
        full_requests = rest.count()
        check(skel, 'skeleton is shown while the first load runs')
        check(text(page, 'dashTodaySales') == rm(exp['sales']), f"Jualan hari ini = {rm(exp['sales'])} (VOID / unpaid / other company excluded)")
        check(text(page, 'dashTodayTransactions') == str(exp['tx']), f"transaksi = {exp['tx']}")
        vals = [float(re.sub(r'[^0-9.]', '', f) or 0) for f in frames if f.startswith('RM')]
        check(len(set(frames)) >= 5 and vals == sorted(vals) and frames[-1] == rm(exp['sales']), f'sales counts up once and ends exact ({len(set(frames))} steps)')
        check(text(page, 'dashActiveJobs') == '6', 'Job aktif = 6 (completed / cancelled excluded)')
        jb = text(page, 'dashJobsBreakdown')
        check('3 sedang dibaiki' in jb and '2 baru' in jb and '1 tunggu barang' in jb, f'job breakdown uses the workshop board words: "{jb}"')
        check(text(page, 'dashBookingToday') == '3', 'Booking hari ini = 3: today only (5 from yesterday ignored, cancelled ignored)')
        check(text(page, 'dashLowStock') == str(exp['low']), f"Stok rendah = {exp['low']} (Inventori rule)")
        check(f"{exp['out']} habis stok" in text(page, 'dashStockBreakdown'), f"{exp['out']} habis stok")
        check(text(page, 'dashTotalCustomers') == '248', 'customers = 248 active')
        check(text(page, 'dashDrawerStatus') == 'DIBUKA', 'cash drawer open')
        check(page.evaluate("()=>document.querySelectorAll('.rtd-skel-row,.rtd-bar.is-skel').length") == 0, 'no skeleton left after load')
        check(page.evaluate("()=>!document.getElementById('view-dashboard').classList.contains('is-intro')&&!document.getElementById('dashSalesBars').classList.contains('is-intro')"), 'intro classes removed after the intro')
        lt = page.evaluate('()=>window.__lt.filter(x=>x[0]>=window.__openAt).map(x=>x[1])')
        check(not [d for d in lt if d > 50], f'no long main-thread task (>50 ms) while the dashboard opens and animates ({lt})')

        # ---------------------------------------------------------- 2. background refresh, nothing changed
        page.evaluate("""()=>{window.__mut=0;window.__obs=new MutationObserver(m=>{window.__mut+=m.filter(x=>x.type==='childList').length});
          ['dashRecentSales','dashReminders','dashLowStockList','dashSalesBars'].forEach(id=>window.__obs.observe(document.getElementById(id),{childList:true,subtree:true}))}""")
        rest.log.clear()
        page.evaluate('()=>window.loadDashboard({background:true})')
        wait_idle(page)
        bg = rest.count()
        check(bg <= 5 and rest.count('products') == 0 and rest.count('stock_balances') == 0, f'background refresh: {bg} requests (first open: {full_requests}); stock not re-read')
        check(page.evaluate('()=>window.__mut') == 0, 'background refresh with no change does not redraw lists or chart')
        check(page.evaluate("()=>document.querySelectorAll('.rtd-flash').length") == 0, 'no flash when nothing changed')

        # ---------------------------------------------------------- 3. new sale arrives
        now = datetime.now(MYT) - timedelta(seconds=30)
        db['invoices'].append({'id': 'new-sale-1', 'company_id': 'co1', 'invoice_no': 'INV-2610-999', 'total': 88, 'status': 'PAID', 'payment_status': 'PAID', 'created_at': iso(now)})
        db['payments'].append({'invoice_id': 'new-sale-1', 'company_id': 'co1', 'payment_method': 'QR', 'created_at': iso(now)})
        page.evaluate('()=>window.loadDashboard({background:true})')
        wait_idle(page)
        check(text(page, 'dashTodaySales') == rm(exp['sales'] + 88), 'new sale added to Jualan hari ini')
        check(page.evaluate("()=>document.querySelector('.rtd-kpi-hero').classList.contains('rtd-flash')"), 'sales card flashes when the number changes')
        first_row = page.evaluate("()=>{const r=document.querySelector('#dashRecentSales .rtd-item');return [r.className,r.textContent]}")
        check('is-new' in first_row[0] and 'INV-2610-999' in first_row[1] and 'QR' in first_row[1], 'new sale slides in at the top of Jualan terkini with its payment method')
        check(page.evaluate("()=>!document.querySelector('.rtd-kpi:not(.rtd-kpi-hero).rtd-flash')"), 'cards that did not change do not flash')

        # ---------------------------------------------------------- 4. refresh fails after data is on screen
        rest.fail = {'invoices'}
        page.evaluate('()=>window.loadDashboard({background:true})')
        wait_idle(page)
        check(text(page, 'dashLastUpdated').startswith('Gagal dikemas kini'), 'failed refresh shows "Gagal dikemas kini" in the status pill')
        check(page.evaluate("()=>document.querySelectorAll('#dashRecentSales .rtd-item').length") >= 6, 'failed refresh keeps the last good data on screen')
        rest.fail = set()
        page.evaluate("()=>{window.__loc=window.locationId;window.locationId=async()=>{throw new Error('lookup failed')}}")
        rest.log.clear()
        page.evaluate('()=>window.loadDashboard()')
        wait_idle(page)
        check(text(page, 'dashLastUpdated').startswith('Dikemas kini') and rest.count('locations') == 1 and text(page, 'dashLowStock') == str(exp['low']),
              'location lookup failing falls back to the first active location, as before')
        page.evaluate("()=>{window.locationId=window.__loc}")
        page.evaluate('()=>window.loadDashboard()')
        wait_idle(page)
        check(text(page, 'dashLastUpdated').startswith('Dikemas kini'), 'next refresh recovers')

        # ---------------------------------------------------------- 5. duplicate calls
        rest.log.clear()
        page.evaluate('()=>{window.loadDashboard();window.loadDashboard();window.loadDashboard({background:true})}')
        wait_idle(page)
        time.sleep(0.3)
        check(rest.count('products') == 1 and rest.count('invoices') == 1, 'three quick calls -> one load (no duplicate requests)')

        # ---------------------------------------------------------- 6. press feedback on iPad
        cdp = ctx.new_cdp_session(page)
        obj = cdp.send('Runtime.evaluate', {'expression': "document.getElementById('view-dashboard')"})['result']['objectId']
        ls = cdp.send('DOMDebugger.getEventListeners', {'objectId': obj})['listeners']
        check(any(x['type'] == 'touchstart' and x.get('passive') for x in ls), 'passive touchstart listener present (enables :active press effect in Safari iPad)')
        box = page.locator('.rtd-action').nth(2).bounding_box()
        page.mouse.move(box['x'] + 20, box['y'] + 20)
        page.mouse.down()
        time.sleep(0.25)
        tf = page.evaluate("()=>getComputedStyle(document.querySelectorAll('.rtd-action')[2]).transform")
        page.mouse.up()
        check(tf.startswith('matrix(0.97'), f'button shrinks while pressed ({tf})')
        check(not errors, f'no JavaScript errors ({errors[:2]})')
        page.evaluate("()=>window.switchView('dashboard')")
        wait_idle(page)

        # ---------------------------------------------------------- 7. layout at iPad / phone sizes
        for name, w, h in [('ipad-landscape', 1180, 820), ('ipad-portrait', 820, 1180), ('ipad-pro-landscape', 1366, 1024), ('phone', 390, 844)]:
            page.set_viewport_size({'width': w, 'height': h})
            time.sleep(0.4)
            ov = page.evaluate("()=>{const v=document.getElementById('view-dashboard');return [v.scrollWidth-v.clientWidth,document.documentElement.scrollWidth-innerWidth]}")
            check(ov[0] <= 1 and ov[1] <= 1, f'{name} {w}x{h}: no sideways scroll')
            if SHOT_DIR:
                os.makedirs(SHOT_DIR, exist_ok=True)
                hh = page.evaluate("()=>document.getElementById('view-dashboard').scrollHeight+130")
                page.set_viewport_size({'width': w, 'height': max(h, hh)})
                time.sleep(0.3)
                page.screenshot(path=os.path.join(SHOT_DIR, f'dash-{name}.png'))
        ctx.close()

        # ---------------------------------------------------------- 8. >1000 products: same number as Inventori > PESAN STOK
        db = build(big=True)
        exp = expected(db)
        rest = Rest(db)
        ctx, page, errors = boot(browser, base, rest)
        open_dashboard(page)
        dash_low = text(page, 'dashLowStock').replace(',', '')
        page.evaluate("()=>window.switchView('inventory')")
        page.wait_for_function("()=>Array.isArray(window.rtInventoryCache)&&window.rtInventoryCache.length===2600", timeout=15000)
        page.wait_for_function("()=>{const b=document.getElementById('rtReorderCount');return b&&b.textContent.trim()!==''}", timeout=5000)
        inv_low = text(page, 'rtReorderCount')
        check(dash_low == str(exp['low']) == inv_low, f"2,600 products: dashboard {dash_low} = Inventori PESAN STOK {inv_low} = expected {exp['low']}")
        check(not errors, f'no JavaScript errors ({errors[:2]})')
        ctx.close()

        # ---------------------------------------------------------- 9. first load fails, then recovers
        db = build()
        exp = expected(db)
        rest = Rest(db)
        rest.fail = {'invoices'}
        ctx, page, errors = boot(browser, base, rest, 820, 1180)
        open_dashboard(page)
        check(page.evaluate("()=>!!document.querySelector('#dashRecentSales .rtd-error')"), 'first-load failure shows the error message')
        check(page.evaluate("()=>document.querySelectorAll('.rtd-skel-row,.rtd-bar.is-skel').length") == 0 and
              page.evaluate("()=>!document.getElementById('view-dashboard').classList.contains('is-skeleton')"), 'no endless skeleton after a failure')
        rest.fail = set()
        page.evaluate('()=>window.loadDashboard()')
        wait_idle(page)
        time.sleep(1)
        check(text(page, 'dashTodaySales') == rm(exp['sales']), 'after the failure, Refresh loads the data')
        check(not errors, f'no JavaScript errors ({errors[:2]})')
        ctx.close()

        # ---------------------------------------------------------- 10. Reduce Motion
        rest = Rest(build())
        ctx, page, errors = boot(browser, base, rest, reduce=True)
        skel, frames = open_dashboard(page)
        middle = [f for f in frames if f not in ('RM 0.00', '—', rm(exp['sales']))]
        check(not middle, 'Reduce Motion: numbers appear straight away (no count-up)')
        anim = page.evaluate("()=>[...document.querySelectorAll('#view-dashboard *')].filter(e=>getComputedStyle(e).animationName!=='none').length")
        check(anim == 0, f'Reduce Motion: no element is animated ({anim})')
        check(not errors, f'no JavaScript errors ({errors[:2]})')
        ctx.close()
        browser.close()
    srv.shutdown()
    print(('\nALL PASSED' if not FAILS else f'\n{len(FAILS)} FAILED'), flush=True)
    sys.exit(1 if FAILS else 0)


if __name__ == '__main__':
    main()
