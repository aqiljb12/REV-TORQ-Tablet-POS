const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const root=path.resolve(__dirname,'..');const read=s=>fs.readFileSync(path.join(root,s),'utf8');
test('Dashboard V2 assets are loaded with a new version',()=>{
  const index=read('index.html');
  assert.match(index,/css\/rt-dashboard\.css\?v=20261021-dash3/);
  assert.match(index,/js\/dashboard\.js\?v=20261021-dash3/);
  assert.equal((index.match(/id="view-dashboard"/g)||[]).length,1);
});
test('Every element the dashboard writes to exists in the markup',()=>{
  const index=read('index.html'),js=read('js/dashboard.js');
  const ids=new Set([...js.matchAll(/(?:set|html|pill)\('([A-Za-z]+)'/g)].map(m=>m[1]).concat([...js.matchAll(/\$\('([A-Za-z-]+)'\)/g)].map(m=>m[1])));
  assert.ok(ids.size>15);
  for(const id of ids)assert.ok(index.includes(`id="${id}"`),'missing #'+id);
});
test('Dashboard CSS stays Android 9 WebView safe and scoped',()=>{
  const css=read('css/rt-dashboard.css').replace(/\/\*[\s\S]*?\*\//g,'');
  for(const bad of [':has(',':is(',':where(','aspect-ratio','clamp(','inset:'])assert.ok(!css.includes(bad),bad);
  assert.doesNotMatch(css,/(^|\})\s*(button|span|div|b|i)\s*\{/);
});
test('Dashboard keeps real-data queries and public API',()=>{
  const js=read('js/dashboard.js');
  for(const k of ["from('invoices')","eq('payment_status','PAID')","neq('status','VOID')","from('cash_drawers')","from('service_reminders')","from('stock_balances')",'window.loadDashboard','window.startDashboardRealtime','window.rtDebouncedDashboard'])assert.ok(js.includes(k),k);
  assert.doesNotMatch(read('index.html'),/rt-modern-dashboard"/);
});
test('Motion: keyframes animate only transform/opacity; hover only for real pointers; Reduce Motion honoured',()=>{
  const css=read('css/rt-dashboard.css').replace(/\/\*[\s\S]*?\*\//g,'');
  const frames=[...css.matchAll(/@keyframes\s+[\w-]+\s*\{((?:[^{}]*\{[^{}]*\})*)\s*\}/g)];
  assert.ok(frames.length>=7,'keyframes found');
  for(const f of frames){for(const d of f[1].matchAll(/([a-z-]+)\s*:/g))assert.ok(['transform','-webkit-transform','opacity'].includes(d[1]),'animated property '+d[1])}
  const hoverBlock=css.match(/@media\s*\(hover:hover\)\s*\{((?:[^{}]*\{[^{}]*\})*)\s*\}/);
  assert.ok(hoverBlock,'@media (hover:hover) block');
  assert.doesNotMatch(css.replace(hoverBlock[0],''),/:hover/,'every :hover rule is inside @media (hover:hover)');
  assert.match(css,/@media \(prefers-reduced-motion:reduce\)\{[^}]*animation:none!important/);
  const js=read('js/dashboard.js');
  assert.match(js,/addEventListener\('touchstart',\(\)=>\{\},\{passive:true\}\)/,'passive touch listener for :active on iPad');
  assert.match(js,/prefers-reduced-motion: reduce/);
});
test('Data rules: booking uses the Malaysia DATE, stock follows Inventori > PESAN STOK and reads every page',()=>{
  const js=read('js/dashboard.js');
  assert.match(js,/\.eq\('preferred_date',todayMY\(\)\)/);
  assert.doesNotMatch(js,/gte\('preferred_date'/);
  assert.match(js,/p\.min_stock==null\?5/);
  assert.match(js,/p\.active!==false/);
  assert.match(js,/\.range\(from,from\+PAGE-1\)/);
  assert.match(js,/from\('stock_balances'\)\.select\('product_id,quantity'\)/);
  assert.match(read('js/rt-inventory-plus.js'),/p\.min_stock==null\?5:num\(p\.min_stock\)/,'Inventori rule unchanged');
});
test('Idle loop fix: POS scan button binds once and rtInit never stacks timers',()=>{
  const index=read('index.html');
  assert.match(index,/if\(!b\|\|b\.dataset\.rtBound==='1'\)return;\s*b\.dataset\.rtBound='1';/);
  assert.match(index,/if\(rtInitTimer\)return;rtInitTimer=setTimeout/);
  assert.doesNotMatch(index,/new MutationObserver\(\(\)=>\{setTimeout\(rtInit,50\);\}\)/);
  assert.match(read('js/inventory-tools-rc7.js'),/if\(input&&input\.placeholder!==ph\)input\.placeholder=ph;/);
  assert.match(index,/js\/inventory-tools-rc7\.js\?v=20261021-idlefix/);
});
