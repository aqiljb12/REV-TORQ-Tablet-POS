"""Optional browser smoke test: python tests/cost-manager-ui.test.py"""
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent.parent
HTML='''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">\n<link rel="stylesheet" href="file://CSS"></head><body><button id="rtServiceCostBtn" hidden>KOS SERVIS</button><script>\nwindow.currentProfile={role:'owner'};\nwindow.confirm=()=>true; window.showToast=(s,t)=>{window.__toast=s};\nwindow.supabaseClient={from:(table)=>({select:()=>({eq:()=>({maybeSingle:async()=>({data:{id:'00000000-0000-4000-8000-000000000001',sku:'SKU-1',name:'Motul 7100',category:'MINYAK',cost_price:48,sell_price:75},error:null})})})}),\nrpc:async(name,args)=>{window.__call={name,args};(window.__calls=window.__calls||[]).push({name,args}); if(name==='rt_service_cost_list')return {data:[{service_name:'Labour Service',cost_per_service:5}],error:null};return {data:{sku:'SKU-1'},error:null}}};\n</script><script src="file://JS"></script></body></html>'''.replace('CSS',str(ROOT/'css/rt-cost-manager.css')).replace('JS',str(ROOT/'js/rt-cost-manager.js'))
with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--allow-file-access-from-files'])
  page=browser.new_page(viewport={'width':375,'height':750});page.set_content(HTML)
  page.add_style_tag(content='.hidden{display:none!important}')
  page.add_style_tag(path=str(ROOT/'css/rt-cost-manager.css'))
  page.add_script_tag(path=str(ROOT/'js/rt-cost-manager.js'))
  print('open',flush=True);page.evaluate("window.rtOpenQuickCost('00000000-0000-4000-8000-000000000001')")
  page.wait_for_function("document.querySelector('#rtCostProductName')?.textContent === 'Motul 7100'", timeout=5000)
  print('loaded cost',flush=True);page.fill('#rtCostValue','55')
  assert page.inner_text('#rtCostGross')=='RM 20.00', page.inner_text('#rtCostGross')
  assert page.inner_text('#rtCostMargin')=='26.7%'
  print('click product',flush=True);page.click('#rtCostProductSave',timeout=2500);page.wait_for_function("window.__call?.name === 'rt_product_cost_update'")
  assert page.evaluate('window.__call.args.p_cost_price')==55
  print('service open',flush=True);page.evaluate('window.rtOpenServiceCosts()');page.wait_for_selector('#rtCostServiceList button', timeout=2000)
  print('service list',flush=True);page.click('#rtCostServiceList button',timeout=2500);assert page.input_value('#rtCostServiceName')=='Labour Service'
  page.fill('#rtCostServiceAmount','8');print('service save',flush=True);page.click('#rtCostServiceSave',timeout=2500);page.wait_for_function("window.__calls?.some(x=>x.name==='rt_service_cost_upsert')",timeout=2000)
  assert page.evaluate("window.__calls.find(x=>x.name==='rt_service_cost_upsert').args.p_cost_per_service")==8
  page.evaluate("window.currentProfile.role='pos'")
  assert page.evaluate("window.rtCostCanEdit()") is False
  page.evaluate('window.rtCostUIRefresh()')
  assert page.locator('#rtServiceCostBtn').is_hidden()
  browser.close()
print('PASS: product cost, preview, service costs, role-based UI, responsive modal')
