const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const root=path.resolve(__dirname,'..');const r=p=>fs.readFileSync(path.join(root,p),'utf8');
const PWA=process.env.REVTORQ_PWA_DIR||path.resolve(root,'../work_customer');
const readPwa=p=>fs.readFileSync(path.join(PWA,p),'utf8');
// The Customer PWA is a separate package: its checks run only when that folder is next to this one (or REVTORQ_PWA_DIR is set).
const HAS_PWA=fs.existsSync(path.join(PWA,'js','app.js'));
test('POS both customer creation flows reuse canonical RPC, not unconditional UUID',()=>{
 const customers=r('js/customers.js'),pos=r('js/pos.js');
 assert.match(customers,/rpc\('rt_pos_find_or_create_customer'/);
 assert.match(pos,/supabaseRpc\('rt_pos_find_or_create_customer'/);
 const create=customers.slice(customers.indexOf('async function saveCustomer('),customers.indexOf('function openAddVehicle'));
 assert.doesNotMatch(create,/db\.collection\("customers"\)\.doc\(custId\)\.set/);
});
test('PWA claim is OTP-like code, NOT auto link from metadata.phone',{skip:HAS_PWA?false:'Customer PWA folder not present (separate package)'},()=>{
 const app=readPwa('js/app.js');
 assert.match(app,/rt_customer_redeem_claim_code/);
 assert.match(app,/async function ensureCustomerProfile/);
 assert.match(app,/if\(pending\)/);
 assert.match(app,/function rtShowLinkPosDialog/);
 assert.match(app,/id="rPosClaim"/);
 assert.match(app,/id="profileLinkPos"/);
 assert.doesNotMatch(app,/rt_customer_claim_or_create_profile/);
});
test('SQL installs code hashes, RLS, role verification, atomic vehicle and point merge',()=>{
 const sql=r('migration_2026_10_21_pos_customer_pwa_secure_link.sql');
 for(const token of ['begin;','commit;','enable row level security','extensions.digest','extensions.gen_random_bytes','rt_staff_context','auth.uid()','CLAIM_CODE_INVALID_OR_EXPIRED','update public.vehicles set customer_id','update public.invoices set customer_id','update public.job_cards set customer_id','update public.loyalty_transactions set customer_id','on conflict(customer_id) do update','revoke all on table public.rt_customer_claim_codes'])assert.ok(sql.toLowerCase().includes(token.toLowerCase()),token);
});
test('POS issue UI is in POS panel; PWA service worker has new cache key',{skip:HAS_PWA?false:'Customer PWA folder not present (separate package)'},()=>{
 assert.match(r('index.html'),/id="rtIssueCustomerClaimCode"/);
 assert.match(r('index.html'),/customer-pos-link\.js\?v=20261021-poslink1/);
 assert.match(readPwa('sw.js'),/revtorq-customer-20261021-poslink1-v1/);
 assert.match(readPwa('index.html'),/app\.js\?v=20261021-poslink1/);
});
