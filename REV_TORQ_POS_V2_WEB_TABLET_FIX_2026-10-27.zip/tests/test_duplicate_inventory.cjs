const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const elements={
 invIsEdit:{value:'false'},invName:{value:'Engine Oil Ultra 10W40'},invCat:{value:'MINYAK'},
 searchInventory:{value:''}
};
let saveCalls=0, rpcCalls=0, stockOpen=null, confirmation=false, messages=[];
const handlers={};
const doc={getElementById:id=>elements[id]||null,addEventListener:(event,fn)=>handlers[event]=fn};
const profiles=[{sku:'SKU-1',name:'Engine Oil Ultra 10W40',category:'MINYAK'}];
const client={
 from:table=>{
  assert.equal(table,'products');
  const chain={select(){return this},eq(){return this},limit:async()=>({data:profiles,error:null})};
  return chain;
 },
 rpc:async()=>{rpcCalls++;return {data:{deleted:true},error:null}}
};
const sandbox={
 window:{currentProfile:{companyId:'company1'},supabaseClient:client,rtInventoryCache:[{id:'product1',stock:10,sku:'SKU-1',name:'Engine Oil Ultra 10W40'}],rtHasAdminAccess:()=>true,
   showToast:(message,type)=>messages.push({message,type}),
   saveInventory:async()=>{saveCalls++},
   openStockAdjustment:async sku=>{stockOpen=sku},
   confirm:()=>confirmation,
   rtOverride:{}},
 document:doc,alert:message=>messages.push({message}),confirm:()=>confirmation,Promise,console,setTimeout
};
vm.runInNewContext(fs.readFileSync('js/rt-inventory-delete-duplicate.js','utf8'),sandbox);
const ev={preventDefault(){}};
(async()=>{
 await sandbox.window.saveInventory(ev);
 assert.equal(saveCalls,0,'duplicate name cannot create another product');
 assert.ok(messages.some(x=>x.message.includes('sudah wujud')));
 elements.invName.value='Engine Oil Ultra 15W40';
 await sandbox.window.saveInventory(ev);
 assert.equal(saveCalls,1,'unique product can be saved normally');
 elements.invIsEdit.value='true';
 elements.invName.value='Engine Oil Ultra 10W40';
 await sandbox.window.saveInventory(ev);
 assert.equal(saveCalls,2,'editing existing product must not be blocked');
 confirmation=true;
 await sandbox.window.rtDeleteUnusedInventoryItem('product1');
 assert.equal(stockOpen,'SKU-1','record with stock directs to stock correction');
 assert.equal(rpcCalls,0,'record with stock never triggers deletion');
 assert.ok(messages.some(x=>x.message.includes('sudah wujud')));
 console.log('5/5 simulated flows PASS');
})().catch(e=>{console.error(e);process.exit(1)});
