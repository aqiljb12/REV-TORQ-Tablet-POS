const assert=require('node:assert/strict');
const test=require('node:test');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'..');
const link=require('../js/rt-customer-points-link.js');

test('correct PWA profile deeplink and link only appended once',()=>{
  assert.equal(link.url,'https://revtorq.com.my/?tab=profile');
  const raw='REV TORQ\nResit: RT-001\nJumlah: RM 66.00\n\nTerima kasih kerana berurusan dengan kami.';
  const result=link.append(raw);
  assert.match(result,/Semak Point & Voucher REV TORQ/);
  assert.ok(result.includes(link.url));
  assert.equal((result.match(/https:\/\/revtorq.com.my/g)||[]).length,1);
  assert.equal(link.append(result),result);
  assert.ok(result.indexOf(link.url)<result.indexOf('Terima kasih'));
  assert.equal(link.append(''), '');
});

test('POS, PDF native-share and PDF Whatsapp fallback all use customer portal link',()=>{
  const pos=fs.readFileSync(path.join(root,'js/pos.js'),'utf8');
  const pdf=fs.readFileSync(path.join(root,'js/rt-receipt-pdf.js'),'utf8');
  const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
  assert.match(pos,/window\.RTCustomerPointsLink\.append\(baseText\)/);
  assert.match(pdf,/w\.RTCustomerPointsLink\.append\(text\)/);
  assert.match(pdf,/w\.RTCustomerPointsLink\.append\(msg\)/);
  assert.match(pdf,/pushWrapped\('https:\/\/revtorq\.com\.my\/\?tab=profile'/);
  assert.match(html,/js\/rt-customer-points-link\.js\?v=20261027-wa-points/);
  assert.ok(html.indexOf('js/rt-customer-points-link.js') < html.indexOf('js/pos.js'));
});
