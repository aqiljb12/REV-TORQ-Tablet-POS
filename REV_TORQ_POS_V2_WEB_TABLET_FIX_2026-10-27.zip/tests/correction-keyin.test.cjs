const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
test('wrong POS item is removed immediately and Undo restores quantity and discount',()=>{
 const src=read('js/pos.js');
 const code=src.slice(src.indexOf('let rtCartLastRemoved = null;'),src.indexOf('// V2 polish: two-line cart rows'));
 const ctx={posCart:[{sku:'A01',name:'Minyak',qty:3,discount:1},{sku:'B02',name:'Tayar',qty:1,discount:0}], renderCart:()=>{},rtPosPromo:null,rtSchedulePromoRevalidate:()=>{},rtCartEsc:v=>v,window:{}};
 vm.createContext(ctx);vm.runInContext(code,ctx);
 ctx.rtCartRemove('A01');
 assert.deepEqual(ctx.posCart.map(x=>x.sku),['B02']);
 ctx.rtCartUndoRemove();
 assert.deepEqual(ctx.posCart.map(x=>[x.sku,x.qty,x.discount]),[['A01',3,1],['B02',1,0]]);
 ctx.rtCartRemove('B02');ctx.posClearCart();ctx.rtCartUndoRemove();
 assert.equal(ctx.posCart.length,0,'clearing cart must also invalidate undo');
});
test('0 typed quantity now removes uncommitted item; blank input is safe',()=>{
 const src=read('js/pos.js'),fn=src.slice(src.indexOf('function rtCartSetQty'),src.indexOf('function rtCartPatchRow'));
 assert.match(fn,/raw === '0'/);
 assert.match(fn,/rtCartRemove\(sku\)/);
 assert.match(fn,/!Number\.isFinite\(q\)/);
});
test('Archived records are routed to audited Override, not direct database deletion',()=>{
 const src=read('js/rt-input-correction.js');
 assert.match(src,/rtOverride\.openPage\(entity,term\)/);
 assert.doesNotMatch(src,/\.delete\(|\.from\(|\.rpc\(/);
 assert.match(read('js/customers.js'),/data-rt-correction-type="CUSTOMER"/);
 assert.match(read('js/inventory-canonical-list.js'),/data-rt-correction-type="PRODUCT"/);
 const override=read('js/rt-override.js');
 assert.match(override,/pendingFocus=\{entity:entity, query:/);
});
test('Input correction control has a Backspace alternative and clear field but excludes passwords',()=>{
 const src=read('js/rt-input-correction.js');
 assert.match(src,/PADAM 1/);assert.match(src,/KOSONGKAN/);
 assert.match(src,/allowedTypes=new Set/);
 assert.doesNotMatch(src,/password/);
 const html=read('index.html');
 assert.ok(html.includes('js/rt-input-correction.js?v=20261027-tabletfix'));
});
