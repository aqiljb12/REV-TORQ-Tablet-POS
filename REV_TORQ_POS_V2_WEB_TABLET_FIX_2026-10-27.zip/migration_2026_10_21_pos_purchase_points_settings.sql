-- REV TORQ | Purchase Points V1 | 2026-10-21
-- For project wabtoq. Review/back up before deployment.
-- Does not change the existing service points trigger or historical balances.
-- By default ALL PURCHASE CATEGORIES ARE DISABLED until Admin explicitly enables them.
-- Only new PAID, no-Job-Card POS invoices with a selected customer with phone earn purchase points.
-- Uses 1 point per configured RM spending for each category. Does not grant points to fees,
-- free-form service/labour, Dyno, or products without an inventory category rule.
BEGIN;

CREATE TABLE IF NOT EXISTS public.rt_purchase_loyalty_rules (
  company_id uuid NOT NULL REFERENCES public.companies(id),
  category text NOT NULL,
  rm_per_point numeric(10,2) NOT NULL CHECK (rm_per_point >= 0.01 AND rm_per_point <= 1000),
  enabled boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(company_id, category),
  CONSTRAINT rt_purchase_loyalty_category_canonical CHECK (category=upper(btrim(category)) AND length(category) BETWEEN 1 AND 50)
);
ALTER TABLE public.rt_purchase_loyalty_rules ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.rt_purchase_loyalty_rules FROM PUBLIC, anon, authenticated;

INSERT INTO public.rt_purchase_loyalty_rules(company_id,category,rm_per_point,enabled)
SELECT c.id,v.category,v.rate,false
FROM public.companies c
CROSS JOIN (VALUES
  ('MINYAK',1.00::numeric),
  ('TAYAR',2.00::numeric),
  ('SPAREPART',5.00::numeric),
  ('AKSESORI',5.00::numeric),
  ('BARANG LUAR',1000.00::numeric),
  ('SERVIS',1000.00::numeric)
) v(category,rate)
WHERE c.active IS TRUE
ON CONFLICT (company_id,category) DO NOTHING;

CREATE OR REPLACE FUNCTION public.rt_pos_get_purchase_loyalty_rules()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=public,pg_temp
AS $fn$
DECLARE
  s record;
  result jsonb;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'AUTH_REQUIRED'; END IF;
  SELECT * INTO s FROM public.rt_staff_context() LIMIT 1;
  IF s.staff_id IS NULL OR lower(coalesce(s.role,'')) NOT IN
    ('owner','super_admin','admin','manager','cashier','pos') THEN
    RAISE EXCEPTION 'POS_ACCESS_REQUIRED';
  END IF;
  SELECT coalesce(jsonb_agg(jsonb_build_object(
    'category',category,'rm_per_point',rm_per_point,'enabled',enabled
  ) ORDER BY category),'[]'::jsonb)
  INTO result
  FROM public.rt_purchase_loyalty_rules
  WHERE company_id=s.company_id;
  RETURN result;
END;
$fn$;

CREATE OR REPLACE FUNCTION public.rt_pos_save_purchase_loyalty_rule(
  p_category text,
  p_rm_per_point numeric,
  p_enabled boolean
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=public,pg_temp
AS $fn$
DECLARE
  s record;
  k text := upper(btrim(coalesce(p_category,'')));
  v_rate numeric(10,2);
  v_enabled boolean := coalesce(p_enabled,false);
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'AUTH_REQUIRED'; END IF;
  SELECT * INTO s FROM public.rt_staff_context() LIMIT 1;
  IF s.staff_id IS NULL OR lower(coalesce(s.role,'')) NOT IN
    ('owner','super_admin','admin') THEN
    RAISE EXCEPTION 'ADMIN_ONLY';
  END IF;
  IF k='' OR length(k)>50 OR p_rm_per_point IS NULL OR p_rm_per_point<0.01 OR p_rm_per_point>1000 THEN
    RAISE EXCEPTION 'INVALID_CATEGORY_OR_RATE';
  END IF;
  -- Only allow categories already in this company's inventory, or already seeded categories.
  IF NOT EXISTS(SELECT 1 FROM public.rt_purchase_loyalty_rules WHERE company_id=s.company_id AND category=k)
     AND NOT EXISTS(SELECT 1 FROM public.products WHERE company_id=s.company_id AND upper(btrim(coalesce(category,'')))=k) THEN
    RAISE EXCEPTION 'CATEGORY_NOT_FOUND';
  END IF;
  IF k IN ('SERVIS','DYNO') AND v_enabled THEN
    RAISE EXCEPTION 'NON_RETAIL_CATEGORY';
  END IF;
  v_rate:=round(p_rm_per_point,2);
  IF v_rate<0.01 THEN RAISE EXCEPTION 'RATE_TOO_SMALL'; END IF;
  INSERT INTO public.rt_purchase_loyalty_rules(company_id,category,rm_per_point,enabled,updated_at)
  VALUES(s.company_id,k,v_rate,v_enabled,now())
  ON CONFLICT(company_id,category) DO UPDATE
  SET rm_per_point=excluded.rm_per_point,enabled=excluded.enabled,updated_at=now();
  RETURN jsonb_build_object('category',k,'rm_per_point',v_rate,'enabled',v_enabled);
END;
$fn$;

CREATE OR REPLACE FUNCTION public.rt_award_purchase_loyalty_on_paid_invoice()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=public,pg_temp
AS $fn$
DECLARE
  v_phone text;
  v_points integer := 0;
  v_previous integer := 0;
  v_line record;
  v_after_discount numeric;
  v_subtotal numeric := greatest(0,coalesce(new.subtotal,0));
  v_discount numeric := greatest(0,coalesce(new.discount,0));
BEGIN
  -- Explicitly reverse earlier award if an invoice is voided after payment.
  IF tg_op='UPDATE' AND upper(coalesce(new.status,''))='VOID'
     AND upper(coalesce(old.status,'')) IS DISTINCT FROM 'VOID' THEN
    SELECT coalesce(sum(points),0)::integer INTO v_previous
    FROM public.loyalty_transactions
    WHERE customer_id=new.customer_id AND reference_type='INVOICE'
      AND reference_id=new.id AND transaction_type='POS_PURCHASE';
    IF v_previous>0 AND new.customer_id IS NOT NULL THEN
      PERFORM public.rt_add_loyalty_points(
        new.customer_id,-v_previous,'POS_PURCHASE_REVERSAL',
        'Batal invois '||coalesce(new.invoice_no,new.id::text),
        'INVOICE',new.id,'invoice-purchase-reversal:'||new.id::text
      );
    END IF;
    RETURN new;
  END IF;

  IF upper(coalesce(new.status,''))<>'PAID'
     OR upper(coalesce(new.payment_status,''))<>'PAID'
     OR new.customer_id IS NULL
     OR new.job_card_id IS NOT NULL THEN RETURN new; END IF;

  IF tg_op='UPDATE' AND upper(coalesce(old.status,''))='PAID'
     AND upper(coalesce(old.payment_status,''))='PAID' THEN RETURN new; END IF;

  SELECT phone_normalized INTO v_phone FROM public.customers
   WHERE id=new.customer_id AND company_id=new.company_id AND active IS TRUE;
  IF v_phone IS NULL THEN RETURN new; END IF;

  -- Each category receives points from aggregate *net* line spend. Allocate invoice-level
  -- discount proportionally; free-form service, labour and external charges never earn points.
  FOR v_line IN
    SELECT upper(btrim(coalesce(p.category,''))) as category,
           coalesce(sum(greatest(0,coalesce(ii.line_total,0))),0) AS gross_eligible,
           r.rm_per_point
    FROM public.invoice_items ii
    JOIN public.products p ON p.id=ii.product_id AND p.company_id=new.company_id
    JOIN public.rt_purchase_loyalty_rules r
      ON r.company_id=new.company_id
      AND r.category=upper(btrim(coalesce(p.category,''))) AND r.enabled=true
    WHERE ii.invoice_id=new.id
      AND upper(coalesce(ii.job_item_type,'PART')) NOT IN ('SERVICE','LABOUR','OTHER')
      AND upper(coalesce(p.category,'')) NOT IN ('SERVIS','DYNO')
    GROUP BY upper(btrim(coalesce(p.category,''))),r.rm_per_point
  LOOP
    v_after_discount := greatest(0,v_line.gross_eligible-
      CASE WHEN v_subtotal>0 THEN v_discount*(v_line.gross_eligible/v_subtotal) ELSE 0 END);
    v_points:=v_points+floor(round(v_after_discount,2)/v_line.rm_per_point)::integer;
  END LOOP;

  IF v_points>0 THEN
    PERFORM public.rt_add_loyalty_points(
      new.customer_id,v_points,'POS_PURCHASE',
      'Belian barang invoice '||coalesce(new.invoice_no,new.id::text)||' · +'||v_points||' point',
      'INVOICE',new.id,'invoice-purchase-loyalty:'||new.id::text
    );
    INSERT INTO public.notifications(company_id,customer_id,title,body,notification_type,dedupe_key,created_at)
    VALUES(new.company_id,new.customer_id,'Point belian REV TORQ',
      '+'||v_points||' point daripada pembelian barang '||coalesce(new.invoice_no,new.id::text),
      'LOYALTY','invoice-purchase-notification:'||new.id::text,now())
    ON CONFLICT DO NOTHING;
  END IF;
  RETURN new;
END;
$fn$;

DROP TRIGGER IF EXISTS trg_rt_purchase_loyalty_paid ON public.invoices;
CREATE TRIGGER trg_rt_purchase_loyalty_paid
  AFTER INSERT OR UPDATE OF status,payment_status ON public.invoices
  FOR EACH ROW EXECUTE FUNCTION public.rt_award_purchase_loyalty_on_paid_invoice();

REVOKE ALL ON FUNCTION public.rt_pos_get_purchase_loyalty_rules() FROM PUBLIC,anon,authenticated;
REVOKE ALL ON FUNCTION public.rt_pos_save_purchase_loyalty_rule(text,numeric,boolean) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.rt_pos_get_purchase_loyalty_rules() TO authenticated;
GRANT EXECUTE ON FUNCTION public.rt_pos_save_purchase_loyalty_rule(text,numeric,boolean) TO authenticated;

COMMIT;
