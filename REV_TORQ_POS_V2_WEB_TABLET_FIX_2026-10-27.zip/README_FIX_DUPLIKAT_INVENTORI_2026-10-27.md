# REV TORQ POS — Padam Salah Key-in / Barang Berganda (27 Oct 2026)

## Apa yang ditambah
1. **Inventori → PADAM DUPLIKAT** untuk Owner/Admin. Masukkan SKU item yang hendak dipadam, sebab, dan sahkan sesi Override dengan PIN sendiri.
2. Server **hanya memadam kekal item yang tiada stok dan tidak pernah dirujuk oleh transaksi, pergerakan stok, job, invoice, sebut harga atau jadual lain**. Ia mengesan foreign key ke jadual `products` semasa operasi dan gagal secara selamat jika item mempunyai sejarah.
3. Item yang ada stok tidak boleh dipadam: butang arahkan Admin ke pelarasan STOK. **SET = 0** kini dibenarkan untuk jumlah stok yang benar-benar sifar. Ambil kira lokasi lain dan sejarah pergerakan: jika item pernah mempunyai pergerakan, `ARKIB` ialah tindakan yang selamat.
4. Inventori aktif tidak lagi memaparkan produk `active=false`; produk yang sudah diarkib masih boleh dicari/dipulihkan melalui Override.
5. **Sekat daftar barang nama + kategori sama dua kali** (walaupun SKU/barcode berlainan). Barang sedia ada perlu di-EDIT atau dibuat pelarasan STOK.
6. Pembaikan sebelumnya (troli UNDO, toolbar Backspace, Purchase Points, Customer Link dan Dashboard Laju) dikekalkan.

## Cara pasang
1. Backup Supabase `wabtoq` sebelum migrasi.
2. Jalankan `migration_2026_10_27_pos_delete_unused_product.sql` dalam Supabase SQL Editor. SQL hanya memasang RPC, **tidak** memadam mana-mana rekod sedia ada.
3. Pastikan migrasi `migration_2026_10_05_override_audit.sql` sudah dipasang; prosedur ini menggunakan Override.
4. Deploy ZIP POS ini sebagai laman web POS.
5. Login Owner/Admin dan uji pada satu produk ujian kosong tanpa stok/sejarah. Sahkan rekod kekal dipadam dan audit log mencatat peristiwa `OVERRIDE_PRODUCT_DELETE_UNUSED`.
6. Uji dua produk dengan nama sama dan kategori sama: simpan kali kedua mesti disekat dengan mesej rujuk SKU sedia ada.
7. Uji item yang pernah dibeli/dijual atau mempunyai stok: padam kekal mesti **DITOLAK**. Boleh gunakan STOK / ARKIB selepas pengesahan inventori fizikal.

## Penting: jenis duplikat
- **Rekod barang berganda tetapi stok sifar dan belum digunakan:** boleh padam kekal.
- **Rekod barang berganda yang telah mempunyai stok atau rekod ledger:** tidak boleh padam kekal; betulkan kuantiti fizikal melalui STOK, arkib rekod tambahan melalui Override. Jangan pindahkan/tolak kuantiti secara membuta tuli.
- **Satu rekod barang dengan stok terlebih masuk:** pembetulan ialah STOK → `Tetapkan Stok Sebenar` (bukan padam item).
- **Invoice yang sudah dibayar:** tidak boleh padam dengan fungsi ini. Gunakan VOID yang diaudit.

## Status pengesahan
- Sintaks semua 61 fail JS akar: lulus.
- Ujian simulasi 5/5 untuk sekat duplicate, benarkan simpan normal dan lindungi barang berstok: lulus.
- Ujian unit utama untuk dashboard, Override, Purchase Points, input, dan tambah motosikal: lulus. Dua ujian Customer PWA dalam pakej POS tidak boleh dijalankan sendiri kerana path `work_customer` tidak wujud dalam pakej ini.
- Migrasi SQL belum dijalankan pada live; ujian integrasi Supabase dan UI iPad/Android belum dilakukan.
