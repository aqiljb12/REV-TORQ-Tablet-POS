/* REV TORQ — salah key-in / barang berganda, safe permanent removal.
   No product is removed from the browser directly: dedicated secure SQL RPC
   enforces Admin, Override, zero stock and no historic references. */
(function(){
 'use strict';
 const $=id=>document.getElementById(id);
 const esc=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const norm=v=>String(v||'').normalize('NFKC').trim().replace(/\s+/g,' ').toLocaleUpperCase('en-US');
 const toast=(s,type)=>{try{window.showToast?.(s,type||'info');}catch(_){alert(s);}};
 function admin(){return typeof window.rtHasAdminAccess==='function'&&window.rtHasAdminAccess();}
 function client(){return window.supabaseClient||null;}
 function fromCache(id){return (window.rtInventoryCache||[]).find(p=>String(p.id)===String(id))||null;}
 function errText(e){return String(e?.message||e||'Ralat tidak diketahui.');}
 function friendly(e){
   const t=errText(e);
   if(t.includes('PRODUCT_HAS_STOCK'))return 'Barang masih mempunyai stok. Betulkan/asingkan stok sebenar melalui STOK dahulu. Jangan padam baki stok secara automatik.';
   if(t.includes('PRODUCT_HAS_HISTORY'))return 'Barang pernah digunakan dalam transaksi/pergerakan stok. Padam kekal disekat. Gunakan ARKIB selepas semak stok.';
   if(t.includes('SKU_CONFIRM_MISMATCH'))return 'SKU pengesahan tidak sama. Tiada rekod dipadam.';
   if(t.includes('ADMIN_ONLY'))return 'Padam kekal hanya untuk Admin / Owner.';
   if(t.includes('OVERRIDE_'))return 'Sesi Override tidak sah atau tamat. Aktifkan semula Override.';
   if(t.includes('PGRST202')||/could not find the function|does not exist/i.test(t))return 'SQL Padam Rekod Salah belum dipasang di Supabase.';
   return t;
 }
 let busy=false;
 function ask(record){
   return new Promise(resolve=>{
     const existing=$('rtDeleteDuplicateDlg'); if(existing)existing.remove();
     const pane=document.createElement('div');pane.id='rtDeleteDuplicateDlg';
     pane.className='fixed inset-0 flex items-center justify-center p-4';
     pane.style.cssText='z-index:12000;background:rgba(15,23,42,.75);backdrop-filter:blur(3px)';
     pane.innerHTML=`<form class="bg-white rounded-2xl shadow-2xl w-full max-w-md p-5" style="max-height:85dvh;overflow-y:auto">
       <h3 class="text-lg font-black text-slate-900 mb-2">PADAM REKOD SALAH KEY-IN</h3>
       <p class="text-sm text-slate-700 mb-3">${esc(record.name)}<br><b>SKU: ${esc(record.sku)}</b></p>
       <p class="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-lg p-3 mb-3">Hanya rekod yang belum pernah digunakan dan stoknya 0 boleh dipadam kekal. Barang yang mempunyai sejarah jualan atau stok perlu diarkib.</p>
       <label class="block text-xs font-bold text-slate-700">Taip semula SKU untuk sahkan</label>
       <input id="rtDeleteDuplicateSku" required autocomplete="off" spellcheck="false" class="w-full rounded-lg border border-slate-300 p-3 mb-3 text-sm" placeholder="${esc(record.sku)}" />
       <label class="block text-xs font-bold text-slate-700">Sebab pembetulan</label>
       <input id="rtDeleteDuplicateReason" required minlength="8" value="Rekod barang berganda" class="w-full rounded-lg border border-slate-300 p-3 mb-4 text-sm" />
       <div class="flex gap-2 justify-end"><button type="button" id="rtDeleteDuplicateCancel" class="rounded-lg px-4 py-2 border text-slate-700">BATAL</button>
       <button type="submit" class="rounded-lg px-4 py-2 text-white bg-rose-600 font-bold">PADAM JIKA SELAMAT</button></div>
     </form>`;
     const close=x=>{pane.remove();resolve(x);};
     pane.addEventListener('click',ev=>{if(ev.target===pane)close(null);});
     pane.querySelector('#rtDeleteDuplicateCancel').addEventListener('click',()=>close(null));
     pane.querySelector('form').addEventListener('submit',ev=>{
       ev.preventDefault();
       const sku=pane.querySelector('#rtDeleteDuplicateSku').value.trim();
       const reason=pane.querySelector('#rtDeleteDuplicateReason').value.trim();
       if(sku!==record.sku){toast('SKU pengesahan tidak sama.','error');return;}
       if(reason.length<8){toast('Sebab mesti sekurang-kurangnya 8 aksara.','error');return;}
       close({sku,reason});
     });
     document.body.appendChild(pane);
     pane.querySelector('#rtDeleteDuplicateSku').focus();
   });
 }
 async function removeDuplicate(id){
   if(busy)return;
   if(!admin()){toast('Hanya Admin / Owner boleh padam rekod.','error');return;}
   const item=fromCache(id);
   if(!item){toast('Rekod tidak dijumpai. Refresh inventori.','error');return;}
   if(Number(item.stock||0)!==0){
     const open=window.confirm('Stok '+item.sku+' masih '+item.stock+'. Tidak boleh padam item berstok. Buka pelarasan STOK untuk semak jumlah sebenar?');
     if(open)await Promise.resolve(window.openStockAdjustment?.(item.sku));
     return;
   }
   const confirmation=await ask(item);
   if(!confirmation)return;
   busy=true;
   try{
     if(!window.rtOverride?.ensure)throw new Error('Override belum tersedia.');
     const granted=await window.rtOverride.ensure({title:'Sahkan Padam Rekod Salah',message:'Admin perlu sahkan PIN dan sebab melalui Override.'});
     const sid=granted?.sessionId||window.rtOverride.status?.().sessionId;
     if(!sid)throw new Error('OVERRIDE_SESSION_REQUIRED');
     const res=await client().rpc('rt_admin_delete_unused_product',{
       p_product_id:item.id,p_confirm_sku:confirmation.sku,
       p_session_id:sid,p_reason:confirmation.reason
     });
     if(res.error)throw res.error;
     if(!res.data?.deleted)throw new Error('Pelayan tidak mengesahkan padam rekod.');
     toast('Rekod '+item.sku+' dipadam kekal. Audit disimpan.','success');
     await Promise.resolve(window.loadInventory?.({silent:true}));
     if(typeof window.loadPOS==='function')Promise.resolve(window.loadPOS()).catch(()=>{});
   }catch(e){
     if(e?.rtSilent)return;
     toast(friendly(e),'error');
     if(errText(e).includes('PRODUCT_HAS_HISTORY')){
       if(window.confirm('Item pernah digunakan. Buka Override untuk ARKIB (bukan padam kekal)?'))
         window.rtOpenCorrection?.('PRODUCT',item.sku);
     }
   }finally{busy=false;}
 }
 document.addEventListener('click',ev=>{
   const el=ev.target.closest?.('button[data-rt-permanent-delete-product]');
   if(!el)return;
   ev.preventDefault();
   removeDuplicate(el.getAttribute('data-rt-permanent-delete-product'));
 });
 // Stop a second inventory SKU from being created with exactly the same
 // normalized name and category (even if its SKU/barcode differs).
 const previousSave=window.saveInventory;
 if(typeof previousSave==='function'){
   let validating=false;
   window.saveInventory=async function(ev){
     ev?.preventDefault?.();
     if(validating)return;
     if($('invIsEdit')?.value==='true')return previousSave.call(this,ev);
     validating=true;
     try{
       const name=$('invName')?.value?.trim()||'';
       const cat=$('invCat')?.value||'';
       if(name){
         const profile=window.currentProfile||{};
         const cid=typeof window.companyId==='function'?await window.companyId():(profile.companyId||profile.company_id);
         if(!cid)throw new Error('Company tidak dijumpai untuk semakan nama berganda.');
         const query=await client().from('products').select('sku,name,category').eq('company_id',cid).eq('active',true).limit(1000);
         if(query.error)throw query.error;
         const dup=(query.data||[]).find(p=>norm(p.name)===norm(name)&&norm(p.category)===norm(cat));
         if(dup){
           toast('Barang "'+dup.name+'" sudah wujud (SKU '+dup.sku+'). Gunakan EDIT atau STOK, bukan daftar sekali lagi.','error');
           const search=$('searchInventory');if(search)search.value=dup.sku;
           return;
         }
       }
       return await previousSave.call(this,ev);
     }catch(e){toast('Semakan duplikat gagal: '+friendly(e),'error');}
     finally{validating=false;}
   };
 }
 window.rtDeleteUnusedInventoryItem=removeDuplicate;
})();
