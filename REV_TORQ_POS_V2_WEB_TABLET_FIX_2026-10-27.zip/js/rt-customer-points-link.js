/* REV TORQ POS — stable customer portal link for WhatsApp & PDF receipts.
 * Pure formatter: no stock, payment, loyalty or database mutation. */
(function(root){
  'use strict';
  var url='https://revtorq.com.my/?tab=profile';
  var section='🎁 *Semak Point & Voucher REV TORQ*\n'+url+'\nLog masuk / daftar akaun untuk lihat mata ganjaran anda.';
  function append(text){
    var original=String(text==null?'':text).trim();
    if(!original)return '';
    // Reprint and native/PDF paths can call this again. Never duplicate the URL.
    if(/https:\/\/revtorq\.com\.my\//i.test(original))return original;
    var marker='\nTerima kasih kerana berurusan dengan kami.';
    var i=original.lastIndexOf(marker);
    if(i>=0)return original.slice(0,i)+'\n\n'+section+'\n'+original.slice(i);
    return original+'\n\n'+section;
  }
  var api={url:url,section:section,append:append};
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.RTCustomerPointsLink=api;
})(typeof window!=='undefined'?window:(typeof globalThis!=='undefined'?globalThis:this));
