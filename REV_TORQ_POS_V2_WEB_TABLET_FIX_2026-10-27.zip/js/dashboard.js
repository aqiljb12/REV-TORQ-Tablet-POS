// ================= DASHBOARD V2.1 (2026-10-21) =================
// REV TORQ canonical dashboard — real production data only.
//  - Stok rendah uses the Inventori > PESAN STOK rule (active items, stock at this
//    location <= minimum, no minimum set = 5) and reads every product in 1000-row
//    pages, so both screens show the same number.
//  - Booking hari ini compares the DATE column with today's Malaysia date.
//  - Background refresh (every 30 s) re-reads sales, jobs, bookings and the cash
//    drawer only; stock, customers and reminders at most every 3 minutes. Opening
//    the page or pressing Refresh reads everything again.
//  - Motion: one-time intro + count-up, a short flash when a number changes,
//    nothing replays on refresh, and all of it is off under Reduce Motion.
(function(){
'use strict';
const $=id=>document.getElementById(id);
const sb=()=>window.sb||window.supabaseClient;
const esc=v=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const money=v=>'RM '+Number(v||0).toLocaleString('ms-MY',{minimumFractionDigits:2,maximumFractionDigits:2});
const int=v=>Math.round(Number(v||0)).toLocaleString('ms-MY');
const short=v=>{v=Number(v||0);if(v>=1e6)return (v/1e6).toFixed(1).replace(/\.0$/,'')+'j';if(v>=1000)return (v/1000).toFixed(1).replace(/\.0$/,'')+'k';return v.toFixed(0)};
const set=(id,v)=>{const e=$(id);if(e&&e.textContent!==String(v))e.textContent=v};
const html=(id,v)=>{const e=$(id);if(e&&e.__rtd!==v){e.__rtd=v;e.innerHTML=v}};
const toDate=v=>{
  if(!v)return null;if(typeof v.toDate==='function')return v.toDate();if(v.seconds)return new Date(v.seconds*1000);
  if(typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v)){const p=v.split('-').map(Number);return new Date(p[0],p[1]-1,p[2])}
  const d=new Date(v);return Number.isNaN(d.getTime())?null:d;
};
const errText=e=>[e?.code,e?.message,e?.details,e?.hint].filter(Boolean).join(' | ')||String(e||'Unknown error');
const isJwtFuture=e=>String(e?.code||'').toUpperCase()==='PGRST303'||/jwt issued at future/i.test(String(e?.message||''));
const dayKey=d=>`${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
const todayMY=()=>{try{return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kuala_Lumpur',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())}catch(_){return new Date().toLocaleDateString('en-CA')}};
const timeNow=()=>new Date().toLocaleTimeString('ms-MY',{hour:'2-digit',minute:'2-digit'});
const reduced=()=>{try{return !!(window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches)}catch(_){return false}};
const METHOD={CASH:'Tunai',QR:'QR',DUITNOW:'DuitNow',CARD:'Kad',DEBIT:'Kad',CREDIT:'Kad',TRANSFER:'Transfer',BANK_TRANSFER:'Transfer',EWALLET:'e-Wallet'};
const methodLabel=m=>METHOD[String(m||'').toUpperCase()]||String(m||'');
const ACTIVE_JOB=['OPEN','IN_PROGRESS','WAITING_PARTS'];
const PAGE=1000,SLOW_MS=180000;

// ---------------------------------------------------------------- data
async function refreshSessionOnce(){try{const c=sb();if(!c?.auth)return false;const r=await c.auth.refreshSession();return !r.error&&!!r.data?.session}catch(_){return false}}
// Reads every row, 1000 at a time (the API stops at 1000 rows per request). Same as the Inventori page.
async function fetchAll(build){const out=[];for(let from=0;;from+=PAGE){const r=await build().range(from,from+PAGE-1);if(r.error)throw r.error;const rows=r.data||[];for(const x of rows)out.push(x);if(rows.length<PAGE)break}return out}
// Company/location are verified again on every full load (open page / Refresh); background refreshes reuse them.
let ctxCache=null;
async function ctx(fresh){
  const p=window.currentProfile||{},key=String(p.companyId||p.company_id||'');
  if(!fresh&&ctxCache&&ctxCache.key===key)return ctxCache.value;
  let companyId=p.companyId||p.company_id||null,locationId=null;
  try{if(typeof window.companyId==='function')companyId=companyId||await window.companyId()}catch(_){}
  try{if(typeof window.locationId==='function')locationId=await window.locationId()}catch(_){}
  if(!companyId)throw new Error('Company tidak dijumpai untuk sesi ini.');
  if(!locationId){const r=await sb().from('locations').select('id').eq('company_id',companyId).eq('active',true).order('code',{ascending:true}).limit(1).maybeSingle();if(!r.error)locationId=r.data?.id||null}
  const value={companyId,locationId};ctxCache={key,value};return value;
}
function localRange(offset=0){const n=new Date(),s=new Date(n.getFullYear(),n.getMonth(),n.getDate()+offset),e=new Date(n.getFullYear(),n.getMonth(),n.getDate()+offset+1);return [s.toISOString(),e.toISOString()]}
function weekRange(){const n=new Date(),s=new Date(n.getFullYear(),n.getMonth(),n.getDate()-6),e=new Date(n.getFullYear(),n.getMonth(),n.getDate()+1);return [s.toISOString(),e.toISOString()]}
async function countHead(table,companyId,mut){let q=sb().from(table).select('id',{count:'exact',head:true}).eq('company_id',companyId);if(mut)q=mut(q);const r=await q;if(r.error)throw r.error;return Number(r.count||0)}
async function jobCounts(companyId){
  const rows=await fetchAll(()=>sb().from('job_cards').select('id,status').eq('company_id',companyId).in('status',ACTIVE_JOB).order('id',{ascending:true}));
  const by={OPEN:0,IN_PROGRESS:0,WAITING_PARTS:0};rows.forEach(r=>{const s=String(r.status||'').toUpperCase();if(s in by)by[s]++});
  return {total:rows.length,by};
}
// Paid invoices of the last 7 days; today's list is taken from the same rows (one request instead of two).
async function weekInvoices(companyId,start,end){
  return fetchAll(()=>sb().from('invoices').select('id,invoice_no,total,status,payment_status,created_at').eq('company_id',companyId).neq('status','VOID').eq('payment_status','PAID').gte('created_at',start).lt('created_at',end).order('created_at',{ascending:false}).order('id',{ascending:true}));
}
async function methods(invoiceIds,companyId){const m=new Map();if(!invoiceIds.length)return m;const r=await sb().from('payments').select('invoice_id,payment_method,created_at').eq('company_id',companyId).in('invoice_id',invoiceIds).order('created_at',{ascending:true});if(r.error)throw r.error;(r.data||[]).forEach(p=>{const a=m.get(p.invoice_id)||[];if(p.payment_method&&!a.includes(p.payment_method))a.push(p.payment_method);m.set(p.invoice_id,a)});return m}
// Same rule as Inventori > PESAN STOK (js/rt-inventory-plus.js): active items whose stock at this location <= minimum; no minimum set = 5.
async function stockNeeds(companyId,locP){
  const [products,balances]=await Promise.all([
    fetchAll(()=>sb().from('products').select('id,sku,name,min_stock,active').eq('company_id',companyId).order('sku',{ascending:true})),
    Promise.resolve(locP).then(loc=>loc?fetchAll(()=>sb().from('stock_balances').select('product_id,quantity').eq('location_id',loc).order('product_id',{ascending:true})):[])
  ]);
  const qty=new Map();balances.forEach(b=>qty.set(b.product_id,Number(b.quantity||0)));
  return products.filter(p=>p.active!==false).map(p=>{const stock=Number(qty.get(p.id)||0),m=Number(p.min_stock);return {id:p.id,sku:p.sku,name:p.name,stock,min:p.min_stock==null?5:(Number.isFinite(m)?m:0)}})
    .filter(p=>p.stock<=p.min)
    .sort((a,b)=>((a.stock<=0)===(b.stock<=0)?0:a.stock<=0?-1:1)||a.stock-b.stock||String(a.name||'').localeCompare(String(b.name||'')));
}
async function reminders(companyId){
  const r=await sb().from('service_reminders').select('id,customer_id,vehicle_id,due_date,due_mileage,reminder_type,status').eq('company_id',companyId).neq('status','DONE').order('due_date',{ascending:true}).limit(5);if(r.error)throw r.error;
  const rows=r.data||[],cids=[...new Set(rows.map(x=>x.customer_id).filter(Boolean))],vids=[...new Set(rows.map(x=>x.vehicle_id).filter(Boolean))],cm=new Map(),vm=new Map();
  const [c,v]=await Promise.all([
    cids.length?sb().from('customers').select('id,name,phone').in('id',cids):Promise.resolve({data:[]}),
    vids.length?sb().from('vehicles').select('id,plate_no,brand,model').in('id',vids):Promise.resolve({data:[]})
  ]);
  if(c.error)throw c.error;if(v.error)throw v.error;
  (c.data||[]).forEach(x=>cm.set(x.id,x));(v.data||[]).forEach(x=>vm.set(x.id,x));
  return rows.map(x=>({...x,customer:cm.get(x.customer_id)||{},vehicle:vm.get(x.vehicle_id)||{}}));
}
// preferred_date is a DATE column: compare with today's date in Malaysia (same as the Booking page).
async function todayBookings(companyId){
  const r=await sb().from('bookings').select('id,status,preferred_date,preferred_time').eq('company_id',companyId).eq('preferred_date',todayMY()).limit(500);
  if(r.error){console.warn('Dashboard bookings:',r.error);return null}
  return (r.data||[]).filter(x=>!['CANCELLED','CANCELED','REJECTED'].includes(String(x.status||'').toUpperCase()));
}
async function drawer(companyId,locationId){let q=sb().from('cash_drawers').select('id,status,drawer_code,opening_float,opened_at,updated_at').eq('company_id',companyId).eq('status','OPEN').order('opened_at',{ascending:false}).limit(1);if(locationId)q=q.eq('location_id',locationId);const r=await q;if(r.error){console.warn('Dashboard cash drawer:',r.error);return undefined}return r.data?.[0]||null}

// ---------------------------------------------------------------- motion
const last=new Map();          // last text written per KPI, to spot changes
let painted=false;             // first successful render done (intro + count-up only once)
let countToken=0;
function flash(card){if(!card||reduced())return;card.classList.remove('rtd-flash');void card.offsetWidth;card.classList.add('rtd-flash');clearTimeout(card.__rtdFlash);card.__rtdFlash=setTimeout(()=>card.classList.remove('rtd-flash'),1400)}
function countUp(items){
  const token=++countToken,t0=performance.now(),dur=750,ease=t=>1-Math.pow(1-t,3);
  items.forEach(it=>{it.el.textContent=it.fmt(0)});
  const step=now=>{
    if(token!==countToken)return;
    const p=Math.min(1,Math.max(0,(now-t0)/dur)),k=ease(p);
    items.forEach(it=>{it.el.textContent=p<1?it.fmt(it.to*k):it.text});
    if(p<1)requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}
function kpi(id,value,fmt,intro,queue){
  const el=$(id);if(!el)return;
  const text=fmt(value),prev=last.get(id);last.set(id,text);
  if(intro){queue.push({el,to:Number(value)||0,fmt,text});return}
  if(el.textContent!==text)el.textContent=text;
  if(prev!==undefined&&prev!==text)flash(el.closest('.rtd-kpi'));
}
function list(id,markup,intro){
  const el=$(id);if(!el||el.__rtd===markup)return;
  if(intro){el.classList.add('is-intro');setTimeout(()=>el.classList.remove('is-intro'),1200)}
  el.__rtd=markup;el.innerHTML=markup;
}

// ---------------------------------------------------------------- render
function greeting(){
  const n=new Date(),h=n.getHours();
  const part=h<12?'Selamat pagi':h<15?'Selamat tengah hari':h<19?'Selamat petang':'Selamat malam';
  const name=String(window.currentProfile?.name||'').trim().split(/\s+/)[0]||'';
  set('dashGreeting',name?`${part}, ${name}`:part);
  set('dashToday',n.toLocaleDateString('ms-MY',{weekday:'long',day:'numeric',month:'long',year:'numeric'}));
}
function renderSalesKpi(todayInv,weekInv,intro,queue){
  const sales=todayInv.reduce((a,x)=>a+Number(x.total||0),0);
  kpi('dashTodaySales',sales,money,intro,queue);
  set('dashTodayTransactions',int(todayInv.length));
  set('dashAvgTicket',todayInv.length?money(sales/todayInv.length):'—');
  // Compare with yesterday up to the same time of day, so the morning never looks like a loss.
  const n=new Date(),ys=new Date(n.getFullYear(),n.getMonth(),n.getDate()-1),cut=new Date(n.getTime()-864e5);
  const ySales=weekInv.reduce((a,x)=>{const d=toDate(x.created_at);return d&&d>=ys&&d<=cut?a+Number(x.total||0):a},0);
  const el=$('dashSalesDelta');if(!el)return;
  let text,cls='';
  if(!ySales&&!sales)text='Belum ada jualan semalam & hari ini';
  else if(!ySales){text=`Semalam ${money(0)} pada waktu ini`;cls='is-up'}
  else{const pct=Math.round(((sales-ySales)/ySales)*100);
    if(pct===0)text='Sama seperti semalam (waktu sama)';
    else{cls=pct>0?'is-up':'is-down';text=`${pct>0?'▲':'▼'} ${Math.abs(pct)}% berbanding semalam`}}
  if(el.textContent!==text)el.textContent=text;
  el.classList.toggle('is-up',cls==='is-up');el.classList.toggle('is-down',cls==='is-down');
  el.title=ySales?`Semalam sehingga waktu ini: ${money(ySales)}`:'';
}
function renderJobs(j,intro,queue){
  kpi('dashActiveJobs',j.total,int,intro,queue);
  const p=[];if(j.by.IN_PROGRESS)p.push(`<b>${j.by.IN_PROGRESS}</b> sedang dibaiki`);if(j.by.OPEN)p.push(`<b>${j.by.OPEN}</b> baru`);if(j.by.WAITING_PARTS)p.push(`<b>${j.by.WAITING_PARTS}</b> tunggu barang`);
  html('dashJobsBreakdown',j.total?p.join(' · '):'Tiada kerja berjalan');
}
function renderBookings(rows,intro,queue){
  if(!rows){set('dashBookingToday','—');last.delete('dashBookingToday');html('dashBookingBreakdown','Tidak dapat dimuatkan');return}
  kpi('dashBookingToday',rows.length,int,intro,queue);
  const up=s=>String(s||'').toUpperCase(),conf=rows.filter(x=>up(x.status)==='CONFIRMED').length,fresh=rows.filter(x=>up(x.status)==='NEW').length;
  const p=[];if(conf)p.push(`<b>${conf}</b> disahkan`);if(fresh)p.push(`<b>${fresh}</b> perlu disahkan`);
  html('dashBookingBreakdown',rows.length?(p.join(' · ')||'Lihat senarai booking'):'Tiada booking hari ini');
}
function renderStock(rows,intro,queue){
  kpi('dashLowStock',rows.length,int,intro,queue);
  const out=rows.filter(x=>x.stock<=0).length;
  const card=$('dashLowStock')?.closest('.rtd-kpi');if(card)card.classList.toggle('is-alert',out>0);
  html('dashStockBreakdown',!rows.length?'Semua stok mencukupi':out?`<span class="is-bad">${int(out)} habis stok</span>`:'Perlu ditambah');
  if(!rows.length){list('dashLowStockList','<div class="rtd-empty"><i class="fas fa-circle-check"></i>Semua stok di atas paras minimum.</div>',intro);return}
  const top=rows.slice(0,5);
  list('dashLowStockList',top.map(x=>`<div class="rtd-item"><div class="rtd-item-main"><b>${esc(x.name||x.sku||'-')}</b><span>${esc(x.sku||'')}${x.sku?' · ':''}Min ${int(x.min)}</span></div><div class="rtd-item-end">${x.stock<=0?'<span class="rtd-badge is-bad">Habis</span>':`<span class="rtd-qty">${int(x.stock)} <small>baki</small></span>`}</div></div>`).join('')
    +(rows.length>top.length?`<button type="button" class="rtd-more" onclick="switchView('inventory')">+${int(rows.length-top.length)} lagi item</button>`:''),intro);
}
let saleIds=null;
function renderSales(rows,pay,intro){
  if(!rows.length){saleIds=new Set();list('dashRecentSales','<div class="rtd-empty"><i class="fas fa-receipt"></i>Belum ada jualan berbayar hari ini.</div>',intro);return}
  const shown=rows.slice(0,6),known=saleIds;saleIds=new Set(rows.map(x=>x.id));
  const isNew=x=>!intro&&known&&!known.has(x.id)&&!reduced();
  list('dashRecentSales',shown.map(x=>{const d=toDate(x.created_at),ms=(pay.get(x.id)||[]).map(m=>`<span class="rtd-chip">${esc(methodLabel(m))}</span>`).join('');
    return `<div class="rtd-item${isNew(x)?' is-new':''}"><div class="rtd-item-main"><b>${esc(x.invoice_no||x.id)}</b><span>${ms}${d?d.toLocaleTimeString('ms-MY',{hour:'2-digit',minute:'2-digit'}):'—'}</span></div><div class="rtd-item-end"><span class="rtd-amount">${money(x.total)}</span></div></div>`}).join('')
    +(rows.length>6?`<button type="button" class="rtd-more" onclick="switchView('sales')">+${int(rows.length-6)} lagi transaksi hari ini</button>`:''),intro);
}
function dueBadge(due){
  if(!due)return '<span class="rtd-badge">—</span>';
  const n=new Date(),t=new Date(n.getFullYear(),n.getMonth(),n.getDate()),d=new Date(due.getFullYear(),due.getMonth(),due.getDate());
  const days=Math.round((d-t)/864e5);
  if(days<0)return `<span class="rtd-badge is-bad">Lewat ${-days} hari</span>`;
  if(days===0)return '<span class="rtd-badge is-warn">Hari ini</span>';
  if(days<=3)return `<span class="rtd-badge is-warn">${days} hari lagi</span>`;
  return `<span class="rtd-badge">${d.toLocaleDateString('ms-MY',{day:'numeric',month:'short'})}</span>`;
}
function renderReminders(rows,intro){
  if(!rows.length){list('dashReminders','<div class="rtd-empty"><i class="fas fa-bell-slash"></i>Tiada peringatan aktif.</div>',intro);return}
  list('dashReminders',rows.map(x=>{const v=x.vehicle||{},model=[v.brand,v.model].filter(Boolean).join(' ');
    return `<div class="rtd-item"><div class="rtd-item-main"><b>${esc(v.plate_no||'-')}${model?` <small class="rtd-model">· ${esc(model)}</small>`:''}</b><span>${esc(x.customer?.name||'Pelanggan')} · ${esc(x.reminder_type||'Servis')}</span></div><div class="rtd-item-end">${dueBadge(toDate(x.due_date))}</div></div>`}).join(''),intro);
}
function renderChart(rows,intro){
  const n=new Date(),days=[];
  for(let i=6;i>=0;i--){const d=new Date(n.getFullYear(),n.getMonth(),n.getDate()-i);days.push({key:dayKey(d),wd:d.toLocaleDateString('ms-MY',{weekday:'short'}),dd:d.getDate(),total:0,today:i===0})}
  const idx=new Map(days.map((x,i)=>[x.key,i]));
  rows.forEach(inv=>{const d=toDate(inv.created_at);if(!d)return;const i=idx.get(dayKey(d));if(i!==undefined)days[i].total+=Number(inv.total||0)});
  const week=days.reduce((a,x)=>a+x.total,0);
  set('dashWeekTotal',money(week));set('dashWeekAvg',money(week/7));set('dashSalesPeriod','7 Hari');
  html('dashSalesLabels',days.map(x=>`<span class="${x.today?'is-today':''}"><b>${x.today?'Hari ini':esc(x.wd)}</b>${x.dd}</span>`).join(''));
  const bars=$('dashSalesBars');if(!bars)return;
  const max=Math.max(...days.map(x=>x.total),1);
  const markup=!week?'<div class="rtd-chart-empty">Belum ada jualan berbayar dalam 7 hari.</div>':days.map((x,i)=>{const h=x.total?Math.max(4,(x.total/max)*86):0;
    return `<div class="rtd-bar${x.today?' is-today':''}${x.total?'':' is-zero'}" style="--d:${i*45}ms" title="${esc(x.wd)} ${x.dd}: ${money(x.total)}"><span>${x.total?short(x.total):''}</span><i style="height:${h.toFixed(1)}%"></i></div>`}).join('');
  if(bars.__rtd===markup)return;
  if(intro){bars.classList.add('is-intro');setTimeout(()=>bars.classList.remove('is-intro'),1500)}
  bars.__rtd=markup;bars.innerHTML=markup;
}
function pill(id,state){const p=$(id);if(!p)return;['is-ok','is-warn','is-bad'].forEach(c=>p.classList.toggle(c,c===state))}
function renderStatus(openDrawer){
  if(openDrawer===undefined){set('dashDrawerStatus','—');pill('dashDrawerPill',null)}
  else{set('dashDrawerStatus',openDrawer?'DIBUKA':'DITUTUP');pill('dashDrawerPill',openDrawer?'is-ok':'is-warn')}
  set('dashDbStatus','CONNECTED');pill('dashLivePill','is-ok');
  set('dashLastUpdated','Dikemas kini '+timeNow());
}
function showError(e){
  set('dashDbStatus','ERROR');pill('dashLivePill','is-bad');
  if(painted){set('dashLastUpdated','Gagal dikemas kini · '+timeNow());return}   // keep the last good data on screen
  const view=$('view-dashboard');if(view)view.classList.remove('is-skeleton');
  set('dashLastUpdated','Gagal dimuatkan');
  const none='<div class="rtd-empty">Tidak dapat dimuatkan.</div>';
  list('dashRecentSales',`<div class="rtd-error"><b>Data dashboard tidak dapat dimuatkan.</b><br>${esc(errText(e))}</div>`,false);
  list('dashReminders',none,false);list('dashLowStockList',none,false);
  html('dashSalesBars','<div class="rtd-chart-empty">Tidak dapat dimuatkan.</div>');html('dashSalesLabels','');
}

// ---------------------------------------------------------------- load
let slow=null,slowAt=0;
const pay=new Map();   // invoice id -> payment methods (kept only once found; a paid invoice's payments do not change)
async function loadInner(full){
  if(!sb())throw new Error('Supabase belum sedia.');
  // Company/location are resolved (full loads: re-verified) alongside the data requests instead of
  // before them. As before, a failed location lookup falls back to the first active location.
  const prof=window.currentProfile||{},ctxP=ctx(full);
  const companyId=prof.companyId||prof.company_id||(await ctxP).companyId;
  const locP=ctxP.then(c=>c.locationId);
  const [ws,we]=weekRange(),todayStart=new Date(localRange()[0]).getTime();
  const needSlow=full||!slow||Date.now()-slowAt>SLOW_MS;
  const slowP=needSlow
    ?Promise.all([countHead('customers',companyId,q=>q.eq('active',true)),stockNeeds(companyId,locP),reminders(companyId)]).then(([customers,stock,rem])=>({customers,stock,rem}))
    :Promise.resolve(slow);
  // Payment methods are looked up as soon as the invoices arrive (not after everything else).
  const salesP=weekInvoices(companyId,ws,we).then(async weekInv=>{
    const todayInv=weekInv.filter(x=>{const d=toDate(x.created_at);return d&&d.getTime()>=todayStart});
    const missing=todayInv.slice(0,6).map(x=>x.id).filter(id=>!pay.has(id));
    if(missing.length){const m=await methods(missing,companyId);if(pay.size>500)pay.clear();missing.forEach(id=>{const a=m.get(id);if(a&&a.length)pay.set(id,a)})}
    return {weekInv,todayInv};
  });
  const [c,s,jobs,sales,bookings,openDrawer]=await Promise.all([ctxP,slowP,jobCounts(companyId),salesP,todayBookings(companyId),locP.then(loc=>drawer(companyId,loc))]);
  if(c.companyId!==companyId){ctxCache=null;throw new Error('Sesi telah berubah. Sila muat semula halaman.')}
  if(needSlow){slow=s;slowAt=Date.now()}
  const {weekInv,todayInv}=sales;

  const view=$('view-dashboard'),intro=!painted&&!reduced(),queue=[];
  if(!intro)countToken++;            // stop a count-up still running from the first paint
  if(view)view.classList.remove('is-skeleton');
  set('dashTotalCustomers',int(s.customers));
  renderSalesKpi(todayInv,weekInv,intro,queue);renderJobs(jobs,intro,queue);renderBookings(bookings,intro,queue);renderStock(s.stock,intro,queue);
  renderSales(todayInv,pay,intro);renderReminders(s.rem,intro);renderChart(weekInv,intro);renderStatus(openDrawer);
  if(queue.length)countUp(queue);
  painted=true;
}
let inflight=null,inflightFull=false,again=false,introArmed=false;
// loadDashboard()                     full read (open page, Refresh, login)
// loadDashboard({background:true})    30-second refresh: stock/customers/reminders reused for up to 3 minutes
window.loadDashboard=function(opts){
  const background=!!(opts&&typeof opts==='object'&&opts.background===true);
  if(inflight){if(!background&&!inflightFull)again=true;return inflight}
  inflightFull=!background;
  const view=$('view-dashboard');
  greeting();
  if(view){
    view.classList.add('is-loading');
    // The intro plays while the page is first on screen; drop it afterwards so taps and later refreshes stay instant.
    if(!introArmed&&view.offsetParent!==null){introArmed=true;setTimeout(()=>view.classList.remove('is-intro'),900)}
  }
  inflight=(async()=>{
    try{await loadInner(!background)}
    catch(e){
      let err=e;
      if(isJwtFuture(e)&&await refreshSessionOnce()){try{await loadInner(true);err=null}catch(e2){err=e2}}
      if(err){console.error('Dashboard error:',err);showError(err)}
    }finally{
      if(view)view.classList.remove('is-loading');
      inflight=null;inflightFull=false;
      if(again){again=false;setTimeout(()=>window.loadDashboard(),0)}
    }
  })();
  return inflight;
};
// Safari on iPad shows :active (press feedback) only when a touch listener exists.
(function(){const v=$('view-dashboard');if(v)v.addEventListener('touchstart',()=>{},{passive:true})})();
// Background refresh only while the Dashboard is on screen; POS/other views stay quiet.
const dashVisible=()=>document.visibilityState==='visible'&&window.__rtActiveView==='dashboard';
let started=false,interval=null;window.startDashboardRealtime=function(){if(started)return;started=true;const bg=()=>{if(dashVisible())window.loadDashboard({background:true})};interval=setInterval(bg,30000);window.addEventListener('focus',bg);document.addEventListener('visibilitychange',bg)};
window.RT_DASH_DEBOUNCE=window.RT_DASH_DEBOUNCE||{timer:null};window.rtDebouncedDashboard=function(fn,ms){clearTimeout(window.RT_DASH_DEBOUNCE.timer);window.RT_DASH_DEBOUNCE.timer=setTimeout(()=>{try{fn()}catch(e){console.warn('Dashboard refresh:',e)}},ms||350)};
})();
