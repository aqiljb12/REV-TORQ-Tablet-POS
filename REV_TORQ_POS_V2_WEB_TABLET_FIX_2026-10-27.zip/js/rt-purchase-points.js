/* REV TORQ Purchase Points v1: Admin settings, server-authorized RPC, no checkout mutations. */
(function(){
  'use strict';
  const categories={'MINYAK':'Minyak Hitam','TAYAR':'Tayar','SPAREPART':'Spare Part','AKSESORI':'Aksesori','BARANG LUAR':'Barang Luar','SERVIS':'Servis'};
  const $=id=>document.getElementById(id);
  const client=()=>window.supabaseClient;
  function isAdmin(){return ['owner','super_admin','admin'].includes(String(window.currentProfile?.role||'').toLowerCase());}
  function modal(){
    let root=$('rtPurchasePointsModal');if(root)return root;
    root=document.createElement('div');root.id='rtPurchasePointsModal';root.hidden=true;
    Object.assign(root.style,{position:'fixed',inset:'0',background:'rgba(15,23,42,.64)',zIndex:'99999',padding:'12px',display:'none',alignItems:'center',justifyContent:'center'});
    const panel=document.createElement('section');Object.assign(panel.style,{maxWidth:'570px',width:'100%',maxHeight:'90vh',overflowY:'auto',background:'#fff',borderRadius:'18px',boxShadow:'0 18px 60px #0005',padding:'20px',color:'#0f172a'});
    const head=document.createElement('div');Object.assign(head.style,{display:'flex',justifyContent:'space-between',gap:'10px',alignItems:'center'});
    const title=document.createElement('strong');title.textContent='Tetapan Point Pembelian';title.style.fontSize='19px';
    const close=document.createElement('button');close.type='button';close.textContent='✕';close.title='Tutup';close.style.cssText='padding:6px 10px;color:#334155;background:#f1f5f9;border-radius:8px;';close.onclick=()=>window.rtClosePurchasePoints();
    head.append(title,close);
    const hint=document.createElement('p');hint.style.cssText='font-size:12px;line-height:1.6;color:#475569;margin:12px 0';hint.textContent='Tetapkan berapa RM belian bersamaan 1 point. Hanya invois barang PAID dengan pelanggan dipilih akan dapat point. Kategori OFF tidak mendapat point. Tidak mengubah point servis.';
    const rules=document.createElement('div');rules.id='rtPurchasePointsRules';
    const state=document.createElement('div');state.id='rtPurchasePointsState';state.setAttribute('role','status');state.style.cssText='font-size:12px;margin:12px 0;color:#334155';
    const save=document.createElement('button');save.type='button';save.id='rtPurchasePointsSave';save.textContent='SIMPAN SEMUA TETAPAN';save.style.cssText='width:100%;background:#1d4ed8;color:#fff;padding:13px;border-radius:12px;font-weight:800';save.onclick=saveRules;
    panel.append(head,hint,rules,state,save);root.append(panel);root.addEventListener('click',e=>{if(e.target===root)window.rtClosePurchasePoints()});document.body.append(root);
    return root;
  }
  function makeRow(o){
    const row=document.createElement('div');row.className='rt-point-rule';row.dataset.category=o.category;
    row.style.cssText='display:grid;grid-template-columns:1fr auto;gap:9px;align-items:center;padding:12px 0;border-bottom:1px solid #e2e8f0';
    const left=document.createElement('div');
    const name=document.createElement('strong');name.textContent=categories[o.category]||o.category;name.style.cssText='display:block;font-size:13px';
    const cap=document.createElement('small');cap.textContent='RM belian untuk 1 point';cap.style.cssText='display:block;color:#64748b;font-size:11px;margin-top:3px';left.append(name,cap);
    const right=document.createElement('div');right.style.cssText='display:flex;align-items:center;gap:8px';
    const input=document.createElement('input');input.type='number';input.min='.01';input.max='1000';input.step='.01';input.inputMode='decimal';input.value=Number(o.rm_per_point||1).toFixed(2);input.className='rt-point-rate';input.style.cssText='width:94px;border:1px solid #cbd5e1;color:#0f172a;padding:9px;border-radius:8px;text-align:right';
    const check=document.createElement('input');check.type='checkbox';check.checked=!!o.enabled;check.className='rt-point-enabled';check.setAttribute('aria-label','Aktifkan '+(categories[o.category]||o.category));check.style.cssText='width:20px;height:20px;accent-color:#2563eb';
    if(o.category==='SERVIS'||o.category==='DYNO'){check.checked=false;check.disabled=true;input.disabled=true;}
    const label=document.createElement('small');label.textContent='ON';label.style.cssText='font-weight:700;font-size:10px;color:#64748b';right.append(input,check,label);row.append(left,right);
    return row;
  }
  function displayMessage(t,ok=false){const state=$('rtPurchasePointsState');if(state){state.textContent=t;state.style.color=ok?'#047857':'#b91c1c';}}
  async function open(){
    if(!isAdmin())return;
    const m=modal();m.hidden=false;m.style.display='flex';$('rtPurchasePointsRules').textContent='Memuatkan kadar point...';
    try{
      const sb=client();if(!sb)throw Error('Supabase tidak bersambung');
      const res=await sb.rpc('rt_pos_get_purchase_loyalty_rules');if(res.error)throw res.error;
      const list=Array.isArray(res.data)?res.data:[];
      const body=$('rtPurchasePointsRules');body.replaceChildren(...list.map(makeRow));
      displayMessage('Tetapan diambil dari Supabase. Semua perubahan bermula pada jualan seterusnya.',true);
    }catch(e){$('rtPurchasePointsRules').textContent='Gagal memuatkan tetapan.';displayMessage(String(e.message||e).includes('PGRST202')?'Pasang SQL RT_POS_PURCHASE_POINTS dahulu.':String(e.message||e));}
  }
  async function saveRules(){
    if(!isAdmin()){displayMessage('Hanya Admin boleh mengubah kadar point.');return;}
    const save=$('rtPurchasePointsSave');if(save.disabled)return;
    const rows=Array.from(document.querySelectorAll('#rtPurchasePointsRules .rt-point-rule'));
    if(!rows.length){displayMessage('Tiada peraturan untuk disimpan.');return;}
    const data=[];
    for(const r of rows){const rate=Number(r.querySelector('.rt-point-rate').value);if(!Number.isFinite(rate)||rate<.01||rate>1000){displayMessage('Kadar tidak sah untuk '+r.dataset.category+'.');return;}data.push({p_category:r.dataset.category,p_rm_per_point:rate,p_enabled:!!r.querySelector('.rt-point-enabled').checked});}
    save.disabled=true;save.textContent='MENYIMPAN...';let saved=0;
    try{
      for(const rule of data){const result=await client().rpc('rt_pos_save_purchase_loyalty_rule',rule);if(result.error)throw result.error;saved++;}
      displayMessage('Berjaya simpan '+saved+' kategori ke Supabase.',true);
    }catch(e){displayMessage('Hanya '+saved+' daripada '+data.length+' kategori disimpan. '+String(e.message||e));}
    finally{save.disabled=false;save.textContent='SIMPAN SEMUA TETAPAN';}
  }
  window.rtOpenPurchasePoints=open;
  window.rtClosePurchasePoints=function(){const m=$('rtPurchasePointsModal');if(m){m.hidden=true;m.style.display='none';}};
  function setup(){
    const bar=$('rtPosMemberPoints');if(!bar)return;
    let b=$('rtPurchaseSettingsButton');if(!b){b=document.createElement('button');b.id='rtPurchaseSettingsButton';b.type='button';b.textContent='⚙ SET POINT BELIAN';b.onclick=open;b.style.cssText='font-size:10px;font-weight:800;border-radius:8px;border:1px solid #93c5fd;background:#eff6ff;color:#1d4ed8;padding:6px 9px;margin-left:8px';bar.parentElement.append(b);}
    b.hidden=!isAdmin();b.style.display=isAdmin()?'inline-block':'none';
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setup);else setup();
  window.addEventListener('load',()=>{setup();setTimeout(setup,800);setTimeout(setup,2000);});
  setInterval(setup,4000);
})();
