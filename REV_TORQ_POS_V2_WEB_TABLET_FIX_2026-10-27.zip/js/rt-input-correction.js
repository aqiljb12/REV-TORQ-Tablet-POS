/* REV TORQ: safer corrections for mistaken key-ins, without deleting historical sales.
   2026-10-27 tablet fix: the bar used to sit bottom-right, which on an iPad is exactly where BAYAR (POS) and
   SIMPAN (Sebut Harga) are, so a tap on BAYAR pressed "PADAM 1" instead. Now:
   - it is not shown for the POS cash box (Diterima: it has its own RM buttons) or the POS search / scanner box;
   - it is placed where it covers neither the field being typed in nor a button (bottom-left of the page first,
     then the other corners, then next to the field), and moves again when the keyboard or the page moves. */
(function(){
 'use strict';
 let focused=null;
 const allowedTypes=new Set(['text','tel','number','search','email','url']);
 const SKIP='#posAmountReceived,#posSearch,[data-rt-no-correct]';
 const GAP=8;
 const toolbar=document.createElement('div');
 toolbar.id='rtCorrectionToolbar';
 toolbar.setAttribute('role','group');
 toolbar.setAttribute('aria-label','Pembetulan tulisan');
 toolbar.hidden=true;
 toolbar.innerHTML='<span class="rt-correct-title">BETULKAN INPUT</span><button type="button" data-rt-key="backspace" aria-label="Padam satu huruf">⌫ PADAM 1</button><button type="button" data-rt-key="clear" aria-label="Kosongkan medan">✕ KOSONGKAN</button><button type="button" data-rt-key="close" aria-label="Tutup">TUTUP</button>';
 function editable(el){
   if(!el || !el.matches || !el.matches('input,textarea')) return false;
   if(el.disabled || el.readOnly) return false;
   if(el.matches(SKIP)) return false;
   if(el.matches('textarea'))return true;
   return allowedTypes.has(String(el.type||'text').toLowerCase());
 }
 function withinApp(el){return !!el.closest('#appContainer,#modalOverlay,#view-inventory-form,#rtOverrideModal');}

 // ---- placement
 function screenBox(){
   // the part of the page that is really visible (the on-screen keyboard makes it shorter), in position:fixed coordinates
   const vv=window.visualViewport;
   const top=vv?vv.offsetTop:0,left=vv?vv.offsetLeft:0;
   const w=vv?vv.width:window.innerWidth,h=vv?vv.height:window.innerHeight;
   return {left:left,top:top,right:left+w,bottom:top+h};
 }
 function contentBox(b){
   // right of the sidebar and under the top bar, so the bar never sits on the menu or the header buttons
   let l=b.left,t=b.top;
   const main=document.querySelector('#appContainer main');
   if(main){const r=main.getBoundingClientRect();if(r.width&&r.left>l&&r.left<b.right-240)l=r.left;}
   const head=document.querySelector('#appContainer main>header');
   if(head){const r=head.getBoundingClientRect();if(r.height&&r.bottom>t&&r.bottom<b.bottom-160)t=r.bottom;}
   return {left:l,top:t,right:b.right,bottom:b.bottom};
 }
 function scopeOf(el){
   return el.closest('.modal-content,#rtCustPanel,.rt-confirm-box,[role="dialog"],.view-section')||document.body;
 }
 function overlap(a,b){
   const x=Math.max(0,Math.min(a.right,b.right)-Math.max(a.left,b.left));
   const y=Math.max(0,Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top));
   return x*y;
 }
 // Buttons the bar must never cover (pay / save); small buttons (+, -, BUANG, a price box) count more than a big
 // product card, of which a corner may be covered without hiding it.
 const KEY='#btnCheckout,#rtqSave,#rtqTemp,.rt-btn-primary,[data-act="yes"],[data-qact="save"],[data-qact="savetemp"],.rt-pay-method,[onclick*="posSetPaymentMethod"]';
 function targets(scope){
   const out=[];
   scope.querySelectorAll('button,a[href],input,select,textarea,[onclick],[role="button"]').forEach(function(e){
     if(toolbar.contains(e))return;
     const r=e.getBoundingClientRect();
     if(r.width<1||r.height<1)return;
     const area=r.width*r.height;
     out.push({r:r,area:area,w:e.matches(KEY)?40:(area<9000?4:1)});
   });
   return out;
 }
 function place(){
   if(toolbar.hidden||!focused||!focused.isConnected)return;
   const b=screenBox(),c=contentBox(b);
   toolbar.style.right='auto';toolbar.style.bottom='auto';
   const tw=toolbar.offsetWidth,th=toolbar.offsetHeight;
   const f=focused.getBoundingClientRect();
   const xL=c.left+GAP,xR=Math.max(xL,c.right-tw-GAP),xC=Math.max(xL,(c.left+c.right-tw)/2);
   const yB=c.bottom-th-GAP,yT=c.top+GAP;
   const xF=Math.min(Math.max(xL,f.left),xR);
   // first choice = bottom-left of the page, then the other corners and next to the field; then every free spot on a
   // grid, so a gap between buttons is found on a busy screen. Score = how much of a button / box would be covered
   // (the field being typed in rules a spot out), then the distance to the field as a small tie-break.
   const cands=[{x:xL,y:yB},{x:xR,y:yB},{x:xC,y:yB},{x:xL,y:yT},{x:xR,y:yT},{x:xC,y:yT},{x:xF,y:f.bottom+GAP},{x:xF,y:f.top-th-GAP}];
   for(let y=yT;y<=yB;y+=16)for(let x=xL;x<=xR;x+=24)cands.push({x:x,y:y});
   const rects=targets(scopeOf(focused));
   // a search box shows its results right under it (customers, products...): keep that strip free as well
   if(focused.matches('input[type="search"],[list],[aria-autocomplete],[id*="Search"],[id*="search"]')){
     const strip={left:f.left,right:f.right,top:f.bottom,bottom:f.bottom+260};
     rects.push({r:strip,area:Math.max(1,(strip.right-strip.left)*(strip.bottom-strip.top)),w:40});
   }
   const fx=(f.left+f.right)/2,fy=(f.top+f.bottom)/2;
   let best=null,bestScore=Infinity;
   cands.forEach(function(p,i){
     const r={left:p.x,top:p.y,right:p.x+tw,bottom:p.y+th};
     if(r.top<c.top-1||r.bottom>c.bottom+1||r.left<c.left-1||r.right>c.right+1)return;   // must be fully on screen
     let s=overlap(r,f)?100000:0;                                                     // never on the field itself
     for(let k=0;k<rects.length;k++){const o=overlap(r,rects[k].r);if(o){s+=o/rects[k].area*rects[k].w*100;if(s>=bestScore)return;}}
     s+=(i<8?0:0.5)+Math.hypot((r.left+r.right)/2-fx,(r.top+r.bottom)/2-fy)/100000;
     if(s<bestScore){bestScore=s;best=p;}
   });
   if(!best)best={x:xL,y:yB};
   toolbar.style.left=Math.round(best.x)+'px';
   toolbar.style.top=Math.round(best.y)+'px';
 }
 let queued=false;
 function placeSoon(){if(queued||toolbar.hidden)return;queued=true;requestAnimationFrame(function(){queued=false;place();});}

 function sendInput(el){try{el.dispatchEvent(new Event('input',{bubbles:true}));}catch(_){}}
 function changeValue(mode){
   const el=focused;if(!editable(el)||!el.isConnected)return;
   const v=String(el.value||'');
   let a=v.length,b=v.length;
   try{if(typeof el.selectionStart==='number')a=el.selectionStart;if(typeof el.selectionEnd==='number')b=el.selectionEnd;}catch(_){ }
   if(mode==='backspace' && a===b)a=Math.max(0,a-1);
   const next=mode==='clear'?'':v.slice(0,a)+v.slice(b);
   el.value=next;
   sendInput(el);
   try{el.focus({preventScroll:true});const caret=mode==='clear'?0:a;el.setSelectionRange(caret,caret);}catch(_){try{el.focus();}catch(__){}}
   placeSoon();
 }
 function start(){
   document.body.appendChild(toolbar);
   if(window.visualViewport){window.visualViewport.addEventListener('resize',placeSoon);window.visualViewport.addEventListener('scroll',placeSoon);}
   window.addEventListener('resize',placeSoon);
   document.addEventListener('scroll',placeSoon,true);           // the pages scroll inside their own boxes
   document.addEventListener('input',placeSoon,true);            // typing may open a result list under the field
   try{new MutationObserver(function(list){
     if(toolbar.hidden)return;
     for(let i=0;i<list.length;i++){if(!toolbar.contains(list[i].target)){placeSoon();return;}}
   }).observe(document.body,{childList:true,subtree:true});}catch(_){}
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
 document.addEventListener('focusin',function(ev){
   const el=ev.target;
   if(editable(el)&&withinApp(el)){
     focused=el;toolbar.hidden=false;place();
   }else if(!toolbar.contains(el)){
     focused=null;toolbar.hidden=true;
   }
 },true);
 document.addEventListener('focusout',function(ev){
   if(ev.target!==focused)return;
   setTimeout(function(){if(document.activeElement!==focused && !toolbar.contains(document.activeElement))toolbar.hidden=true;},130);
 },true);
 toolbar.addEventListener('pointerdown',function(ev){if(ev.target.closest('button'))ev.preventDefault();});
 toolbar.addEventListener('click',function(ev){
   const b=ev.target.closest('button[data-rt-key]');if(!b)return;
   const mode=b.dataset.rtKey;
   if(mode==='close'){toolbar.hidden=true;try{if(focused)focused.blur();}catch(_){}return;}
   changeValue(mode);
 });
 window.rtCorrectionPlace=place;
 window.rtOpenCorrection=function(entity,term){
   if(typeof window.rtHasAdminAccess!=='function'||!window.rtHasAdminAccess()){
     if(window.showToast)window.showToast('Hanya Admin / Owner boleh arkib rekod. Gunakan EDIT untuk membetulkan maklumat.','error');return;
   }
   if(!window.rtOverride||!window.rtOverride.openPage){if(window.showToast)window.showToast('Menu Override belum tersedia.','error');return;}
   window.rtOverride.openPage(entity,term);
 };
 document.addEventListener('click',function(ev){
   const b=ev.target.closest('[data-rt-correction-type][data-rt-correction-query]');if(!b)return;
   ev.preventDefault();window.rtOpenCorrection(b.dataset.rtCorrectionType,b.dataset.rtCorrectionQuery);
 });
})();
