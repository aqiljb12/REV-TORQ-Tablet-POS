/* REV TORQ POS 2026-10-21: staff-issued, one-time customer identity claim code. */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id)};
  function escapeHtml(text){return String(text||'').replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]})}
  function selectedCustomer(){var sel=$('rtPosCustomerSelect');return sel&&sel.value?sel.value:null;}
  window.rtIssueCustomerClaimCode=async function(){
    var id=selectedCustomer(),out=$('rtPosClaimCodeResult'),btn=$('rtIssueCustomerClaimCode');
    if(!id){if(out)out.textContent='Pilih pelanggan atau tekan CARI / DAFTAR dahulu.';return;}
    var client=window.supabaseClient;
    if(!client||!client.rpc){if(out)out.textContent='Supabase belum bersambung.';return;}
    if(btn)btn.disabled=true;
    if(out)out.textContent='Mengeluarkan kod...';
    try{
      var result=await client.rpc('rt_pos_issue_customer_claim_code',{p_customer_id:id});
      if(result.error)throw result.error;
      var row=result.data||{},code=String(row.code||'');
      if(!code)throw new Error('Kod tidak diterima.');
      if(out){
        out.innerHTML='<div style="padding:10px;border:1px solid #86efac;background:#f0fdf4;border-radius:12px"><strong style="display:block;font-size:15px;letter-spacing:0.5px;color:#14532d">'+escapeHtml(code)+'</strong><small>Kod tamat 7 hari dari sekarang · beri kepada pemilik motor sahaja.</small><div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap"><button id="rtPosCopyClaim" type="button" style="padding:8px;background:#166534;color:white;border-radius:8px;font-weight:700">SALIN KOD</button></div></div>';
        var copy=$('rtPosCopyClaim');if(copy)copy.onclick=function(){
          if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(code).catch(function(){window.prompt('Salin kod',code)});
          else window.prompt('Salin kod',code);
        };
      }
    }catch(e){
      var msg=String(e.message||e||'Ralat');
      if(/Could not find the function|PGRST202|42883/i.test(msg))msg='SQL POS-Customer Link belum dipasang di Supabase.';
      if(out)out.textContent='Gagal: '+msg;
    }finally{if(btn)btn.disabled=false;}
  };
})();
