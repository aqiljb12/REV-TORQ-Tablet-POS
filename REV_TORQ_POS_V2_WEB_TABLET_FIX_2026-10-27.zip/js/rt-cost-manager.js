/* REV TORQ POS V2 | Margin Cost Manager 2026-10-11
   Owner/Admin UI only. Server RPCs enforce owner/admin company scope.
   The POS checkout RPC and existing cart/receipt remain unchanged. */
(function(){
'use strict';
const $=id=>document.getElementById(id);
const sb=window.supabaseClient;
const escape=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const amount=n=>'RM '+Number(n||0).toLocaleString('en-MY',{minimumFractionDigits:2,maximumFractionDigits:2});
const owner=()=>['owner','admin','super_admin'].includes(String(window.currentProfile?.role||'').trim().toLowerCase());
const notice=(message,type='info')=>window.showToast?.(message,type);
let mode='product', productId=null, busy=false, serviceRows=[];

function modal(){
  let el=$('rtCostModal');if(el)return el;
  el=document.createElement('div');el.id='rtCostModal';el.className='rt-cost-overlay hidden';
  el.setAttribute('role','dialog');el.setAttribute('aria-modal','true');el.setAttribute('aria-labelledby','rtCostTitle');
  el.innerHTML=`<div class="rt-cost-dialog">
    <div class="rt-cost-head"><div><small>REV TORQ / INVENTORI</small><h2 id="rtCostTitle">Tetapkan Harga Kos</h2></div><button type="button" id="rtCostClose" aria-label="Tutup">✕</button></div>
    <div class="rt-cost-content">
      <div id="rtCostProduct" class="hidden">
        <div class="rt-cost-name" id="rtCostProductName"></div><div class="rt-cost-meta" id="rtCostProductMeta"></div>
        <label for="rtCostValue">Harga kos / unit (RM)</label><input id="rtCostValue" type="number" min="0" step="0.01" inputmode="decimal" placeholder="0.00" required>
        <p class="rt-cost-hint" id="rtCostHint">Harga kos semasa hanya untuk jualan seterusnya, bukan mengubah rekod jualan lepas.</p>
        <div class="rt-cost-preview"><div><small>Harga jual semasa</small><b id="rtCostSell">—</b></div><div><small>Untung kasar / unit</small><b id="rtCostGross">—</b></div><div><small>Margin kasar</small><b id="rtCostMargin">—</b></div></div>
        <button type="button" id="rtCostProductSave" class="rt-cost-primary">Simpan Harga Kos</button>
      </div>
      <div id="rtCostServices" class="hidden">
        <p class="rt-cost-hint">Untuk servis yang ditaip terus di butang LABOUR. Nama mesti sama dengan nama yang direkod dalam invois. Letak kos bahan pakai habis/upah luar sahaja; jangan masukkan stok yang sudah dicaj berasingan atau gaji yang dikira dalam HR.</p>
        <div class="rt-cost-service-list" id="rtCostServiceList"></div>
        <label for="rtCostServiceName">Nama servis seperti di POS</label><input id="rtCostServiceName" maxlength="160" placeholder="Contoh: Labour Service" autocomplete="off">
        <label for="rtCostServiceAmount">Kos langsung / satu servis (RM)</label><input id="rtCostServiceAmount" type="number" min="0" step="0.01" inputmode="decimal" placeholder="0.00">
        <button type="button" id="rtCostServiceSave" class="rt-cost-primary">Simpan Kos Servis</button>
      </div>
    </div>
  </div>`;
  document.body.appendChild(el);
  $('rtCostClose').onclick=close;
  el.addEventListener('click',e=>{if(e.target===el)close()});
  $('rtCostValue').addEventListener('input',()=>updatePreview());
  $('rtCostProductSave').onclick=saveProduct;
  $('rtCostServiceSave').onclick=saveService;
  el.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
  return el;
}
function close(){const el=$('rtCostModal');if(el){el.classList.add('hidden');el.style.display='none';}busy=false;}
function open(which){
  if(!owner()){notice('Hanya Owner/Admin boleh menetapkan harga kos.','error');return false;}
  if(!sb){notice('Sambungan Supabase tidak tersedia.','error');return false;}
  mode=which;modal();$('rtCostProduct').classList.toggle('hidden',which!=='product');$('rtCostServices').classList.toggle('hidden',which!=='services');
  $('rtCostTitle').textContent=which==='product'?'Harga Kos Produk':'Kos Servis / Labour';
  $('rtCostModal').classList.remove('hidden');$('rtCostModal').style.display='flex';return true;
}
function updatePreview(){
 const sell=Number($('rtCostValue').dataset.sell||0), cost=Number($('rtCostValue').value);
 const valid=$('rtCostValue').value.trim()!==''&&Number.isFinite(cost)&&cost>=0&&Number.isFinite(sell);
 $('rtCostSell').textContent=amount(sell);$('rtCostGross').textContent=valid?amount(sell-cost):'—';
 $('rtCostMargin').textContent=valid&&sell>0?((sell-cost)/sell*100).toFixed(1)+'%':'—';
 $('rtCostGross').classList.toggle('rt-cost-loss',valid&&cost>sell);
}
async function openProduct(id){
  if(!open('product'))return;
  productId=null;$('rtCostProductName').textContent='Memuatkan...';$('rtCostProductSave').disabled=true;
  try{
    const r=await sb.from('products').select('id,sku,name,category,cost_price,sell_price').eq('id',id).maybeSingle();
    if(r.error)throw r.error;if(!r.data)throw new Error('Produk tidak ditemui.');
    if(!owner())throw new Error('Akses tidak dibenarkan.');
    const p=r.data;productId=p.id;
    $('rtCostProductName').textContent=p.name||p.sku;
    $('rtCostProductMeta').textContent=(p.sku||'')+' • '+(p.category||'BARANG');
    $('rtCostValue').value=Number(p.cost_price||0).toFixed(2);
    $('rtCostValue').dataset.sell=Number(p.sell_price||0);
    $('rtCostHint').textContent=String(p.category||'').toUpperCase()==='SERVIS'
      ?'Kos langsung setiap servis katalog. Jangan masukkan gaji tetap atau barang yang dijual pada baris invois berasingan.'
      :'Kos belian seunit. Rekod kos jualan akan menyimpan harga kos ketika jualan berlaku selepas migrasi dipasang.';
    $('rtCostProductSave').disabled=false;updatePreview();$('rtCostValue').focus();
  }catch(e){$('rtCostProductName').textContent=e.message||String(e);notice('Gagal memuat produk: '+(e.message||e),'error');}
}
function validPrice(el){const raw=String(el.value||'').trim(),n=Number(raw);if(!raw||!Number.isFinite(n)||n<0||Math.abs(n*100-Math.round(n*100))>0.00001)throw new Error('Kos mesti RM0.00 atau lebih dengan maksimum 2 perpuluhan.');return Math.round(n*100)/100;}
async function saveProduct(){
 if(busy)return;try{
  if(!owner()||!productId)throw new Error('Owner/Admin dan produk yang sah diperlukan.');
  const cost=validPrice($('rtCostValue'));
  if(cost===0&&!window.confirm('Kos RM0.00. Teruskan? Margin mungkin tidak tepat.'))return;
  busy=true;$('rtCostProductSave').disabled=true;
  const r=await sb.rpc('rt_product_cost_update',{p_product_id:productId,p_cost_price:cost});
  if(r.error)throw r.error;
  const row=Array.isArray(r.data)?r.data[0]:r.data;
  notice('Harga kos '+(row?.sku||'')+' disimpan: '+amount(cost),'success');close();
  if(Array.isArray(window.rtInventoryCache)){const i=window.rtInventoryCache.find(p=>p.id===productId);if(i)i.cost_price=cost;}
  Promise.resolve(window.loadInventory?.({silent:true})).catch(console.warn);
 }catch(e){notice('Simpan kos gagal: '+(e.message||e),'error');}finally{busy=false;$('rtCostProductSave').disabled=false;}
}
async function openServices(){if(!open('services'))return;await fetchServices();}
async function fetchServices(){
 $('rtCostServiceList').textContent='Memuatkan senarai kos servis...';
 try{const r=await sb.rpc('rt_service_cost_list');if(r.error)throw r.error;serviceRows=Array.isArray(r.data)?r.data:[];
  $('rtCostServiceList').innerHTML=serviceRows.length?serviceRows.map((s,i)=>`<button type="button" data-rt-service-index="${i}"><span>${escape(s.service_name)}</span><b>${amount(s.cost_per_service)}</b></button>`).join(''):'<p>Belum ada kos servis ditetapkan.</p>';
  $('rtCostServiceList').querySelectorAll('button').forEach(b=>b.onclick=()=>{const x=serviceRows[Number(b.dataset.rtServiceIndex)];$('rtCostServiceName').value=x.service_name;$('rtCostServiceAmount').value=Number(x.cost_per_service).toFixed(2);});
 }catch(e){$('rtCostServiceList').textContent='Sila pasang SQL Kos & Margin dahulu: '+(e.message||e);}
}
async function saveService(){
 if(busy)return;try{
  if(!owner())throw new Error('Hanya Owner/Admin boleh simpan kos servis.');
  const name=$('rtCostServiceName').value.trim();if(name.length<2||name.length>160)throw new Error('Nama servis mesti 2–160 aksara.');
  const cost=validPrice($('rtCostServiceAmount'));
  if(cost===0&&!window.confirm('Kos servis RM0.00. Teruskan?'))return;
  busy=true;$('rtCostServiceSave').disabled=true;
  const r=await sb.rpc('rt_service_cost_upsert',{p_service_name:name,p_cost_per_service:cost});if(r.error)throw r.error;
  notice('Kos servis '+name+' disimpan: '+amount(cost),'success');
  $('rtCostServiceName').value='';$('rtCostServiceAmount').value='';await fetchServices();
 }catch(e){notice('Simpan kos servis gagal: '+(e.message||e),'error');}finally{busy=false;$('rtCostServiceSave').disabled=false;}
}
function updateAccess(){const b=$('rtServiceCostBtn');if(b)b.hidden=!owner();}
window.rtCostCanEdit=owner;
window.rtOpenQuickCost=openProduct;
window.rtOpenServiceCosts=openServices;
window.rtCostUIRefresh=updateAccess;
document.addEventListener('DOMContentLoaded',updateAccess);
window.addEventListener('load',updateAccess);
})();
