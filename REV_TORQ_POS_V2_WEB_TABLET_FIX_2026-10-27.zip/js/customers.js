// ================= CUSTOMERS & VEHICLES =================
        function rtCustomerSetValue(id,value,uppercase=false,rebuild=true) {
            const el = document.getElementById(id);
            if(!el) return false;
            if(window.rtSetNativeInputValue) return window.rtSetNativeInputValue(el,value,{uppercase,rebuild});
            el.value = uppercase ? String(value == null ? '' : value).toUpperCase() : String(value == null ? '' : value);
            return true;
        }
        function rtCustomerUuid() {
            if(typeof window.rtUuidV4 === 'function') return window.rtUuidV4();
            if(window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
            throw new Error('UUID generator tidak tersedia.');
        }
        function openNewCustomer() {
            document.getElementById('custIsEdit').value = "false";
            document.getElementById('custIdField').value = "";
            document.getElementById('customerModalTitle').innerText = "Daftar Pelanggan";
            document.getElementById('custName').value = "";
            document.getElementById('custPhone').value = "";
            document.getElementById('custInitialVehicleGroup').style.display = 'block';
            rtCustomerSetValue('custInitPlat', '', true, false);
            document.getElementById('custInitModel').value = "";
            openModal('customerModal');
        }

        async function editCustomer(id) {
            document.getElementById('custIsEdit').value = "true";
            document.getElementById('custIdField').value = id;
            document.getElementById('customerModalTitle').innerText = "Kemaskini Pelanggan";
            document.getElementById('custInitialVehicleGroup').style.display = 'none'; // hide initial vehicle section for edit
            try {
                const doc = await db.collection("customers").doc(id).get();
                if(doc.exists) {
                    const d = doc.data();
                    document.getElementById('custName').value = d.name;
                    document.getElementById('custPhone').value = d.phone;
                    openModal('customerModal');
                }
            } catch(e) { showToast(e.message, 'error'); }
        }

        async function loadCustomers() {
            const tbody = document.querySelector('#tblCustomers tbody');
            const request = loadCustomers.request = (loadCustomers.request || 0) + 1;
            if (!loadCustomers.loaded) tbody.innerHTML = '<tr><td colspan="5" class="text-center p-4">Loading...</td></tr>';
            
            try {
                const snap = await db.collection("customers").orderBy("createdAt", "desc").get();
                let rows = '';
                const customerIds = [...new Set(snap.docs.map(doc => doc.data().customerId).filter(Boolean))];
                const vehiclesByCustomer = new Map();
                for (let i = 0; i < customerIds.length; i += 100) {
                    const vSnap = await db.collection("vehicles").where("customerId", "in", customerIds.slice(i, i + 100)).get();
                    vSnap.forEach(vDoc => {
                        const v = vDoc.data();
                        if (!vehiclesByCustomer.has(v.customerId)) vehiclesByCustomer.set(v.customerId, []);
                        vehiclesByCustomer.get(v.customerId).push(v);
                    });
                }
                // Customer names/plates can come from the customer web app: always escape.
                const esc = v => String(v ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
                const jsArg = v => esc(String(v ?? '').replace(/\\/g, '\\\\').replace(/'/g, "\\'"));
                for (const doc of snap.docs) {
                    const d = doc.data();
                    if (d.active === false) continue; // diarkibkan melalui Override
                    // Many motorcycles per customer: chips wrap inside the cell (never under the buttons).
                    const chips = (vehiclesByCustomer.get(d.customerId) || []).filter(v => v.active !== false).map(v => {
                        const label = [v.plateNo, v.model].filter(Boolean).join(' - ');
                        return `<span class="rt-veh-chip" title="${esc(label)}">${esc(label)}</span>`;
                    }).join('');
                    const vHtml = chips ? `<div class="rt-veh-list">${chips}</div>` : `<span class="text-xs text-gray-500">Tiada kenderaan</span>`;
                    const id = jsArg(d.customerId);

                    rows += `
                        <tr class="hover:bg-slate-50 rt-cust-row">
                            <td class="p-4 text-xs font-mono text-slate-500">${esc(d.customerId)}</td>
                            <td class="p-4 font-bold text-slate-800 rt-cust-name">${esc(d.name)}</td>
                            <td class="p-4 font-mono text-slate-700 rt-cust-phone">${esc(d.phone)}</td>
                            <td class="p-4 rt-cust-veh">${vHtml}</td>
                            <td class="p-4 text-right rt-cust-actions">
                                <button type="button" onclick="editCustomer('${id}')" class="rt-cust-btn rt-cust-btn-edit"><i data-feather="edit" class="w-4 h-4 inline"></i> KEMASKINI</button>
                                <button type="button" onclick="openAddVehicle('${id}')" class="rt-cust-btn rt-cust-btn-veh"><i data-feather="plus-circle" class="w-4 h-4 inline"></i> KENDERAAN</button>
                                ${(typeof window!=='undefined'&&typeof window.rtHasAdminAccess==='function'&&window.rtHasAdminAccess()) ? `<button type="button" class="rt-cust-btn rt-cust-btn-archive" data-rt-correction-type="CUSTOMER" data-rt-correction-query="${esc(d.phone||d.name)}" title="Arkib rekod salah key-in (Admin)">ARKIB</button>` : ''}
                            </td>
                        </tr>
                    `;
                }
                if (request !== loadCustomers.request) return;
                tbody.innerHTML = rows || '<tr><td colspan="5" class="text-center p-4 text-gray-500">Tiada rekod</td></tr>';
                loadCustomers.loaded = true;
                feather.replace();
            } catch (e) {
                if (request === loadCustomers.request && !loadCustomers.loaded) tbody.innerHTML = `<tr><td colspan="5" class="text-center p-4 text-red-500">Ralat: ${e.message}</td></tr>`;
                else console.error('Customer refresh failed', e);
            }
        }

        async function saveCustomer(e) {
            e.preventDefault();
            const btnId = 'btnSaveCustomer';
            setOriginalText(btnId);
            toggleLoading(btnId, true);

            const isEdit = document.getElementById('custIsEdit').value === "true";
            const name = document.getElementById('custName').value.trim();
            const phone = document.getElementById('custPhone').value.trim();
            let createdCustomerId = document.getElementById('custIdField').value || null;
            
            try {
                if (isEdit) {
                    const custId = document.getElementById('custIdField').value;
                    await db.collection("customers").doc(custId).update({
                        name: name,
                        phone: phone,
                        updatedAt: new Date().toISOString()
                    });
                    showToast(`Pelanggan ${name} dikemaskini.`);
                    await logAudit('UPDATE_CUSTOMER', `Updated customer: ${custId}`, { entityType:'customers', entityId:custId, after:{ name, phone } });
                } else {
                    const initPlat = document.getElementById('custInitPlat').value.trim().toUpperCase();
                    rtCustomerSetValue('custInitPlat', initPlat, true, true);
                    const initModel = document.getElementById('custInitModel').value.trim();
                    // The POS member dialog and this Pelanggan page must use the SAME
                    // canonical server-side phone upsert. Generating an unconditional UUID
                    // here used to create a second customer record for an existing PWA user.
                    const rpc = window.supabaseRpc || (window.supabaseClient && ((name,args) => window.supabaseClient.rpc(name,args).then(r => { if(r.error)throw r.error;return r.data; })));
                    if(!rpc)throw new Error('Supabase belum tersedia. Cuba semula.');
                    const result=await rpc('rt_pos_find_or_create_customer',{p_phone:phone,p_name:name||null});
                    const row=Array.isArray(result)?result[0]:result;
                    if(!row || !row.customer_id)throw new Error('Customer ID tidak diterima daripada Supabase.');
                    const custId=row.customer_id;
                    createdCustomerId=custId;

                    // Do not write duplicate bikes when staff re-registers a known phone.
                    if(initPlat && initModel) {
                        const existing=await window.supabaseClient.from('vehicles')
                          .select('id,plate_no').eq('company_id',window.currentProfile.companyId)
                          .eq('customer_id',custId).eq('active',true).limit(150);
                        if(existing.error)throw existing.error;
                        const norm=p=>String(p||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
                        const hasPlate=(existing.data||[]).some(v=>norm(v.plate_no)===norm(initPlat));
                        if(!hasPlate){
                            const vId = rtCustomerUuid();
                            await db.collection("vehicles").doc(vId).set({
                                vehicleId: vId,
                                customerId: custId,
                                plateNo: initPlat,
                                model: initModel,
                                active: true,
                                createdAt: new Date().toISOString()
                            });
                        }
                    }

                    showToast(row.created_now?`Pelanggan ${name} didaftarkan.`:`Rekod pelanggan sedia ada digunakan untuk ${name}.`);
                    if(row.created_now)await logAudit('CREATE_CUSTOMER', `Created customer: ${custId}`, { entityType:'customers', entityId:custId, after:{ name, phone } });
                }
                closeModal('customerModal');
                await loadCustomers();
                if (pendingJobCustomerId === 'JOB') {
                    pendingJobCustomerId = null;
                    await populateJCSelects();
                    document.getElementById('jcCustomerSelect').value = createdCustomerId;
                    await loadCustomerVehiclesForJC(createdCustomerId);
                    openModal('jobCardModal');
                }
            } catch (e) {
                showToast(e.message, 'error');
            } finally {
                toggleLoading(btnId, false);
            }
        }

        function openAddVehicle(customerId) {
            document.getElementById('vehCustomerId').value = customerId;
            rtCustomerSetValue('vehPlate', '', true, false);
            document.getElementById('vehModel').value = '';
            openModal('vehicleModal');
        }

        async function saveVehicle(e) {
            e.preventDefault();
            const btnId = 'btnSaveVehicle';
            setOriginalText(btnId);
            toggleLoading(btnId, true);

            const cid = document.getElementById('vehCustomerId').value;
            const plate = document.getElementById('vehPlate').value.trim().toUpperCase();
            rtCustomerSetValue('vehPlate', plate, true, true);
            const model = document.getElementById('vehModel').value.trim();

            try {
                const vId = rtCustomerUuid();
                await db.collection("vehicles").doc(vId).set({
                    vehicleId: vId,
                    customerId: cid,
                    plateNo: plate,
                    model: model,
                    active: true,
                    createdAt: new Date().toISOString()
                });
                showToast("Kenderaan baru ditambah.");
                await logAudit('CREATE_VEHICLE', `Added vehicle ${plate} to customer ${cid}`, { entityType:'vehicles', entityId:vId, after:{ plate_no:plate, model }, meta:{ customer_id:cid } });
                closeModal('vehicleModal');
                loadCustomers();
            } catch (e) { showToast(e.message, 'error'); } 
            finally { toggleLoading(btnId, false); }
        }

        
