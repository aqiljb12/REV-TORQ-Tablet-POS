-- REV TORQ Admin POS | Inventory Control 1-5 | 2026-10-27
-- INSTALL ONLY: existing product names/SKU/prices and stock balances are NOT modified by this script.
-- Backup the Supabase database before applying. No old records are removed.
begin;

create table if not exists public.rt_inventory_sku_aliases (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id),
  product_id uuid not null references public.products(id),
  legacy_sku text not null,
  changed_by uuid references public.staff(id),
  created_at timestamptz not null default now(),
  unique(company_id,legacy_sku)
);
create index if not exists rt_inv_alias_product_idx on public.rt_inventory_sku_aliases(product_id);
alter table public.rt_inventory_sku_aliases enable row level security;
revoke all on public.rt_inventory_sku_aliases from anon, authenticated;
-- Read only aliases belonging to an authenticated staff member's own company.
grant select on public.rt_inventory_sku_aliases to authenticated;
drop policy if exists rt_inv_alias_company_read on public.rt_inventory_sku_aliases;
create policy rt_inv_alias_company_read on public.rt_inventory_sku_aliases for select to authenticated
 using(exists(select 1 from public.staff s where s.auth_user_id=auth.uid() and s.company_id=rt_inventory_sku_aliases.company_id and s.active=true));

create table if not exists public.rt_inventory_admin_receipts (
 id uuid primary key default gen_random_uuid(),
 company_id uuid not null references public.companies(id),
 location_id uuid not null references public.locations(id),
 supplier_id uuid not null references public.suppliers(id),
 reference_no text not null,
 status text not null default 'POSTED' check (status in ('POSTED','REVERSED')),
 note text,
 created_by uuid not null references public.staff(id),
 created_at timestamptz not null default now(),
 reversed_by uuid references public.staff(id),
 reversed_at timestamptz,
 reverse_reason text
);
create unique index if not exists rt_inv_receipt_do_unique on public.rt_inventory_admin_receipts(company_id,supplier_id,upper(reference_no)) where status='POSTED';
create table if not exists public.rt_inventory_admin_receipt_lines (
 id uuid primary key default gen_random_uuid(),
 receipt_id uuid not null references public.rt_inventory_admin_receipts(id),
 product_id uuid not null references public.products(id),
 product_sku text not null,
 product_name text not null,
 quantity numeric not null check (quantity>0),
 unit_cost numeric not null check(unit_cost>=0),
 movement_id uuid references public.stock_movements(id)
);
create index if not exists rt_inv_receipt_lines_receipt on public.rt_inventory_admin_receipt_lines(receipt_id);
alter table public.rt_inventory_admin_receipts enable row level security;
alter table public.rt_inventory_admin_receipt_lines enable row level security;
revoke all on public.rt_inventory_admin_receipts,public.rt_inventory_admin_receipt_lines from anon,authenticated;
grant select on public.rt_inventory_admin_receipts,public.rt_inventory_admin_receipt_lines to authenticated;
drop policy if exists rt_inv_receipts_admin_read on public.rt_inventory_admin_receipts;
create policy rt_inv_receipts_admin_read on public.rt_inventory_admin_receipts for select to authenticated
 using(exists(select 1 from public.staff s where s.auth_user_id=auth.uid() and s.company_id=rt_inventory_admin_receipts.company_id and s.active=true and lower(s.role) in ('owner','admin','super_admin')));
drop policy if exists rt_inv_receipt_lines_admin_read on public.rt_inventory_admin_receipt_lines;
create policy rt_inv_receipt_lines_admin_read on public.rt_inventory_admin_receipt_lines for select to authenticated
 using(exists(select 1 from public.rt_inventory_admin_receipts r where r.id=receipt_id));

-- Privileged routines are callable only by staff verified from auth.uid() in the same company.
create or replace function public.rt_inv_admin_context()
returns table(staff_id uuid,company_id uuid,location_id uuid)
language plpgsql security definer set search_path='public','pg_temp' as $$
begin
 if auth.uid() is null then raise exception 'LOGIN_REQUIRED'; end if;
 return query select s.id,s.company_id,coalesce(s.location_id,
   (select l.id from public.locations l where l.company_id=s.company_id and l.active=true order by l.code limit 1))
 from public.staff s where s.auth_user_id=auth.uid() and s.active=true
 and coalesce(s.removed_from_active_list,false)=false and s.blocked_at is null
 and lower(trim(s.role)) in ('owner','admin','super_admin') limit 1;
 if not found then raise exception 'ADMIN_ONLY'; end if;
end;$$;
revoke all on function public.rt_inv_admin_context() from public,anon;
grant execute on function public.rt_inv_admin_context() to authenticated;

create or replace function public.rt_inv_admin_master(p_product_id uuid,p_patch jsonb,p_expected_updated_at timestamptz default null)
returns jsonb language plpgsql security definer set search_path='public','pg_temp' as $$
declare c record; oldp public.products%rowtype; newp public.products%rowtype;
 n text;cat text;brandval text;u text;skuval text;bc text; cost numeric; price numeric;
begin
 select * into c from public.rt_inv_admin_context();
 if p_patch is null or jsonb_typeof(p_patch)<>'object' or p_patch='{}'::jsonb then raise exception 'EMPTY_PATCH'; end if;
 if exists(select 1 from jsonb_object_keys(p_patch) as keycheck(field_name) where field_name not in ('name','category','brand','unit','rack_location','cost_price','sell_price','sku')) then raise exception 'UNSUPPORTED_FIELD'; end if;
 select * into oldp from public.products p where p.id=p_product_id and p.company_id=c.company_id for update;
 if not found then raise exception 'PRODUCT_NOT_FOUND'; end if;
 if p_expected_updated_at is not null and oldp.updated_at is distinct from p_expected_updated_at then raise exception 'PRODUCT_CHANGED_REFRESH'; end if;
 n:=upper(regexp_replace(btrim(coalesce(p_patch->>'name',oldp.name)),'[[:space:]]+',' ','g'));
 cat:=upper(btrim(coalesce(p_patch->>'category',oldp.category)));
 brandval:=nullif(upper(btrim(coalesce(p_patch->>'brand',oldp.brand,''))),'');
 u:=lower(btrim(coalesce(p_patch->>'unit',oldp.unit,'pcs')));
 skuval:=upper(btrim(coalesce(p_patch->>'sku',oldp.sku)));
 if n='' or length(n)>220 then raise exception 'INVALID_NAME'; end if;
 if cat not in ('MINYAK','TAYAR','SPAREPART','AKSESORI','BARANG LUAR','SERVIS') then raise exception 'INVALID_CATEGORY'; end if;
 if u not in ('pcs','botol','set','kotak','pasang','liter') then raise exception 'INVALID_UNIT'; end if;
 if skuval is distinct from oldp.sku and (skuval='' or length(skuval)>110 or skuval !~ '^[A-Z0-9][A-Z0-9._/-]*$') then raise exception 'SKU_FORMAT_INVALID'; end if;
 cost:=case when p_patch ? 'cost_price' then (p_patch->>'cost_price')::numeric else oldp.cost_price end;
 price:=case when p_patch ? 'sell_price' then (p_patch->>'sell_price')::numeric else oldp.sell_price end;
 if cost<0 or price<0 or cost>10000000 or price>10000000 then raise exception 'INVALID_PRICE'; end if;
 if exists(select 1 from public.products p where p.company_id=c.company_id and p.id<>p_product_id and p.active=true and upper(regexp_replace(btrim(p.name),'[[:space:]]+',' ','g'))=n and upper(coalesce(p.category,''))=cat)
 and (n is distinct from upper(regexp_replace(btrim(oldp.name),'[[:space:]]+',' ','g')) or cat is distinct from oldp.category) then raise exception 'DUPLICATE_NAME_CATEGORY_REVIEW'; end if;
 if skuval is distinct from oldp.sku and (exists(select 1 from public.products p where p.company_id=c.company_id and p.sku=skuval) or exists(select 1 from public.rt_inventory_sku_aliases a where a.company_id=c.company_id and a.legacy_sku=skuval)) then raise exception 'SKU_TAK_AVAILABLE'; end if;
 update public.products set name=n,category=cat,brand=brandval,unit=u,sku=skuval,
 rack_location=nullif(upper(btrim(coalesce(p_patch->>'rack_location',oldp.rack_location,''))),'') ,
 cost_price=cost,sell_price=price,updated_at=now()
 where id=p_product_id returning * into newp;
 if skuval is distinct from oldp.sku then
  insert into public.rt_inventory_sku_aliases(company_id,product_id,legacy_sku,changed_by) values(c.company_id,p_product_id,oldp.sku,c.staff_id)
  on conflict(company_id,legacy_sku) do nothing;
 end if;
 insert into public.audit_logs(company_id,location_id,transaction_id,staff_id,action,entity_type,entity_id,before_data,after_data,metadata)
 values(c.company_id,c.location_id,gen_random_uuid(),c.staff_id,'INV_ADMIN_MASTER_CLEANUP','PRODUCT',p_product_id,to_jsonb(oldp),to_jsonb(newp),jsonb_build_object('source','admin_pos_inventory_control'));
 return jsonb_build_object('id',newp.id,'sku',newp.sku,'name',newp.name,'category',newp.category,'updated_at',newp.updated_at);
end;$$;
revoke all on function public.rt_inv_admin_master(uuid,jsonb,timestamptz) from public,anon;
grant execute on function public.rt_inv_admin_master(uuid,jsonb,timestamptz) to authenticated;

create or replace function public.rt_inv_admin_adjust(p_product_id uuid,p_location_id uuid,p_expected_quantity numeric,p_physical_quantity numeric,p_reason text)
returns jsonb language plpgsql security definer set search_path='public','pg_temp' as $$
declare c record;p record; b numeric;reserved numeric;delta numeric;m uuid;
begin
 select * into c from public.rt_inv_admin_context();
 if p_physical_quantity is null or p_physical_quantity<0 or p_physical_quantity>999999 then raise exception 'INVALID_PHYSICAL_QUANTITY'; end if;
 if length(btrim(coalesce(p_reason,'')))<8 then raise exception 'REASON_REQUIRED_MIN_8'; end if;
 if not exists(select 1 from public.locations where id=p_location_id and company_id=c.company_id and active) then raise exception 'INVALID_LOCATION'; end if;
 select id,name,sku,cost_price,category into p from public.products where id=p_product_id and company_id=c.company_id and active=true;
 if not found then raise exception 'PRODUCT_NOT_FOUND'; end if;
 if p.category='SERVIS' and p_physical_quantity<>0 then raise exception 'SERVICE_COUNT_MUST_BE_ZERO'; end if;
 insert into public.stock_balances(product_id,location_id,quantity,reserved_quantity) values(p_product_id,p_location_id,0,0) on conflict do nothing;
 select quantity,reserved_quantity into b,reserved from public.stock_balances where product_id=p_product_id and location_id=p_location_id for update;
 if p_expected_quantity is null or b is distinct from p_expected_quantity then raise exception 'STOCK_CHANGED_REFRESH'; end if;
 if p_physical_quantity<coalesce(reserved,0) then raise exception 'BELOW_RESERVED_QUANTITY'; end if;
 delta:=p_physical_quantity-b;
 if delta<>0 then
  m:=public.post_stock_movement(c.company_id,p_location_id,p_product_id,case when delta>0 then 'ADJUSTMENT_IN' else 'ADJUSTMENT_OUT' end,abs(delta),p.cost_price,'INV_PHYSICAL_COUNT',null,c.staff_id,null,gen_random_uuid());
 end if;
 insert into public.audit_logs(company_id,location_id,transaction_id,staff_id,action,entity_type,entity_id,before_data,after_data,metadata)
 values(c.company_id,p_location_id,gen_random_uuid(),c.staff_id,'INV_ADMIN_PHYSICAL_COUNT','PRODUCT',p_product_id,
 jsonb_build_object('quantity',b),jsonb_build_object('quantity',p_physical_quantity),jsonb_build_object('sku',p.sku,'reason',p_reason,'delta',delta,'movement_id',m));
 return jsonb_build_object('sku',p.sku,'before',b,'after',p_physical_quantity,'delta',delta,'movement_id',m);
end;$$;
revoke all on function public.rt_inv_admin_adjust(uuid,uuid,numeric,numeric,text) from public,anon;
grant execute on function public.rt_inv_admin_adjust(uuid,uuid,numeric,numeric,text) to authenticated;

create or replace function public.rt_inv_admin_receive(p_location_id uuid,p_supplier_id uuid,p_reference_no text,p_lines jsonb,p_note text default null)
returns jsonb language plpgsql security definer set search_path='public','pg_temp' as $$
declare c record;r public.rt_inventory_admin_receipts%rowtype;line jsonb;p public.products%rowtype;qty numeric;price numeric;m uuid;n integer:=0;v_seen uuid[]:=array[]::uuid[];
begin
 select * into c from public.rt_inv_admin_context();
 if not exists(select 1 from public.locations where id=p_location_id and company_id=c.company_id and active=true) then raise exception 'INVALID_LOCATION'; end if;
 if not exists(select 1 from public.suppliers where id=p_supplier_id and company_id=c.company_id and active=true) then raise exception 'SUPPLIER_REQUIRED'; end if;
 if length(btrim(coalesce(p_reference_no,'')))<3 or length(p_reference_no)>100 then raise exception 'DO_REFERENCE_REQUIRED'; end if;
 if jsonb_typeof(p_lines)<>'array' or jsonb_array_length(p_lines)<1 or jsonb_array_length(p_lines)>80 then raise exception 'INVALID_RECEIPT_LINES'; end if;
 if exists(select 1 from public.rt_inventory_admin_receipts z where z.company_id=c.company_id and z.supplier_id=p_supplier_id and upper(z.reference_no)=upper(btrim(p_reference_no)) and z.status='POSTED') then raise exception 'DO_ALREADY_RECEIVED'; end if;
 insert into public.rt_inventory_admin_receipts(company_id,location_id,supplier_id,reference_no,created_by,note)
 values(c.company_id,p_location_id,p_supplier_id,upper(btrim(p_reference_no)),c.staff_id,nullif(btrim(p_note),'')) returning * into r;
 for line in select value from jsonb_array_elements(p_lines) loop
  select * into p from public.products where id=(line->>'product_id')::uuid and company_id=c.company_id and active=true;
  if not found or p.category='SERVIS' then raise exception 'INVALID_PRODUCT_IN_RECEIPT'; end if;
  if p.id=any(v_seen) then raise exception 'DUPLICATE_PRODUCT_LINE'; end if;
  v_seen:=array_append(v_seen,p.id);
  qty:=(line->>'quantity')::numeric;
  price:=(line->>'unit_cost')::numeric;
  if qty is null or qty<=0 or qty>99999 or price is null or price<0 or price>10000000 then raise exception 'INVALID_RECEIPT_QTY_COST'; end if;
  m:=public.post_stock_movement(c.company_id,p_location_id,p.id,'PURCHASE',qty,price,'INV_ADMIN_RECEIPT',r.id,c.staff_id,null,gen_random_uuid());
  insert into public.rt_inventory_admin_receipt_lines(receipt_id,product_id,product_sku,product_name,quantity,unit_cost,movement_id)
   values(r.id,p.id,p.sku,p.name,qty,price,m);
  n:=n+1;
 end loop;
 insert into public.audit_logs(company_id,location_id,transaction_id,staff_id,action,entity_type,entity_id,after_data,metadata)
 values(c.company_id,p_location_id,gen_random_uuid(),c.staff_id,'INV_ADMIN_RECEIPT_POSTED','STOCK_RECEIPT',r.id,to_jsonb(r),jsonb_build_object('lines',n));
 return jsonb_build_object('receipt_id',r.id,'reference_no',r.reference_no,'item_count',n,'status','POSTED');
end;$$;
revoke all on function public.rt_inv_admin_receive(uuid,uuid,text,jsonb,text) from public,anon;
grant execute on function public.rt_inv_admin_receive(uuid,uuid,text,jsonb,text) to authenticated;

create or replace function public.rt_inv_admin_reverse_receipt(p_receipt_id uuid,p_confirm_ref text,p_reason text)
returns jsonb language plpgsql security definer set search_path='public','pg_temp' as $$
declare c record;r public.rt_inventory_admin_receipts%rowtype;l record; m uuid;
begin
 select * into c from public.rt_inv_admin_context();
 if length(btrim(coalesce(p_reason,'')))<8 then raise exception 'REASON_REQUIRED_MIN_8'; end if;
 select * into r from public.rt_inventory_admin_receipts where id=p_receipt_id and company_id=c.company_id for update;
 if not found then raise exception 'RECEIPT_NOT_FOUND'; end if;
 if r.status <> 'POSTED' then raise exception 'RECEIPT_ALREADY_REVERSED'; end if;
 if upper(btrim(coalesce(p_confirm_ref,'')))<>r.reference_no then raise exception 'REFERENCE_CONFIRM_MISMATCH'; end if;
 for l in select * from public.rt_inventory_admin_receipt_lines where receipt_id=r.id order by product_id loop
  -- No negative stock: abort the entire reversal if any line lacks sufficient available stock.
  m:=public.post_stock_movement(c.company_id,r.location_id,l.product_id,'ADJUSTMENT_OUT',l.quantity,l.unit_cost,'INV_ADMIN_RECEIPT_REVERSAL',r.id,c.staff_id,null,gen_random_uuid());
 end loop;
 update public.rt_inventory_admin_receipts set status='REVERSED',reversed_by=c.staff_id,reversed_at=now(),reverse_reason=p_reason where id=r.id;
 insert into public.audit_logs(company_id,location_id,transaction_id,staff_id,action,entity_type,entity_id,metadata)
 values(c.company_id,r.location_id,gen_random_uuid(),c.staff_id,'INV_ADMIN_RECEIPT_REVERSED','STOCK_RECEIPT',r.id,jsonb_build_object('reference_no',r.reference_no,'reason',p_reason));
 return jsonb_build_object('reference_no',r.reference_no,'status','REVERSED');
end;$$;
revoke all on function public.rt_inv_admin_reverse_receipt(uuid,text,text) from public,anon;
grant execute on function public.rt_inv_admin_reverse_receipt(uuid,text,text) to authenticated;


-- SKU auto generation, for NEW items only. Existing OEM SKU/barcode remain untouched.
create sequence if not exists public.rt_inv_new_sku_seq;
revoke all on sequence public.rt_inv_new_sku_seq from anon, authenticated;
create or replace function public.rt_inv_admin_next_sku(p_category text)
returns text language plpgsql security definer set search_path='public','pg_temp' as $$
declare c record; prefix text; candidate text; n int;
begin
 select * into c from public.rt_inv_admin_context();
 prefix:=case upper(trim(coalesce(p_category,''))) when 'MINYAK' then 'OIL' when 'TAYAR' then 'TYR' when 'SPAREPART' then 'SP' when 'AKSESORI' then 'ACC' when 'BARANG LUAR' then 'EXT' when 'SERVIS' then 'SRV' when 'BATERI' then 'BAT' else null end;
 if prefix is null then raise exception 'INVALID_CATEGORY'; end if;
 for n in 1..50 loop
  candidate:=prefix||'-'||lpad(nextval('public.rt_inv_new_sku_seq')::text,6,'0');
  if not exists(select 1 from public.products p where p.company_id=c.company_id and p.sku=candidate)
     and not exists(select 1 from public.rt_inventory_sku_aliases a where a.company_id=c.company_id and a.legacy_sku=candidate) then return candidate; end if;
 end loop;
 raise exception 'SKU_SEQUENCE_EXHAUSTED';
end;$$;
revoke all on function public.rt_inv_admin_next_sku(text) from public,anon;
grant execute on function public.rt_inv_admin_next_sku(text) to authenticated;

-- Guard all POS product creation entry points, including legacy rt_inventory_save_fast.
-- This does not change or merge any existing duplicate records.
create or replace function public.rt_inv_protect_duplicate_product()
returns trigger language plpgsql security definer set search_path='public','pg_temp' as $$
declare n text;c text;
begin
 if coalesce(new.active,true)=false then return new; end if;
 n:=upper(regexp_replace(btrim(coalesce(new.name,'')),'[[:space:]]+',' ','g'));
 c:=upper(btrim(coalesce(new.category,'')));
 if tg_op='UPDATE' and n=upper(regexp_replace(btrim(coalesce(old.name,'')),'[[:space:]]+',' ','g')) and c=upper(btrim(coalesce(old.category,''))) then return new; end if;
 if n='' then return new; end if;
 perform pg_advisory_xact_lock(hashtext(new.company_id::text||'|'||n||'|'||c));
 if exists(select 1 from public.products p where p.company_id=new.company_id and p.active=true and p.id is distinct from new.id and upper(regexp_replace(btrim(coalesce(p.name,'')),'[[:space:]]+',' ','g'))=n and upper(btrim(coalesce(p.category,'')))=c) then
   raise exception 'DUPLICATE_PRODUCT_NAME_CATEGORY';
 end if;
 return new;
end;$$;
drop trigger if exists trg_rt_inv_protect_duplicate_product on public.products;
create trigger trg_rt_inv_protect_duplicate_product before insert or update of name,category on public.products
 for each row execute function public.rt_inv_protect_duplicate_product();

commit;
