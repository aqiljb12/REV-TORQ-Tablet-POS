# REV TORQ — AI Scan Invoice Supplier (Admin POS)

## Apa fungsi ini
- Admin POS → Inventori → INVENTORY CONTROL → **Barang Sampai**.
- Tekan **AMBIL GAMBAR** (kamera belakang iPhone / Android) atau **PILIH GAMBAR**.
- Gambar dihantar melalui Supabase Edge Function `rt-ai-invoice-scan` kepada OpenAI Responses API.
- AI cuba baca **nama supplier, nombor invoice, tarikh, baris barang, kuantiti, harga seunit dan jumlah**.
- Jika SKU, barcode atau nama sepadan *tepat* dengan item yang ada dalam inventory, produk itu dipilih. Selebihnya mesti dipilih oleh Admin (tiada matching spekulatif).
- Admin semak dan betulkan baris, tekan **PINDAH BARANG KE DRAF STOK MASUK**. Stok **BELUM** berubah.
- Admin pilih supplier, semak nombor invoice dan tekan **SAHKAN STOK MASUK**. Ini menggunakan RPC penerimaan `rt_inv_admin_receive` sedia ada, sekali sahaja untuk setiap rujukan unik.
- Gambar diproses untuk bacaan sahaja; ia **belum disimpan sebagai lampiran kekal**. Tiada data produk/stock baru diwujudkan oleh AI.

## Setup — pasang bersama POS
1. Backup Supabase production dahulu.
2. Pastikan migrasi `migration_2026_10_27_admin_inventory_control.sql` (Inventory Control 1–5) telah dipasang kerana fungsi terimaan `rt_inv_admin_receive` diperlukan.
3. Di **Supabase Dashboard → Edge Functions → Secrets**, tambah secret `OPENAI_API_KEY` (API key daripada OpenAI API; **bukan** kunci ChatGPT atau Supabase). Jangan simpan key di JavaScript atau GitHub. Opsyen `OPENAI_INVOICE_MODEL` jika mahu menukar model; default `gpt-4o-mini`.
4. Deploy Supabase Edge Function `rt-ai-invoice-scan` daripada `supabase/functions/rt-ai-invoice-scan/index.ts`. Contoh terminal yang mempunyai akses projek: `supabase functions deploy rt-ai-invoice-scan --project-ref cnvgwzugqdsavaxrwokm`. **Biarkan JWT verification enabled**; jangan guna `--no-verify-jwt`.
5. Deploy ZIP POS yang dibekalkan. Clear cache/hard refresh iPad selepas deploy.
6. Login Owner/Admin, uji **gambar invoice supplier contoh** dahulu dan bandingkan semua nombor sebelum mengesahkan.

## Risiko dan sempadan keselamatan
- OpenAI API menggunakan bil berasingan daripada langganan ChatGPT. Set had perbelanjaan API.
- Scan cuma untuk akaun staff role Admin/Owner, diverifikasi dalam Edge Function terhadap Supabase Auth dan jadual `staff` menggunakan server-side key. AI key dan secret Supabase tidak berada dalam frontend.
- Kandungan invoice dihantar ke penyedia AI untuk dibaca. Elakkan dokumen sensitif yang tidak berkaitan dengan pembelian.
- Kalau gambar kabur, salah unit (kotak vs biji), diskaun invois, OCR salah baca, atau pembekal tidak dikenali, Admin **wajib** semak manual. AI tidak pernah memanggil RPC restok secara automatik.
- PDF/HEIC mungkin tidak disokong sama rata di semua browser. Foto kamera JPG/PNG lebih selamat; hanya imej dihantar (dikecilkan untuk elak kos berlebihan).
- Tiada migration SQL tambahan khusus untuk **AI** kerana baca imej dan draf melalui Edge Function sahaja. Tetapi migrasi Inventory Control 1–5 terdahulu tetap diperlukan.
- Fungsi ini **belum dideploy** dan API key belum dikonfigurasi oleh assistant. Ujian sebenar hanya boleh dibuat selepas secrets dan fungsi live siap.
