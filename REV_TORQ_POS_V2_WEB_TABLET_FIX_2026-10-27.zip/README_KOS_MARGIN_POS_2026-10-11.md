# REV TORQ POS V2 — Tetapan Kos Barang / Kos Servis (2026-10-11)

Berasaskan ZIP **REV_TORQ_POS_V2_WEB_SEBUT_HARGA_SIMPAN_SEMENTARA_2026-10-09**. Semua ciri POS asal, checkout, sebut harga, simpan sementara, cashier, scanner, invois dan inventori dikekalkan. Perubahan utama hanya pada 2 fail asal (`index.html`, `js/inventory-canonical-list.js`) dan fail tambahan (`js/rt-cost-manager.js`, `css/rt-cost-manager.css`, SQL migrasi).

## Apa yang baharu

- Inventori → setiap item ada butang **KOS** (Owner/Admin). Klik untuk melihat harga kos, harga jual, untung kasar seunit, margin %. Simpan hanya harga kos, tidak ubah jual, stok, barcode atau harga sebut harga.
- Inventori → **KOS SERVIS** (Owner/Admin) untuk servis bebas yang ditaip melalui LABOUR. Tetapkan kos bahan langsung/upah luar mengikut **nama servis yang sama** dalam invois. Kos servis stok berdaftar (`SERVIS`) boleh diedit melalui butang KOS produk, tetapi perlu pastikan ia menggunakan product_id apabila invois dibuat.
- Simpanan dilakukan ke Supabase dengan pengesahan peranan owner/admin pada RPC; tidak disimpan dalam browser sahaja.
- Migrasi `migration_2026_10_11_pos_cost_service_snapshot.sql` menambah rekod kos **pada saat setiap baris invois baharu** (hanya mulai pemasangan migrasi). Ia membuat rekod di `rt_sale_cost_snapshots`, tanpa mengubah `invoice_items`, checkout atau stok.
- Baris invois yang tiada kos yang dipadankan ditanda `UNMAPPED` dan margin tidak dikira sebagai untung pasti.

## Cara pasang (penting)

1. Backup database Supabase dan POS sedia ada.
2. Audit dan jalankan **satu** SQL: `migration_2026_10_11_pos_cost_service_snapshot.sql` di Supabase SQL Editor **wabtoq** sebelum deploy POS versi ini. Jangan jalankan skrip pembersihan data.
3. Deploy **ZIP POS ini sahaja** ke Netlify POS. Jangan tukar tapak Accounting atau Customer App dengan ZIP POS.
4. Log masuk **Owner/Admin**, buka **Inventori → KOS** dan masukkan harga kos sebenar. Untuk servis LABOUR yang ditaip bebas, buka **KOS SERVIS** dan masukkan nama tepat.
5. Jalankan satu jualan **ujian terkawal** setelah confirm dan semak rekod `rt_sale_cost_snapshots` melalui akaun Owner/Admin. Pastikan nilai dalam POS, invois, stok dan rekod bayaran sepadan. VOID ujian mengikut SOP asal jika perlu; JANGAN padam invoice asal secara rawak.
6. Versi Accounting dengan pembaca snapshot ialah `REV_TORQ_ACCOUNTING_V23_1_MARGIN_SYNC.zip` (pakej berasingan). Selepas deploy, Accounting → POS → Selaras dan semak margin.

## Had penting

- Kos lama **tidak boleh dikira semula dengan tepat** berdasarkan harga kos baharu. Jangan backfill invois lama dengan harga sekarang tanpa rekod pembelian asal.
- Margin bukan untung bersih: sewa, gaji, KWSP, PERKESO, kos tetap dan stok tidak terjual bukan ditolak di paparan margin item.
- Kos servis yang dilihat dalam `rt_sale_cost_snapshots` **hanya kos langsung**, elakkan dua kali kira stok yang sudah dijual sebagai item serta kos gaji HR.
- Sumber peranan untuk RPC ini disemak di Supabase. Namun akses ke `products.cost_price` melalui dasar RLS POS sedia ada masih boleh dibaca pengguna syarikat yang diberi akses inventori; perlindungan penuh kolum harga kos untuk staf memerlukan audit polisi SQL/akses aplikasi yang lebih luas.
- `rt_sale_cost_snapshots` ialah rekod analitik; belum dipos automatik ke lejar Untung Rugi Accounting supaya tidak menggandakan COGS dengan Stock Take. Jangan sahkan agihan untung kontrak 30% hanya daripada laporan margin item.
- **Migrasi tidak dijalankan pada production semasa menyediakan ZIP ini.**

## Ujian

- Semua fail JS sintaks lulus.
- Browser UI smoke test: Owner boleh buka kos produk, lihat margin, simpan; kos servis boleh disimpan; staf POS tiada butang fungsi baharu.
- Regresi 49 ujian POS/quotation/cart/offline lulus.
- SQL belum diuji melalui jualan production sebenar.
