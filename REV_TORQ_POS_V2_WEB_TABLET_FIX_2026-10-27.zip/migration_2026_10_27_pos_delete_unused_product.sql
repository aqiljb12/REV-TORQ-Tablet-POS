-- REV TORQ POS: remove mistaken duplicate inventory records safely.
-- Install ONLY after backing up the production database.
-- Admin/Owner + active Override session + exact SKU + reason are required.
-- Only an item with ZERO stock and NO stock/financial/other historical references
-- may be permanently removed. A used item must instead be archived.
-- This migration changes no existing product rows.

begin;

create or replace function public.rt_admin_delete_unused_product(
  p_product_id uuid,
  p_confirm_sku text,
  p_session_id uuid,
  p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $rt_delete_unused$
declare
  v_ctx record;
  v_product public.products%rowtype;
  v_reason text := btrim(coalesce(p_reason, ''));
  v_fk record;
  v_has_rows boolean;
  v_audit uuid;
  v_deleted integer;
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into v_ctx from public.rt_staff_context() limit 1;
  if v_ctx.staff_id is null then raise exception 'STAFF_ONLY'; end if;
  if lower(coalesce(v_ctx.role,'')) not in ('owner','admin','super_admin') then
    raise exception 'ADMIN_ONLY';
  end if;
  perform public.rt_override_require_session(p_session_id, v_ctx.staff_id, v_ctx.company_id);
  if char_length(v_reason) < 8 then raise exception 'REASON_REQUIRED'; end if;
  if p_product_id is null then raise exception 'PRODUCT_ID_REQUIRED'; end if;

  select * into v_product from public.products
   where id=p_product_id and company_id=v_ctx.company_id
   for update;
  if v_product.id is null then raise exception 'PRODUCT_NOT_FOUND'; end if;
  if btrim(coalesce(p_confirm_sku, '')) <> v_product.sku then
    raise exception 'SKU_CONFIRM_MISMATCH';
  end if;

  -- Never silently discard physical inventory from a mistaken double entry.
  if exists(select 1 from public.stock_balances
            where product_id = v_product.id and quantity is distinct from 0) then
    raise exception 'PRODUCT_HAS_STOCK';
  end if;

  -- All known and future FK references to products must be empty. This protects
  -- sales, invoices, quotations, jobs, purchase orders, movements, cost snapshots,
  -- etc. The only exception is empty balances (safe to remove atomically).
  for v_fk in
    select con.conrelid::regclass::text as table_name,
           attr.attname as column_name,
           cardinality(con.conkey) as key_columns
    from pg_catalog.pg_constraint con
    join pg_catalog.pg_attribute attr
      on attr.attrelid=con.conrelid and attr.attnum=con.conkey[1]
    where con.contype='f'
      and con.confrelid='public.products'::regclass
  loop
    if v_fk.key_columns <> 1 then
      raise exception 'PRODUCT_HAS_HISTORY'; -- fail closed for composite FKs
    end if;
    if v_fk.table_name in ('stock_balances','public.stock_balances') then
      continue;
    end if;
    execute format('select exists(select 1 from %s where %I = $1)',
                   v_fk.table_name, v_fk.column_name)
      into v_has_rows using v_product.id;
    if v_has_rows then raise exception 'PRODUCT_HAS_HISTORY'; end if;
  end loop;

  -- Additional guards even if a legacy schema has not declared FK constraints.
  if exists (select 1 from public.stock_movements where product_id = v_product.id)
     or exists (select 1 from public.invoice_items where product_id = v_product.id)
     or exists (select 1 from public.job_card_items where product_id = v_product.id) then
    raise exception 'PRODUCT_HAS_HISTORY';
  end if;

  -- Write an audit event *before* the removal; if removal fails the whole
  -- transaction rolls back together with this audit event.
  insert into public.audit_logs (
    company_id, location_id, staff_id, action, entity_type, entity_id,
    before_data, after_data, metadata
  ) values (
    v_ctx.company_id, v_ctx.location_id, v_ctx.staff_id,
    'OVERRIDE_PRODUCT_DELETE_UNUSED', 'products', v_product.id,
    public.rt_audit_trim(to_jsonb(v_product)), null,
    jsonb_build_object('reason', left(v_reason,300), 'override_session',p_session_id,
                       'sku',v_product.sku,'source','pos','role',v_ctx.role)
  ) returning id into v_audit;

  -- This action is already fully audited above; avoid a duplicate row trigger.
  perform set_config('rt.override_action','1',true);
  delete from public.stock_balances where product_id=v_product.id and quantity=0;
  delete from public.products where id=v_product.id and company_id=v_ctx.company_id;
  get diagnostics v_deleted = row_count;
  if v_deleted <> 1 then raise exception 'PRODUCT_DELETE_NOT_COMPLETED'; end if;

  return jsonb_build_object('ok',true,'deleted',true,'id',v_product.id,
                            'sku',v_product.sku,'audit_id',v_audit);
end;
$rt_delete_unused$;

revoke all on function public.rt_admin_delete_unused_product(uuid,text,uuid,text) from public;
revoke all on function public.rt_admin_delete_unused_product(uuid,text,uuid,text) from anon;
grant execute on function public.rt_admin_delete_unused_product(uuid,text,uuid,text) to authenticated;

commit;
