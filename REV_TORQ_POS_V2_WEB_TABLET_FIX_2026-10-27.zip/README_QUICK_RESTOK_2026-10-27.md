# REV TORQ Admin POS — Restok Pantas, 27 Oktober 2026

## Tujuan
Restok barang yang sudah ada tanpa order PO / masukkan DO. Akses hanya Admin/Owner.

## Cara guna
1. Admin POS → Inventori.
2. Cari barang → klik **+ RESTOK** pada baris produk (atau **INVENTORY CONTROL → RESTOK PANTAS +**).
3. Masukkan kuantiti **yang baru sampai**, dan kos seunit (diisi awal mengikut kos master semasa; boleh diperbetul).
4. Semak ringkasan dan klik **SAHKAN RESTOK**.
5. Sistem menambah stok, merekod `stock_movements.PURCHASE` dan log audit.

**Contoh:** stok asal 5 botol; barang sampai 12 botol; isi `12` (BUKAN `17`). Baki baru menjadi `17`.

## Pemasangan
1. Backup database live.
2. Pastikan migrasi `migration_2026_10_27_admin_inventory_control.sql` telah dipasang.
3. Jalankan migrasi BARU `migration_2026_10_27_admin_quick_restock.sql` melalui Supabase SQL Editor.
4. Deploy ZIP POS baharu. Hard refresh iPad/iPhone jika masih nampak UI lama.

## Keselamatan
- Tiada data live diubah oleh ZIP/migrasi pemasangan ini.
- RPC `rt_inv_admin_quick_restock` semak auth/staff/admin/company/lokasi/prod, tidak menerima kategori SERVIS.
- Penambahan stok idempoten dengan request UUID unik; refresh/click berulang untuk request sama tidak gandakan stok.
- Kos restok direkod pada pergerakan, **tidak mengubah kos/harga jual produk** secara automatik.
- Tiada PO/DO wajib. Untuk dokumen pembekal dan restok beberapa item serentak, guna tab **Barang Sampai**.
- Kalau salah masukkan kuantiti **setelah simpan**, Admin gunakan Audit Stok untuk semak fizik dan pelarasan berjejak. Jangan DELETE ledger.
- Jika `rt_inv_admin_context` belum wujud, pasang migrasi Inventory Control 1–5 dahulu.

## Pengujian
Unit syntax & structural tests are included in `tests/quick-restok.test.cjs`; real Supabase/browser testing is required after migration and deploy. Database live was not modified.
