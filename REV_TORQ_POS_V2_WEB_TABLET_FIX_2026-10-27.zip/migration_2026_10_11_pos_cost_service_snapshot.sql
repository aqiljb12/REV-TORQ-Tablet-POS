-- REV TORQ POS V2 — Harga Kos Barang + Kos Servis + historical cost snapshot
-- ADDITIVE ONLY. Does not rewrite historical invoice_items or existing stock.
-- Designed for wabtoq public schema; apply once in Supabase SQL Editor after backup.
-- IMPORTANT: older sales will NOT be backfilled from current product costs.
BEGIN;

CREATE TABLE IF NOT EXISTS public.rt_service_costs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES public.companies(id),
  service_name text NOT NULL CHECK(length(btrim(service_name)) BETWEEN 2 AND 160),
  service_key text NOT NULL,
  cost_per_service numeric(14,2) NOT NULL CHECK(cost_per_service>=0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(company_id,service_key)
);
ALTER TABLE public.rt_service_costs ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.rt_service_costs FROM PUBLIC,anon,authenticated;
-- RPCs are the only read/write interface for service cost definitions.

CREATE TABLE IF NOT EXISTS public.rt_sale_cost_snapshots (
 invoice_item_id uuid PRIMARY KEY REFERENCES public.invoice_items(id),
 company_id uuid NOT NULL REFERENCES public.companies(id),
 invoice_id uuid NOT NULL REFERENCES public.invoices(id),
 product_id uuid REFERENCES public.products(id),
 service_description text,
 quantity numeric(14,3) NOT NULL,
 unit_cost_snapshot numeric(14,2) CHECK(unit_cost_snapshot>=0),
 total_cost_snapshot numeric(14,2) CHECK(total_cost_snapshot>=0),
 capture_source text NOT NULL CHECK(capture_source IN ('PRODUCT','SERVICE_RULE','NON_COST','UNMAPPED')),
 captured_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS rt_sale_cost_snapshots_company_invoice_idx ON public.rt_sale_cost_snapshots(company_id,invoice_id);
ALTER TABLE public.rt_sale_cost_snapshots ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.rt_sale_cost_snapshots FROM PUBLIC,anon,authenticated;
GRANT SELECT ON public.rt_sale_cost_snapshots TO authenticated;
DROP POLICY IF EXISTS rt_sale_cost_owner_read ON public.rt_sale_cost_snapshots;
CREATE POLICY rt_sale_cost_owner_read ON public.rt_sale_cost_snapshots FOR SELECT TO authenticated
  USING(company_id=(SELECT public.get_my_company_id()) AND (SELECT public.get_my_staff_role()) IN ('owner','admin','super_admin'));

-- Only Owner/Admin may change costs; never sends costs to customer receipts.
CREATE OR REPLACE FUNCTION public.rt_product_cost_update(p_product_id uuid,p_cost_price numeric)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE v_company uuid; v_role text; v_before public.products%ROWTYPE; v_after public.products%ROWTYPE;
DECLARE v_staff uuid; v_location uuid;
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Log masuk diperlukan'; END IF;
 v_company:=public.get_my_company_id(); v_role:=lower(coalesce(public.get_my_staff_role(),''));
 IF v_company IS NULL OR v_role NOT IN ('owner','admin','super_admin') THEN
   RAISE EXCEPTION 'Owner/Admin sahaja boleh tetapkan harga kos'; END IF;
 IF p_cost_price IS NULL OR p_cost_price<0 OR p_cost_price<>round(p_cost_price,2) THEN
   RAISE EXCEPTION 'Harga kos tidak sah: gunakan 0 atau lebih dan 2 perpuluhan'; END IF;
 SELECT * INTO v_before FROM public.products WHERE id=p_product_id AND company_id=v_company FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Produk tidak dijumpai'; END IF;
 UPDATE public.products SET cost_price=p_cost_price,updated_at=now()
 WHERE id=v_before.id RETURNING * INTO v_after;
 SELECT s.id,s.location_id INTO v_staff,v_location FROM public.staff s
 WHERE s.auth_user_id=auth.uid() AND s.company_id=v_company AND s.active=true LIMIT 1;
 INSERT INTO public.audit_logs(company_id,location_id,transaction_id,staff_id,action,entity_type,entity_id,before_data,after_data,metadata)
 VALUES(v_company,v_location,gen_random_uuid(),v_staff,'UPDATE_PRODUCT_COST','PRODUCT',v_after.id,
   jsonb_build_object('cost_price',v_before.cost_price),jsonb_build_object('cost_price',v_after.cost_price),
   jsonb_build_object('source','POS_COST_MANAGER','sku',v_after.sku));
 RETURN jsonb_build_object('id',v_after.id,'sku',v_after.sku,'name',v_after.name,
 'category',v_after.category,'cost_price',v_after.cost_price,'sell_price',v_after.sell_price);
END $$;
REVOKE ALL ON FUNCTION public.rt_product_cost_update(uuid,numeric) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.rt_product_cost_update(uuid,numeric) TO authenticated;

CREATE OR REPLACE FUNCTION public.rt_service_cost_upsert(p_service_name text,p_cost_per_service numeric)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE v_company uuid; v_key text; v_name text; v_row public.rt_service_costs%ROWTYPE;
BEGIN
 IF auth.uid() IS NULL OR lower(coalesce(public.get_my_staff_role(),'')) NOT IN ('owner','admin','super_admin')
 THEN RAISE EXCEPTION 'Owner/Admin sahaja'; END IF;
 v_company:=public.get_my_company_id();
 v_name:=btrim(coalesce(p_service_name,'')); v_key:=regexp_replace(lower(v_name),'[[:space:]]+',' ','g');
 IF v_company IS NULL OR length(v_name)<2 OR length(v_name)>160 THEN RAISE EXCEPTION 'Nama servis tidak sah'; END IF;
 IF p_cost_per_service IS NULL OR p_cost_per_service<0 OR p_cost_per_service<>round(p_cost_per_service,2)
 THEN RAISE EXCEPTION 'Kos servis tidak sah'; END IF;
 INSERT INTO public.rt_service_costs(company_id,service_key,service_name,cost_per_service)
 VALUES(v_company,v_key,v_name,p_cost_per_service)
 ON CONFLICT(company_id,service_key) DO UPDATE
 SET service_name=excluded.service_name,cost_per_service=excluded.cost_per_service,updated_at=now()
 RETURNING * INTO v_row;
 RETURN jsonb_build_object('id',v_row.id,'service_name',v_row.service_name,'cost_per_service',v_row.cost_per_service);
END $$;
REVOKE ALL ON FUNCTION public.rt_service_cost_upsert(text,numeric) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.rt_service_cost_upsert(text,numeric) TO authenticated;

CREATE OR REPLACE FUNCTION public.rt_service_cost_list()
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE v_company uuid; v_result jsonb;
BEGIN
 IF auth.uid() IS NULL OR lower(coalesce(public.get_my_staff_role(),'')) NOT IN ('owner','admin','super_admin')
 THEN RAISE EXCEPTION 'Owner/Admin sahaja'; END IF;
 v_company:=public.get_my_company_id();
 SELECT coalesce(jsonb_agg(jsonb_build_object('service_name',service_name,'cost_per_service',cost_per_service) ORDER BY service_name),'[]'::jsonb)
 INTO v_result FROM public.rt_service_costs WHERE company_id=v_company;
 RETURN v_result;
END $$;
REVOKE ALL ON FUNCTION public.rt_service_cost_list() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.rt_service_cost_list() TO authenticated;

-- Existing checkout RPCs insert into invoice_items. This AFTER INSERT hook records the
-- current product cost (or a named standalone service rule) in a private ledger.
-- It is NOT a second stock deduction or a second invoice charge.
CREATE OR REPLACE FUNCTION public.rt_capture_invoice_cost_snapshot()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE v_company uuid; v_cost numeric(14,2); v_source text:='UNMAPPED'; v_key text;
BEGIN
 SELECT i.company_id INTO v_company FROM public.invoices i WHERE i.id=NEW.invoice_id;
 IF v_company IS NULL THEN RAISE EXCEPTION 'Invoice company not found for cost snapshot'; END IF;
 IF NEW.product_id IS NOT NULL THEN
   SELECT p.cost_price INTO v_cost FROM public.products p WHERE p.id=NEW.product_id AND p.company_id=v_company;
   IF FOUND THEN v_source:='PRODUCT'; END IF;
 ELSIF upper(coalesce(NEW.job_item_type,'')) IN ('SERVICE','LABOUR') THEN
   v_key:=regexp_replace(lower(btrim(coalesce(NEW.description,''))),'[[:space:]]+',' ','g');
   SELECT s.cost_per_service INTO v_cost FROM public.rt_service_costs s
   WHERE s.company_id=v_company AND s.service_key=v_key;
   IF FOUND THEN v_source:='SERVICE_RULE'; END IF;
 ELSIF upper(coalesce(NEW.job_item_type,''))='OTHER' THEN
   v_cost:=0;v_source:='NON_COST';
 END IF;
 INSERT INTO public.rt_sale_cost_snapshots(invoice_item_id,company_id,invoice_id,product_id,service_description,
 quantity,unit_cost_snapshot,total_cost_snapshot,capture_source)
 VALUES(NEW.id,v_company,NEW.invoice_id,NEW.product_id,NEW.description,NEW.quantity,
 v_cost,CASE WHEN v_cost IS NOT NULL THEN round(greatest(0,v_cost*NEW.quantity),2) ELSE NULL END,v_source);
 RETURN NULL;
END $$;
REVOKE ALL ON FUNCTION public.rt_capture_invoice_cost_snapshot() FROM PUBLIC,anon,authenticated;
DROP TRIGGER IF EXISTS rt_capture_invoice_cost_snapshot_tg ON public.invoice_items;
CREATE TRIGGER rt_capture_invoice_cost_snapshot_tg AFTER INSERT ON public.invoice_items
 FOR EACH ROW EXECUTE FUNCTION public.rt_capture_invoice_cost_snapshot();

COMMIT;
NOTIFY pgrst, 'reload schema';
