# REV TORQ Customer PWA V182 · POS Customer Link FIX 1

## Punca yang disahkan dalam ZIP asal

- `js/app.js` -> `ensureCustomerProfile()` membuat **INSERT pelanggan baharu** setiap kali `auth_user_id` tiada, tanpa menghubungkan rekod POS mengikut identiti yang disahkan.
- POS `js/customers.js` -> `saveCustomer()` pula sebelum ini menjana UUID baharu tanpa melakukan canonical find/create mengikut telefon. Sumber POS member (dalam `js/pos.js`) sebenarnya sudah menggunakan `rt_pos_find_or_create_customer` yang lebih betul.
- Paparan motosikal & sejarah servis website memang memuat menggunakan `customer_id`, bukan nombor telefon. Oleh itu walaupun nama/telefon sama, motosikal/invoice tidak keluar apabila ID tak sama.

## Keselamatan dan penyelesaian

**Nombor telefon yang ditaip bukan bukti pemilikan.** Pautan AUTOMATIK menggunakan input telefon sahaja akan membolehkan orang yang tahu nombor orang lain mengambil rekod servis, invois, point dan motosikal. Oleh itu, versi ini menggunakan **kod tuntutan sekali guna** dijana server dan diserahkan oleh staff POS kepada pelanggan sebenar; ia tidak mengubah proses checkout.

Aliran:
1. Staff POS pilih atau cari/daftar pelanggan dalam dialog **Pelanggan & Motosikal**.
2. Staff klik **KOD SAMBUNG CUSTOMER APP**. Supabase mengembalikan kod `RTQ-XXXX-XXXX-XXXX-XXXX-XXXX` (sah 7 hari, keluaran baharu membatalkan kod sebelumnya).
3. Pelanggan di Customer PWA:
   - ketika daftar masukkan kod pada **Kod Sambung POS** (pilihan), kemudian sahkan email dan login; atau
   - akaun web sedia ada -> **Akaun > Sambung Rekod POS**.
4. Supabase mengesahkan kod sekali guna, kemudian memaut ID POS asal (web profil belum ada), **atau** menggabungkan data POS ke profil web sedia ada (jika wujud), termasuk motor, job card, invois dan point. Konflik unik menolak transaksi penuh dan memerlukan admin.
5. Customer PWA reload data dan memaparkan senarai semasa.

## Cara pasang

**WAJIB pasang SQL pertama (sekali sahaja)** sebelum dua ZIP baru:

`supabase/migrations/20261021_pos_customer_pwa_secure_link.sql`

Jalankan di SQL Editor projek `wabtoq` selepas backup DB dan semak akaun admin. SQL hanya memasang jadual kod dan dua RPC; **tidak meminda data pelanggan sedia ada ketika pemasangan**. Selepas SQL berjaya, deploy dua ZIP di tapak masing-masing. Jangan import fail ZIP sebagai migrasi SQL.

**Jangan menggabungkan rekod berganda yang sudah aktif/dituntut oleh dua Auth ID secara automatik.** Kes sedemikian perlu pengesahan identiti dan audit manual.

## Ujian manual di staging / transaksi terkawal

1. Staff POS daftar pelanggan ujian dengan telefon baru + motor, catat Customer ID.
2. POS keluarkan kod dan salin; buka Customer PWA, buat signup dengan kod, sahkan email/login.
3. Semak motor, model, plate, point, invois (jika ada); `customers.auth_user_id` mesti dipautkan kepada customer sebenar.
4. Untuk existing web account, keluarkan kod kepada rekod POS yang belum dipautkan; claim dari halaman Akaun, pastikan POS/customer web tinggal **satu rekod aktif** dan ID pada vehicle/invoice/job selari.
5. Cuba tuntut semula kod sama: mesti ditolak. Tukar kod dan cuba tamat tempoh: mesti ditolak. Akaun lain dan staff tanpa hak tidak boleh mengeluarkan kod.
6. POS cashier masih boleh jual barang, simpan motor, print resit dan urus inventori. PWA masih boleh buka 3D Garage.

**Had:** Integrasi sebenar perlu SQL + kedua-dua deploy; fail ini telah diuji sintaks/static sahaja, tidak pernah menjalankan tuntutan pada rekod production. Legacy RPC `rt_customer_claim_or_create_profile` yang mempunyai tuntutan berdasarkan telefon tanpa OTP masih wujud di DB lama; audit dan tutup akses RPC lama setelah semua versi web/klien lama dipastikan tidak memerlukannya.
