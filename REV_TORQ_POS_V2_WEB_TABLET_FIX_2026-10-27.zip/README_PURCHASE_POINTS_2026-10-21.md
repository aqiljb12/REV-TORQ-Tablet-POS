# REV TORQ POS — Purchase Points Settings

Source: `REV_TORQ_POS_V2_CUSTOMER_LINK_FIX_2026-10-21.zip` (same POS as the previous customer-link fix).

## What changed

- Admin/Owner: open POS > Pelanggan & Motosikal > `⚙ SET POINT BELIAN`.
- Configure **RM spending for 1 point** and toggle each category ON/OFF. E.g. MINYAK 1.00, TAYAR 2.00, SPAREPART 5.00, AKSESORI 5.00.
- All purchase point categories are **OFF on SQL installation** to avoid unexpectedly giving away loyalty rewards. Owner/Admin must explicitly enable them and save.
- `BARANG LUAR` is OFF; `SERVIS` cannot be enabled in retail purchase setting.
- Only new **PAID** retail POS invoices (no Job Card), with selected customer and a saved phone number, qualify. Standalone service/labour/other-charge lines never earn retail points.
- Existing fixed service points (oil 10, periodic 20, CVT 20 etc) are left untouched.
- Discounts apply before purchase points. The order-wide discount is apportioned to eligible category totals.
- Receipt/Customer PWA show the resulting balance using existing `loyalty_accounts` / `loyalty_transactions`. Server writes are idempotent per invoice.
- Voiding a paid invoice automatically creates a points reversal. Partial returns/exchanges are not implemented; handle these under the workshop's return policy.

## Installation order (do NOT silently change production)

1. Back up production Supabase first.
2. Run `migration_2026_10_21_pos_purchase_points_settings.sql` ONCE in Supabase SQL Editor (project wabtoq). It creates 1 table, 2 restricted RPCs and 1 new retail-only invoice trigger. No historical customer point balances are changed, and all purchase categories start OFF.
3. Deploy the new POS ZIP (or deploy its `index.html` plus `js/rt-purchase-points.js` to the web root). **Customer PWA does not need to be redeployed** for this feature.
4. Login as owner/admin, open POS > Pelanggan > ⚙ SET POINT BELIAN, switch ON eligible categories and click SIMPAN SEMUA TETAPAN.
5. Do a controlled *real* retail sale with one test customer and 2 product categories; see that points display in Customer PWA. Test also a walk-in sale without customer, sale with a job card, dyno, a discount, void, and retry checkout (no duplicate points).

## Important loyalty economics

Purchase points add to the SAME `loyalty_accounts.balance` as service/daily check-in. The Customer PWA curated catalog currently includes RM5/500 point, RM10/1000 point, RM20/2000 point (1% equivalent for RM1=1 point). Supabase also has older active reward records (including a legacy RM20 / 100 point); verify that old rewards cannot be redeemed unrestricted before marketing new spending points.

## Limitations

- No database migration, live customer edits, or production deployment has been performed in this package build.
- SQL has been reviewed statically only; test on staging/live controlled sale after migration.
- User interface tests and existing POS regression tests do NOT substitute for running the SQL against a production clone and exercising actual checkout RPCs.
- Changes to purchase rules apply prospectively, not retroactively.
- Don't run the old `migration_2026_09_18_loyalty_phone_member_claim.sql` again: it contains a DIFFERENT spend-based trigger which would overwrite the CURRENT fixed-service rules.
