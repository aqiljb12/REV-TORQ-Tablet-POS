# REV TORQ — Link Point pada Resit WhatsApp

Versi: 27 Oktober 2026. Ini kemas kini kepada ZIP POS V2 AI Scan Invois Supplier.

## Perubahan
- Resit teks WhatsApp menyertakan `https://revtorq.com.my/?tab=profile` dan ajakan semak Point & Voucher.
- WhatsApp resit PDF (native share dan fallback) menyertakan pautan sama dalam mesej. Pautan juga dicetak sebagai teks dalam PDF supaya pelanggan boleh baca apabila aplikasi perkongsian tidak menghantar caption.
- Teks resit cetakan thermal biasa tidak berubah.
- Semua pautan pergi ke profil pelanggan berlogin; tiada ID pelanggan, telefon, token atau baki poin yang dihantar dalam URL.
- Tiada migrasi SQL / API key baharu diperlukan untuk perubahan pautan ini.
- Versi script diberi cache-busting query supaya tablet memuatkan fail JavaScript terkini.

## Pasang
Deploy seluruh ZIP POS ini ke hosting POS sedia ada. Jangan deploy ke `revtorq.com.my` kerana itu PWA pelanggan. Dalam POS, buat resit ujian dan tekan WHATSAPP; pastikan mesej ada pautan. Uji butang PDF juga.

## Perhatian
- Link profil berfungsi bagi pengguna yang telah log masuk; pengguna belum berdaftar perlu daftar/log masuk terlebih dahulu.
- Link tidak memberikan mata ganjaran; pemberian point bergantung pada konfigurasi loyalty dalam Supabase dan link akaun pelanggan.
- Penghantaran WhatsApp masih melalui wa.me/share sheet dan memerlukan cashier menghantar secara manual.
- Fail PDF yang dikongsi melalui sesetengah peranti mungkin tidak menyertakan teks WhatsApp sebagai caption; pautan turut ada di dalam PDF sebagai fallback.
- Tiada Supabase database, product, stock, customer, invoice, atau loyalty row diubah oleh patch ini.
