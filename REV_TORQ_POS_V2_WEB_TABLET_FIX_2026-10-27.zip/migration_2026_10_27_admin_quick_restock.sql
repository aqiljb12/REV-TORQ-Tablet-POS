-- REV TORQ / ADMIN POS / QUICK RESTOK, 2026-10-27
-- Run AFTER migration_2026_10_27_admin_inventory_control.sql.
-- Safe installation: does not modify existing stock, product records or old ledger entries.
begin;
create table if not exists public.rt_inv_admin_quick_restocks (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id),
  location_id uuid not null references public.locations(id),
  product_id uuid not null references public.products(id),
  request_id uuid not null,
  quantity numeric not null check (quantity>0 and quantity<=99999),
  unit_cost numeric not null check (unit_cost>=0 and unit_cost<=10000000),
  movement_id uuid references public.stock_movements(id),
  note text,
  created_by uuid not null references public.staff(id),
  created_at timestamptz not null default now(),
  unique(company_id,request_id)
);
create index if not exists rt_inv_quick_restock_product_idx on public.rt_inv_admin_quick_restocks(product_id,created_at desc);
alter table public.rt_inv_admin_quick_restocks enable row level security;
revoke all on public.rt_inv_admin_quick_restocks from anon,authenticated;
-- All reads/writes to this table are through the admin-only RPC below, not through direct API.

create or replace function public.rt_inv_admin_quick_restock(
  p_product_id uuid, p_location_id uuid, p_quantity numeric, p_unit_cost numeric,
  p_request_id uuid, p_note text default null
) returns jsonb
language plpgsql security definer set search_path='public','pg_temp' as $$
declare
  c record;
  p public.products%rowtype;
  r public.rt_inv_admin_quick_restocks%rowtype;
  v_stock_before numeric;
  v_stock_after numeric;
  v_movement uuid;
begin
  select * into c from public.rt_inv_admin_context();
  if p_request_id is null then raise exception 'REQUEST_ID_REQUIRED'; end if;
  if p_quantity is null or p_quantity<>trunc(p_quantity) or p_quantity<=0 or p_quantity>99999 then
    raise exception 'RESTOCK_QTY_INVALID';
  end if;
  if p_unit_cost is null or p_unit_cost<0 or p_unit_cost>10000000 then
    raise exception 'RESTOCK_COST_INVALID';
  end if;
  if p_note is not null and length(p_note)>350 then raise exception 'RESTOCK_NOTE_TOO_LONG'; end if;
  if not exists(select 1 from public.locations l where l.id=p_location_id and l.company_id=c.company_id and l.active=true) then
    raise exception 'INVALID_LOCATION';
  end if;
  select * into p from public.products where id=p_product_id and company_id=c.company_id and active=true for share;
  if not found then raise exception 'PRODUCT_NOT_FOUND'; end if;
  if p.category='SERVIS' then raise exception 'SERVICE_CANNOT_RESTOCK'; end if;

  -- Unique request id makes HTTP retries and double-taps idempotent.
  insert into public.rt_inv_admin_quick_restocks
    (company_id,location_id,product_id,request_id,quantity,unit_cost,note,created_by)
  values(c.company_id,p_location_id,p_product_id,p_request_id,p_quantity,p_unit_cost,
         nullif(btrim(p_note),''),c.staff_id)
  on conflict(company_id,request_id) do nothing returning * into r;
  if r.id is null then
    select * into r from public.rt_inv_admin_quick_restocks where company_id=c.company_id and request_id=p_request_id;
    if r.id is null then raise exception 'RESTOCK_RETRY_REFRESH'; end if;
    if r.product_id<>p_product_id or r.location_id<>p_location_id or r.quantity<>p_quantity or r.unit_cost<>p_unit_cost then
      raise exception 'RESTOCK_REQUEST_REUSED';
    end if;
    select coalesce(sb.quantity,0) into v_stock_after from public.stock_balances sb
      where sb.product_id=p_product_id and sb.location_id=p_location_id;
    return jsonb_build_object('id',r.id,'quantity',r.quantity,'sku',p.sku,
      'stock_after',coalesce(v_stock_after,0),'replayed',true,'movement_id',r.movement_id);
  end if;
  select coalesce(sb.quantity,0) into v_stock_before from public.stock_balances sb
    where sb.product_id=p_product_id and sb.location_id=p_location_id;
  v_stock_before:=coalesce(v_stock_before,0);
  v_movement:=public.post_stock_movement(
    c.company_id,p_location_id,p_product_id,'PURCHASE',p_quantity,p_unit_cost,
    'INV_QUICK_RESTOCK',r.id,c.staff_id,null,p_request_id
  );
  update public.rt_inv_admin_quick_restocks set movement_id=v_movement where id=r.id;
  select quantity into v_stock_after from public.stock_balances
    where product_id=p_product_id and location_id=p_location_id;
  insert into public.audit_logs
    (company_id,location_id,transaction_id,staff_id,action,entity_type,entity_id,before_data,after_data,metadata)
  values(c.company_id,p_location_id,p_request_id,c.staff_id,'INV_ADMIN_QUICK_RESTOCK',
    'PRODUCT',p.id,jsonb_build_object('stock',v_stock_before),
    jsonb_build_object('stock',v_stock_after),
    jsonb_build_object('restock_id',r.id,'quantity',p_quantity,'unit_cost',p_unit_cost,'movement_id',v_movement,'note',p_note));
  return jsonb_build_object('id',r.id,'quantity',p_quantity,'sku',p.sku,
    'stock_before',v_stock_before,'stock_after',v_stock_after,
    'replayed',false,'movement_id',v_movement);
end;$$;
revoke all on function public.rt_inv_admin_quick_restock(uuid,uuid,numeric,numeric,uuid,text) from public,anon;
grant execute on function public.rt_inv_admin_quick_restock(uuid,uuid,numeric,numeric,uuid,text) to authenticated;
commit;
