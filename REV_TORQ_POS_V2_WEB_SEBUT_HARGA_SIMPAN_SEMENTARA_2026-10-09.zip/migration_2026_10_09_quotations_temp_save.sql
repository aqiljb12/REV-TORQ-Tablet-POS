-- REV TORQ POS V2 — SEBUT HARGA: SIMPAN SEMENTARA (2026-10-09)
--
-- WHY
--   A quotation that is still being typed (no customer name yet, a price missing, no rows yet) could only be kept on the
--   device it was typed on. This lets the "SIMPAN SEMENTARA" button put an unfinished quotation into the shared database
--   as a DRAFT, so it can be opened again from the list on any device.
--
-- WHAT THIS DOES (it only touches the 3 Sebut Harga tables / 5 functions from migration_2026_10_08_quotations.sql)
--   * Adds one column: quotations.is_partial (false for everything that exists today).
--   * rt_quote_save: new optional field "partial": true. A partial save may have a blank customer name, no rows, blank
--     rows (dropped), a missing quantity (-> 1), a missing price (-> 0) and a discount bigger than the subtotal (-> cut
--     down to the subtotal). It is only allowed for a NEW quotation or one that is still a DRAFT.
--     Without "partial" nothing changes: every rule of the 2026-10-08 file still applies word for word,
--     and a normal save clears is_partial.
--   * An unfinished quotation (is_partial) cannot be marked SENT or ACCEPTED (QUOTE_INCOMPLETE). It can still be
--     edited, rejected or cancelled. The app also hides PDF / WhatsApp for it until it is saved complete.
--   * rt_quote_list returns is_partial; rt_quote_ready now answers version 2 (the app uses it to know this file was run).
--   Same roles, same RPC-only access, same audit trail (the audit row says partial = true / false).
--
-- HOW TO RUN (Supabase -> SQL Editor): run migration_2026_10_08_quotations.sql first (you already did), then this file
--   in one go. One transaction: if anything fails, nothing is changed.
--   Rollback: run migration_2026_10_08_quotations.sql again (it puts the previous functions back). The extra column is
--   harmless and can stay.

begin;

do $check$
begin
  if to_regclass('public.quotations') is null or to_regprocedure('public.rt_quote_save(jsonb)') is null then
    raise exception 'RUN_MIGRATION_2026_10_08_QUOTATIONS_FIRST';
  end if;
end
$check$;

alter table public.quotations add column if not exists is_partial boolean not null default false;

create or replace function public.rt_quote_ready()
returns jsonb
language sql
stable
set search_path = public, pg_temp
as $$ select jsonb_build_object('ready', true, 'version', 2) $$;

-- =====================================================================
-- SAVE (create or edit)  — as 2026-10-08, plus the optional "partial" mode
-- =====================================================================
create or replace function public.rt_quote_save(p_quote jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  v_staff     record;
  v_q         public.quotations%rowtype;
  v_before    jsonb;
  v_id        uuid;
  v_ref       text;
  v_type      text;
  v_name      text;
  v_phone     text;
  v_plate     text;
  v_model     text;
  v_title     text;
  v_notes     text;
  v_valid     date;
  v_disc      numeric;
  v_sub       numeric := 0;
  v_cust      uuid;
  v_veh       uuid;
  v_item      jsonb;
  v_items     jsonb;
  v_partial   boolean := false;
  v_n         int := 0;
  v_desc      text;
  v_qty       numeric;
  v_price     numeric;
  v_kind      text;
  v_prod      uuid;
  v_sku       text;
  v_line      numeric;
  v_year      int;
  v_no        int;
  v_prefix    text;
  v_action    text;
  v_today     date := (now() at time zone 'Asia/Kuala_Lumpur')::date;
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into v_staff from public.rt_staff_context() limit 1;
  if v_staff.staff_id is null then raise exception 'STAFF_ONLY'; end if;
  if lower(coalesce(v_staff.role,'')) not in ('owner','admin','super_admin','manager','cashier','pos','staff') then
    raise exception 'QUOTE_ROLE_NOT_ALLOWED';
  end if;
  if p_quote is null or jsonb_typeof(p_quote) <> 'object' then raise exception 'QUOTE_INVALID'; end if;

  begin v_partial := coalesce((p_quote->>'partial')::boolean, false); exception when others then v_partial := false; end;

  -- ---- read + clean the fields (never trust lengths from the browser)
  v_name  := left(btrim(coalesce(p_quote->>'customer_name','')), 120);
  v_phone := left(btrim(coalesce(p_quote->>'customer_phone','')), 40);
  v_plate := upper(left(btrim(coalesce(p_quote->>'plate_no','')), 20));
  v_model := left(btrim(coalesce(p_quote->>'vehicle_model','')), 80);
  v_title := left(btrim(coalesce(p_quote->>'title','')), 160);
  v_notes := left(btrim(coalesce(p_quote->>'notes','')), 2000);
  v_ref   := nullif(left(btrim(coalesce(p_quote->>'client_ref','')), 80), '');
  if v_name = '' and not v_partial then raise exception 'QUOTE_CUSTOMER_REQUIRED'; end if;

  begin
    v_valid := nullif(btrim(coalesce(p_quote->>'valid_until','')), '')::date;
  exception when others then
    raise exception 'QUOTE_VALID_UNTIL_INVALID';
  end;

  begin
    v_disc := round(coalesce(nullif(btrim(coalesce(p_quote->>'discount','')), '')::numeric, 0), 2);
  exception when others then
    if v_partial then v_disc := 0; else raise exception 'QUOTE_DISCOUNT_INVALID'; end if;
  end;
  if v_disc < 0 then
    if v_partial then v_disc := 0; else raise exception 'QUOTE_DISCOUNT_INVALID'; end if;
  end if;

  if jsonb_typeof(p_quote->'items') = 'array' then
    v_items := p_quote->'items';
  elsif v_partial then
    v_items := '[]'::jsonb;
  else
    raise exception 'QUOTE_ITEMS_REQUIRED';
  end if;
  if jsonb_array_length(v_items) = 0 and not v_partial then raise exception 'QUOTE_ITEMS_REQUIRED'; end if;
  if jsonb_array_length(v_items) > 80 then raise exception 'QUOTE_TOO_MANY_ITEMS'; end if;

  -- Optional links to existing customer / motorcycle: must belong to this company.
  v_cust := null; v_veh := null;
  begin v_cust := nullif(p_quote->>'customer_id','')::uuid; exception when others then v_cust := null; end;
  begin v_veh  := nullif(p_quote->>'vehicle_id','')::uuid;  exception when others then v_veh := null; end;
  if v_cust is not null and not exists
     (select 1 from public.customers c where c.id = v_cust and c.company_id = v_staff.company_id) then
    v_cust := null;
  end if;
  if v_veh is not null and not exists
     (select 1 from public.vehicles v where v.id = v_veh and v.company_id = v_staff.company_id) then
    v_veh := null;
  end if;

  -- ---- find the quotation (edit) or an earlier save of the same client_ref (retry)
  v_id := null;
  begin v_id := nullif(p_quote->>'id','')::uuid; exception when others then raise exception 'QUOTE_NOT_FOUND'; end;

  if v_id is null and v_ref is not null then
    select q.id into v_id from public.quotations q
     where q.company_id = v_staff.company_id and q.client_ref = v_ref;
    if v_id is not null then
      return public.rt_quote_json(v_id) || jsonb_build_object('duplicate', true);
    end if;
  end if;

  if v_id is not null then
    -- ===== EDIT
    select * into v_q from public.quotations q
     where q.id = v_id and q.company_id = v_staff.company_id for update;
    if not found then raise exception 'QUOTE_NOT_FOUND'; end if;
    if v_q.status not in ('DRAFT','SENT') then raise exception 'QUOTE_LOCKED'; end if;
    if v_partial and v_q.status <> 'DRAFT' then raise exception 'QUOTE_PARTIAL_ONLY_DRAFT'; end if;
    if nullif(p_quote->>'expected_revision','') is not null
       and (p_quote->>'expected_revision')::int <> v_q.revision then
      raise exception 'QUOTE_CHANGED';
    end if;
    v_before := public.rt_quote_json(v_id);
    v_type := v_q.quote_type;                       -- the kind never changes after creation
    v_action := 'QUOTE_UPDATED';
    delete from public.quotation_items where quotation_id = v_id;
  else
    -- ===== CREATE
    v_type := upper(btrim(coalesce(p_quote->>'quote_type','')));
    if v_type not in ('UBAH_SUAI','SERVIS') then raise exception 'QUOTE_TYPE_INVALID'; end if;
    v_year := extract(year from (now() at time zone 'Asia/Kuala_Lumpur'))::int;
    insert into public.quotation_counters(company_id, quote_type, yr, last_no)
    values (v_staff.company_id, v_type, v_year, 1)
    on conflict (company_id, quote_type, yr)
    do update set last_no = public.quotation_counters.last_no + 1
    returning last_no into v_no;
    v_prefix := case v_type when 'UBAH_SUAI' then 'UBS' else 'SRV' end;
    insert into public.quotations(company_id, location_id, quote_type, quote_no, client_ref, status,
                                  customer_name, subtotal, discount, total, created_by, updated_by)
    values (v_staff.company_id, v_staff.location_id, v_type,
            v_prefix || '-' || v_year || '-' || lpad(v_no::text, 4, '0'), v_ref, 'DRAFT',
            v_name, 0, 0, 0, v_staff.staff_id, v_staff.staff_id)
    returning id into v_id;
    v_before := null;
    v_action := 'QUOTE_CREATED';
  end if;

  -- ---- items (qty x price is calculated here, the browser's totals are ignored)
  for v_item in select * from jsonb_array_elements(v_items) loop
    v_desc := left(btrim(coalesce(v_item->>'description','')), 200);
    if v_desc = '' then
      if v_partial then continue; end if;           -- unfinished: a blank row is simply dropped
      raise exception 'QUOTE_ITEM_DESCRIPTION_REQUIRED';
    end if;
    if v_partial then
      v_qty := null; v_price := null;
      begin v_qty := round(nullif(btrim(coalesce(v_item->>'quantity','')), '')::numeric, 2); exception when others then v_qty := null; end;
      begin v_price := round(nullif(btrim(coalesce(v_item->>'unit_price','')), '')::numeric, 2); exception when others then v_price := null; end;
      if v_qty is null or v_qty <= 0 or v_qty > 99999 then v_qty := 1; end if;
      if v_price is null or v_price < 0 or v_price > 9999999 then v_price := 0; end if;
    else
      begin
        v_qty   := round((v_item->>'quantity')::numeric, 2);
        v_price := round((v_item->>'unit_price')::numeric, 2);
      exception when others then
        raise exception 'QUOTE_ITEM_NUMBER_INVALID';
      end;
      if v_qty is null or v_qty <= 0 or v_qty > 99999 then raise exception 'QUOTE_ITEM_QTY_INVALID'; end if;
      if v_price is null or v_price < 0 or v_price > 9999999 then raise exception 'QUOTE_ITEM_PRICE_INVALID'; end if;
    end if;
    v_kind := upper(btrim(coalesce(v_item->>'kind','PART')));
    if v_kind not in ('PART','LABOUR','OTHER') then v_kind := 'PART'; end if;
    v_sku := nullif(left(btrim(coalesce(v_item->>'sku','')), 60), '');
    v_prod := null;
    begin v_prod := nullif(v_item->>'product_id','')::uuid; exception when others then v_prod := null; end;
    if v_prod is not null and not exists
       (select 1 from public.products p where p.id = v_prod and p.company_id = v_staff.company_id) then
      v_prod := null;
    end if;
    v_line := round(v_qty * v_price, 2);
    v_n := v_n + 1;
    v_sub := v_sub + v_line;
    insert into public.quotation_items(company_id, quotation_id, line_no, kind, product_id, sku,
                                       description, quantity, unit_price, line_total)
    values (v_staff.company_id, v_id, v_n, v_kind, v_prod, v_sku, v_desc, v_qty, v_price, v_line);
  end loop;

  if v_disc > v_sub then
    if v_partial then v_disc := v_sub; else raise exception 'QUOTE_DISCOUNT_TOO_BIG'; end if;
  end if;
  if v_sub > 99999999 then raise exception 'QUOTE_TOTAL_TOO_BIG'; end if;

  update public.quotations q set
         customer_id = v_cust, vehicle_id = v_veh,
         customer_name = v_name, customer_phone = nullif(v_phone,''), plate_no = nullif(v_plate,''),
         vehicle_model = nullif(v_model,''), title = nullif(v_title,''), notes = nullif(v_notes,''),
         valid_until = coalesce(v_valid, case when v_action = 'QUOTE_CREATED' then v_today + 14 else q.valid_until end),
         subtotal = v_sub, discount = v_disc, total = v_sub - v_disc,
         is_partial = v_partial,
         revision = case when v_action = 'QUOTE_UPDATED' then q.revision + 1 else q.revision end,
         updated_by = v_staff.staff_id, updated_at = now()
   where q.id = v_id;

  insert into public.audit_logs(company_id, location_id, staff_id, action, entity_type, entity_id, before_data, after_data, metadata)
  values (v_staff.company_id, v_staff.location_id, v_staff.staff_id, v_action, 'QUOTATION', v_id,
          case when v_before is null then null
               else jsonb_build_object('status', v_before->>'status', 'subtotal', v_before->'subtotal',
                                       'discount', v_before->'discount', 'total', v_before->'total',
                                       'items', jsonb_array_length(v_before->'items'),
                                       'customer_name', v_before->>'customer_name') end,
          jsonb_build_object('subtotal', v_sub, 'discount', v_disc, 'total', v_sub - v_disc,
                             'items', v_n, 'customer_name', v_name),
          jsonb_build_object('quote_no', (select quote_no from public.quotations where id = v_id),
                             'quote_type', v_type, 'role', v_staff.role, 'partial', v_partial));

  return public.rt_quote_json(v_id) || jsonb_build_object('duplicate', false);
end;
$function$;

-- =====================================================================
-- STATUS CHANGE — as 2026-10-08, plus: an unfinished quotation cannot be SENT or ACCEPTED
-- =====================================================================
create or replace function public.rt_quote_set_status(p_id uuid, p_status text, p_reason text default null)
returns jsonb
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  v_staff  record;
  v_q      public.quotations%rowtype;
  v_to     text := upper(btrim(coalesce(p_status,'')));
  v_reason text := nullif(left(btrim(coalesce(p_reason,'')), 300), '');
  v_allowed boolean;
  v_admin  boolean;
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into v_staff from public.rt_staff_context() limit 1;
  if v_staff.staff_id is null then raise exception 'STAFF_ONLY'; end if;
  v_admin := lower(coalesce(v_staff.role,'')) in ('owner','admin','super_admin','manager');
  if not v_admin and lower(coalesce(v_staff.role,'')) not in ('cashier','pos','staff') then
    raise exception 'QUOTE_ROLE_NOT_ALLOWED';
  end if;
  if v_to not in ('DRAFT','SENT','ACCEPTED','REJECTED','CANCELLED') then raise exception 'QUOTE_STATUS_INVALID'; end if;

  select * into v_q from public.quotations q
   where q.id = p_id and q.company_id = v_staff.company_id for update;
  if not found then raise exception 'QUOTE_NOT_FOUND'; end if;

  if v_q.status = v_to then
    return public.rt_quote_json(p_id) || jsonb_build_object('unchanged', true);
  end if;

  v_allowed := case v_q.status
    when 'DRAFT'    then v_to in ('SENT','ACCEPTED','REJECTED','CANCELLED')
    when 'SENT'     then v_to in ('ACCEPTED','REJECTED','CANCELLED')
    when 'REJECTED' then v_to in ('SENT','CANCELLED')
    when 'ACCEPTED' then v_to = 'CANCELLED'
    else false end;
  if not v_allowed then raise exception 'QUOTE_STATUS_NOT_ALLOWED'; end if;
  if v_q.is_partial and v_to in ('SENT','ACCEPTED') then raise exception 'QUOTE_INCOMPLETE'; end if;
  if v_q.status = 'ACCEPTED' and not v_admin then raise exception 'QUOTE_ADMIN_ONLY'; end if;
  if v_to = 'CANCELLED' and v_reason is null then raise exception 'QUOTE_REASON_REQUIRED'; end if;

  update public.quotations q set
         status = v_to,
         status_note = case when v_to in ('REJECTED','CANCELLED') then v_reason else null end,
         sent_at = case when v_to = 'SENT' then coalesce(q.sent_at, now()) else q.sent_at end,
         decided_at = case when v_to in ('ACCEPTED','REJECTED') then now()
                           when v_to = 'SENT' then null else q.decided_at end,
         cancelled_at = case when v_to = 'CANCELLED' then now() else q.cancelled_at end,
         revision = q.revision + 1,
         updated_by = v_staff.staff_id, updated_at = now()
   where q.id = p_id;

  insert into public.audit_logs(company_id, location_id, staff_id, action, entity_type, entity_id, before_data, after_data, metadata)
  values (v_staff.company_id, v_staff.location_id, v_staff.staff_id, 'QUOTE_STATUS', 'QUOTATION', p_id,
          jsonb_build_object('status', v_q.status), jsonb_build_object('status', v_to),
          jsonb_build_object('quote_no', v_q.quote_no, 'quote_type', v_q.quote_type,
                             'reason', v_reason, 'total', v_q.total, 'role', v_staff.role));

  return public.rt_quote_json(p_id) || jsonb_build_object('unchanged', false);
end;
$function$;

-- =====================================================================
-- LIST — as 2026-10-08, plus is_partial on every row
-- =====================================================================
create or replace function public.rt_quote_list(
  p_type   text default null,
  p_status text default null,
  p_search text default null,
  p_limit  int  default 30,
  p_offset int  default 0)
returns jsonb
language plpgsql
stable
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  v_staff  record;
  v_type   text := nullif(upper(btrim(coalesce(p_type,''))), '');
  v_status text := nullif(upper(btrim(coalesce(p_status,''))), '');
  v_s      text := nullif(btrim(coalesce(p_search,'')), '');
  v_lim    int  := least(greatest(coalesce(p_limit,30), 1), 100);
  v_off    int  := greatest(coalesce(p_offset,0), 0);
  v_pat    text;
  v_rows   jsonb;
  v_n      int;
  v_counts jsonb;
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into v_staff from public.rt_staff_context() limit 1;
  if v_staff.staff_id is null then raise exception 'STAFF_ONLY'; end if;
  if lower(coalesce(v_staff.role,'')) not in ('owner','admin','super_admin','manager','cashier','pos','staff') then
    raise exception 'QUOTE_ROLE_NOT_ALLOWED';
  end if;
  if v_type is not null and v_type not in ('UBAH_SUAI','SERVIS') then raise exception 'QUOTE_TYPE_INVALID'; end if;
  if v_status is not null and v_status not in ('DRAFT','SENT','ACCEPTED','REJECTED','CANCELLED') then
    raise exception 'QUOTE_STATUS_INVALID';
  end if;
  v_pat := case when v_s is null then null
                else '%' || replace(replace(replace(lower(v_s), '\', '\\'), '%', '\%'), '_', '\_') || '%' end;

  select coalesce(jsonb_object_agg(t.status, t.n), '{}'::jsonb) into v_counts
    from (select q.status, count(*)::int as n from public.quotations q
           where q.company_id = v_staff.company_id and (v_type is null or q.quote_type = v_type)
           group by q.status) t;

  select coalesce(jsonb_agg(r.j order by r.created_at desc, r.id desc), '[]'::jsonb), count(*)::int
    into v_rows, v_n
    from (select q.id, q.created_at,
                 jsonb_build_object('id', q.id, 'quote_type', q.quote_type, 'quote_no', q.quote_no, 'status', q.status,
                                    'revision', q.revision, 'customer_name', q.customer_name,
                                    'customer_phone', q.customer_phone, 'plate_no', q.plate_no,
                                    'vehicle_model', q.vehicle_model, 'title', q.title,
                                    'valid_until', q.valid_until, 'total', q.total, 'created_at', q.created_at,
                                    'updated_at', q.updated_at, 'sent_at', q.sent_at, 'is_partial', q.is_partial,
                                    'expired', (q.status in ('DRAFT','SENT') and q.valid_until is not null
                                                and q.valid_until < (now() at time zone 'Asia/Kuala_Lumpur')::date)) as j
            from public.quotations q
           where q.company_id = v_staff.company_id
             and (v_type is null or q.quote_type = v_type)
             and (v_status is null or q.status = v_status)
             and (v_pat is null
                  or lower(q.quote_no) like v_pat or lower(q.customer_name) like v_pat
                  or lower(coalesce(q.customer_phone,'')) like v_pat or lower(coalesce(q.plate_no,'')) like v_pat
                  or lower(coalesce(q.title,'')) like v_pat)
           order by q.created_at desc, q.id desc
           offset v_off limit v_lim + 1) r;

  -- one extra row was read only to know whether there is another page
  if v_n > v_lim then
    v_rows := (select coalesce(jsonb_agg(e.value order by e.ord), '[]'::jsonb)
                 from jsonb_array_elements(v_rows) with ordinality as e(value, ord) where e.ord <= v_lim);
  end if;
  return jsonb_build_object('rows', v_rows, 'has_more', v_n > v_lim, 'counts', v_counts);
end;
$function$;

-- permissions (unchanged; repeated so this file is safe on its own)
revoke all on function public.rt_quote_ready() from public;
revoke all on function public.rt_quote_save(jsonb) from public;
revoke all on function public.rt_quote_set_status(uuid, text, text) from public;
revoke all on function public.rt_quote_list(text, text, text, int, int) from public;
revoke execute on function public.rt_quote_ready() from anon;
revoke execute on function public.rt_quote_save(jsonb) from anon;
revoke execute on function public.rt_quote_set_status(uuid, text, text) from anon;
revoke execute on function public.rt_quote_list(text, text, text, int, int) from anon;
grant execute on function public.rt_quote_ready() to authenticated;
grant execute on function public.rt_quote_save(jsonb) to authenticated;
grant execute on function public.rt_quote_set_status(uuid, text, text) to authenticated;
grant execute on function public.rt_quote_list(text, text, text, int, int) to authenticated;

commit;
