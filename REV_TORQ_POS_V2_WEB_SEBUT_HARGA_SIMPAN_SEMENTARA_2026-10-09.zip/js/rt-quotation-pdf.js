/* REV TORQ POS V2 — Sebut Harga (quotation) as an A4 PDF + the WhatsApp text.
   Pure drawing code: it only turns a quotation (the object the rt_quote_* RPCs return) and the workshop profile
   into PDF bytes / text. Nothing is uploaded, no network, no Supabase. Works in the browser and in node (tests).
   Fonts are the PDF standard Helvetica / Helvetica-Bold / Helvetica-Oblique (nothing embedded, so the file stays small);
   letter widths below are the Helvetica widths (checked against Liberation Sans, which has the same metrics),
   so right-aligned numbers and wrapped lines line up. Plain ES2017-compatible code (older iPad Safari). */
(function(root){
  'use strict';

  // ------------------------------------------------------------------ page + metrics
  var PAGE_W=595.28,PAGE_H=841.89,M=40,CW=PAGE_W-2*M,FOOT=34;

  // Helvetica advance widths (1/1000 em): ASCII 32..126, then Latin-1 161..255 (160 = space)
  var WR=[278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584];
  var WRH=[333,556,556,556,556,260,556,333,737,370,556,584,333,737,552,400,549,333,333,333,576,537,333,333,333,365,556,834,834,834,611,667,667,667,667,667,667,1000,722,667,667,667,667,278,278,278,278,722,722,778,778,778,778,778,584,778,722,722,722,722,667,667,611,556,556,556,556,556,556,889,500,556,556,556,556,278,278,278,278,556,556,556,556,556,556,556,549,611,556,556,556,556,500,556,500];
  var WB=[278,333,474,556,556,889,722,238,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,333,333,584,584,584,611,975,722,722,722,722,667,611,778,722,278,556,722,611,833,722,778,667,778,722,667,611,722,667,944,667,667,611,333,278,333,584,556,333,556,611,556,611,556,333,611,611,278,278,556,278,889,611,611,611,611,389,556,333,611,556,778,556,556,500,389,280,389,584];
  var WBH=[333,556,556,556,556,280,556,333,737,370,556,584,333,737,552,400,549,333,333,333,576,556,333,333,333,365,556,834,834,834,611,722,722,722,722,722,722,1000,722,667,667,667,667,278,278,278,278,722,722,778,778,778,778,778,584,778,722,722,722,722,667,667,611,556,556,556,556,556,556,889,556,556,556,556,556,278,278,278,278,611,611,611,611,611,611,611,549,611,611,611,611,611,556,611,556];

  function num(v){var n=Number(v);return isFinite(n)?n:0;}
  function fmt(v){                                   // 1,250.50 (the app shows thousands commas)
    var s=num(v).toFixed(2),neg=s.charAt(0)==='-';if(neg)s=s.slice(1);
    var p=s.split('.');p[0]=p[0].replace(/\B(?=(\d{3})+(?!\d))/g,',');
    return (neg?'-':'')+p.join('.');
  }
  function money(v){return 'RM '+fmt(v);}
  function fmtQty(v){var n=Math.round(num(v)*100)/100;return String(n);}

  // PDF text is WinAnsi: plain ASCII and Latin-1 only; typographic marks become plain, '?' for the rest.
  function clean(s){
    s=String(s==null?'':s)
      .replace(/[\u2018\u2019\u201B]/g,"'").replace(/[\u201C\u201D]/g,'"')
      .replace(/[\u2013\u2014]/g,'-').replace(/\u2026/g,'...').replace(/\u00a0/g,' ')
      .replace(/[\r\n\t]+/g,' ');
    var out='';
    for(var i=0;i<s.length;i++){
      var c=s.charCodeAt(i);
      out+=((c>=32&&c<=126)||(c>=161&&c<=255))?s.charAt(i):'?';
    }
    return out;
  }
  function charW(c,bold){
    if(c>=32&&c<=126)return (bold?WB:WR)[c-32];
    if(c===160)return 278;
    if(c>=161&&c<=255)return (bold?WBH:WRH)[c-161];
    return 556;
  }
  function textW(text,size,bold){
    text=String(text);var w=0;
    for(var i=0;i<text.length;i++)w+=charW(text.charCodeAt(i),bold);
    return w*size/1000;
  }
  // Wrap on spaces to a pixel width; a word longer than the line is cut. Hard newlines are kept as line breaks.
  function wrapText(text,size,bold,maxW){
    var out=[];
    String(text==null?'':text).split(/\r?\n/).forEach(function(par){
      par=clean(par).replace(/\s+/g,' ').trim();
      if(!par){out.push('');return;}
      var line='';
      par.split(' ').forEach(function(word){
        while(textW(word,size,bold)>maxW){
          if(line){out.push(line);line='';}
          var k=word.length;while(k>1&&textW(word.slice(0,k),size,bold)>maxW)k--;
          out.push(word.slice(0,k));word=word.slice(k);
        }
        if(!line)line=word;
        else if(textW(line+' '+word,size,bold)<=maxW)line+=' '+word;
        else{out.push(line);line=word;}
      });
      if(line)out.push(line);
    });
    while(out.length>1&&out[out.length-1]==='')out.pop();
    return out.length?out:[''];
  }

  // ------------------------------------------------------------------ dates (Malaysia time, no daylight saving)
  function two(n){return (n<10?'0':'')+n;}
  function myParts(v){
    var d=v instanceof Date?v:new Date(v);
    if(isNaN(d))return null;
    var m=new Date(d.getTime()+8*3600*1000);
    return {y:m.getUTCFullYear(),m:m.getUTCMonth()+1,d:m.getUTCDate(),hh:m.getUTCHours(),mm:m.getUTCMinutes()};
  }
  function dateText(v){                              // 08/10/2026
    if(!v)return '';
    var s=String(v);
    var m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
    if(m)return m[3]+'/'+m[2]+'/'+m[1];              // a plain date (valid_until): no time zone shifting
    var p=myParts(v);return p?two(p.d)+'/'+two(p.m)+'/'+p.y:'';
  }
  var TYPE_LABEL={UBAH_SUAI:'UBAH SUAI',SERVIS:'SERVIS'};
  function typeLabel(t){return TYPE_LABEL[String(t||'').toUpperCase()]||String(t||'');}

  // ------------------------------------------------------------------ layout -> pages of drawing operations
  // op: {k:'t',x,y,s,f:'R'|'B'|'I',z,c,a:'l'|'r'|'c',rot}   text, y = baseline measured from the TOP of the page
  //     {k:'l',x1,y1,x2,y2,w,c}                               line
  //     {k:'r',x,y,w,h,fill,stroke}                           rectangle (y = top edge)
  var GREY=[0.42,0.42,0.42],LIGHT=[0.93,0.93,0.93],RULE=[0.78,0.78,0.78],INK=[0.07,0.07,0.07];
  function layoutQuote(q,shop,opts){
    q=q||{};shop=shop||{};opts=opts||{};
    var pages=[],ops,y;
    var items=Array.isArray(q.items)?q.items:[];
    var shopName=clean(shop.workshopName||shop.shopName||'REV TORQ WORKSHOP');

    function T(x,yy,s,z,f,o){o=o||{};ops.push({k:'t',x:x,y:yy,s:clean(s),z:z,f:f||'R',c:o.c||INK,a:o.a||'l',rot:o.rot||0});}
    function LN(x1,y1,x2,y2,w,c){ops.push({k:'l',x1:x1,y1:y1,x2:x2,y2:y2,w:w||0.6,c:c||RULE});}
    function RC(x,yy,w,h,fill,stroke){ops.push({k:'r',x:x,y:yy,w:w,h:h,fill:fill||null,stroke:stroke||null});}
    function limit(){return PAGE_H-M-FOOT;}

    function firstHeader(){
      var leftY=M,lines;
      wrapText(shopName,15,true,300).forEach(function(l){T(M,leftY+13,l,15,'B');leftY+=18;});
      String(shop.address||'').split(/\r?\n/).forEach(function(a){
        if(!String(a).trim())return;
        wrapText(a,8.5,false,300).forEach(function(l){T(M,leftY+8,l,8.5,'R',{c:GREY});leftY+=11;});
      });
      if(shop.phone){T(M,leftY+8,'Tel: '+shop.phone,8.5,'R',{c:GREY});leftY+=11;}
      if(shop.regNo){wrapText('SSM / No. Pendaftaran: '+shop.regNo,8.5,false,300).forEach(function(l){T(M,leftY+8,l,8.5,'R',{c:GREY});leftY+=11;});}

      var rx=PAGE_W-M,ry=M;
      T(rx,ry+18,'SEBUT HARGA',20,'B',{a:'r'});ry+=26;
      T(rx,ry+9,typeLabel(q.quote_type),10,'B',{a:'r',c:GREY});ry+=17;
      function meta(label,value){
        if(!value)return;
        T(rx,ry+8,String(value),9,'B',{a:'r'});
        T(rx-textW(String(value),9,true)-6,ry+8,label,9,'R',{a:'r',c:GREY});
        ry+=13;
      }
      meta('No.',q.quote_no||'');
      meta('Tarikh',dateText(q.created_at));
      meta('Sah sehingga',dateText(q.valid_until));
      y=Math.max(leftY,ry)+8;
      LN(M,y,PAGE_W-M,y,1,INK);
      y+=14;
    }
    function contHeader(){
      T(M,M+9,shopName,9,'B',{c:GREY});
      T(PAGE_W-M,M+9,'SEBUT HARGA  '+clean(q.quote_no||''),9,'B',{a:'r',c:GREY});
      LN(M,M+16,PAGE_W-M,M+16,0.6,RULE);
      y=M+30;
    }
    function newPage(first){
      ops=[];pages.push(ops);
      if(first)firstHeader();else contHeader();
    }

    // ---------- customer + motorcycle
    newPage(true);
    var halfW=(CW-14)/2,hasBike=!!(q.plate_no||q.vehicle_model);
    function box(x,w,label,main,sub){
      var yy=y;
      T(x,yy+7,label,7.5,'B',{c:GREY});yy+=13;
      wrapText(main||'-',11,true,w).forEach(function(l){T(x,yy+9,l,11,'B');yy+=14;});
      (sub||[]).forEach(function(s){if(s)wrapText(s,9.5,false,w).forEach(function(l){T(x,yy+8,l,9.5,'R');yy+=12.5;});});
      return yy;
    }
    var y1=box(M,hasBike?halfW:CW,'KEPADA',q.customer_name,[q.customer_phone?'Tel: '+q.customer_phone:'']);
    var y2=hasBike?box(M+halfW+14,halfW,'MOTOSIKAL',q.plate_no||q.vehicle_model,[q.plate_no?q.vehicle_model:'']):y;
    y=Math.max(y1,y2)+4;
    if(q.title){
      wrapText('Perkara: '+q.title,10,true,CW).forEach(function(l){T(M,y+9,l,10,'B');y+=14;});
      y+=2;
    }
    y+=6;

    // ---------- items table
    var cNo=24,cQty=50,cPrice=80,cTot=86,cDesc=CW-cNo-cQty-cPrice-cTot;
    var xDesc=M+cNo,xQty=xDesc+cDesc,xPrice=xQty+cQty,xTot=xPrice+cPrice;
    function tableHead(){
      RC(M,y,CW,19,LIGHT,null);
      T(M+6,y+13,'BIL',8,'B',{c:GREY});
      T(xDesc+4,y+13,'PERIHAL',8,'B',{c:GREY});
      T(xQty+cQty-6,y+13,'KUANTITI',8,'B',{a:'r',c:GREY});
      T(xPrice+cPrice-6,y+13,'HARGA (RM)',8,'B',{a:'r',c:GREY});
      T(xTot+cTot-6,y+13,'JUMLAH (RM)',8,'B',{a:'r',c:GREY});
      y+=19;
    }
    tableHead();
    items.forEach(function(it,n){
      var lines=wrapText(it.description||'-',9.5,false,cDesc-10);
      var sku=it.sku?clean('SKU: '+it.sku):'';
      var h=7+lines.length*12.2+(sku?10:0)+3;
      if(y+h>limit()){newPage(false);tableHead();}
      var top=y,base=y+7+9;
      T(M+6,base,String(n+1),9.5,'R',{c:GREY});
      lines.forEach(function(l,k){T(xDesc+4,base+k*12.2,l,9.5,'R');});
      if(sku)T(xDesc+4,base+lines.length*12.2-1,sku,7.5,'R',{c:GREY});
      T(xQty+cQty-6,base,fmtQty(it.quantity),9.5,'R',{a:'r'});
      T(xPrice+cPrice-6,base,fmt(it.unit_price),9.5,'R',{a:'r'});
      T(xTot+cTot-6,base,fmt(it.line_total!=null?it.line_total:num(it.quantity)*num(it.unit_price)),9.5,'B',{a:'r'});
      y=top+h;
      LN(M,y,PAGE_W-M,y,0.4,RULE);
    });
    if(!items.length){T(xDesc+4,y+16,'(tiada item)',9.5,'I',{c:GREY});y+=26;}

    // ---------- totals, notes, terms, signatures (kept together on one page when they fit)
    var sub=q.subtotal!=null?num(q.subtotal):items.reduce(function(a,it){return a+num(it.line_total);},0);
    var disc=num(q.discount),total=q.total!=null?num(q.total):sub-disc;
    var noteLines=q.notes?wrapText(q.notes,9,false,CW):[];
    var terms=[];
    if(q.valid_until)terms.push('Sebut harga ini sah sehingga '+dateText(q.valid_until)+'.');
    terms.push('Sebut harga ini bukan invois atau resit.');
    var need=18+(disc>0?2:1)*15+30+(noteLines.length?16+noteLines.length*11.5:0)+terms.length*11+16+70;
    if(y+need>limit()){newPage(false);}
    y+=14;
    var lx=PAGE_W-M-190,vx=PAGE_W-M-6;
    T(lx,y+9,'Jumlah kecil',9.5,'R',{c:GREY});T(vx,y+9,money(sub),9.5,'R',{a:'r'});y+=15;
    if(disc>0){T(lx,y+9,'Diskaun',9.5,'R',{c:GREY});T(vx,y+9,'-'+money(disc),9.5,'R',{a:'r'});y+=15;}
    LN(lx,y+1,PAGE_W-M,y+1,1,INK);y+=4;
    RC(lx-6,y,196,24,LIGHT,null);
    T(lx,y+16,'JUMLAH',11,'B');T(vx,y+16,money(total),12,'B',{a:'r'});
    y+=24+14;

    if(noteLines.length){
      T(M,y+8,'CATATAN',8,'B',{c:GREY});y+=14;
      noteLines.forEach(function(l){T(M,y+8,l,9,'R');y+=11.5;});
      y+=8;
    }
    terms.forEach(function(t){T(M,y+8,t,8,'I',{c:GREY});y+=11;});
    y+=18;
    var sigW=(CW-40)/2;
    LN(M,y+40,M+sigW,y+40,0.6,INK);
    T(M,y+52,'Disediakan oleh'+(q.created_by_name?': '+q.created_by_name:''),8.5,'R',{c:GREY});
    LN(M+sigW+40,y+40,PAGE_W-M,y+40,0.6,INK);
    T(M+sigW+40,y+52,'Persetujuan pelanggan (tandatangan / tarikh)',8.5,'R',{c:GREY});

    // ---------- footer + watermark on every page
    var total_pages=pages.length;
    pages.forEach(function(p,i){
      ops=p;
      LN(M,PAGE_H-M-8,PAGE_W-M,PAGE_H-M-8,0.5,RULE);
      T(M,PAGE_H-M+4,clean(q.quote_no||'')+'  |  '+shopName,8,'R',{c:GREY});
      T(PAGE_W-M,PAGE_H-M+4,'Halaman '+(i+1)+' / '+total_pages,8,'R',{a:'r',c:GREY});
      if(String(q.status||'').toUpperCase()==='CANCELLED'){
        // diagonal stamp, drawn first so the text stays readable
        ops.unshift({k:'t',x:PAGE_W/2-170,y:PAGE_H/2+120,s:'DIBATALKAN',z:72,f:'B',c:[0.86,0.86,0.86],a:'l',rot:35});
      }
    });
    return pages;
  }

  // ------------------------------------------------------------------ PDF writer
  function pdfEscape(s){return String(s).replace(/\\/g,'\\\\').replace(/\(/g,'\\(').replace(/\)/g,'\\)');}
  function n2(v){return (Math.round(v*100)/100).toFixed(2);}
  function col(c){return n2(c[0])+' '+n2(c[1])+' '+n2(c[2]);}
  function pageContent(ops){
    var s='';
    ops.forEach(function(o){
      if(o.k==='r'){
        var yy=PAGE_H-o.y-o.h;
        if(o.fill){s+=col(o.fill)+' rg '+n2(o.x)+' '+n2(yy)+' '+n2(o.w)+' '+n2(o.h)+' re f\n';}
        if(o.stroke){s+=col(o.stroke)+' RG '+n2(o.x)+' '+n2(yy)+' '+n2(o.w)+' '+n2(o.h)+' re S\n';}
      }else if(o.k==='l'){
        s+=col(o.c)+' RG '+n2(o.w)+' w '+n2(o.x1)+' '+n2(PAGE_H-o.y1)+' m '+n2(o.x2)+' '+n2(PAGE_H-o.y2)+' l S\n';
      }else if(o.k==='t'&&o.s){
        var bold=o.f==='B',x=o.x;
        var w=textW(o.s,o.z,bold);
        if(o.a==='r')x=o.x-w;else if(o.a==='c')x=o.x-w/2;
        var font=o.f==='B'?'F2':(o.f==='I'?'F3':'F1');
        var py=PAGE_H-o.y;
        if(o.rot){
          var r=o.rot*Math.PI/180,cs=Math.cos(r),sn=Math.sin(r);
          s+='BT '+col(o.c)+' rg /'+font+' '+n2(o.z)+' Tf '+cs.toFixed(4)+' '+sn.toFixed(4)+' '+(-sn).toFixed(4)+' '+cs.toFixed(4)+' '+n2(x)+' '+n2(py)+' Tm ('+pdfEscape(o.s)+') Tj ET\n';
        }else{
          s+='BT '+col(o.c)+' rg /'+font+' '+n2(o.z)+' Tf '+n2(x)+' '+n2(py)+' Td ('+pdfEscape(o.s)+') Tj ET\n';
        }
      }
    });
    return s;
  }
  function buildPdfText(pages,meta){
    meta=meta||{};
    var out='',offsets=[];
    function obj(n,body){offsets[n]=out.length;out+=n+' 0 obj\n'+body+'\nendobj\n';}
    out+='%PDF-1.4\n%âãÏÓ\n';
    var firstPage=7;
    var kids=pages.map(function(_,k){return (firstPage+k*2)+' 0 R';}).join(' ');
    obj(1,'<< /Type /Catalog /Pages 2 0 R >>');
    obj(2,'<< /Type /Pages /Count '+pages.length+' /Kids ['+kids+'] >>');
    obj(3,'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    obj(4,'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    obj(5,'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique /Encoding /WinAnsiEncoding >>');
    var stamp=meta.date instanceof Date&&!isNaN(meta.date)?meta.date:new Date();
    var cd='D:'+stamp.getFullYear()+two(stamp.getMonth()+1)+two(stamp.getDate())+two(stamp.getHours())+two(stamp.getMinutes())+two(stamp.getSeconds());
    obj(6,'<< /Title ('+pdfEscape(clean(meta.title||'Sebut Harga'))+') /Producer (REV TORQ POS) /CreationDate ('+cd+') >>');
    pages.forEach(function(ops,k){
      var content=pageContent(ops),pn=firstPage+k*2,cn=pn+1;
      obj(pn,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+PAGE_W.toFixed(2)+' '+PAGE_H.toFixed(2)+'] /Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R >> >> /Contents '+cn+' 0 R >>');
      obj(cn,'<< /Length '+content.length+' >>\nstream\n'+content+'endstream');
    });
    var count=firstPage+pages.length*2;
    var xref=out.length;
    out+='xref\n0 '+count+'\n0000000000 65535 f \n';
    for(var n=1;n<count;n++){out+=('0000000000'+offsets[n]).slice(-10)+' 00000 n \n';}
    out+='trailer\n<< /Size '+count+' /Root 1 0 R /Info 6 0 R >>\nstartxref\n'+xref+'\n%%EOF\n';
    return out;
  }
  function toBytes(str){
    var b=new Uint8Array(str.length);
    for(var i=0;i<str.length;i++)b[i]=str.charCodeAt(i)&255;
    return b;
  }
  function buildQuotePdfBytes(q,shop,date){
    q=q||{};
    return toBytes(buildPdfText(layoutQuote(q,shop),{title:'Sebut Harga '+(q.quote_no||''),date:date}));
  }
  function fileName(q){
    var base=String((q&&q.quote_no)||'sebut-harga').replace(/[^A-Za-z0-9_-]+/g,'_').replace(/^_+|_+$/g,'')||'sebut-harga';
    return 'Sebut-Harga-'+base+'.pdf';
  }

  // ------------------------------------------------------------------ WhatsApp text (WhatsApp shows *x* as bold)
  function whatsappText(q,shop){
    q=q||{};shop=shop||{};
    var L=[];
    var items=Array.isArray(q.items)?q.items:[];
    L.push('*SEBUT HARGA - '+typeLabel(q.quote_type)+'*');
    L.push(String(shop.workshopName||shop.shopName||'REV TORQ WORKSHOP'));
    if(shop.phone)L.push('Tel: '+shop.phone);
    L.push('');
    L.push('No: '+(q.quote_no||'-'));
    if(q.created_at)L.push('Tarikh: '+dateText(q.created_at));
    if(q.valid_until)L.push('Sah sehingga: '+dateText(q.valid_until));
    L.push('');
    L.push('Kepada: '+(q.customer_name||'-')+(q.customer_phone?' ('+q.customer_phone+')':''));
    if(q.plate_no||q.vehicle_model)L.push('Motosikal: '+[q.plate_no,q.vehicle_model].filter(Boolean).join(' - '));
    if(q.title)L.push('Perkara: '+q.title);
    L.push('');
    items.forEach(function(it,n){
      var qty=fmtQty(it.quantity);
      var lt=it.line_total!=null?it.line_total:num(it.quantity)*num(it.unit_price);
      L.push((n+1)+'. '+String(it.description||'-').replace(/\s+/g,' ').trim());
      L.push('    '+qty+' x '+fmt(it.unit_price)+' = '+money(lt));
    });
    L.push('');
    var sub=q.subtotal!=null?num(q.subtotal):items.reduce(function(a,it){return a+num(it.line_total);},0);
    var disc=num(q.discount),total=q.total!=null?num(q.total):sub-disc;
    if(disc>0){L.push('Jumlah kecil: '+money(sub));L.push('Diskaun: -'+money(disc));}
    L.push('*JUMLAH: '+money(total)+'*');
    if(q.notes){L.push('');L.push('Catatan: '+String(q.notes).trim());}
    L.push('');
    L.push('Terima kasih. Sila hubungi kami untuk pengesahan.');
    return L.join('\n');
  }

  var api={layoutQuote:layoutQuote,buildPdfText:buildPdfText,buildQuotePdfBytes:buildQuotePdfBytes,whatsappText:whatsappText,
           wrapText:wrapText,textW:textW,clean:clean,fmt:fmt,money:money,dateText:dateText,typeLabel:typeLabel,fileName:fileName,
           PAGE_W:PAGE_W,PAGE_H:PAGE_H,M:M};
  if(typeof module==='object'&&module&&module.exports){module.exports=api;}
  if(root&&root.document)root.RTQuotePdf=api;
})(typeof window!=='undefined'?window:(typeof globalThis!=='undefined'?globalThis:this));
