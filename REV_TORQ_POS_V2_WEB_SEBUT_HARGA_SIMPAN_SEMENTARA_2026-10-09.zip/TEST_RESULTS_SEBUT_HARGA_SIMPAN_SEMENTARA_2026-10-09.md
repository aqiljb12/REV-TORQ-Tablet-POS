# Verification — Sebut Harga: Simpan Sementara + draf kelihatan (2026-10-09)

## What was found first
Reproduced in the browser harness: type a form, close the app (reload), open Quotation → the list says "Belum ada sebut harga" with no sign of the typed form. The draft was still on the device, but only offered after pressing "+ SEBUT HARGA BARU". It would also never appear on another device. (I cannot see your laptop's storage, so I cannot say where yesterday's form was kept.)

## Automated
**SQL on a throw-away Postgres (PGlite) — NOT your real database**
- `tests/sql-quotations-temp.pglite.cjs`: **44 / 44** (runs the 2026-10-08 file, then the upgrade). Refuses to run before the first file (nothing changed); runs twice; a quotation made before the upgrade stays `is_partial = false`; grants unchanged; partial save with no name / no rows; blank rows dropped, quantity 0 / blank → 1, price blank / text → 0, discount cut to the subtotal, text discount → 0; still refused in partial mode: bad kind, bad date, 81 rows, not an object, mechanic, another company's quotation; `"partial":"maybe"` is a normal strict save; same `client_ref` → same quotation; stale revision → `QUOTE_CHANGED`; SENT / ACCEPTED cannot be saved partially (`QUOTE_PARTIAL_ONLY_DRAFT` / `QUOTE_LOCKED`); unfinished cannot become SENT / ACCEPTED (`QUOTE_INCOMPLETE`) but can be REJECTED / CANCELLED (reason still required); a normal save finishes it (`is_partial` cleared) and then SENT works; list rows carry `is_partial`; audit rows say partial true / false and still exactly one per change; re-running the 2026-10-08 file goes back (version 1, strict again, no data lost).
- `tests/sql-quotations.pglite.cjs` (the 103 checks of the first file): **103 / 103** on its own, and **104 / 104** with the upgrade applied on top (`QUOTE_UPGRADE_SQL=migration_2026_10_09_quotations_temp_save.sql`) — every strict rule behaves exactly as before.

**Node suite: 194 / 195** (31 Sebut Harga tests: 15 PDF + 16 page/SQL structure). The one failure is the old "root / APK assets / WAB_DEPLOY runtime files are identical" check (no Android folder in the web build), unchanged.

## Browser run with a simulated backend (Chromium)
Sizes as before (laptop 1366×768 and 1366×657 with a mouse, iPad 1024×768 / 1180×820 / portrait, phone 390×844).
**Sebut Harga page: 216 / 216 passed** (171 from the last release + 45 new):
- after a reload the unsaved form is shown on top of the list (name, kind, rows, total, time, SAMBUNG / BUANG); another staff member on the same device does not see it; SAMBUNG restores everything without asking again
- SIMPAN SEMENTARA with an unfinished form: saved as DRAF + `is_partial`, number given, blank price shown blank again when edited; the editor stays open ("Edit UBS-…", BELUM LENGKAP); the device copy is replaced; the second press is an edit (id + revision), not a new number
- an unfinished quotation: BELUM LENGKAP badge in the list, banner on its page, no PDF / WhatsApp / DIHANTAR / DITERIMA, EDIT / LENGKAPKAN offered; the normal SIMPAN finishes it and everything returns
- a complete form saved with SIMPAN SEMENTARA is saved as complete (`partial:false`); nothing to save → says so, sends nothing; no button when editing a SENT quotation
- an unsaved edit of a saved quotation is listed ("edit UBS-…") and SAMBUNG brings it back; BUANG asks first and does not touch the saved quotation
- connection lost during SIMPAN SEMENTARA: message, form kept, the retry creates exactly one (same `client_ref`)
- server without the upgrade file: no SIMPAN SEMENTARA button, the note names the file, the device draft and the draft card still work
- tab numbers of both kinds (a quotation can no longer hide on the other tab)
- three-button bar (BATAL / SIMPAN SEMENTARA / SIMPAN SEBUT HARGA) fits and is 48 px+ tall on laptop, iPad and phone; the draft card fits (no sideways scroll)
- all earlier checks unchanged (only the one that looked at the very last list read now allows the extra 1-row count read for the tab number)

**Regression (same build):** audit fixes 112 / 112, add motorcycle 72 / 72, cart room + customer dialog 182 / 182, receipt PDF + points 57 / 57, Pesanan serentak 88 / 88, Gantung 31 / 31, POS 54 / 54, WhatsApp 15 / 15, Papan Bengkel 25 / 25, Carian pantas 25 / 25, Pesan stok 28 / 28, Booking 28 / 28, full names 63 / 63, tidy-ups 26 / 26, Override + audit 109 / 109, offline / fast 59 / 59, customer list, scanner overlay guard, job-checkout heal, job part product id, native bridge: unchanged.

## Not verified
- **Your real database.** The upgrade ran on a stand-in Postgres. It adds one column to the Sebut Harga table and replaces 4 of its functions; run it in one go and read the result. If it fails, nothing changes.
- A real iPad / laptop (keyboard, share sheet, date picker).
- Where yesterday's form was kept (see above).
