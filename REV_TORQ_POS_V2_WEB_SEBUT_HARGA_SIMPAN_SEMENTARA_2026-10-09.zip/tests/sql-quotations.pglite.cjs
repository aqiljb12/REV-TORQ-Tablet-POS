/* OPTIONAL self-check for migration_2026_10_08_quotations.sql. It does NOT touch Supabase:
   it runs the script on a throw-away in-memory Postgres (PGlite) with a small stand-in schema
   (staff, customers, vehicles, products, audit_logs, rt_staff_context) and checks the behaviour:
   roles, number series, server-side totals, idempotent save, edit conflicts, status rules,
   list / search / counts, company isolation, RPC-only access, audit rows, rollback.
   Usage:  npm i --no-save @electric-sql/pglite  &&  node tests/sql-quotations.pglite.cjs
   The stand-in schema is NOT your real schema: run PART 0 of the SQL file first. */
const fs=require('fs'),path=require('path');
const {PGlite}=require('@electric-sql/pglite');
const sqlFile=path.resolve(process.argv[2]||path.join(__dirname,'..','migration_2026_10_08_quotations.sql'));
const results=[];const ok=(n,c,i='')=>results.push({n,pass:!!c,i:String(i)});

const U={own:'00000000-0000-4000-8000-0000000000a1',adm:'00000000-0000-4000-8000-0000000000a2',cash:'00000000-0000-4000-8000-0000000000a3',other:'00000000-0000-4000-8000-0000000000a4',mech:'00000000-0000-4000-8000-0000000000a5',none:'00000000-0000-4000-8000-0000000000ff'};
const C1='11111111-1111-4111-8111-111111111111',C2='22222222-2222-4222-8222-222222222222',L1='33333333-3333-4333-8333-333333333333';
const S={own:'10000000-0000-4000-8000-000000000001',adm:'10000000-0000-4000-8000-000000000002',cash:'10000000-0000-4000-8000-000000000003',other:'10000000-0000-4000-8000-000000000004',mech:'10000000-0000-4000-8000-000000000005'};
const CU1='c0000000-0000-4000-8000-000000000001',CU2='c0000000-0000-4000-8000-000000000002',VE1='d0000000-0000-4000-8000-000000000001',VE2='d0000000-0000-4000-8000-000000000002',P1='aaaaaaaa-0000-4000-8000-000000000001',P2='aaaaaaaa-0000-4000-8000-000000000002';

const SCHEMA=`
create schema auth;
create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub', true),'')::uuid $$;
create role anon nologin; create role authenticated nologin;
grant usage on schema public to anon, authenticated; grant usage on schema auth to anon, authenticated;
create table public.staff(id uuid primary key, company_id uuid not null, location_id uuid, staff_code text, name text, role text, active boolean default true, auth_user_id uuid);
create table public.customers(id uuid primary key default gen_random_uuid(), company_id uuid not null, name text, phone text);
create table public.vehicles(id uuid primary key default gen_random_uuid(), company_id uuid not null, customer_id uuid, plate_no text);
create table public.products(id uuid primary key default gen_random_uuid(), company_id uuid not null, sku text, name text);
create table public.audit_logs(id uuid primary key default gen_random_uuid(), company_id uuid, location_id uuid, transaction_id uuid, staff_id uuid, action text not null, entity_type text, entity_id uuid, before_data jsonb, after_data jsonb, metadata jsonb default '{}'::jsonb, created_at timestamptz default now());
create function public.rt_staff_context() returns table(staff_id uuid, company_id uuid, location_id uuid, role text) language sql stable security definer set search_path=public as $$
  select s.id, s.company_id, s.location_id, s.role from public.staff s where s.auth_user_id = auth.uid() and s.active $$;
grant all on all tables in schema public to anon, authenticated;
grant execute on all functions in schema public to anon, authenticated;
insert into public.staff(id,company_id,location_id,staff_code,name,role,auth_user_id) values
 ('${S.own}','${C1}','${L1}','OWN','Owner','owner','${U.own}'),
 ('${S.adm}','${C1}','${L1}','ADM','Admin','admin','${U.adm}'),
 ('${S.cash}','${C1}','${L1}','CSH','Kaunter','cashier','${U.cash}'),
 ('${S.mech}','${C1}','${L1}','MEK','Pomen','mechanic','${U.mech}'),
 ('${S.other}','${C2}',null,'OTH','Lain Syarikat','admin','${U.other}');
insert into public.customers(id,company_id,name,phone) values ('${CU1}','${C1}','Ahmad','0123'),('${CU2}','${C2}','Orang Lain','011');
insert into public.vehicles(id,company_id,customer_id,plate_no) values ('${VE1}','${C1}','${CU1}','JXX 1234'),('${VE2}','${C2}','${CU2}','WAA 1');
insert into public.products(id,company_id,sku,name) values ('${P1}','${C1}','MO-1','Minyak 1L'),('${P2}','${C2}','XX-1','Barang Lain');
`;

const item=(d,q,p,x={})=>Object.assign({description:d,quantity:q,unit_price:p},x);
const quote=(x={})=>Object.assign({quote_type:'UBAH_SUAI',customer_name:'Ahmad',customer_phone:'0123',plate_no:'jxx 1234',vehicle_model:'NVX 155',title:'Kit racing',client_ref:'ref-'+Math.random().toString(36).slice(2),items:[item('Kit racing',1,1200),item('Upah pasang',2,50)]},x);

(async()=>{
  const sql=fs.readFileSync(sqlFile,'utf8');
  const db=new PGlite();
  await db.exec(SCHEMA);
  const as=async(user,fn)=>{await db.exec("reset role");await db.exec("set role authenticated");await db.query("select set_config('request.jwt.claim.sub',$1,false)",[user]);try{return await fn();}finally{await db.exec("reset role");}};
  const q=(s,p)=>db.query(s,p).then(r=>r.rows);
  const fails=async(fn)=>{try{await fn();return null;}catch(e){return e.message||String(e);}};
  const rpc=(user,name,args)=>as(user,async()=>(await q(`select public.${name}(${args.map((_,i)=>'$'+(i+1)).join(',')}) as r`,args))[0].r);
  const save=(user,body)=>rpc(user,'rt_quote_save',[JSON.stringify(body)]);
  const setStatus=(user,id,st,reason)=>rpc(user,'rt_quote_set_status',[id,st,reason===undefined?null:reason]);
  const list=(user,a={})=>rpc(user,'rt_quote_list',[a.type||null,a.status||null,a.search||null,a.limit||30,a.offset||0]);
  const year=new Date().getFullYear();

  // ===== run the migration (and again: must be repeatable)
  const e1=await fails(()=>db.exec(sql));
  ok('migration runs on the stand-in schema',e1===null,e1);
  const e1b=await fails(()=>db.exec(sql));
  ok('migration can be run twice (nothing breaks, nothing duplicated)',e1b===null,e1b);
  // QUOTE_UPGRADE_SQL=<file>: apply the later upgrade on top; then every assertion below must still hold unchanged
  if(process.env.QUOTE_UPGRADE_SQL){
    const e1c=await fails(()=>db.exec(fs.readFileSync(path.resolve(process.env.QUOTE_UPGRADE_SQL),'utf8')));
    ok('upgrade file runs on top of the base file',e1c===null,e1c);
  }
  ok('three tables created, RLS on',(await q("select count(*)::int as n from pg_class where relname in ('quotations','quotation_items','quotation_counters') and relrowsecurity")) [0].n===3);

  // ===== PART 0 diagnostics are valid SQL
  const p0=sql.slice(sql.indexOf('-- PART 0'),sql.indexOf('\nbegin;'));
  const dsql=p0.split('\n').filter(l=>l.startsWith('-- select')||l.startsWith('--  where')||l.startsWith('-- where')).map(l=>l.replace(/^-- ?/,'')).join('\n');
  ok('diagnostics block is not empty',dsql.length>50);

  // ===== access
  ok('ready answers for any login',(await rpc(U.mech,'rt_quote_ready',[])).ready===true);
  await db.query("select set_config('request.jwt.claim.sub','',false)");   // no login at all
  const eAuth=await fails(()=>q("select public.rt_quote_list()"));
  ok('no login -> AUTH_REQUIRED',/AUTH_REQUIRED/.test(eAuth||''),eAuth);
  ok('login without a staff row -> STAFF_ONLY',/STAFF_ONLY/.test(await fails(()=>list(U.none))||''));
  ok('mechanic cannot list / save / read',/QUOTE_ROLE_NOT_ALLOWED/.test(await fails(()=>list(U.mech))||'')&&/QUOTE_ROLE_NOT_ALLOWED/.test(await fails(()=>save(U.mech,quote()))||''));

  // ===== numbers: two separate series, per company, per year
  const a1=await save(U.cash,quote({quote_type:'UBAH_SUAI'}));
  const a2=await save(U.adm,quote({quote_type:'UBAH_SUAI'}));
  const s1=await save(U.cash,quote({quote_type:'SERVIS',title:'Servis 10k'}));
  const o1=await save(U.other,quote({quote_type:'UBAH_SUAI'}));
  ok('UBAH_SUAI numbers: UBS-yyyy-0001, 0002',a1.quote_no===`UBS-${year}-0001`&&a2.quote_no===`UBS-${year}-0002`,a1.quote_no+' '+a2.quote_no);
  ok('SERVIS has its own series SRV-yyyy-0001',s1.quote_no===`SRV-${year}-0001`,s1.quote_no);
  ok('another company starts again at 0001',o1.quote_no===`UBS-${year}-0001`,o1.quote_no);
  ok('new quotation is DRAFT, revision 1, valid 14 days',a1.status==='DRAFT'&&a1.revision===1&&!!a1.valid_until&&a1.expired===false,JSON.stringify({s:a1.status,r:a1.revision,v:a1.valid_until}));
  const vu=new Date(a1.valid_until+'T00:00:00Z').getTime(),now=Date.now();
  ok('default validity is about 14 days ahead',Math.abs((vu-now)/864e5-14)<2,a1.valid_until);
  ok('created_by is the staff on the login, not from the browser',a1.created_by===S.cash&&a1.created_by_name==='Kaunter'&&a1.company_id===C1);
  const forged=await save(U.cash,quote({company_id:C2,created_by:S.own,staff_id:S.own,quote_no:'HACK-1',status:'ACCEPTED',total:1}));
  ok('company / staff / number / status / total in the payload are ignored',forged.company_id===C1&&forged.created_by===S.cash&&forged.quote_no!=='HACK-1'&&forged.status==='DRAFT'&&Number(forged.total)===1300,JSON.stringify([forged.company_id,forged.created_by,forged.quote_no,forged.status,forged.total]));

  // ===== totals are calculated on the server
  const t=await save(U.cash,quote({discount:'25.5',items:[item('Bolt',3,3.335),item('Upah',0.5,99.99,{kind:'LABOUR'}),item('Lain',1,0,{kind:'OTHER'})],total:1,subtotal:1}));
  ok('line totals: 3 x 3.335 -> 3.34 x 3 = 10.02; 0.5 x 99.99 -> 50.00',Number(t.items[0].unit_price)===3.34&&Number(t.items[0].line_total)===10.02&&Number(t.items[1].line_total)===50,JSON.stringify(t.items.map(i=>[i.unit_price,i.line_total])));
  ok('subtotal / discount / total from the server',Number(t.subtotal)===60.02&&Number(t.discount)===25.5&&Number(t.total)===34.52,JSON.stringify([t.subtotal,t.discount,t.total]));
  ok('items keep their order, kinds and line numbers',t.items.map(i=>i.line_no).join()==='1,2,3'&&t.items.map(i=>i.kind).join()==='PART,LABOUR,OTHER');
  ok('plate is upper-cased, name / phone trimmed',(await save(U.cash,quote({plate_no:' jxx 1234 ',customer_name:'  Ali  '}))).plate_no==='JXX 1234');

  // ===== optional links must belong to the company
  const lk=await save(U.cash,quote({customer_id:CU1,vehicle_id:VE1,items:[item('Plug',1,10,{product_id:P1,sku:'MO-1'})]}));
  ok('own customer / vehicle / product are linked',lk.customer_id===CU1&&lk.vehicle_id===VE1&&lk.items[0].product_id===P1&&lk.items[0].sku==='MO-1');
  const lk2=await save(U.cash,quote({customer_id:CU2,vehicle_id:VE2,items:[item('Plug',1,10,{product_id:P2})]}));
  ok('another company\'s customer / vehicle / product are dropped, not trusted',lk2.customer_id===null&&lk2.vehicle_id===null&&lk2.items[0].product_id===null);

  // ===== validation (each refusal leaves nothing behind)
  const before=(await q("select (select count(*) from quotations)::int as q,(select count(*) from quotation_items)::int as i,(select last_no from quotation_counters where company_id=$1 and quote_type='UBAH_SUAI' and yr=$2) as n",[C1,year]))[0];
  const bad=async(name,body,re)=>{const e=await fails(()=>save(U.cash,body));ok('refused: '+name,re.test(e||''),e);};
  await bad('no customer name',quote({customer_name:'  '}),/QUOTE_CUSTOMER_REQUIRED/);
  await bad('bad type',quote({quote_type:'LAIN'}),/QUOTE_TYPE_INVALID/);
  await bad('no items',quote({items:[]}),/QUOTE_ITEMS_REQUIRED/);
  await bad('items not a list',quote({items:'x'}),/QUOTE_ITEMS_REQUIRED/);
  await bad('empty description',quote({items:[item(' ',1,5)]}),/QUOTE_ITEM_DESCRIPTION_REQUIRED/);
  await bad('qty 0',quote({items:[item('A',0,5)]}),/QUOTE_ITEM_QTY_INVALID/);
  await bad('negative qty',quote({items:[item('A',-1,5)]}),/QUOTE_ITEM_QTY_INVALID/);
  await bad('negative price',quote({items:[item('A',1,-5)]}),/QUOTE_ITEM_PRICE_INVALID/);
  await bad('price is text',quote({items:[item('A',1,'abc')]}),/QUOTE_ITEM_NUMBER_INVALID/);
  await bad('discount bigger than the subtotal',quote({discount:5000}),/QUOTE_DISCOUNT_TOO_BIG/);
  await bad('negative discount',quote({discount:-1}),/QUOTE_DISCOUNT_INVALID/);
  await bad('discount is text',quote({discount:'abc'}),/QUOTE_DISCOUNT_INVALID/);
  await bad('bad date',quote({valid_until:'31/12/2026'}),/QUOTE_VALID_UNTIL_INVALID/);
  await bad('81 items',quote({items:Array.from({length:81},(_,i)=>item('I'+i,1,1))}),/QUOTE_TOO_MANY_ITEMS/);
  await bad('not an object',[1,2],/QUOTE_INVALID/);
  const after=(await q("select (select count(*) from quotations)::int as q,(select count(*) from quotation_items)::int as i,(select last_no from quotation_counters where company_id=$1 and quote_type='UBAH_SUAI' and yr=$2) as n",[C1,year]))[0];
  ok('refused saves leave no quotation, no item and do not burn a number',JSON.stringify(before)===JSON.stringify(after),JSON.stringify([before,after]));
  const afterBad=await save(U.cash,quote());
  ok('the next number after the refusals is still continuous',Number(afterBad.quote_no.slice(-4))===Number(after.n)+1,afterBad.quote_no+' after '+after.n);
  ok('a long note / name is cut to the limit',(await save(U.cash,quote({notes:'x'.repeat(5000),customer_name:'N'.repeat(500)}))).notes.length===2000);

  // ===== idempotent save
  const ref='retry-'+Date.now();
  const r1=await save(U.cash,quote({client_ref:ref}));
  const r2=await save(U.cash,quote({client_ref:ref,customer_name:'Bukan Ahmad',items:[item('Lain',9,9)]}));
  ok('same client_ref -> the same quotation, flagged duplicate, nothing new',r1.id===r2.id&&r2.duplicate===true&&r1.duplicate===false&&r2.customer_name==='Ahmad'&&r2.items.length===2);
  ok('the retry did not use up another number',(await q("select count(*)::int as n from quotations where client_ref=$1",[ref]))[0].n===1);
  const r3=await save(U.other,quote({client_ref:ref}));
  ok('the same client_ref in another company is a different quotation',r3.id!==r1.id&&r3.company_id===C2);
  const [p1,p2]=await Promise.all([save(U.cash,quote({client_ref:'par-1'})),save(U.adm,quote({client_ref:'par-2'}))]);
  ok('two saves at the same time get different numbers',p1.quote_no!==p2.quote_no,p1.quote_no+' '+p2.quote_no);

  // ===== edit
  const e0=await save(U.cash,quote({client_ref:'edit-1',notes:'asal'}));
  const ed=await save(U.adm,{id:e0.id,expected_revision:1,quote_type:'SERVIS',customer_name:'Ahmad B',items:[item('Kit baru',1,900)],discount:100,notes:'diubah'});
  ok('edit changes fields, replaces items, revision 2',ed.customer_name==='Ahmad B'&&ed.items.length===1&&Number(ed.total)===800&&ed.revision===2&&ed.notes==='diubah');
  ok('edit keeps the number and the type (type in the payload is ignored)',ed.quote_no===e0.quote_no&&ed.quote_type==='UBAH_SUAI'&&ed.created_by===S.cash&&ed.updated_by===S.adm);
  ok('edit does not leave the old items behind',(await q("select count(*)::int as n from quotation_items where quotation_id=$1",[e0.id]))[0].n===1);
  ok('edit with the old revision is refused (QUOTE_CHANGED)',/QUOTE_CHANGED/.test(await fails(()=>save(U.cash,{id:e0.id,expected_revision:1,customer_name:'Z',items:[item('x',1,1)]}))||''));
  const ed2=await save(U.cash,{id:e0.id,expected_revision:2,customer_name:'Ahmad B',items:[item('Kit baru',1,900)]});
  ok('edit with the current revision works',ed2.revision===3);
  ok('another company cannot edit it',/QUOTE_NOT_FOUND/.test(await fails(()=>save(U.other,{id:e0.id,customer_name:'Z',items:[item('x',1,1)]}))||''));
  ok('unknown id',/QUOTE_NOT_FOUND/.test(await fails(()=>save(U.cash,{id:'99999999-9999-4999-8999-999999999999',customer_name:'Z',items:[item('x',1,1)]}))||''));
  ok('an id that is not a uuid',/QUOTE_NOT_FOUND/.test(await fails(()=>save(U.cash,{id:'abc',customer_name:'Z',items:[item('x',1,1)]}))||''));

  // ===== status rules
  const w=await save(U.cash,quote());
  const st1=await setStatus(U.cash,w.id,'SENT');
  ok('DRAFT -> SENT sets sent_at',st1.status==='SENT'&&!!st1.sent_at&&st1.revision===w.revision+1);
  ok('SENT can still be edited (price revision) and stays SENT',(await save(U.cash,{id:w.id,expected_revision:st1.revision,customer_name:'Ahmad',items:[item('Kit',1,1000)]})).status==='SENT');
  ok('same status again -> unchanged, no new revision',(await setStatus(U.cash,w.id,'SENT')).unchanged===true);
  const st2=await setStatus(U.cash,w.id,'REJECTED','Mahal');
  ok('SENT -> REJECTED keeps the reason',st2.status==='REJECTED'&&st2.status_note==='Mahal'&&!!st2.decided_at);
  ok('REJECTED is locked for edits',/QUOTE_LOCKED/.test(await fails(()=>save(U.cash,{id:w.id,customer_name:'A',items:[item('x',1,1)]}))||''));
  ok('REJECTED -> SENT (customer came back) clears the reason',(await setStatus(U.cash,w.id,'SENT')).status_note===null);
  const st3=await setStatus(U.cash,w.id,'ACCEPTED');
  ok('SENT -> ACCEPTED',st3.status==='ACCEPTED'&&!!st3.decided_at);
  ok('ACCEPTED is locked for edits',/QUOTE_LOCKED/.test(await fails(()=>save(U.adm,{id:w.id,customer_name:'A',items:[item('x',1,1)]}))||''));
  ok('cashier cannot cancel an ACCEPTED quotation',/QUOTE_ADMIN_ONLY/.test(await fails(()=>setStatus(U.cash,w.id,'CANCELLED','salah'))||''));
  ok('ACCEPTED -> CANCELLED needs a reason',/QUOTE_REASON_REQUIRED/.test(await fails(()=>setStatus(U.adm,w.id,'CANCELLED','  '))||''));
  const st4=await setStatus(U.adm,w.id,'CANCELLED','Pelanggan batal');
  ok('admin can cancel an ACCEPTED quotation with a reason',st4.status==='CANCELLED'&&st4.status_note==='Pelanggan batal'&&!!st4.cancelled_at);
  ok('CANCELLED is final (no reopen, no edit)',/QUOTE_STATUS_NOT_ALLOWED/.test(await fails(()=>setStatus(U.own,w.id,'SENT'))||'')&&/QUOTE_LOCKED/.test(await fails(()=>save(U.own,{id:w.id,customer_name:'A',items:[item('x',1,1)]}))||''));
  const w2=await save(U.cash,quote());
  ok('DRAFT -> CANCELLED needs a reason too',/QUOTE_REASON_REQUIRED/.test(await fails(()=>setStatus(U.cash,w2.id,'CANCELLED'))||''));
  ok('ACCEPTED cannot go back to SENT / DRAFT',/QUOTE_STATUS_NOT_ALLOWED/.test(await fails(async()=>{const x=await save(U.cash,quote());await setStatus(U.cash,x.id,'ACCEPTED');await setStatus(U.adm,x.id,'SENT');})||''));
  const w3=await save(U.cash,quote());await setStatus(U.cash,w3.id,'SENT');
  ok('nothing goes back to DRAFT',/QUOTE_STATUS_NOT_ALLOWED/.test(await fails(()=>setStatus(U.cash,w3.id,'DRAFT'))||''));
  ok('bad status name',/QUOTE_STATUS_INVALID/.test(await fails(()=>setStatus(U.cash,w2.id,'DONE'))||''));
  ok('another company cannot change the status',/QUOTE_NOT_FOUND/.test(await fails(()=>setStatus(U.other,w2.id,'SENT'))||''));
  ok('mechanic cannot change the status',/QUOTE_ROLE_NOT_ALLOWED/.test(await fails(()=>setStatus(U.mech,w2.id,'SENT'))||''));

  // ===== read + list
  const g=await rpc(U.cash,'rt_quote_get',[e0.id]);
  ok('get returns the quotation with its items',g.id===e0.id&&g.items.length===1&&g.quote_no===e0.quote_no);
  ok('get of another company\'s quotation is refused',/QUOTE_NOT_FOUND/.test(await fails(()=>rpc(U.other,'rt_quote_get',[e0.id]))||''));
  const L=await list(U.cash,{limit:100});
  ok('list shows only this company, newest first, no items',L.rows.every(r=>!('items' in r))&&L.rows.length===(await q("select count(*)::int as n from quotations where company_id=$1",[C1]))[0].n&&L.rows[0].created_at>=L.rows[L.rows.length-1].created_at);
  ok('list of the other company has only its own',(await list(U.other)).rows.every(r=>['Ahmad','Ahmad'].length&&r.id===o1.id||r.id===r3.id));
  const LU=await list(U.cash,{type:'UBAH_SUAI',limit:100}),LS=await list(U.cash,{type:'SERVIS',limit:100});
  ok('filter by type keeps the two kinds apart',LU.rows.every(r=>r.quote_type==='UBAH_SUAI')&&LS.rows.length===1&&LS.rows[0].quote_no===`SRV-${year}-0001`);
  ok('filter by status',(await list(U.cash,{status:'CANCELLED'})).rows.every(r=>r.status==='CANCELLED')&&(await list(U.cash,{status:'CANCELLED'})).rows.length>=1);
  ok('counts per status for the kind',LU.counts.DRAFT>0&&LU.counts.CANCELLED>=1&&LS.counts.DRAFT===1&&!('SENT' in LS.counts));
  ok('search by number / name / phone / plate / title',
    (await list(U.cash,{search:`srv-${year}-0001`})).rows.length===1&&(await list(U.cash,{search:'ahmad b'})).rows.some(r=>r.id===e0.id)&&
    (await list(U.cash,{search:'0123'})).rows.length>3&&(await list(U.cash,{search:'jxx'})).rows.length>3&&(await list(U.cash,{search:'servis 10k'})).rows.length===1);
  const wild=await save(U.cash,quote({customer_name:'100% Ori_Ali'}));
  ok('search treats % and _ as plain letters',(await list(U.cash,{search:'100%'})).rows.length===1&&(await list(U.cash,{search:'%'})).rows.length===1&&(await list(U.cash,{search:'ori_'})).rows.length===1&&(await list(U.cash,{search:'i_a'})).rows.length===1);
  const pg1=await list(U.cash,{limit:5,offset:0}),pg2=await list(U.cash,{limit:5,offset:5});
  ok('paging: 5 rows, has_more, next page differs',pg1.rows.length===5&&pg1.has_more===true&&pg2.rows.length===5&&!pg2.rows.some(r=>pg1.rows.some(x=>x.id===r.id)));
  const last=await list(U.cash,{limit:100});
  ok('last page has_more false',last.has_more===false);
  ok('limit is capped, bad kind / status refused',/QUOTE_TYPE_INVALID/.test(await fails(()=>list(U.cash,{type:'X'}))||'')&&/QUOTE_STATUS_INVALID/.test(await fails(()=>list(U.cash,{status:'X'}))||''));
  const old=await save(U.cash,quote({valid_until:'2020-01-01',customer_name:'Lama'}));
  ok('past valid_until -> expired flag (list and get), still DRAFT',old.expired===true&&old.status==='DRAFT'&&(await list(U.cash,{search:'lama'})).rows[0].expired===true);
  const oldAcc=await setStatus(U.cash,old.id,'ACCEPTED');
  ok('an ACCEPTED quotation is never "expired"',oldAcc.expired===false);

  // ===== RPC-only access
  const dir=async(user,sqlText)=>user?as(user,()=>fails(()=>q(sqlText))):(async()=>{await db.exec("reset role");await db.exec("set role anon");try{return await fails(()=>q(sqlText));}finally{await db.exec("reset role");}})();
  for(const tb of ['quotations','quotation_items','quotation_counters']){
    ok('login cannot read '+tb+' directly',/permission denied/.test(await dir(U.own,`select * from public.${tb}`)||''));
    ok('login cannot write '+tb+' directly',/permission denied/.test(await dir(U.own,`delete from public.${tb}`)||''));
    ok('anon cannot read '+tb,/permission denied/.test(await dir(null,`select * from public.${tb}`)||''));
  }
  ok('login cannot call the internal rt_quote_json',/permission denied/.test(await dir(U.own,`select public.rt_quote_json('${e0.id}')`)||''));
  ok('anon cannot call the RPCs',/permission denied/.test(await dir(null,"select public.rt_quote_list()")||'')&&/permission denied/.test(await dir(null,"select public.rt_quote_save('{}'::jsonb)")||''));

  // ===== audit trail
  const au=await q("select action,entity_type,staff_id,company_id,before_data,after_data,metadata from audit_logs where entity_id=$1 order by created_at,id",[w.id]);
  ok('audit: created, updated, then every status change, in order',au.map(a=>a.action).join()==='QUOTE_CREATED,QUOTE_STATUS,QUOTE_UPDATED,QUOTE_STATUS,QUOTE_STATUS,QUOTE_STATUS,QUOTE_STATUS',au.map(a=>a.action).join());
  ok('audit rows carry the quotation, company and staff from the server',au.every(a=>a.entity_type==='QUOTATION'&&a.company_id===C1&&a.metadata.quote_no===w.quote_no));
  const cancelAudit=au[au.length-1];
  ok('audit of the cancellation keeps who, from -> to and the reason',cancelAudit.staff_id===S.adm&&cancelAudit.before_data.status==='ACCEPTED'&&cancelAudit.after_data.status==='CANCELLED'&&cancelAudit.metadata.reason==='Pelanggan batal');
  const upd=(await q("select before_data,after_data from audit_logs where entity_id=$1 and action='QUOTE_UPDATED' order by created_at",[e0.id]));
  ok('audit of an edit keeps before / after totals',upd.length===2&&Number(upd[0].before_data.total)===1300&&Number(upd[0].after_data.total)===800);
  // every quotation: 1 create + (revision-1) edits/status changes = 1 audit row each (nothing silent, nothing doubled)
  ok('every create / edit / status change wrote exactly one audit row',(await q("select (select count(*)::int from audit_logs where action in ('QUOTE_CREATED','QUOTE_UPDATED','QUOTE_STATUS')) as a, (select (count(*)+sum(revision-1))::int from quotations) as b"))[0].a===(await q("select (count(*)+sum(revision-1))::int as b from quotations"))[0].b);

  // ===== the migration refuses to run on a database it does not understand
  const db2=new PGlite();
  await db2.exec(SCHEMA.replace('before_data jsonb, after_data jsonb,',''));
  const e3=await fails(()=>db2.exec(sql));
  await fails(()=>db2.exec('rollback'));
  ok('refuses to run if audit_logs lacks columns (nothing changed)',/AUDIT_LOGS_COLUMNS_MISSING/.test(e3||'')&&(await db2.query("select to_regclass('public.quotations') as t")).rows[0].t===null,e3);
  const db3=new PGlite();
  await db3.exec(SCHEMA.replace(/create function public\.rt_staff_context[\s\S]*?\$\$;/,'').replace(/insert into public\.staff[\s\S]*?;\n/,''));
  const e5=await fails(()=>db3.exec(sql));
  await fails(()=>db3.exec('rollback'));
  ok('refuses to run without rt_staff_context',/RT_STAFF_CONTEXT_MISSING/.test(e5||''),e5);

  // ===== rollback block works (and the data is only lost for the quotation tables)
  const rb=sql.slice(sql.indexOf('-- PART 9'));
  const rbSql=rb.split('\n').filter(l=>l.startsWith('-- ')&&!l.startsWith('-- ====')&&!/^-- PART 9/.test(l)).map(l=>l.slice(3)).join('\n');
  const e4=await fails(()=>db.exec(rbSql));
  if(e4)await fails(()=>db.exec('rollback'));
  ok('rollback block runs',e4===null,e4);
  ok('after rollback: tables and functions gone, audit rows kept',(await q("select count(*)::int as n from pg_class where relname like 'quotation%'"))[0].n===0&&(await q("select count(*)::int as n from pg_proc where proname like 'rt_quote%'"))[0].n===0&&(await q("select count(*)::int as n from audit_logs where action like 'QUOTE_%'"))[0].n>0);

  for(const r of results)console.log((r.pass?'PASS':'FAIL')+' '+r.n+(r.pass?'':'  :: '+r.i));
  console.log(`\n${results.filter(r=>r.pass).length}/${results.length} passed`);
  process.exit(results.every(r=>r.pass)?0:1);
})().catch(e=>{console.error('HARNESS ERROR',e);process.exit(2);});
