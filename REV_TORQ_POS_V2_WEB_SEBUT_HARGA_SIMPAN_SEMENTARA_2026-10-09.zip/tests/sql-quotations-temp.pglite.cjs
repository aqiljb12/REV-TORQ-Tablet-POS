/* OPTIONAL self-check for migration_2026_10_09_quotations_temp_save.sql (SIMPAN SEMENTARA). Runs the 2026-10-08 file first, then the upgrade. It does NOT touch Supabase:
   it runs the script on a throw-away in-memory Postgres (PGlite) with a small stand-in schema
   (staff, customers, vehicles, products, audit_logs, rt_staff_context) and checks the behaviour:
   roles, number series, server-side totals, idempotent save, edit conflicts, status rules,
   list / search / counts, company isolation, RPC-only access, audit rows, rollback.
   Usage:  npm i --no-save @electric-sql/pglite  &&  node tests/sql-quotations-temp.pglite.cjs
   The stand-in schema is NOT your real schema: run PART 0 of the SQL file first. */
const fs=require('fs'),path=require('path');
const {PGlite}=require('@electric-sql/pglite');
const baseFile=path.join(__dirname,'..','migration_2026_10_08_quotations.sql');
const sqlFile=path.resolve(process.argv[2]||path.join(__dirname,'..','migration_2026_10_09_quotations_temp_save.sql'));
const results=[];const ok=(n,c,i='')=>results.push({n,pass:!!c,i:String(i)});

const U={own:'00000000-0000-4000-8000-0000000000a1',adm:'00000000-0000-4000-8000-0000000000a2',cash:'00000000-0000-4000-8000-0000000000a3',other:'00000000-0000-4000-8000-0000000000a4',mech:'00000000-0000-4000-8000-0000000000a5',none:'00000000-0000-4000-8000-0000000000ff'};
const C1='11111111-1111-4111-8111-111111111111',C2='22222222-2222-4222-8222-222222222222',L1='33333333-3333-4333-8333-333333333333';
const S={own:'10000000-0000-4000-8000-000000000001',adm:'10000000-0000-4000-8000-000000000002',cash:'10000000-0000-4000-8000-000000000003',other:'10000000-0000-4000-8000-000000000004',mech:'10000000-0000-4000-8000-000000000005'};
const CU1='c0000000-0000-4000-8000-000000000001',CU2='c0000000-0000-4000-8000-000000000002',VE1='d0000000-0000-4000-8000-000000000001',VE2='d0000000-0000-4000-8000-000000000002',P1='aaaaaaaa-0000-4000-8000-000000000001',P2='aaaaaaaa-0000-4000-8000-000000000002';

const SCHEMA=`
create schema auth;
create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub', true),'')::uuid $$;
create role anon nologin; create role authenticated nologin;
grant usage on schema public to anon, authenticated; grant usage on schema auth to anon, authenticated;
create table public.staff(id uuid primary key, company_id uuid not null, location_id uuid, staff_code text, name text, role text, active boolean default true, auth_user_id uuid);
create table public.customers(id uuid primary key default gen_random_uuid(), company_id uuid not null, name text, phone text);
create table public.vehicles(id uuid primary key default gen_random_uuid(), company_id uuid not null, customer_id uuid, plate_no text);
create table public.products(id uuid primary key default gen_random_uuid(), company_id uuid not null, sku text, name text);
create table public.audit_logs(id uuid primary key default gen_random_uuid(), company_id uuid, location_id uuid, transaction_id uuid, staff_id uuid, action text not null, entity_type text, entity_id uuid, before_data jsonb, after_data jsonb, metadata jsonb default '{}'::jsonb, created_at timestamptz default now());
create function public.rt_staff_context() returns table(staff_id uuid, company_id uuid, location_id uuid, role text) language sql stable security definer set search_path=public as $$
  select s.id, s.company_id, s.location_id, s.role from public.staff s where s.auth_user_id = auth.uid() and s.active $$;
grant all on all tables in schema public to anon, authenticated;
grant execute on all functions in schema public to anon, authenticated;
insert into public.staff(id,company_id,location_id,staff_code,name,role,auth_user_id) values
 ('${S.own}','${C1}','${L1}','OWN','Owner','owner','${U.own}'),
 ('${S.adm}','${C1}','${L1}','ADM','Admin','admin','${U.adm}'),
 ('${S.cash}','${C1}','${L1}','CSH','Kaunter','cashier','${U.cash}'),
 ('${S.mech}','${C1}','${L1}','MEK','Pomen','mechanic','${U.mech}'),
 ('${S.other}','${C2}',null,'OTH','Lain Syarikat','admin','${U.other}');
insert into public.customers(id,company_id,name,phone) values ('${CU1}','${C1}','Ahmad','0123'),('${CU2}','${C2}','Orang Lain','011');
insert into public.vehicles(id,company_id,customer_id,plate_no) values ('${VE1}','${C1}','${CU1}','JXX 1234'),('${VE2}','${C2}','${CU2}','WAA 1');
insert into public.products(id,company_id,sku,name) values ('${P1}','${C1}','MO-1','Minyak 1L'),('${P2}','${C2}','XX-1','Barang Lain');
`;

const item=(d,q,p,x={})=>Object.assign({description:d,quantity:q,unit_price:p},x);
const quote=(x={})=>Object.assign({quote_type:'UBAH_SUAI',customer_name:'Ahmad',customer_phone:'0123',plate_no:'jxx 1234',vehicle_model:'NVX 155',title:'Kit racing',client_ref:'ref-'+Math.random().toString(36).slice(2),items:[item('Kit racing',1,1200),item('Upah pasang',2,50)]},x);

(async()=>{
  const base=fs.readFileSync(baseFile,'utf8'),sql=fs.readFileSync(sqlFile,'utf8');
  const db=new PGlite();
  await db.exec(SCHEMA);
  const as=async(user,fn)=>{await db.exec("reset role");await db.exec("set role authenticated");await db.query("select set_config('request.jwt.claim.sub',$1,false)",[user]);try{return await fn();}finally{await db.exec("reset role");}};
  const q=(s,p)=>db.query(s,p).then(r=>r.rows);
  const fails=async(fn)=>{try{await fn();return null;}catch(e){return e.message||String(e);}};
  const rpc=(user,name,args)=>as(user,async()=>(await q(`select public.${name}(${args.map((_,i)=>'$'+(i+1)).join(',')}) as r`,args))[0].r);
  const save=(user,body)=>rpc(user,'rt_quote_save',[JSON.stringify(body)]);
  const setStatus=(user,id,st,reason)=>rpc(user,'rt_quote_set_status',[id,st,reason===undefined?null:reason]);
  const list=(user,a={})=>rpc(user,'rt_quote_list',[a.type||null,a.status||null,a.search||null,a.limit||30,a.offset||0]);
  const year=new Date().getFullYear();
  const part=(x={})=>Object.assign({quote_type:'UBAH_SUAI',partial:true,client_ref:'p-'+Math.random().toString(36).slice(2),customer_name:'',items:[]},x);

  // ===== upgrade refuses to run on its own (nothing changed)
  const dbX=new PGlite();await dbX.exec(SCHEMA);
  const eX=await fails(()=>dbX.exec(sql));await fails(()=>dbX.exec('rollback'));
  ok('refuses to run before the 2026-10-08 file (nothing changed)',/RUN_MIGRATION_2026_10_08_QUOTATIONS_FIRST/.test(eX||'')&&(await dbX.query("select to_regclass('public.quotations') as t")).rows[0].t===null,eX);

  // ===== base file first, one quotation made BEFORE the upgrade
  const eb=await fails(()=>db.exec(base));ok('base file runs',eb===null,eb);
  ok('before the upgrade: ready answers version 1',(await rpc(U.cash,'rt_quote_ready',[])).version===1);
  const old=await save(U.cash,{quote_type:'SERVIS',customer_name:'Lama',items:[{description:'Servis',quantity:1,unit_price:50}]});
  const e1=await fails(()=>db.exec(sql));ok('upgrade runs',e1===null,e1);
  const e1b=await fails(()=>db.exec(sql));ok('upgrade can be run twice',e1b===null,e1b);
  ok('after the upgrade: ready answers version 2',(await rpc(U.cash,'rt_quote_ready',[])).version===2);
  ok('a quotation made before the upgrade is not "partial" and still reads fine',(await rpc(U.cash,'rt_quote_get',[old.id])).is_partial===false&&(await rpc(U.cash,'rt_quote_get',[old.id])).items.length===1);
  ok('upgrade left the grants as they were (anon blocked, authenticated allowed)',/permission denied/.test(await (async()=>{await db.exec("reset role");await db.exec("set role anon");try{return await fails(()=>q("select public.rt_quote_list()"));}finally{await db.exec("reset role");}})()||'')&&(await list(U.cash)).rows.length===1);

  // ===== partial create: nothing typed but a number
  const p0=await save(U.cash,part());
  ok('partial: no name, no rows -> saved as DRAFT with a number, is_partial, total 0',p0.status==='DRAFT'&&p0.is_partial===true&&p0.quote_no===`UBS-${year}-0001`&&p0.customer_name===''&&p0.items.length===0&&Number(p0.total)===0,JSON.stringify([p0.status,p0.is_partial,p0.quote_no,p0.items]));
  ok('partial: created_by / company from the login',p0.created_by===S.cash&&p0.company_id===C1);

  // ===== partial with rows: blank rows dropped, missing qty -> 1, missing / text price -> 0, discount cut to the subtotal
  const p1=await save(U.cash,part({customer_name:'  ',discount:'999',items:[
    {description:'Kit racing',quantity:2,unit_price:'1,250'},          // price text with a comma -> 0 (the app sends numbers)
    {description:'  ',quantity:3,unit_price:10},                       // blank description -> dropped
    {description:'Upah',kind:'LABOUR',quantity:'',unit_price:80},      // blank qty -> 1
    {description:'Plug',quantity:0,unit_price:15.5},                   // 0 qty -> 1
    {description:'Percuma',quantity:1,unit_price:null}]}));
  ok('partial: 4 kept rows in order, blank one dropped',p1.items.map(i=>i.description).join('|')==='Kit racing|Upah|Plug|Percuma',p1.items.map(i=>i.description).join('|'));
  ok('partial: quantities 2 / 1 / 1 / 1 and prices 0 / 80 / 15.50 / 0',p1.items.map(i=>Number(i.quantity)+'x'+Number(i.unit_price)).join(',')==='2x0,1x80,1x15.5,1x0',p1.items.map(i=>Number(i.quantity)+'x'+Number(i.unit_price)).join(','));
  ok('partial: subtotal 95.50, discount cut from 999 to 95.50, total 0.00',Number(p1.subtotal)===95.5&&Number(p1.discount)===95.5&&Number(p1.total)===0,JSON.stringify([p1.subtotal,p1.discount,p1.total]));
  const p1b=await save(U.cash,part({discount:'abc',items:[{description:'X',quantity:1,unit_price:5}]}));
  ok('partial: text discount -> 0 instead of a refusal',Number(p1b.discount)===0&&Number(p1b.total)===5);

  // ===== partial is still protected where it matters
  const bad=async(n,body,re,user=U.cash)=>{const e=await fails(()=>save(user,body));ok('partial still refused: '+n,re.test(e||''),e);};
  await bad('bad kind',part({quote_type:'LAIN'}),/QUOTE_TYPE_INVALID/);
  await bad('bad date',part({valid_until:'31/12/2026'}),/QUOTE_VALID_UNTIL_INVALID/);
  await bad('81 rows',part({items:Array.from({length:81},(_,i)=>({description:'I'+i,quantity:1,unit_price:1}))}),/QUOTE_TOO_MANY_ITEMS/);
  await bad('not an object',[1],/QUOTE_INVALID/);
  await bad('mechanic',part(),/QUOTE_ROLE_NOT_ALLOWED/,U.mech);
  await bad('another company\'s quotation id',Object.assign(part(),{id:p0.id}),/QUOTE_NOT_FOUND/,U.other);
  ok('partial: another company\'s customer / product links are dropped as before',(await save(U.cash,part({customer_id:CU2,items:[{description:'A',quantity:1,unit_price:1,product_id:P2}]}))).customer_id===null);
  ok('partial: "partial":"maybe" (not a boolean) is treated as a normal strict save',/QUOTE_CUSTOMER_REQUIRED/.test(await fails(()=>save(U.cash,{quote_type:'UBAH_SUAI',partial:'maybe',customer_name:'',items:[]}))||''));

  // ===== retry + conflicts still work in partial mode
  const ref='pr-'+Date.now();
  const r1=await save(U.cash,part({client_ref:ref})),r2=await save(U.cash,part({client_ref:ref,customer_name:'Lain'}));
  ok('partial: same client_ref -> same quotation, duplicate flag, no extra number',r1.id===r2.id&&r2.duplicate===true&&r2.customer_name==='');
  const pe=await save(U.cash,Object.assign(part({customer_name:'Ali'}),{id:p0.id,client_ref:null,expected_revision:1,items:[{description:'Kit',quantity:1,unit_price:100}]}));
  ok('partial edit of a partial draft: same number, revision 2, name kept',pe.id===p0.id&&pe.revision===2&&pe.quote_no===p0.quote_no&&pe.customer_name==='Ali'&&pe.is_partial===true);
  ok('partial edit with a stale revision -> QUOTE_CHANGED',/QUOTE_CHANGED/.test(await fails(()=>save(U.cash,Object.assign(part(),{id:p0.id,client_ref:null,expected_revision:1})))||''));

  // ===== an unfinished quotation cannot be sent or accepted
  ok('SENT refused while unfinished (QUOTE_INCOMPLETE)',/QUOTE_INCOMPLETE/.test(await fails(()=>setStatus(U.cash,p0.id,'SENT'))||''));
  ok('ACCEPTED refused while unfinished',/QUOTE_INCOMPLETE/.test(await fails(()=>setStatus(U.adm,p0.id,'ACCEPTED'))||''));
  ok('...and it stayed an unfinished DRAFT',(await rpc(U.cash,'rt_quote_get',[p0.id])).status==='DRAFT');
  // a normal (strict) save with the missing details finishes it
  ok('a normal save still needs the rules (blank name refused)',/QUOTE_CUSTOMER_REQUIRED/.test(await fails(()=>save(U.cash,{id:p0.id,expected_revision:2,customer_name:'',items:[{description:'Kit',quantity:1,unit_price:100}]}))||''));
  ok('a normal save with a missing price is refused',/QUOTE_ITEM_PRICE_INVALID|QUOTE_ITEM_NUMBER_INVALID/.test(await fails(()=>save(U.cash,{id:p0.id,expected_revision:2,customer_name:'Ali',items:[{description:'Kit',quantity:1}]}))||''));
  const full=await save(U.cash,{id:p0.id,expected_revision:2,customer_name:'Ali',customer_phone:'0123',items:[{description:'Kit',quantity:1,unit_price:100}]});
  ok('a complete normal save clears is_partial',full.is_partial===false&&full.revision===3&&Number(full.total)===100);
  const sent=await setStatus(U.cash,p0.id,'SENT');
  ok('...and then SENT works',sent.status==='SENT'&&!!sent.sent_at);
  ok('partial save of a SENT quotation is refused (QUOTE_PARTIAL_ONLY_DRAFT)',/QUOTE_PARTIAL_ONLY_DRAFT/.test(await fails(()=>save(U.cash,Object.assign(part(),{id:p0.id,client_ref:null})))||''));
  await setStatus(U.cash,p0.id,'ACCEPTED');
  ok('partial save of an ACCEPTED quotation is refused (QUOTE_LOCKED)',/QUOTE_LOCKED/.test(await fails(()=>save(U.adm,Object.assign(part(),{id:p0.id,client_ref:null})))||''));
  // unfinished ones can still be rejected / cancelled
  const u1=await save(U.cash,part()),u2=await save(U.cash,part());
  ok('an unfinished DRAFT can be REJECTED',(await setStatus(U.cash,u1.id,'REJECTED','tak jadi')).status==='REJECTED');
  ok('an unfinished DRAFT can be CANCELLED with a reason (and still needs one)',/QUOTE_REASON_REQUIRED/.test(await fails(()=>setStatus(U.cash,u2.id,'CANCELLED'))||'')&&(await setStatus(U.cash,u2.id,'CANCELLED','salah buat')).status==='CANCELLED');
  ok('a REJECTED unfinished quotation cannot be reopened as SENT',/QUOTE_INCOMPLETE/.test(await fails(()=>setStatus(U.cash,u1.id,'SENT'))||''));

  // ===== list + audit
  const L=await list(U.cash,{type:'UBAH_SUAI',limit:100});
  ok('list rows carry is_partial (true for the unfinished, false for the finished)',L.rows.some(r=>r.is_partial===true)&&L.rows.some(r=>r.is_partial===false)&&L.rows.every(r=>typeof r.is_partial==='boolean'));
  ok('list: old quotation (before the upgrade) is_partial false',(await list(U.cash,{type:'SERVIS'})).rows[0].is_partial===false);
  const au=await q("select action,metadata from audit_logs where entity_id=$1 order by created_at,id",[p0.id]);
  ok('audit rows say partial true / false',au[0].action==='QUOTE_CREATED'&&au[0].metadata.partial===true&&au.find(a=>a.action==='QUOTE_UPDATED'&&a.metadata.partial===false)&&au.filter(a=>a.action==='QUOTE_STATUS').length===2);
  ok('every create / edit / status change still wrote exactly one audit row',(await q("select (select count(*)::int from audit_logs where action in ('QUOTE_CREATED','QUOTE_UPDATED','QUOTE_STATUS')) as a, (select (count(*)+sum(revision-1))::int from quotations) as b"))[0].a===(await q("select (count(*)+sum(revision-1))::int as b from quotations"))[0].b);

  // ===== going back = running the base file again: previous behaviour returns, data stays
  const eb2=await fails(()=>db.exec(base));ok('base file can be re-run to go back',eb2===null,eb2);
  ok('after going back: ready answers version 1 and a "partial" save is strict again',(await rpc(U.cash,'rt_quote_ready',[])).version===1&&/QUOTE_CUSTOMER_REQUIRED/.test(await fails(()=>save(U.cash,part()))||''));
  ok('after going back: nothing was lost',(await q("select count(*)::int as n from quotations"))[0].n>=7);

  for(const r of results)console.log((r.pass?'PASS':'FAIL')+' '+r.n+(r.pass?'':'  :: '+r.i));
  console.log(`\n${results.filter(r=>r.pass).length}/${results.length} passed`);
  process.exit(results.every(r=>r.pass)?0:1);
})().catch(e=>{console.error('HARNESS ERROR',e);process.exit(2);});
