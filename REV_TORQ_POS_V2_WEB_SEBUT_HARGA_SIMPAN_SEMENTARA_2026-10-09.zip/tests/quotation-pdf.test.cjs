const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const {spawnSync}=require('child_process');
const os=require('os');
const root=path.resolve(__dirname,'..');
const Q=require(path.join(root,'js/rt-quotation-pdf.js'));

const shop={workshopName:'REV TORQ PERFORMANCE',address:'No 12, Jalan Maju\nSungai Buloh',phone:'012-3456789',regNo:'123456-A'};
const quote=(x={})=>Object.assign({quote_type:'UBAH_SUAI',quote_no:'UBS-2026-0001',status:'DRAFT',created_at:'2026-10-07T17:30:00Z',valid_until:'2026-10-21',
  customer_name:'Ahmad bin Abdullah',customer_phone:'0123456789',plate_no:'JXX 1234',vehicle_model:'NVX 155',title:'Kit racing',created_by_name:'Kaunter',
  items:[{description:'Kit racing 62mm lengkap',sku:'MAL-62',quantity:1,unit_price:1250.5,line_total:1250.5},{description:'Upah pasang',quantity:2.5,unit_price:80,line_total:200}],
  subtotal:1450.5,discount:50.5,total:1400,notes:'Harga termasuk upah.\nDeposit RM300.'},x);
const bytes=(q,d)=>Q.buildQuotePdfBytes(q,shop,d||new Date(2026,9,8,10,0,0));
const asText=b=>Buffer.from(b).toString('latin1');
const many=n=>quote({items:Array.from({length:n},(_,i)=>({description:'Item servis nombor '+(i+1)+' dengan keterangan yang agak panjang supaya baris menjadi dua baris',quantity:1,unit_price:10,line_total:10})),subtotal:n*10,discount:0,total:n*10});
const textOps=pages=>pages.flatMap((ops,i)=>ops.filter(o=>o.k==='t').map(o=>Object.assign({page:i},o)));

test('quotation PDF: a real, valid A4 PDF (header, xref offsets, stream lengths, trailer)',()=>{
  const t=asText(bytes(quote()));
  assert.match(t,/^%PDF-1\.4\n/);
  assert.match(t,/%%EOF\n$/);
  assert.match(t,/\/MediaBox \[0 0 595\.28 841\.89\]/);
  for(const f of ['Helvetica','Helvetica-Bold','Helvetica-Oblique'])assert.ok(t.includes('/BaseFont /'+f+' '),f);
  assert.match(t,/\/Count 1 /);
  const xr=t.indexOf('xref\n');assert.ok(xr>0);
  assert.equal(Number(/startxref\n(\d+)\n/.exec(t)[1]),xr);
  const rows=t.slice(xr).split('\n').slice(3).filter(l=>/^\d{10} 00000 n $/.test(l));
  assert.equal(rows.length,8);                       // catalog, pages, 3 fonts, info, page, content
  rows.forEach((l,i)=>assert.ok(t.slice(Number(l.slice(0,10))).startsWith((i+1)+' 0 obj'),'object '+(i+1)+' offset'));
  const m=/<< \/Length (\d+) >>\nstream\n([\s\S]*?)endstream/.exec(t);
  assert.equal(Number(m[1]),m[2].length);
  assert.match(t,/\/Title \(Sebut Harga UBS-2026-0001\)/);
  assert.ok(/\/CreationDate \(D:20261008100000\)/.test(t));
});

test('quotation PDF: shop, type, number, customer, motorcycle, lines and totals are on the page',()=>{
  const pages=Q.layoutQuote(quote(),shop),all=textOps(pages).map(o=>o.s).join('\n');
  for(const s of ['REV TORQ PERFORMANCE','No 12, Jalan Maju','Sungai Buloh','Tel: 012-3456789','SSM / No. Pendaftaran: 123456-A','SEBUT HARGA','UBAH SUAI','UBS-2026-0001',
                  '08/10/2026','21/10/2026','Ahmad bin Abdullah','Tel: 0123456789','JXX 1234','NVX 155','Perkara: Kit racing','Kit racing 62mm lengkap','SKU: MAL-62','Upah pasang',
                  '1,250.50','2.5','80.00','200.00','RM 1,450.50','-RM 50.50','RM 1,400.00','Harga termasuk upah.','Deposit RM300.','Disediakan oleh: Kaunter','Halaman 1 / 1'])
    assert.ok(all.includes(s),'missing: '+s);
  assert.equal(pages.length,1);
});

test('quotation PDF: SERVIS has its own label; no discount row without a discount; no bike box without a bike',()=>{
  const all=textOps(Q.layoutQuote(quote({quote_type:'SERVIS',discount:0,total:1450.5,plate_no:'',vehicle_model:''}),shop)).map(o=>o.s).join('\n');
  assert.ok(all.includes('SERVIS')&&!all.includes('UBAH SUAI'));
  assert.ok(!all.includes('Diskaun')&&!all.includes('MOTOSIKAL'));
  assert.ok(all.includes('RM 1,450.50'));
});

test('quotation PDF: Malaysia date (UTC+8): 17:30 UTC on the 7th is the 8th; a plain valid_until date is not shifted',()=>{
  assert.equal(Q.dateText('2026-10-07T17:30:00Z'),'08/10/2026');
  assert.equal(Q.dateText('2026-10-07T15:59:00Z'),'07/10/2026');
  assert.equal(Q.dateText('2026-12-31'),'31/12/2026');
  assert.equal(Q.dateText(null),'');
  assert.equal(Q.dateText('nonsense'),'');
});

test('quotation PDF: wrapping never goes past the width; a very long word is cut; blank lines kept',()=>{
  const W=200;
  for(const bold of [false,true]){
    const lines=Q.wrapText('Kit racing 62mm cylinder block set lengkap dengan piston ring gasket '+'A'.repeat(80)+' selesai',9.5,bold,W);
    assert.ok(lines.length>3);
    lines.forEach(l=>assert.ok(Q.textW(l,9.5,bold)<=W+0.01,l));
    assert.equal(lines.join('').replace(/ /g,'').includes('A'.repeat(80)),true,'no letters lost');
  }
  assert.deepEqual(Q.wrapText('a\n\nb',9,false,300),['a','','b']);
  assert.deepEqual(Q.wrapText('',9,false,300),['']);
  assert.deepEqual(Q.wrapText('   ',9,false,300),['']);
});

test('quotation PDF: Helvetica widths (digits, capitals, bold) and clean() for non-Latin text',()=>{
  assert.equal(Math.round(Q.textW('0123456789',1000,false)),5560);
  assert.equal(Math.round(Q.textW('W',1000,true)),944);
  assert.equal(Math.round(Q.textW('i',1000,false)),222);
  assert.ok(Q.textW('HELLO',10,true)>Q.textW('HELLO',10,false));
  assert.equal(Q.clean('Ahmad “Ali” – 5 pcs…'),'Ahmad "Ali" - 5 pcs...');
  assert.equal(Q.clean('Caf\u00e9 \ud83d\ude00 \u4e2d'),'Caf\u00e9 ?? ?');
});

test('quotation PDF: numbers are right-aligned on the same edge, text stays inside the margins',()=>{
  const pages=Q.layoutQuote(many(40),shop),ops=textOps(pages);
  const right=ops.filter(o=>o.a==='r');
  assert.ok(right.length>100);
  right.forEach(o=>assert.ok(o.x<=Q.PAGE_W-Q.M+0.01&&o.x-Q.textW(o.s,o.z,o.f==='B')>=Q.M-0.01,'right text outside: '+o.s));
  ops.filter(o=>o.a==='l'&&!o.rot).forEach(o=>assert.ok(o.x>=Q.M-0.01&&o.x+Q.textW(o.s,o.z,o.f==='B')<=Q.PAGE_W-Q.M+0.5,'left text outside: '+o.s+' '+(o.x+Q.textW(o.s,o.z,o.f==='B'))));
  const lastCol=ops.filter(o=>o.a==='r'&&/^\d+\.\d\d$/.test(o.s)&&o.f==='B');
  assert.equal(new Set(lastCol.map(o=>o.x.toFixed(2))).size,1,'all line totals share one right edge');
  ops.forEach(o=>assert.ok(o.y>=0&&o.y<=Q.PAGE_H,'text off the page: '+o.s));
});

test('quotation PDF: a long list runs over pages, the table header repeats, totals + signatures come last, page numbers are right',()=>{
  const pages=Q.layoutQuote(many(40),shop);
  assert.ok(pages.length>=2);
  const per=pages.map(ops=>ops.filter(o=>o.k==='t').map(o=>o.s));
  per.forEach((p,i)=>{assert.ok(p.includes('PERIHAL'),'table header on page '+(i+1));assert.ok(p.includes('Halaman '+(i+1)+' / '+pages.length));});
  const total=per.findIndex(p=>p.includes('JUMLAH'));
  assert.equal(total,pages.length-1,'the totals are on the last page');
  assert.ok(per[total].includes('Persetujuan pelanggan (tandatangan / tarikh)'));
  assert.ok(!per.slice(0,total).some(p=>p.includes('Persetujuan pelanggan (tandatangan / tarikh)')));
  const all=per.flat();
  for(let i=1;i<=40;i++)assert.ok(all.some(s=>s.startsWith('Item servis nombor '+i+' ')||s.startsWith('Item servis nombor '+i+' dengan')),'row '+i+' present');
  const rows=pages.map(ops=>ops.filter(o=>o.k==='t'&&o.a==='l'&&/^\d+$/.test(o.s)&&o.x<Q.M+10).map(o=>Number(o.s)));
  assert.deepEqual(rows.flat(),Array.from({length:40},(_,i)=>i+1),'rows in order, none lost or doubled across pages');
  const text=asText(Q.buildQuotePdfBytes(many(40),shop));
  assert.match(text,new RegExp('/Count '+pages.length+' '));
});

test('quotation PDF: only a CANCELLED quotation carries the DIBATALKAN stamp',()=>{
  const has=q=>textOps(Q.layoutQuote(q,shop)).some(o=>o.s==='DIBATALKAN');
  assert.equal(has(quote({status:'CANCELLED'})),true);
  for(const s of ['DRAFT','SENT','ACCEPTED','REJECTED'])assert.equal(has(quote({status:s})),false,s);
});

test('quotation PDF: brackets, backslashes and odd characters in the text cannot break the file',()=>{
  const q=quote({customer_name:'Ali (Bengkel) \\ Co',title:'Servis ) (( 10k',items:[{description:'Bolt ) ( \\ M8 "x" – 😀',quantity:1,unit_price:1,line_total:1}],notes:'a\\b ) c',subtotal:1,discount:0,total:1});
  const t=asText(bytes(q));
  const content=/stream\n([\s\S]*?)endstream/.exec(t)[1];
  // every text string must be balanced once the escapes are removed
  const strings=[...content.matchAll(/\(((?:\\.|[^\\()])*)\) Tj/g)];
  assert.ok(strings.length>20);
  assert.ok(content.includes('Ali \\(Bengkel\\) \\\\ Co'));
  const xr=t.indexOf('xref\n');
  assert.equal(Number(/startxref\n(\d+)\n/.exec(t)[1]),xr);
});

test('quotation PDF: empty / missing data still makes a valid one-page PDF (no NaN, no undefined)',()=>{
  for(const q of [{}, {items:[]}, {customer_name:'X',items:[{description:'Y',quantity:'abc',unit_price:null}]}]){
    const t=asText(Q.buildQuotePdfBytes(q,{}));
    assert.match(t,/^%PDF-1\.4/);assert.ok(!/NaN|undefined/.test(t),JSON.stringify(q));
  }
});

test('quotation PDF: poppler can open it and reads the same words (skipped when pdftotext is not installed)',t=>{
  const probe=spawnSync('pdftotext',['-v']);
  if(probe.error){t.skip('pdftotext not installed');return;}
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'qpdf-'));
  const f=path.join(dir,'q.pdf');
  fs.writeFileSync(f,bytes(many(40)));
  const info=spawnSync('pdfinfo',[f],{encoding:'utf8'}).stdout;
  assert.match(info,/Page size:\s+595\.28 x 841\.89 pts \(A4\)/);
  assert.match(info,/Pages:\s+[2-9]/);
  const txt=spawnSync('pdftotext',['-layout',f,'-'],{encoding:'utf8'}).stdout;
  for(const s of ['SEBUT HARGA','UBS-2026-0001','Ahmad bin Abdullah','JXX 1234','Item servis nombor 40','RM 400.00','Halaman 2 /'])assert.ok(txt.includes(s),'pdftotext missing '+s);
  fs.rmSync(dir,{recursive:true,force:true});
});

test('quotation WhatsApp text: header, customer, bike, numbered lines, discount, bold total, notes',()=>{
  const t=Q.whatsappText(quote(),shop);
  const L=t.split('\n');
  assert.equal(L[0],'*SEBUT HARGA - UBAH SUAI*');
  for(const s of ['REV TORQ PERFORMANCE','Tel: 012-3456789','No: UBS-2026-0001','Tarikh: 08/10/2026','Sah sehingga: 21/10/2026','Kepada: Ahmad bin Abdullah (0123456789)','Motosikal: JXX 1234 - NVX 155','Perkara: Kit racing',
                  '1. Kit racing 62mm lengkap','    1 x 1,250.50 = RM 1,250.50','2. Upah pasang','    2.5 x 80.00 = RM 200.00','Jumlah kecil: RM 1,450.50','Diskaun: -RM 50.50','*JUMLAH: RM 1,400.00*','Catatan: Harga termasuk upah.\nDeposit RM300.'])
    assert.ok(t.includes(s),'missing: '+s);
  assert.ok(!/undefined|NaN|null/.test(t));
  const plain=Q.whatsappText(quote({discount:0,total:1450.5,notes:'',plate_no:'',vehicle_model:'',title:''}),{});
  assert.ok(!plain.includes('Diskaun')&&!plain.includes('Catatan')&&!plain.includes('Motosikal')&&!plain.includes('Perkara'));
  assert.ok(plain.includes('*JUMLAH: RM 1,450.50*')&&plain.includes('REV TORQ WORKSHOP'));
  assert.equal(Q.whatsappText(quote({quote_type:'SERVIS'}),shop).split('\n')[0],'*SEBUT HARGA - SERVIS*');
});

test('quotation PDF: file name is safe',()=>{
  assert.equal(Q.fileName({quote_no:'UBS-2026-0001'}),'Sebut-Harga-UBS-2026-0001.pdf');
  assert.equal(Q.fileName({quote_no:'a/b c?.pdf'}),'Sebut-Harga-a_b_c_pdf.pdf');
  assert.equal(Q.fileName({}),'Sebut-Harga-sebut-harga.pdf');
});

test('quotation PDF: pure module, no network, no storage, no Supabase',()=>{
  const code=fs.readFileSync(path.join(root,'js/rt-quotation-pdf.js'),'utf8').replace(/\/\*[\s\S]*?\*\//g,'').replace(/^\s*\/\/.*$/gm,'').replace(/\s\/\/ .*$/gm,'');
  assert.ok(!/fetch\(|XMLHttpRequest|localStorage|sessionStorage|supabase|\.rpc\(|\.from\(|navigator\./i.test(code));
  assert.ok(!/=>|\bconst\b|\blet\b|`/.test(code),'ES5-style code for older iPad Safari');
});
