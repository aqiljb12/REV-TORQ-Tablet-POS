const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
const stripJs=s=>s.replace(/\/\*[\s\S]*?\*\//g,'').replace(/^\s*\/\/.*$/gm,'').replace(/\s\/\/ .*$/gm,'');

const html=read('index.html'),core=read('js/core.js'),ui=read('js/rt-quotation.js'),sql=read('migration_2026_10_08_quotations.sql'),sql2=read('migration_2026_10_09_quotations_temp_save.sql'),css=read('css/rt-quotation.css');
const uiCode=stripJs(ui);

test('quotations: the page, the stylesheet and the scripts are wired into index.html in the right order',()=>{
  assert.match(html,/<div id="view-quotes" class="view-section hidden">/);
  assert.match(html,/id="rtQuoteBody"/);
  assert.match(html,/id="rtQuoteHead"/);
  assert.match(html,/href="css\/rt-quotation\.css\?v=[^"]+"/);
  const at=n=>html.indexOf('src="js/'+n);
  assert.ok(at('rt-quotation-pdf.js?v=')>0&&at('rt-quotation.js?v=')>at('rt-quotation-pdf.js?v='),'pdf builder first, then the page');
  assert.ok(at('rt-quotation.js?v=')>at('rt-receipt-pdf.js?v='));
  const last=[...html.matchAll(/<script[^>]+src="js\/([^"?]+)/g)].map(m=>m[1]).pop();
  assert.equal(last,'rt-polish.js','rt-polish.js must stay the last script');
  assert.match(html,/js\/core\.js\?v=38\.7\.0-quotes/);
  assert.ok(fs.existsSync(path.join(root,'js/rt-quotation-pdf.js'))&&fs.existsSync(path.join(root,'js/rt-quotation.js'))&&fs.existsSync(path.join(root,'css/rt-quotation.css')));
});

test('quotations: navigation and roles (admin / owner / cashier / staff / pos yes; mechanic, pomen, stor no)',()=>{
  assert.match(core,/quotes:\s*\{\s*icon:\s*'file-plus',\s*title:\s*'Sebut Harga',\s*nav:\s*'Quotation',\s*func:\s*'rtLoadQuotes'\s*\}/);
  const menu=core.slice(core.indexOf('const menuDefinitions'),core.indexOf('const navPrimary'));
  const list=r=>{const m=new RegExp('\\n\\s+'+r+':\\s*\\[([^\\]]*)\\]').exec(menu);return m?m[1].split(',').map(x=>x.trim().replace(/'/g,'')):null;};
  for(const r of ['owner','super_admin','admin','pos','staff','cashier'])assert.ok(list(r).includes('quotes'),r+' has quotes');
  for(const r of ['pomen','mechanic','stor'])assert.ok(!list(r).includes('quotes'),r+' has no quotes');
  assert.deepEqual(list('cashier'),['pos','sales','quotes']);
  const prim=/const navPrimary = \[([^\]]*)\]/.exec(core)[1].split(',').map(x=>x.trim().replace(/'/g,''));
  assert.equal(prim.indexOf('quotes'),prim.indexOf('sales')+1);
  assert.ok(!/navSecondary = \[[^\]]*quotes/.test(core));
});

test('quotations: the page only calls the rt_quote_* functions, and every one exists in the SQL file',()=>{
  const used=[...new Set([...uiCode.matchAll(/rpc\('([a-z_]+)'/g)].map(m=>m[1]))].sort();
  assert.deepEqual(used,['rt_quote_get','rt_quote_list','rt_quote_ready','rt_quote_save','rt_quote_set_status']);
  for(const n of used)assert.match(sql,new RegExp('create or replace function public\\.'+n+'\\('),n+' defined in the SQL file');
  assert.ok(!/post_pos_sale|post_job|stock_movement|cash_|rt_pos_|invoice/i.test(uiCode),'no sale / stock / cash / invoice code in the quotation page');
});

test('quotations: the page never writes a table directly and only reads customers / vehicles / products',()=>{
  assert.ok(!/\.insert\(|\.update\(|\.upsert\(|\.delete\(|\.set\(/.test(uiCode),'no direct writes');
  const from=[...new Set([...uiCode.matchAll(/\.from\('([a-z_]+)'\)/g)].map(m=>m[1]))].sort();
  assert.deepEqual(from,['customers','products','vehicles']);
  assert.ok(!/db\.collection\(['"](invoices|payments|job_cards|stock)/.test(uiCode));
  // the only collection read is the workshop profile (for the PDF header)
  assert.deepEqual([...new Set([...uiCode.matchAll(/collection\('([a-z_]+)'\)/g)].map(m=>m[1]))],['settings']);
});

test('quotations: nothing touches the POS cart, checkout or Job Card',()=>{
  assert.ok(!/posCart|posCheckout|posAddToCart|loadPOS|jobcard|job_card|rtPosAfterSale/i.test(uiCode));
  assert.ok(!/rt_quote|quotation|sebut harga/i.test(read('js/rt-pos-fixes.js')+read('js/v36-4-9-pos-cash-canonical.js')),'the POS / checkout code does not know about quotations');
});

test('quotations: browser code is ES2017-compatible (older iPad Safari) and has no external requests',()=>{
  for(const [name,code] of [['rt-quotation.js',uiCode],['rt-quotation-pdf.js',stripJs(read('js/rt-quotation-pdf.js'))]]){
    assert.ok(!/\?\.|\?\?|\.\.\.[a-zA-Z{\[(]|\.flat\(|\.flatMap\(|\.matchAll\(|\.replaceAll\(|Object\.fromEntries|\bBigInt\b|\bstructuredClone\b|\bat\(-?\d\)/.test(code.replace(/'[^'\n]*'|"[^"\n]*"/g,"''")),name+' uses newer syntax');
    assert.ok(!/https?:\/\/(?!wa\.me\/)/.test(code),name+' has an external URL');
  }
  assert.ok(!/(^|[;{\s])gap:/.test(css),'no flex gap in the stylesheet (older Safari)');
  assert.ok(!/@import|url\(http/.test(css));
});

test('quotations: browser storage is only the kind tab + local drafts, always inside try / catch',()=>{
  const uses=[...uiCode.matchAll(/localStorage|sessionStorage|indexedDB/g)];
  assert.ok(uses.length>=2);
  assert.match(uiCode,/function store\(k,v\)\{try\{[^}]*localStorage[^}]*\}catch\(_\)\{\}\}/);
  assert.match(uiCode,/function load\(k\)\{try\{return w\.localStorage\.getItem\(k\);\}catch\(_\)\{return null;\}\}/);
  assert.deepEqual([...new Set([...uiCode.matchAll(/'(rt_quote_[a-z_0-9]+)'/g)].map(m=>m[1]).filter(k=>/type|drafts/.test(k)))].sort(),['rt_quote_drafts_v1','rt_quote_type']);
});

test('quotations: local drafts are kept per staff member and the page starts clean when another staff member signs in',()=>{
  assert.match(uiCode,/function draftKey\(e\)\{return who\(\)\+'\|'\+/);
  assert.match(uiCode,/if\(S\.who!==me\)\{[\s\S]*?S\.rows=\[\][\s\S]*?S\.shop=null[\s\S]*?S\.ready=null/);
  assert.match(uiCode,/function who\(\)\{var p=w\.currentProfile\|\|\{\};return String\(p\.staffId\|\|p\.staff_code\|\|p\.id\|\|''\);\}/);
});

test('quotations: an edit conflict never overwrites silently (the saver chooses TIMPA or LIHAT TERKINI; a locked quotation cannot be overwritten)',()=>{
  assert.match(uiCode,/QUOTE_CHANGED\/\.test\(msgOf\(err\)\)\)\{resolveConflict\(e\);return;\}/);
  assert.match(uiCode,/function resolveConflict\(e\)\{[\s\S]*?ok:'TIMPA',cancel:'LIHAT TERKINI'[\s\S]*?rt_quote_get[\s\S]*?q\.status!=='DRAFT'&&q\.status!=='SENT'[\s\S]*?e\.revision=q\.revision/);
  assert.match(sql,/raise exception 'QUOTE_CHANGED'/);
});

test('quotations SQL: new tables only, RPC-only access, one transaction, nothing existing is changed',()=>{
  const code=sql.split('\n').filter(l=>!/^\s*--/.test(l)).join('\n');
  assert.match(code,/^\s*begin;/m);assert.match(code,/^\s*commit;/m);
  for(const t of ['quotation_counters','quotations','quotation_items']){
    assert.match(code,new RegExp('create table if not exists public\\.'+t+'\\b'));
    assert.match(code,new RegExp('alter table public\\.'+t+'\\s+enable row level security'));
    assert.match(code,new RegExp('revoke all on public\\.'+t+'\\s+from public, anon, authenticated'));
  }
  const alters=[...code.matchAll(/alter table\s+(?:if exists\s+)?(?:only\s+)?(public\.\w+)/gi)].map(m=>m[1]);
  assert.ok(alters.every(t=>/quotation/.test(t)),alters);
  assert.ok(!/drop\s+(table|function|trigger|policy|column)/i.test(code),'no drop outside the commented rollback');
  assert.ok(!/create\s+(policy|trigger)\b/i.test(code));
  const del=[...code.matchAll(/delete\s+from\s+(public\.\w+)/gi)].map(m=>m[1]);
  assert.deepEqual([...new Set(del)],['public.quotation_items'],'the only delete is the replacement of a quotation\'s own items');
  const ins=[...new Set([...code.matchAll(/insert\s+into\s+(public\.\w+)/gi)].map(m=>m[1]))].sort();
  assert.deepEqual(ins,['public.audit_logs','public.quotation_counters','public.quotation_items','public.quotations']);
  const upd=[...new Set([...code.matchAll(/\bupdate\s+(public\.\w+)/gi)].map(m=>m[1]))].sort();
  assert.deepEqual(upd,['public.quotations']);
});

test('quotations SQL: every function is security definer with a fixed search_path, only "authenticated" may run it, anon may not',()=>{
  const code=sql.split('\n').filter(l=>!/^\s*--/.test(l)).join('\n');
  const fns=[...code.matchAll(/create or replace function (public\.rt_quote_[a-z_]+)\(/g)].map(m=>m[1]);
  assert.deepEqual(fns.sort(),['public.rt_quote_get','public.rt_quote_json','public.rt_quote_list','public.rt_quote_ready','public.rt_quote_save','public.rt_quote_set_status']);
  for(const f of fns.filter(f=>!/ready/.test(f))){
    const body=code.slice(code.indexOf('create or replace function '+f+'('));
    const head=body.slice(0,body.indexOf('as $'));
    assert.match(head,/security definer/,f);
    assert.match(head,/set search_path/,f);
  }
  for(const f of ['rt_quote_ready()','rt_quote_save(jsonb)','rt_quote_set_status(uuid, text, text)','rt_quote_get(uuid)','rt_quote_list(text, text, text, int, int)']){
    assert.ok(code.includes('revoke all on function public.'+f+' from public;'),'revoke public '+f);
    assert.ok(code.includes('revoke execute on function public.'+f+' from anon;'),'revoke anon '+f);
    assert.ok(code.includes('grant execute on function public.'+f+' to authenticated;'),'grant '+f);
  }
  assert.ok(!/grant[^;]*\bto\b[^;]*\banon\b/i.test(code),'nothing is granted to anon');
  assert.ok(code.includes('revoke all on function public.rt_quote_json(uuid) from public, anon, authenticated;'),'the internal JSON helper is not callable');
});

test('quotations SQL: the same staff roles are allowed everywhere and the role comes from the server, not the browser',()=>{
  const code=sql.split('\n').filter(l=>!/^\s*--/.test(l)).join('\n');
  const lists=[...code.matchAll(/not in \(('owner'[^)]*)\)/g)].map(m=>m[1]);
  assert.ok(lists.length>=3);
  const sets=new Set(lists.map(l=>l.split(',').map(x=>x.trim()).sort().join()));
  assert.equal(sets.size,1,'one role list');
  assert.equal([...sets][0],["'admin'","'cashier'","'manager'","'owner'","'pos'","'staff'","'super_admin'"].join());
  assert.ok(!/mechanic|pomen/.test(code),'mechanics are not allowed');
  assert.equal([...code.matchAll(/rt_staff_context\(\)/g)].length>=5,true);
  assert.ok(!/p_company|p_staff|p_role|'company_id'\s*,\s*p_/.test(code),'no company / staff / role argument from the browser');
  assert.match(code,/if auth\.uid\(\) is null then raise exception 'AUTH_REQUIRED'/);
});

test('quotations SQL: the guards the page relies on exist (idempotency, revision, lock, reason, number series)',()=>{
  for(const s of ["unique (company_id, quote_no)",'quotations_client_ref_uq',"raise exception 'QUOTE_CHANGED'","raise exception 'QUOTE_LOCKED'","raise exception 'QUOTE_REASON_REQUIRED'","raise exception 'QUOTE_ADMIN_ONLY'",
                  "check (quote_type in ('UBAH_SUAI','SERVIS'))","'UBS'","'SRV'","on conflict (company_id, quote_type, yr)","'QUOTE_CREATED'","'QUOTE_UPDATED'","'QUOTE_STATUS'",'Asia/Kuala_Lumpur'])
    assert.ok(sql.includes(s),s);
});

test('quotations (simpan sementara): unsaved forms are listed on the page, not hidden; SIMPAN SEMENTARA only for new / DRAF quotations and only when the server has the upgrade',()=>{
  assert.match(uiCode,/function paintDrafts\(\)/);
  assert.match(uiCode,/Draf belum disimpan ke pangkalan data/);
  assert.match(uiCode,/function myDrafts\(\)\{[\s\S]*?k\.indexOf\(mine\)!==0/,'only this staff member\'s drafts');
  assert.match(uiCode,/function canTemp\(e\)\{return S\.version>=2&&\(!e\.id\|\|e\.status==='DRAFT'\);\}/);
  assert.match(uiCode,/S\.version=Number\(r&&r\.version\)\|\|1/);
  assert.match(uiCode,/var partial=!!q\.is_partial;\s*if\(!partial\)\{\s*add\(main,'pdf'[\s\S]*?add\(main,'wa'/,'PDF / WhatsApp only when complete');
  assert.match(uiCode,/if\(st==='DRAFT'&&!partial\)/);
  assert.match(uiCode,/if\(!partial\)add\(stat,'status','DITERIMA'/);
  assert.match(uiCode,/partial:!complete/);
  assert.match(uiCode,/partial:false\};/,'the normal save always says partial:false');
  assert.match(uiCode,/q\.is_partial&&Number\(it\.unit_price\)===0\)r\.unit_price=''/,'a blank price saved as 0 is shown blank again');
  assert.match(uiCode,/data-qact="savetemp"/);
  for(const k of ['draft-open','draft-del','savetemp'])assert.ok(uiCode.includes("case '"+k+"'"),k);
  assert.match(uiCode,/QUOTE_INCOMPLETE:/);
});

test('quotations SQL 2026-10-09 (simpan sementara): only the Sebut Harga objects, strict rules unchanged, partial only for new / DRAF, unfinished cannot be sent',()=>{
  const code=sql2.split('\n').filter(l=>!/^\s*--/.test(l)).join('\n');
  assert.match(code,/^\s*begin;/m);assert.match(code,/^\s*commit;/m);
  assert.match(code,/RUN_MIGRATION_2026_10_08_QUOTATIONS_FIRST/);
  assert.deepEqual([...code.matchAll(/alter table\s+(public\.\w+)\s+add column if not exists (\w+)/gi)].map(m=>m[1]+'.'+m[2]),['public.quotations.is_partial']);
  assert.ok(!/drop\s+(table|function|trigger|policy|column)|create\s+(table|policy|trigger)/i.test(code));
  const fns=[...code.matchAll(/create or replace function (public\.rt_quote_[a-z_]+)\(/g)].map(m=>m[1]).sort();
  assert.deepEqual(fns,['public.rt_quote_list','public.rt_quote_ready','public.rt_quote_save','public.rt_quote_set_status']);
  for(const f of fns.filter(f=>!/ready/.test(f))){
    const body=code.slice(code.indexOf('create or replace function '+f+'('));const head=body.slice(0,body.indexOf('as $'));
    assert.match(head,/security definer/,f);assert.match(head,/set search_path/,f);
  }
  assert.ok(!/grant[^;]*\bto\b[^;]*\banon\b/i.test(code));
  const del=[...code.matchAll(/delete\s+from\s+(public\.\w+)/gi)].map(m=>m[1]);
  assert.deepEqual([...new Set(del)],['public.quotation_items']);
  for(const g of ["raise exception 'QUOTE_PARTIAL_ONLY_DRAFT'","raise exception 'QUOTE_INCOMPLETE'","raise exception 'QUOTE_CHANGED'","raise exception 'QUOTE_LOCKED'","raise exception 'QUOTE_ADMIN_ONLY'","raise exception 'QUOTE_REASON_REQUIRED'","'version', 2","'partial', v_partial"])
    assert.ok(code.includes(g),g);
  // the strict rules of the first file are still there word for word in the non-partial path
  for(const g of ["raise exception 'QUOTE_ITEMS_REQUIRED'","raise exception 'QUOTE_CUSTOMER_REQUIRED'","raise exception 'QUOTE_ITEM_QTY_INVALID'","raise exception 'QUOTE_ITEM_PRICE_INVALID'","raise exception 'QUOTE_ITEM_NUMBER_INVALID'","raise exception 'QUOTE_DISCOUNT_TOO_BIG'","raise exception 'QUOTE_ITEM_DESCRIPTION_REQUIRED'","raise exception 'QUOTE_TOO_MANY_ITEMS'"])
    assert.ok(code.includes(g),g);
  const lists=[...code.matchAll(/not in \(('owner'[^)]*)\)/g)].map(m=>m[1].split(',').map(x=>x.trim()).sort().join());
  assert.ok(lists.length>=2&&new Set(lists).size===1&&lists[0]===["'admin'","'cashier'","'manager'","'owner'","'pos'","'staff'","'super_admin'"].join(),'same roles as the first file');
  assert.ok(!/mechanic|pomen/.test(code));
});

test('quotations: no model / assistant identifiers in the new files',()=>{
  for(const f of ['js/rt-quotation.js','js/rt-quotation-pdf.js','css/rt-quotation.css','migration_2026_10_08_quotations.sql','migration_2026_10_09_quotations_temp_save.sql','tests/sql-quotations.pglite.cjs','tests/sql-quotations-temp.pglite.cjs','tests/quotation-pdf.test.cjs']){
    assert.ok(!/claude|anthropic|sonnet|opus|fable|haiku|gpt|openai/i.test(read(f)),f);
  }
});
