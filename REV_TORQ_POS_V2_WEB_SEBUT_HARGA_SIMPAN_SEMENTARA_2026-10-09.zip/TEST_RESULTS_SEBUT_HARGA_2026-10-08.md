# Verification — Sebut Harga / Quotation (2026-10-08)

## Automated

**SQL on a throw-away Postgres (PGlite) — `tests/sql-quotations.pglite.cjs`: 103 / 103 passed**
This is NOT your real database: it runs `migration_2026_10_08_quotations.sql` on a stand-in schema (staff, customers, vehicles, products, audit_logs, `rt_staff_context`) that I derived from how the app uses them.
Run PART 0 of the SQL file first on your real project.
- the file runs, and runs a second time without breaking; PART 0 is valid SQL; refuses to run (and changes nothing) if `audit_logs` lacks a column or `rt_staff_context` is missing; the rollback block works and keeps the audit rows
- login / role: no login → `AUTH_REQUIRED`; login without a staff row → `STAFF_ONLY`; mechanic → refused for list / save / read / status
- numbers: `UBS-yyyy-0001, 0002` and `SRV-yyyy-0001` are separate series, another company starts again at 0001; company / staff / number / status / total in the payload are ignored (taken from the server)
- totals: line = qty × price rounded like the database (3 × 3.335 → 3.34 × 3 = 10.02), subtotal, discount, total from the server; own customer / vehicle / product linked, another company's dropped
- 15 refusals (no name, bad type, no items, empty description, qty 0 / negative, negative price, text price, discount > subtotal, negative / text discount, bad date, 81 items, not an object) leave no quotation, no item and do not use up a number
- idempotent save (same `client_ref` → same quotation, `duplicate: true`, no new number); the same ref in another company is a different quotation; two saves at once get different numbers
- edit: replaces items, keeps number + type (type in the payload ignored), revision +1; stale revision → `QUOTE_CHANGED`; another company → not found
- status rules: DRAFT→SENT→ACCEPTED / REJECTED, REJECTED→SENT, locked quotations cannot be edited, cancelling needs a reason, cashier cannot cancel an ACCEPTED one (admin can), CANCELLED is final, nothing goes back to DRAFT
- list: only this company, newest first, no items; filters (kind, status), search (number, name, phone, plate, title; `%` and `_` are plain letters), paging + `has_more`, counts per status, `expired` flag (never for ACCEPTED)
- RPC-only: `authenticated` and `anon` cannot read or write the 3 tables, cannot call the internal JSON helper; `anon` cannot call any RPC
- audit: one row for every create / edit / status change (who, from → to, reason, before / after totals)

**Node suite: 191 / 192 passed** (30 of them new: 15 in `tests/quotation-pdf.test.cjs`, 14 in `tests/quotation-ui.test.cjs`, and the SQL test above counted once).
Some old checks pinned the exact menu and were updated on purpose (see below). The one failure is the old "root / APK assets / WAB_DEPLOY runtime files are identical" check (no Android folder in the web build) — same as in the last release.
Old tests that pinned the exact menu were updated on purpose (`navPrimary` now has `quotes`; cashier roles are `['pos','sales','quotes']` and still have no Booking).
- `quotation-pdf` (15): valid A4 PDF (header, xref offsets, stream lengths, trailer, page count), every field on the page, SERVIS vs UBAH SUAI, Malaysia date (UTC+8), wrapping never wider than the column, Helvetica widths, numbers on one right edge, text inside the margins, long list over pages with the table header repeated and totals + signatures last, DIBATALKAN stamp only when cancelled, brackets / backslashes / odd characters cannot break the file, empty data still gives a valid PDF, poppler (`pdfinfo` / `pdftotext`) opens it and reads the same words, WhatsApp text, safe file name, pure ES5-style module
- `quotation-ui` (14): page + css + scripts wired in the right order (`rt-polish.js` still last), menu / roles, only `rt_quote_*` RPCs and only reads of customers / vehicles / products (no direct writes, no sale / stock / cash / invoice code, nothing touches the POS cart or checkout), ES2017-only syntax and no flex `gap`, browser storage only in try / catch, per-staff drafts, edit conflicts never overwrite silently, SQL guards (security definer + fixed search_path on every function, grants only to `authenticated`, the only DELETE is replacing a quotation's own items, nothing existing is altered)

## Browser run with a simulated backend (Chromium)
Sizes: laptop 1366×768 (mouse), short laptop 1366×657, iPad 1024×768 / 1180×820, iPad portrait 820×1180, phone 390×844.
**Quotation page: 171 / 171 passed**
- opens from the sidebar (label "Quotation", not cut off), only that page visible, page title Sebut Harga; two kinds as tabs; empty state
- new quotation: validation (name, row, price, discount > subtotal) with the box marked and focused; "1,250.50" and "2,5" read as numbers; live totals; blank row ignored; double tap on SIMPAN = one quotation; payload has numbers (not text), `client_ref`, kind
- PDF / KONGSI hands a real PDF file (name, type, size, `%PDF-1.4`) to the share sheet; after sharing a DRAF it asks "Tandakan DIHANTAR?"; WHATSAPP (TEKS) opens `wa.me/<customer number>?text=…` with the whole quotation
- edit a SENT quotation; conflict (someone else saved first): asks TIMPA / LIHAT TERKINI, nothing saved until the second SIMPAN, LIHAT TERKINI shows the other version, a quotation accepted meanwhile cannot be overwritten
- status: DITERIMA asks first and locks (no EDIT); cashier cannot cancel an accepted one, admin can; cancel without a reason refused; DITOLAK keeps the reason, BUKA SEMULA clears it; cancelled hidden under "Semua" and listed under "Dibatal"
- SALIN makes a new quotation with a new number; SERVIS has its own number series and its own list; "+ DARI STOK" adds name / SKU / price (dialog stays open to add more); customer search → his motorcycles → fills name, phone, plate, model; typing over the name removes the old customer link
- draft on the device: kept while typing, "Sambung draf?" after a reload, leaving asks first, MULA BARU clears it
- connection lost while saving: message, form + draft kept, the retry creates exactly one quotation (same `client_ref`)
- list: 30 per page + MUAT LAGI, search by plate on the server, chips with counts
- roles: cashier / staff / pos / owner see the page; pomen / stor do not (and `switchView('quotes')` is refused); cashier cannot edit or cancel an accepted quotation but can still send it
- SQL not run yet → clear banner naming the file; "Semak Semula" works after; failing list → retry; save when the functions are missing → tells to run the file and keeps the form
- layout on every size above: no sideways scroll, inputs 16 px+ (no iPad zoom) and 44 px+ tall, SIMPAN visible without scrolling and the sticky bar reaches the screen edge, row numbers stay inside the row (phone: line total on its own line), action buttons 40 px+ and on screen
- quotations never called a sale RPC, never created an invoice, never touched stock; no page errors, no outside requests
- laptop keyboard: Enter in a text box does not save, Tab order, Escape closes dialogs

**Regression (same build):** audit fixes 112 / 112, add motorcycle 72 / 72, cart room + customer dialog 182 / 182, receipt PDF + points 57 / 57, Pesanan serentak 88 / 88, Gantung 31 / 31, POS 54 / 54 (its two menu checks now expect "Quotation" in the sidebar), WhatsApp 15 / 15, Papan Bengkel 25 / 25, Carian pantas 25 / 25, Pesan stok 28 / 28, Booking 28 / 28, full names 63 / 63, tidy-ups 26 / 26, Override + audit 109 / 109, offline / fast 59 / 59, customer list, scanner overlay guard, job-checkout heal, job part product id, native bridge: unchanged.

## Not verified
- **Your real database.** The SQL file ran on a stand-in Postgres, not on your project. Role names (`owner, admin, super_admin, manager, cashier, pos, staff`), `rt_staff_context()` and the `audit_logs` columns are taken from your earlier migrations. PART 0 of the file checks the first two. If `anon` / `authenticated` or RLS are set up differently in your project, the first save is where it would show.
- A real iPad: the share sheet with a PDF file, the keyboard, the date picker; a real Windows laptop screen. (Chromium emulation only; the share sheet was replaced by a stub that receives the PDF.)
- The PDF was opened with poppler, not with iOS "Files" / Chrome / Edge viewers. It uses the standard PDF fonts (Helvetica), no embedded fonts, no images.
- WhatsApp itself (the app opening the chat and attaching the file).
- Printing the PDF (A4 margins 40 pt).
