-- REV TORQ POS V2 — SEBUT HARGA / QUOTATION (2026-10-08)
--
-- WHAT THIS DOES
--   * Two NEW tables (quotations, quotation_items) + one counter table (quotation_counters).
--     Nothing existing is changed: no table, column, policy or function that is already in
--     your database is touched. The POS, Job Card and checkout do not read these tables.
--   * Two separate kinds of quotation, each with its own number series that restarts every year:
--       UBAH_SUAI  (motosikal ubah suai)  ->  UBS-2026-0001, UBS-2026-0002 ...
--       SERVIS     (motosikal servis)     ->  SRV-2026-0001, SRV-2026-0002 ...
--   * RPC-only access (same pattern as the other V2 modules): the tables have row level
--     security ON, no policy, and no direct privilege for anon / authenticated. Everything
--     goes through security-definer functions that read the staff row from the login
--     (rt_staff_context) - the browser can never choose the company, the staff or the number.
--   * Totals are always calculated on the server (qty x price per line, then the discount).
--   * Saving a NEW quotation is idempotent (client_ref): a double tap or a retry after a
--     bad connection returns the same quotation instead of making a second one.
--   * Two people editing the same quotation: the second save is refused (QUOTE_CHANGED) and
--     the app asks to reload, so nobody overwrites the other silently.
--   * A quotation is never deleted. It is CANCELLED (with a reason). Every create / edit /
--     status change writes a row to audit_logs in the same transaction.
--
-- HOW TO RUN (Supabase -> SQL Editor)
--   1. Optional, read-only check first (PART 0): make sure rt_staff_context and audit_logs exist.
--   2. Run everything between BEGIN and COMMIT in one go. It is one transaction:
--      if anything fails, nothing is changed.
--   3. Reload the app. The "Sebut Harga" page tells you if this file has not been run yet.
--   Rollback: PART 9 (commented out).
--
-- Quotations are NOT linked to the POS cart or the Job Card (by design, for now).

-- =====================================================================
-- PART 0 — DIAGNOSTICS (read-only; optional)
-- =====================================================================
-- select proname from pg_proc p join pg_namespace n on n.oid=p.pronamespace
--  where n.nspname='public' and proname in ('rt_staff_context');           -- expect 1 row
-- select column_name from information_schema.columns
--  where table_schema='public' and table_name='audit_logs' order by ordinal_position;
-- select to_regclass('public.quotations') as quotations_exists;             -- expect NULL before running

begin;

-- Fail early (and change nothing) if what this script relies on is missing.
do $check$
declare missing text;
begin
  if to_regprocedure('public.rt_staff_context()') is null then
    raise exception 'RT_STAFF_CONTEXT_MISSING';
  end if;
  select string_agg(c, ', ') into missing
  from unnest(array['id','company_id','location_id','transaction_id','staff_id','action',
                    'entity_type','entity_id','before_data','after_data','metadata','created_at']) c
  where not exists (select 1 from information_schema.columns
                    where table_schema='public' and table_name='audit_logs' and column_name=c);
  if missing is not null then
    raise exception 'AUDIT_LOGS_COLUMNS_MISSING: %', missing;
  end if;
end
$check$;

-- =====================================================================
-- PART 1 — TABLES
-- =====================================================================
create table if not exists public.quotation_counters (
  company_id uuid not null,
  quote_type text not null,
  yr         int  not null,
  last_no    int  not null default 0,
  primary key (company_id, quote_type, yr)
);

create table if not exists public.quotations (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null,
  location_id    uuid,
  quote_type     text not null check (quote_type in ('UBAH_SUAI','SERVIS')),
  quote_no       text not null,
  client_ref     text,
  status         text not null default 'DRAFT'
                 check (status in ('DRAFT','SENT','ACCEPTED','REJECTED','CANCELLED')),
  revision       int  not null default 1,
  customer_id    uuid,
  vehicle_id     uuid,
  customer_name  text not null,
  customer_phone text,
  plate_no       text,
  vehicle_model  text,
  title          text,
  notes          text,
  valid_until    date,
  subtotal       numeric(12,2) not null default 0,
  discount       numeric(12,2) not null default 0 check (discount >= 0),
  total          numeric(12,2) not null default 0,
  status_note    text,
  created_by     uuid,
  updated_by     uuid,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  sent_at        timestamptz,
  decided_at     timestamptz,
  cancelled_at   timestamptz,
  unique (company_id, quote_no)
);
create unique index if not exists quotations_client_ref_uq
  on public.quotations (company_id, client_ref) where client_ref is not null;
create index if not exists quotations_list_ix
  on public.quotations (company_id, quote_type, status, created_at desc);

create table if not exists public.quotation_items (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  quotation_id uuid not null references public.quotations(id),
  line_no      int  not null,
  kind         text not null default 'PART' check (kind in ('PART','LABOUR','OTHER')),
  product_id   uuid,
  sku          text,
  description  text not null,
  quantity     numeric(10,2) not null check (quantity > 0),
  unit_price   numeric(12,2) not null check (unit_price >= 0),
  line_total   numeric(12,2) not null
);
create index if not exists quotation_items_q_ix on public.quotation_items (quotation_id, line_no);

-- RPC-only: row level security on, no policy, no direct privilege.
alter table public.quotation_counters enable row level security;
alter table public.quotations         enable row level security;
alter table public.quotation_items    enable row level security;
revoke all on public.quotation_counters from public, anon, authenticated;
revoke all on public.quotations         from public, anon, authenticated;
revoke all on public.quotation_items    from public, anon, authenticated;

-- =====================================================================
-- PART 2 — HELPERS
-- =====================================================================
create or replace function public.rt_quote_ready()
returns jsonb
language sql
stable
set search_path = public, pg_temp
as $$ select jsonb_build_object('ready', true, 'version', 1) $$;

-- One quotation (with items) as JSON. Internal: callers check company + role first.
create or replace function public.rt_quote_json(p_id uuid)
returns jsonb
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select to_jsonb(q) || jsonb_build_object(
           'created_by_name', (select s.name from public.staff s where s.id = q.created_by),
           'expired', (q.status in ('DRAFT','SENT') and q.valid_until is not null
                       and q.valid_until < (now() at time zone 'Asia/Kuala_Lumpur')::date),
           'items', coalesce((select jsonb_agg(jsonb_build_object(
                       'id', i.id, 'line_no', i.line_no, 'kind', i.kind, 'product_id', i.product_id,
                       'sku', i.sku, 'description', i.description, 'quantity', i.quantity,
                       'unit_price', i.unit_price, 'line_total', i.line_total) order by i.line_no)
                     from public.quotation_items i where i.quotation_id = q.id), '[]'::jsonb))
  from public.quotations q where q.id = p_id
$$;
revoke all on function public.rt_quote_json(uuid) from public, anon, authenticated;

-- =====================================================================
-- PART 3 — SAVE (create or edit)
-- =====================================================================
-- p_quote = {
--   id?, client_ref?, quote_type (on create), expected_revision? (on edit),
--   customer_name, customer_phone?, plate_no?, vehicle_model?, customer_id?, vehicle_id?,
--   title?, notes?, valid_until? (YYYY-MM-DD), discount?,
--   items: [ { kind?, description, quantity, unit_price, sku?, product_id? } ... ]
-- }
create or replace function public.rt_quote_save(p_quote jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  v_staff     record;
  v_q         public.quotations%rowtype;
  v_before    jsonb;
  v_id        uuid;
  v_ref       text;
  v_type      text;
  v_name      text;
  v_phone     text;
  v_plate     text;
  v_model     text;
  v_title     text;
  v_notes     text;
  v_valid     date;
  v_disc      numeric;
  v_sub       numeric := 0;
  v_cust      uuid;
  v_veh       uuid;
  v_item      jsonb;
  v_n         int := 0;
  v_desc      text;
  v_qty       numeric;
  v_price     numeric;
  v_kind      text;
  v_prod      uuid;
  v_sku       text;
  v_line      numeric;
  v_year      int;
  v_no        int;
  v_prefix    text;
  v_action    text;
  v_today     date := (now() at time zone 'Asia/Kuala_Lumpur')::date;
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into v_staff from public.rt_staff_context() limit 1;
  if v_staff.staff_id is null then raise exception 'STAFF_ONLY'; end if;
  if lower(coalesce(v_staff.role,'')) not in ('owner','admin','super_admin','manager','cashier','pos','staff') then
    raise exception 'QUOTE_ROLE_NOT_ALLOWED';
  end if;
  if p_quote is null or jsonb_typeof(p_quote) <> 'object' then raise exception 'QUOTE_INVALID'; end if;

  -- ---- read + clean the fields (never trust lengths from the browser)
  v_name  := left(btrim(coalesce(p_quote->>'customer_name','')), 120);
  v_phone := left(btrim(coalesce(p_quote->>'customer_phone','')), 40);
  v_plate := upper(left(btrim(coalesce(p_quote->>'plate_no','')), 20));
  v_model := left(btrim(coalesce(p_quote->>'vehicle_model','')), 80);
  v_title := left(btrim(coalesce(p_quote->>'title','')), 160);
  v_notes := left(btrim(coalesce(p_quote->>'notes','')), 2000);
  v_ref   := nullif(left(btrim(coalesce(p_quote->>'client_ref','')), 80), '');
  if v_name = '' then raise exception 'QUOTE_CUSTOMER_REQUIRED'; end if;

  begin
    v_valid := nullif(btrim(coalesce(p_quote->>'valid_until','')), '')::date;
  exception when others then
    raise exception 'QUOTE_VALID_UNTIL_INVALID';
  end;

  begin
    v_disc := round(coalesce(nullif(btrim(coalesce(p_quote->>'discount','')), '')::numeric, 0), 2);
  exception when others then
    raise exception 'QUOTE_DISCOUNT_INVALID';
  end;
  if v_disc < 0 then raise exception 'QUOTE_DISCOUNT_INVALID'; end if;

  if jsonb_typeof(p_quote->'items') is distinct from 'array' or jsonb_array_length(p_quote->'items') = 0 then
    raise exception 'QUOTE_ITEMS_REQUIRED';
  end if;
  if jsonb_array_length(p_quote->'items') > 80 then raise exception 'QUOTE_TOO_MANY_ITEMS'; end if;

  -- Optional links to existing customer / motorcycle: must belong to this company.
  v_cust := null; v_veh := null;
  begin v_cust := nullif(p_quote->>'customer_id','')::uuid; exception when others then v_cust := null; end;
  begin v_veh  := nullif(p_quote->>'vehicle_id','')::uuid;  exception when others then v_veh := null; end;
  if v_cust is not null and not exists
     (select 1 from public.customers c where c.id = v_cust and c.company_id = v_staff.company_id) then
    v_cust := null;
  end if;
  if v_veh is not null and not exists
     (select 1 from public.vehicles v where v.id = v_veh and v.company_id = v_staff.company_id) then
    v_veh := null;
  end if;

  -- ---- find the quotation (edit) or an earlier save of the same client_ref (retry)
  v_id := null;
  begin v_id := nullif(p_quote->>'id','')::uuid; exception when others then raise exception 'QUOTE_NOT_FOUND'; end;

  if v_id is null and v_ref is not null then
    select q.id into v_id from public.quotations q
     where q.company_id = v_staff.company_id and q.client_ref = v_ref;
    if v_id is not null then
      return public.rt_quote_json(v_id) || jsonb_build_object('duplicate', true);
    end if;
  end if;

  if v_id is not null then
    -- ===== EDIT
    select * into v_q from public.quotations q
     where q.id = v_id and q.company_id = v_staff.company_id for update;
    if not found then raise exception 'QUOTE_NOT_FOUND'; end if;
    if v_q.status not in ('DRAFT','SENT') then raise exception 'QUOTE_LOCKED'; end if;
    if nullif(p_quote->>'expected_revision','') is not null
       and (p_quote->>'expected_revision')::int <> v_q.revision then
      raise exception 'QUOTE_CHANGED';
    end if;
    v_before := public.rt_quote_json(v_id);
    v_type := v_q.quote_type;                       -- the kind never changes after creation
    v_action := 'QUOTE_UPDATED';
    delete from public.quotation_items where quotation_id = v_id;
  else
    -- ===== CREATE
    v_type := upper(btrim(coalesce(p_quote->>'quote_type','')));
    if v_type not in ('UBAH_SUAI','SERVIS') then raise exception 'QUOTE_TYPE_INVALID'; end if;
    v_year := extract(year from (now() at time zone 'Asia/Kuala_Lumpur'))::int;
    insert into public.quotation_counters(company_id, quote_type, yr, last_no)
    values (v_staff.company_id, v_type, v_year, 1)
    on conflict (company_id, quote_type, yr)
    do update set last_no = public.quotation_counters.last_no + 1
    returning last_no into v_no;
    v_prefix := case v_type when 'UBAH_SUAI' then 'UBS' else 'SRV' end;
    insert into public.quotations(company_id, location_id, quote_type, quote_no, client_ref, status,
                                  customer_name, subtotal, discount, total, created_by, updated_by)
    values (v_staff.company_id, v_staff.location_id, v_type,
            v_prefix || '-' || v_year || '-' || lpad(v_no::text, 4, '0'), v_ref, 'DRAFT',
            v_name, 0, 0, 0, v_staff.staff_id, v_staff.staff_id)
    returning id into v_id;
    v_before := null;
    v_action := 'QUOTE_CREATED';
  end if;

  -- ---- items (qty x price is calculated here, the browser's totals are ignored)
  for v_item in select * from jsonb_array_elements(p_quote->'items') loop
    v_desc := left(btrim(coalesce(v_item->>'description','')), 200);
    if v_desc = '' then raise exception 'QUOTE_ITEM_DESCRIPTION_REQUIRED'; end if;
    begin
      v_qty   := round((v_item->>'quantity')::numeric, 2);
      v_price := round((v_item->>'unit_price')::numeric, 2);
    exception when others then
      raise exception 'QUOTE_ITEM_NUMBER_INVALID';
    end;
    if v_qty is null or v_qty <= 0 or v_qty > 99999 then raise exception 'QUOTE_ITEM_QTY_INVALID'; end if;
    if v_price is null or v_price < 0 or v_price > 9999999 then raise exception 'QUOTE_ITEM_PRICE_INVALID'; end if;
    v_kind := upper(btrim(coalesce(v_item->>'kind','PART')));
    if v_kind not in ('PART','LABOUR','OTHER') then v_kind := 'PART'; end if;
    v_sku := nullif(left(btrim(coalesce(v_item->>'sku','')), 60), '');
    v_prod := null;
    begin v_prod := nullif(v_item->>'product_id','')::uuid; exception when others then v_prod := null; end;
    if v_prod is not null and not exists
       (select 1 from public.products p where p.id = v_prod and p.company_id = v_staff.company_id) then
      v_prod := null;
    end if;
    v_line := round(v_qty * v_price, 2);
    v_n := v_n + 1;
    v_sub := v_sub + v_line;
    insert into public.quotation_items(company_id, quotation_id, line_no, kind, product_id, sku,
                                       description, quantity, unit_price, line_total)
    values (v_staff.company_id, v_id, v_n, v_kind, v_prod, v_sku, v_desc, v_qty, v_price, v_line);
  end loop;

  if v_disc > v_sub then raise exception 'QUOTE_DISCOUNT_TOO_BIG'; end if;
  if v_sub > 99999999 then raise exception 'QUOTE_TOTAL_TOO_BIG'; end if;

  update public.quotations q set
         customer_id = v_cust, vehicle_id = v_veh,
         customer_name = v_name, customer_phone = nullif(v_phone,''), plate_no = nullif(v_plate,''),
         vehicle_model = nullif(v_model,''), title = nullif(v_title,''), notes = nullif(v_notes,''),
         valid_until = coalesce(v_valid, case when v_action = 'QUOTE_CREATED' then v_today + 14 else q.valid_until end),
         subtotal = v_sub, discount = v_disc, total = v_sub - v_disc,
         revision = case when v_action = 'QUOTE_UPDATED' then q.revision + 1 else q.revision end,
         updated_by = v_staff.staff_id, updated_at = now()
   where q.id = v_id;

  insert into public.audit_logs(company_id, location_id, staff_id, action, entity_type, entity_id, before_data, after_data, metadata)
  values (v_staff.company_id, v_staff.location_id, v_staff.staff_id, v_action, 'QUOTATION', v_id,
          case when v_before is null then null
               else jsonb_build_object('status', v_before->>'status', 'subtotal', v_before->'subtotal',
                                       'discount', v_before->'discount', 'total', v_before->'total',
                                       'items', jsonb_array_length(v_before->'items'),
                                       'customer_name', v_before->>'customer_name') end,
          jsonb_build_object('subtotal', v_sub, 'discount', v_disc, 'total', v_sub - v_disc,
                             'items', v_n, 'customer_name', v_name),
          jsonb_build_object('quote_no', (select quote_no from public.quotations where id = v_id),
                             'quote_type', v_type, 'role', v_staff.role));

  return public.rt_quote_json(v_id) || jsonb_build_object('duplicate', false);
end;
$function$;

-- =====================================================================
-- PART 4 — STATUS CHANGE
-- =====================================================================
--   DRAFT    -> SENT, ACCEPTED, REJECTED, CANCELLED
--   SENT     -> ACCEPTED, REJECTED, CANCELLED
--   REJECTED -> SENT (customer came back), CANCELLED
--   ACCEPTED -> CANCELLED (admin / owner only, reason required)
--   CANCELLED-> nothing
create or replace function public.rt_quote_set_status(p_id uuid, p_status text, p_reason text default null)
returns jsonb
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  v_staff  record;
  v_q      public.quotations%rowtype;
  v_to     text := upper(btrim(coalesce(p_status,'')));
  v_reason text := nullif(left(btrim(coalesce(p_reason,'')), 300), '');
  v_allowed boolean;
  v_admin  boolean;
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into v_staff from public.rt_staff_context() limit 1;
  if v_staff.staff_id is null then raise exception 'STAFF_ONLY'; end if;
  v_admin := lower(coalesce(v_staff.role,'')) in ('owner','admin','super_admin','manager');
  if not v_admin and lower(coalesce(v_staff.role,'')) not in ('cashier','pos','staff') then
    raise exception 'QUOTE_ROLE_NOT_ALLOWED';
  end if;
  if v_to not in ('DRAFT','SENT','ACCEPTED','REJECTED','CANCELLED') then raise exception 'QUOTE_STATUS_INVALID'; end if;

  select * into v_q from public.quotations q
   where q.id = p_id and q.company_id = v_staff.company_id for update;
  if not found then raise exception 'QUOTE_NOT_FOUND'; end if;

  if v_q.status = v_to then
    return public.rt_quote_json(p_id) || jsonb_build_object('unchanged', true);
  end if;

  v_allowed := case v_q.status
    when 'DRAFT'    then v_to in ('SENT','ACCEPTED','REJECTED','CANCELLED')
    when 'SENT'     then v_to in ('ACCEPTED','REJECTED','CANCELLED')
    when 'REJECTED' then v_to in ('SENT','CANCELLED')
    when 'ACCEPTED' then v_to = 'CANCELLED'
    else false end;
  if not v_allowed then raise exception 'QUOTE_STATUS_NOT_ALLOWED'; end if;
  if v_q.status = 'ACCEPTED' and not v_admin then raise exception 'QUOTE_ADMIN_ONLY'; end if;
  if v_to = 'CANCELLED' and v_reason is null then raise exception 'QUOTE_REASON_REQUIRED'; end if;

  update public.quotations q set
         status = v_to,
         status_note = case when v_to in ('REJECTED','CANCELLED') then v_reason else null end,
         sent_at = case when v_to = 'SENT' then coalesce(q.sent_at, now()) else q.sent_at end,
         decided_at = case when v_to in ('ACCEPTED','REJECTED') then now()
                           when v_to = 'SENT' then null else q.decided_at end,
         cancelled_at = case when v_to = 'CANCELLED' then now() else q.cancelled_at end,
         revision = q.revision + 1,
         updated_by = v_staff.staff_id, updated_at = now()
   where q.id = p_id;

  insert into public.audit_logs(company_id, location_id, staff_id, action, entity_type, entity_id, before_data, after_data, metadata)
  values (v_staff.company_id, v_staff.location_id, v_staff.staff_id, 'QUOTE_STATUS', 'QUOTATION', p_id,
          jsonb_build_object('status', v_q.status), jsonb_build_object('status', v_to),
          jsonb_build_object('quote_no', v_q.quote_no, 'quote_type', v_q.quote_type,
                             'reason', v_reason, 'total', v_q.total, 'role', v_staff.role));

  return public.rt_quote_json(p_id) || jsonb_build_object('unchanged', false);
end;
$function$;

-- =====================================================================
-- PART 5 — READ: one quotation, and the list
-- =====================================================================
create or replace function public.rt_quote_get(p_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path to 'public','pg_temp'
as $function$
declare v_staff record;
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into v_staff from public.rt_staff_context() limit 1;
  if v_staff.staff_id is null then raise exception 'STAFF_ONLY'; end if;
  if lower(coalesce(v_staff.role,'')) not in ('owner','admin','super_admin','manager','cashier','pos','staff') then
    raise exception 'QUOTE_ROLE_NOT_ALLOWED';
  end if;
  if not exists (select 1 from public.quotations q where q.id = p_id and q.company_id = v_staff.company_id) then
    raise exception 'QUOTE_NOT_FOUND';
  end if;
  return public.rt_quote_json(p_id);
end;
$function$;

-- {rows:[...], has_more, counts:{DRAFT:n,...}}  (rows have no items; counts ignore the search text)
create or replace function public.rt_quote_list(
  p_type   text default null,
  p_status text default null,
  p_search text default null,
  p_limit  int  default 30,
  p_offset int  default 0)
returns jsonb
language plpgsql
stable
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  v_staff  record;
  v_type   text := nullif(upper(btrim(coalesce(p_type,''))), '');
  v_status text := nullif(upper(btrim(coalesce(p_status,''))), '');
  v_s      text := nullif(btrim(coalesce(p_search,'')), '');
  v_lim    int  := least(greatest(coalesce(p_limit,30), 1), 100);
  v_off    int  := greatest(coalesce(p_offset,0), 0);
  v_pat    text;
  v_rows   jsonb;
  v_n      int;
  v_counts jsonb;
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into v_staff from public.rt_staff_context() limit 1;
  if v_staff.staff_id is null then raise exception 'STAFF_ONLY'; end if;
  if lower(coalesce(v_staff.role,'')) not in ('owner','admin','super_admin','manager','cashier','pos','staff') then
    raise exception 'QUOTE_ROLE_NOT_ALLOWED';
  end if;
  if v_type is not null and v_type not in ('UBAH_SUAI','SERVIS') then raise exception 'QUOTE_TYPE_INVALID'; end if;
  if v_status is not null and v_status not in ('DRAFT','SENT','ACCEPTED','REJECTED','CANCELLED') then
    raise exception 'QUOTE_STATUS_INVALID';
  end if;
  v_pat := case when v_s is null then null
                else '%' || replace(replace(replace(lower(v_s), '\', '\\'), '%', '\%'), '_', '\_') || '%' end;

  select coalesce(jsonb_object_agg(t.status, t.n), '{}'::jsonb) into v_counts
    from (select q.status, count(*)::int as n from public.quotations q
           where q.company_id = v_staff.company_id and (v_type is null or q.quote_type = v_type)
           group by q.status) t;

  select coalesce(jsonb_agg(r.j order by r.created_at desc, r.id desc), '[]'::jsonb), count(*)::int
    into v_rows, v_n
    from (select q.id, q.created_at,
                 jsonb_build_object('id', q.id, 'quote_type', q.quote_type, 'quote_no', q.quote_no, 'status', q.status,
                                    'revision', q.revision, 'customer_name', q.customer_name,
                                    'customer_phone', q.customer_phone, 'plate_no', q.plate_no,
                                    'vehicle_model', q.vehicle_model, 'title', q.title,
                                    'valid_until', q.valid_until, 'total', q.total, 'created_at', q.created_at,
                                    'updated_at', q.updated_at, 'sent_at', q.sent_at,
                                    'expired', (q.status in ('DRAFT','SENT') and q.valid_until is not null
                                                and q.valid_until < (now() at time zone 'Asia/Kuala_Lumpur')::date)) as j
            from public.quotations q
           where q.company_id = v_staff.company_id
             and (v_type is null or q.quote_type = v_type)
             and (v_status is null or q.status = v_status)
             and (v_pat is null
                  or lower(q.quote_no) like v_pat or lower(q.customer_name) like v_pat
                  or lower(coalesce(q.customer_phone,'')) like v_pat or lower(coalesce(q.plate_no,'')) like v_pat
                  or lower(coalesce(q.title,'')) like v_pat)
           order by q.created_at desc, q.id desc
           offset v_off limit v_lim + 1) r;

  -- one extra row was read only to know whether there is another page
  if v_n > v_lim then
    v_rows := (select coalesce(jsonb_agg(e.value order by e.ord), '[]'::jsonb)
                 from jsonb_array_elements(v_rows) with ordinality as e(value, ord) where e.ord <= v_lim);
  end if;
  return jsonb_build_object('rows', v_rows, 'has_more', v_n > v_lim, 'counts', v_counts);
end;
$function$;

-- =====================================================================
-- PART 6 — PERMISSIONS
-- =====================================================================
revoke all on function public.rt_quote_ready() from public;
revoke all on function public.rt_quote_save(jsonb) from public;
revoke all on function public.rt_quote_set_status(uuid, text, text) from public;
revoke all on function public.rt_quote_get(uuid) from public;
revoke all on function public.rt_quote_list(text, text, text, int, int) from public;
revoke execute on function public.rt_quote_ready() from anon;
revoke execute on function public.rt_quote_save(jsonb) from anon;
revoke execute on function public.rt_quote_set_status(uuid, text, text) from anon;
revoke execute on function public.rt_quote_get(uuid) from anon;
revoke execute on function public.rt_quote_list(text, text, text, int, int) from anon;
grant execute on function public.rt_quote_ready() to authenticated;
grant execute on function public.rt_quote_save(jsonb) to authenticated;
grant execute on function public.rt_quote_set_status(uuid, text, text) to authenticated;
grant execute on function public.rt_quote_get(uuid) to authenticated;
grant execute on function public.rt_quote_list(text, text, text, int, int) to authenticated;

commit;

-- =====================================================================
-- PART 9 — ROLLBACK (commented out; this deletes all quotations!)
-- =====================================================================
-- begin;
-- drop function if exists public.rt_quote_list(text, text, text, int, int);
-- drop function if exists public.rt_quote_get(uuid);
-- drop function if exists public.rt_quote_set_status(uuid, text, text);
-- drop function if exists public.rt_quote_save(jsonb);
-- drop function if exists public.rt_quote_json(uuid);
-- drop function if exists public.rt_quote_ready();
-- drop table if exists public.quotation_items;
-- drop table if exists public.quotations;
-- drop table if exists public.quotation_counters;
-- commit;
