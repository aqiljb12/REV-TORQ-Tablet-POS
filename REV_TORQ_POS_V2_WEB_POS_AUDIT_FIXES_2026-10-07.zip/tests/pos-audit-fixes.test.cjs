const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const vm=require('vm');
const root=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
const between=(src,a,b)=>{const i=src.indexOf(a);assert.ok(i>=0,a);const j=src.indexOf(b,i);assert.ok(j>i,b);return src.slice(i,j);};

test('product search: every word must match, any order, extra spaces and capitals ignored, name / SKU matches first',()=>{
  const src=read('js/pos.js');
  const code=between(src,'function rtPosTokens','window.rtPosMatches = rtPosMatches;')+'window.rtPosMatches = rtPosMatches;';
  const products=[
    {name:'Motul 7100 10W40 1L',sku:'MO-10W40',barcode:'111',rackCode:'RAK-A',category:'Minyak'},
    {name:'Shell Advance AX7 1L',sku:'MO-SHELL',barcode:'222',rackCode:'RAK-B',category:'Minyak'},
    {name:'Honda Brake Pad Depan',sku:'BP-HON',barcode:'333',rackCode:'RAK-C',category:'Brake'},
    {name:'Brake Pad Belakang Y15',sku:'BP-Y15',barcode:'444',rackCode:'RAK-C',category:'Brake'},
    {name:'Minyak Brek DOT4',sku:'MO-BRAKEF',barcode:'555',rackCode:'RAK-A',category:'Minyak'}
  ];
  let shown=null;
  const sandbox={window:{},allProducts:products,renderPosGrid:x=>{shown=x;}};
  vm.createContext(sandbox);vm.runInContext(code,sandbox);
  const names=q=>{sandbox.posFilterProducts(q);return shown.map(p=>p.sku);};
  assert.deepEqual(names('motul 10w40'),['MO-10W40']);
  assert.deepEqual(names('10W40   MOTUL'),['MO-10W40']);
  assert.deepEqual(names('  shell 1l  '),['MO-SHELL']);
  assert.deepEqual(names('pad honda'),['BP-HON']);
  assert.deepEqual(names('brake pad').sort(),['BP-HON','BP-Y15']);
  assert.deepEqual(names('rak-a').sort(),['MO-10W40','MO-BRAKEF']);
  assert.deepEqual(names('zzz qqq'),[]);
  assert.equal(names('').length,5);
  assert.equal(names('mo-shell ')[0],'MO-SHELL');
  // exact SKU / barcode first
  assert.equal(names('555')[0],'MO-BRAKEF');
});

test('adding to the cart refuses a line that is not in the list (no RM 0 / no stock cap)',()=>{
  const src=read('js/pos.js');
  assert.match(src,/if \(!source && !\(Number\.isFinite\(Number\(price\)\) && Number\.isFinite\(Number\(maxStock\)\)\)\) \{[\s\S]{0,160}Barang tidak ada dalam senarai POS/);
});

test('typed quantity: input in the line, same cap as +, 0 / letters keep the old number, patched in place',()=>{
  const src=read('js/pos.js');
  assert.match(src,/class="rt-qty-input" type="text" inputmode="numeric"/);
  assert.match(src,/onchange="rtCartSetQty\('\$\{sku\}',this\.value\)"/);
  const fn=between(src,'function rtCartSetQty','function rtCartPatchRow');
  assert.match(fn,/Kuantiti minimum 1/);
  assert.match(fn,/q > item\.maxStock/);
  assert.match(fn,/rtCartPatchRow\(item\)\) renderCart\(\)/);
});

test('money on screen has thousands commas (formatMoney); receipts keep their fixed-width format',()=>{
  const core=read('js/core.js');
  const line=core.split('\n').find(l=>l.includes('function formatMoney'));
  const sandbox={};vm.createContext(sandbox);vm.runInContext(line+';this.f=formatMoney;',sandbox);
  assert.equal(sandbox.f(93),'RM 93.00');
  assert.equal(sandbox.f(1250.5),'RM 1,250.50');
  assert.equal(sandbox.f('12345.678'),'RM 12,345.68');
  assert.equal(sandbox.f('abc'),'RM 0.00');
  const pos=read('js/pos.js');
  const rc=between(pos,'async function generateReceiptFromInvoice','// WhatsApp number in international digits');
  assert.doesNotMatch(rc,/toLocaleString\('en-US'/,'the printed receipt columns are 64 px wide');
});

test('rt-pos-fixes.js: reads only (products / stock_balances / locations), never posts, plain ES2017',()=>{
  const src=read('js/rt-pos-fixes.js');
  assert.doesNotMatch(src,/\.rpc\(|supabaseRpc|\.insert\(|\.update\(|\.upsert\(|\.delete\(|\bfetch\(|XMLHttpRequest|sendBeacon/);
  const tables=[...new Set([...src.matchAll(/\.from\('([a-z_]+)'\)/g)].map(m=>m[1]))].sort();
  assert.deepEqual(tables,['locations','products','stock_balances']);
  assert.doesNotMatch(src,/[\w)\]]\?\.[\w[(]/,'no optional chaining');
  assert.doesNotMatch(src,/\?\?[^=]/,'no nullish coalescing');
});

test('the gate: each wrapper once, straight through for a pending sale / Job Card, a failed check never blocks a sale',()=>{
  const src=read('js/rt-pos-fixes.js');
  assert.match(src,/var wrapped=\{method:false,calc:false,checkout:false\}/);
  assert.match(src,/rt_pos_pending_sale_v1[\s\S]{0,200}return true;/,'pending sale / Job Card: no check');
  assert.match(src,/if\(pending\)return orig\.apply\(self,args\);/);
  assert.match(src,/catch\(e\)\{console\.warn\('POS live check skipped',e\);return true;\}/);
  assert.match(src,/never trap a sale behind a bug in the gate/);
  assert.match(src,/BIG_PCT=0\.2,BIG_MIN=10/);
  // services / labour are not checked against the product list
  assert.match(src,/var lines=c\.filter\(function\(i\)\{return !isService\(i\);\}\)/);
});

test('script order: rt-pos-fixes.js after payment-qr.js and before rt-polish.js, rt-polish.js still last',()=>{
  const html=read('index.html');
  const list=[...html.matchAll(/<script src="(js\/[^"?]+)(?:\?[^"]*)?"><\/script>/g)].map(m=>m[1]);
  const at=n=>list.indexOf(n);
  assert.ok(at('js/payment-qr.js')>0&&at('js/rt-pos-fixes.js')>at('js/payment-qr.js'));
  assert.ok(at('js/rt-pos-fixes.js')<at('js/rt-polish.js'));
  assert.equal(list[list.length-1],'js/rt-polish.js');
  for(const f of ['js/pos.js','js/core.js','js/v36-4-9-pos-cash-canonical.js','js/rt-park.js','js/rt-pos-fixes.js','js/rt-receipt-pdf.js','js/rt-polish.js','css/rt-polish.css'])
    assert.match(html,new RegExp(f.replace('.','\\.')+'\\?v=[\\w.-]+'),f+' cache-busted');
  assert.match(html,/js\/pos\.js\?v=37\.0\.8-audit/);
  assert.match(html,/js\/rt-polish\.js\?v=2\.8\.0-audit/);
});

test('checkout payload: reference / motorcycle only when there is one; the plain sale is unchanged',()=>{
  const src=read('js/v36-4-9-pos-cash-canonical.js');
  assert.match(src,/else\{args\.p_discount=disc;if\(vehicleId\)args\.p_vehicle_id=vehicleId;if\(payRef\)args\.p_reference_no=payRef;\}/);
  assert.match(src,/Object\.assign\(args,\{p_vehicle_id:vehicleId,p_location_id:null,p_reference_no:payRef\|\|null\}\)/);
  assert.match(src,/const args=\{p_customer_id:selectedCustomer,p_payment_method:method==='QR \/ DUITNOW'\?'QR':method,p_amount_received:received,p_items:items,p_transaction_id:transactionId\};/);
  // the Job checkout payload is not touched
  assert.match(src,/p_kind:voucher\?'VOUCHER':promo\?'PROMO':'STANDARD'/);
  assert.doesNotMatch(between(src,"const args={p_transaction_id:transactionId,p_job_card_id","const done=await postProductSale('rt_post_job_pos_sale_idempotent'"),/p_reference_no|p_vehicle_id/);
  // the RPCs really take these parameters (migration files in this build)
  const sql=read('migration_2026_09_18_pos_item_discount.sql');
  assert.match(between(sql,'create or replace function public.rt_post_pos_sale(',')\nreturns table'),/p_vehicle_id uuid[\s\S]*p_reference_no text/);
});

test('after a sale only the sold products are re-read; the drawer status retries by itself',()=>{
  const c=read('js/v36-4-9-pos-cash-canonical.js');
  assert.match(c,/function afterSale\(sold\)\{[\s\S]{0,200}rtPosAfterSale[\s\S]{0,120}window\.loadPOS\?\.\(\)/);
  assert.equal((c.match(/afterSale\(c\)/g)||[]).length,2,'standard sale + recovered sale');
  assert.match(c,/window\.loadJobCards\?\.\(\)/,'Job checkout keeps its full reload');
  assert.match(c,/\[4000,8000,15000,30000,60000\]/);
  assert.match(c,/window\.addEventListener\('online',\(\)=>\{refreshCash\(\)\}\)/);
  const f=read('js/rt-pos-fixes.js');
  assert.match(f,/w\.rtPosAfterSale=async function\(sold\)/);
  assert.match(f,/Date\.now\(\)-lastFull>300000/);
});

test('customer search asks the database (read only) and keeps the local list instant',()=>{
  const js=read('js/rt-polish.js');
  const fn=between(js,'function remoteCustomers','function renderCustResults');
  assert.match(fn,/from\('customers'\)\.select\('id,name,phone'\)/);
  assert.doesNotMatch(fn,/\.insert\(|\.update\(|\.delete\(|\.rpc\(/);
  assert.match(fn,/phone_normalized/);
  assert.match(js,/data-remote="1"/);
  assert.match(js,/window\.rtPosSelectedVehicleId=function\(customerId\)/);
});

test('member name, scan fallback, Enter in the search box (index.html)',()=>{
  const html=read('index.html');
  assert.match(html,/id="rtPosMemberName"[^>]*maxlength="60"/);
  assert.match(html,/\(window\.rtPosSearchEnter\|\|window\.rtSelectScannedSku\)\(v\)/);
  const scan=between(html,'window.rtSelectScannedSku=async function','// ---------- INVENTORY MODAL: camera barcode scanner');
  assert.match(scan,/await window\.loadPOS\(\)/);
  assert.doesNotMatch(scan,/db\.collection\('inventory'\)/,'no half-empty item built from the database row');
  assert.match(html,/id="rtPayConfirmPanel"[\s\S]{0,400}id="rtPayConfirm" type="checkbox"[\s\S]{0,500}id="rtPayRef"/);
  const pos=read('js/pos.js');
  assert.match(pos,/p_name:typedName\|\|null/);
});

test('receipt: customer, motorcycle and reference lines only when known; PDF has them too',()=>{
  const pos=read('js/pos.js');
  assert.match(pos,/rcCustName \|\| rcCustPhone \? `<div>Pelanggan:/);
  assert.match(pos,/rcPlate \? `<div>Motosikal:/);
  assert.match(pos,/rcRef \? `<div class="flex justify-end"><span class="w-20 inline-block">Rujukan:/);
  assert.match(pos,/plateNo: rcPlate,[\s\S]{0,80}vehicleModel: rcBike,[\s\S]{0,60}paymentRef: rcRef/);
  const pdf=read('js/rt-receipt-pdf.js');
  assert.match(pdf,/kv\('Motosikal'/);
  assert.match(pdf,/push\(padRight\('Rujukan'/);
  const R=require(path.join(root,'js/rt-receipt-pdf.js'));
  const t=Buffer.from(R.buildReceiptPdfBytes({invNo:'INV-1',items:[],rows:[],total:10,method:'TRANSFER',received:10,balance:0,plateNo:'VAB 1234',vehicleModel:'Yamaha NVX',paymentRef:'MBB 998877'})).toString('latin1');
  for(const x of ['Motosikal','VAB 1234 Yamaha NVX','Rujukan','MBB 998877'])assert.ok(t.includes(x),x);
  const none=Buffer.from(R.buildReceiptPdfBytes({invNo:'INV-2',items:[],rows:[],total:10,method:'CASH',received:10,balance:0})).toString('latin1');
  assert.ok(!none.includes('Motosikal')&&!none.includes('Rujukan'));
});

test('stylesheet: short-laptop mode, typed quantity, confirm panel, touch size, slimmer strip on a short laptop',()=>{
  const css=read('css/rt-polish.css');
  assert.match(css,/@media \(min-width:901px\) and \(max-height:700px\)\{[\s\S]{0,300}rt-pos-topbar\{height:50px!important/);
  assert.match(css,/#view-pos \.rt-qty-input\{/);
  assert.match(css,/#view-pos \.rt-payconfirm\{/);
  assert.match(css,/#view-pos \.rt-payconfirm-ref\{[^}]*font-size:16px!important/);
  assert.match(css,/@media \(pointer:coarse\)\{[\s\S]{0,200}rt-item-discount\{height:40px!important/);
  const park=read('js/rt-park.js');
  assert.match(park,/function roomForStrip\(\)\{return \(window\.innerWidth\|\|0\)>=1200\|\|\(window\.innerHeight\|\|0\)>=800;\}/);
  assert.match(css,/@media \(min-width:901px\) and \(max-height:700px\)\{[\s\S]*\.rt-ot-new,\.rt-ot\{min-height:36px\}/,'slimmer strip on a short laptop');
});
