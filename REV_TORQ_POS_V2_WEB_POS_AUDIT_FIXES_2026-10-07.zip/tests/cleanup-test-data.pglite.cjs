/* OPTIONAL self-check for cleanup_test_data_2026_10_05.sql. It does NOT touch Supabase: it runs the script on a throw-away
   in-memory Postgres (PGlite) with a stand-in schema that HAS foreign keys, with migration_2026_10_05_override_audit.sql
   installed first, and checks dry run, safety stops, what is kept and what is removed.
   Usage:  npm i --no-save @electric-sql/pglite  &&  node tests/cleanup-test-data.pglite.cjs */
const fs=require('fs'),path=require('path');
const {PGlite}=require('@electric-sql/pglite');
const app=path.resolve(process.argv[2]||path.join(__dirname,'..'));
const MIG=fs.readFileSync(path.join(app,'migration_2026_10_05_override_audit.sql'),'utf8');
const CLEAN=fs.readFileSync(path.join(app,'cleanup_test_data_2026_10_05.sql'),'utf8');
const run=fs.readFileSync(path.join(__dirname,'sql-override-audit.pglite.cjs'),'utf8');
const U={own:'00000000-0000-4000-8000-0000000000a1',adm:'00000000-0000-4000-8000-0000000000a2',cash:'00000000-0000-4000-8000-0000000000a3',other:'00000000-0000-4000-8000-0000000000a4',none:'00000000-0000-4000-8000-0000000000a5'};
const C1='11111111-1111-4111-8111-111111111111',C2='22222222-2222-4222-8222-222222222222',L1='33333333-3333-4333-8333-333333333333';
const S={own:'10000000-0000-4000-8000-000000000001',adm:'10000000-0000-4000-8000-000000000002',cash:'10000000-0000-4000-8000-000000000003',other:'10000000-0000-4000-8000-000000000004'};
const SCHEMA0=new Function('U','C1','C2','L1','S','return `'+run.match(/const SCHEMA=`([\s\S]*?)`;/)[1]+'`')(U,C1,C2,L1,S);
const results=[];const ok=(n,c,i='')=>results.push({n,pass:!!c,i:String(i).slice(0,300)});
const id=(p,n)=>p.padEnd(8,'0')+'-0000-4000-8000-'+String(n).padStart(12,'0');
const EXTRA=`
alter table public.invoices add column invoice_no text, add column created_at timestamptz default now();
alter table public.job_cards add column booking_id uuid, add column created_at timestamptz default now();
alter table public.bookings add column booking_no text, add column created_at timestamptz default now();
create table public.invoice_items(id uuid primary key default gen_random_uuid(), company_id uuid, invoice_id uuid, description text);
create table public.cash_movements(id uuid primary key default gen_random_uuid(), company_id uuid, reference_id uuid, amount numeric);
create table public.invoice_events(id uuid primary key default gen_random_uuid(), invoice_id uuid, note text);
create table public.invoice_tags(invoice_id uuid, tag text);
alter table public.job_cards add constraint jc_booking foreign key (booking_id) references public.bookings(id);
alter table public.invoices add constraint inv_job foreign key (job_card_id) references public.job_cards(id);
alter table public.invoice_items add constraint ii_inv foreign key (invoice_id) references public.invoices(id);
alter table public.payments add constraint pay_inv foreign key (invoice_id) references public.invoices(id);
alter table public.job_card_items add constraint jci_job foreign key (job_card_id) references public.job_cards(id);
alter table public.invoice_events add constraint ev_inv foreign key (invoice_id) references public.invoices(id);
alter table public.invoice_tags add constraint tag_inv foreign key (invoice_id) references public.invoices(id);
`;
const OLD="'2026-09-20 10:00+00'",NEW="'2026-10-03 10:00+00'";
const SEED=`
insert into public.bookings(id,company_id,booking_no,status,created_at) values
 ('${id('bb',1)}','${C1}','BK-1','CONFIRMED',${OLD}),('${id('bb',2)}','${C1}','BK-2','CONFIRMED',${OLD}),('${id('bb',3)}','${C1}','BK-3','CONFIRMED',${OLD}),('${id('bb',6)}','${C1}','BK-6','CONFIRMED',${OLD});
insert into public.job_cards(id,company_id,job_no,status,booking_id,created_at) values
 ('${id('f',1)}','${C1}','J1-CANC-VOIDINV','CANCELLED','${id('bb',1)}',${OLD}),
 ('${id('f',2)}','${C1}','J2-OPEN','OPEN','${id('bb',2)}',${OLD}),
 ('${id('f',3)}','${C1}','J3-CANC-PAIDINV','CANCELLED','${id('bb',3)}',${OLD}),
 ('${id('f',4)}','${C1}','J4-CANC-RECENT','CANCELLED',null,${NEW}),
 ('${id('f',5)}','${C1}','J5-CANC-NOINV','CANCELLED',null,${OLD}),
 ('${id('f',6)}','${C1}','J6-CANC-RECENTVOID','CANCELLED','${id('bb',6)}',${OLD});
insert into public.invoices(id,company_id,job_card_id,invoice_no,status,payment_status,total,created_at) values
 ('${id('b',1)}','${C1}','${id('f',1)}','INV-1','VOID','PAID',50,${OLD}),
 ('${id('b',2)}','${C1}',null,'INV-2','VOID','PAID',20,${OLD}),
 ('${id('b',3)}','${C1}',null,'INV-3','PAID','PAID',100,${OLD}),
 ('${id('b',4)}','${C1}','${id('f',3)}','INV-4','PAID','PAID',70,${OLD}),
 ('${id('b',5)}','${C1}',null,'INV-5','VOID','PAID',10,${NEW}),
 ('${id('b',6)}','${C1}','${id('f',6)}','INV-6','VOID','PAID',10,${NEW});
insert into public.invoice_items(id,company_id,invoice_id,description) values ('${id('1',1)}','${C1}','${id('b',1)}','x'),('${id('1',2)}','${C1}','${id('b',2)}','x'),('${id('1',3)}','${C1}','${id('b',3)}','x');
insert into public.payments(id,company_id,invoice_id,amount) values ('${id('a',1)}','${C1}','${id('b',1)}',50),('${id('a',2)}','${C1}','${id('b',2)}',20),('${id('a',3)}','${C1}','${id('b',3)}',100);
insert into public.invoice_events(id,invoice_id,note) values ('${id('e',1)}','${id('b',2)}','receipt reprint');
insert into public.invoice_tags(invoice_id,tag) values ('${id('b',2)}','test'),('${id('b',3)}','keep');
insert into public.job_card_items(id,company_id,job_card_id,item_type,quantity) values ('${id('9',1)}','${C1}','${id('f',1)}','PART',1),('${id('9',2)}','${C1}','${id('f',2)}','PART',1),('${id('9',5)}','${C1}','${id('f',5)}','PART',1);
insert into public.stock_movements(id,company_id,quantity) values ('${id('5',1)}','${C1}',-1),('${id('5',2)}','${C1}',1);
insert into public.cash_movements(id,company_id,reference_id,amount) values ('${id('c',1)}','${C1}','${id('b',1)}',50),('${id('c',2)}','${C1}','${id('b',1)}',-50);
`;
const settings=(sql,o)=>{
  let s=sql;
  if(o.apply!==undefined)s=s.replace('v_apply            boolean     := false;','v_apply            boolean     := '+o.apply+';');
  if(o.before)s=s.replace("v_before           timestamptz := now();","v_before           timestamptz := '"+o.before+"';");
  if(o.inv!==undefined)s=s.replace('v_expect_invoices  int         := null;','v_expect_invoices  int         := '+o.inv+';');
  if(o.jobs!==undefined)s=s.replace('v_expect_jobs      int         := null;','v_expect_jobs      int         := '+o.jobs+';');
  if(o.bookings===false)s=s.replace('v_do_bookings      boolean     := true;','v_do_bookings      boolean     := false;');
  return s;
};
async function fresh(extra=''){
  const db=new PGlite();await db.exec(SCHEMA0);await db.exec(EXTRA+extra);
  await db.exec(MIG);
  await db.exec(SEED);
  return db;
}
const fails=async(fn)=>{try{await fn();return null;}catch(e){return e.message||String(e);}};
(async()=>{
  const db=await fresh();
  const q=(sql,p)=>db.query(sql,p).then(r=>r.rows);
  const cnt=async t=>(await q(`select count(*)::int n from public.${t}`))[0].n;
  const snap=async()=>JSON.stringify({inv:await cnt('invoices'),jobs:await cnt('job_cards'),bk:await cnt('bookings'),ii:await cnt('invoice_items'),pay:await cnt('payments'),jci:await cnt('job_card_items'),ev:await cnt('invoice_events'),tag:await cnt('invoice_tags'),sm:await cnt('stock_movements'),cm:await cnt('cash_movements')});
  const before=await snap();
  const B='2026-10-02 00:00+00';

  // 1. dry run
  let e=await fails(()=>db.exec(settings(CLEAN,{before:B})));
  console.log('--- sample dry-run message ---\n'+e+'\n------------------------------');
  ok('dry run stops with a DRY RUN message',/^DRY RUN/.test(e||''),e);
  ok('dry run counts: 2 VOID invoices, 2 cancelled jobs, 1 booking',/VOID invoices: 2\s+\|\s+cancelled Job Cards: 2\s+\|\s+bookings: 1/.test(e||''),e);
  ok('dry run lists the numbers and how to run for real',/INV-1, INV-2/.test(e||'')&&/J1-CANC-VOIDINV, J5-CANC-NOINV/.test(e||'')&&/v_expect_invoices := 2, v_expect_jobs := 2/.test(e||''),e);
  ok('dry run lists child rows (incl. unknown FK tables)',/invoice_events\s*:\s*1/.test(e||'')&&/invoice_tags\s*:\s*1/.test(e||'')&&/payments\s*:\s*2/.test(e||'')&&/job_card_items\s*:\s*2/.test(e||''),e);
  ok('dry run changed nothing',(await snap())===before);
  ok('dry run wrote no purge record',(await q("select count(*)::int n from public.audit_logs where action='SYSTEM_TEST_DATA_PURGE'"))[0].n===0);
  ok('dry run left no ROW_DELETE records behind (rolled back)',(await q("select count(*)::int n from public.audit_logs where action='ROW_DELETE'"))[0].n===0);

  // 2. real run with wrong numbers -> stopped
  e=await fails(()=>db.exec(settings(CLEAN,{before:B,apply:true,inv:3,jobs:2})));
  ok('real run stops when the numbers differ',/^STOPPED/.test(e||'')&&/Found 2 VOID invoice\(s\) and 2 cancelled/.test(e||''),e);
  ok('real run without numbers stops',/^STOPPED/.test(await fails(()=>db.exec(settings(CLEAN,{before:B,apply:true})))||''));
  ok('nothing changed after stopped runs',(await snap())===before);

  // 3. real run
  e=await fails(()=>db.exec(settings(CLEAN,{before:B,apply:true,inv:2,jobs:2})));
  ok('real run succeeds',e===null,e);
  const ids=async(t)=>(await q(`select id from public.${t} order by id`)).map(r=>r.id);
  ok('VOID old invoices gone, others kept (PAID, recent VOID)',JSON.stringify(await q("select invoice_no from public.invoices order by invoice_no"))===JSON.stringify([{invoice_no:'INV-3'},{invoice_no:'INV-4'},{invoice_no:'INV-5'},{invoice_no:'INV-6'}]));
  ok('cancelled jobs without remaining invoices gone; others kept',JSON.stringify((await q("select job_no from public.job_cards order by job_no")).map(r=>r.job_no))===JSON.stringify(['J2-OPEN','J3-CANC-PAIDINV','J4-CANC-RECENT','J6-CANC-RECENTVOID']));
  ok('booking behind a removed job gone; others kept',JSON.stringify((await q("select booking_no from public.bookings order by booking_no")).map(r=>r.booking_no))===JSON.stringify(['BK-2','BK-3','BK-6']));
  ok('children of removed invoices gone, kept ones stay',(await cnt('invoice_items'))===1&&(await cnt('payments'))===1&&(await cnt('invoice_events'))===0&&(await cnt('invoice_tags'))===1,await snap());
  ok('job lines: removed jobs only',JSON.stringify((await q("select job_card_id from public.job_card_items")).map(r=>r.job_card_id))===JSON.stringify([id('f',2)]));
  ok('stock and cash ledgers untouched',(await cnt('stock_movements'))===2&&(await cnt('cash_movements'))===2);
  const pr=await q("select * from public.audit_logs where action='SYSTEM_TEST_DATA_PURGE'");
  ok('purge summary record written',pr.length===1&&pr[0].company_id===C1&&pr[0].metadata.deleted.invoices===2&&pr[0].metadata.deleted.job_cards===2&&/INV-1, INV-2/.test(pr[0].metadata.invoice_nos)&&/J1-CANC/.test(pr[0].metadata.job_nos),pr);
  const rd=await q("select entity_type,count(*)::int n from public.audit_logs where action='ROW_DELETE' group by 1 order by 1");
  ok('each deleted row also got a ROW_DELETE record (migration triggers)',rd.some(r=>r.entity_type==='invoices'&&r.n===2)&&rd.some(r=>r.entity_type==='job_cards'&&r.n===2)&&rd.some(r=>r.entity_type==='bookings'&&r.n===1),rd);
  ok('purge never touched existing audit rows',(await cnt('audit_logs'))>=1);

  // 4. same settings again: nothing left, expects 0/0
  e=await fails(()=>db.exec(settings(CLEAN,{before:B,apply:true,inv:0,jobs:0})));
  ok('second real run finds nothing and is harmless (no second purge record)',e===null&&(await q("select count(*)::int n from public.audit_logs where action='SYSTEM_TEST_DATA_PURGE'"))[0].n===1,e);
  e=await fails(()=>db.exec(settings(CLEAN,{before:B})));
  ok('dry run with nothing to do says so',/\(nothing matches\)/.test(e||''),e);

  // 5. cut-off in the future also takes the recent ones; bookings switch off keeps bookings
  const db2=await fresh();
  const q2=(s)=>db2.query(s).then(r=>r.rows);
  e=await fails(()=>db2.exec(settings(CLEAN,{before:'2026-12-31 00:00+00',apply:true,inv:4,jobs:4,bookings:false})));
  ok('later cut-off removes recent VOIDs/cancelled too (J3 kept: PAID invoice)',e===null&&JSON.stringify((await q2("select job_no from public.job_cards order by job_no")).map(r=>r.job_no))===JSON.stringify(['J2-OPEN','J3-CANC-PAIDINV']),e);
  ok('bookings kept when the booking switch is off',(await q2("select count(*)::int n from public.bookings"))[0].n===4);

  // 6. a ledger table with a FOREIGN KEY to an invoice -> BLOCKED, nothing changes
  const db3=await fresh("alter table public.cash_movements add constraint cm_inv foreign key (reference_id) references public.invoices(id);");
  const q3=(s)=>db3.query(s).then(r=>r.rows);
  const s3=JSON.stringify(await q3("select (select count(*) from public.invoices)::int i,(select count(*) from public.job_cards)::int j"));
  e=await fails(()=>db3.exec(settings(CLEAN,{before:B})));
  ok('ledger FK -> BLOCKED in dry run',/BLOCKED.*cash_movements/.test(e||''),e);
  e=await fails(()=>db3.exec(settings(CLEAN,{before:B,apply:true,inv:2,jobs:2})));
  ok('ledger FK -> BLOCKED in real run, nothing deleted',/BLOCKED.*cash_movements/.test(e||'')&&JSON.stringify(await q3("select (select count(*) from public.invoices)::int i,(select count(*) from public.job_cards)::int j"))===s3,e);

  // 7. switches
  const db4=await fresh();
  e=await fails(()=>db4.exec(settings(CLEAN,{before:B}).replace('v_do_void          boolean     := true;','v_do_void          boolean     := false;')));
  ok('only cancelled jobs when VOID switch is off (J1 kept: its VOID invoice is not being removed)',/cancelled Job Cards: 1\s/.test(e||'')&&/J5-CANC-NOINV/.test(e||'')&&!/J1-CANC/.test((e||'').split('Job Cards (first 40):')[1]||''),e);

  for(const r of results)console.log((r.pass?'PASS':'FAIL')+' '+r.n+(r.pass?'':'  :: '+r.i));
  console.log(`\n${results.filter(r=>r.pass).length}/${results.length} passed`);
  process.exit(results.every(r=>r.pass)?0:1);
})().catch(e=>{console.error('HARNESS ERROR',e);process.exit(2);});
