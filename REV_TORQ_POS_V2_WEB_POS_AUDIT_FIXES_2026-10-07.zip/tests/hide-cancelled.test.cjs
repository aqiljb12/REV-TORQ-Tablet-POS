const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('Sejarah Jualan hides VOID by default and shows it on demand',()=>{
  const s=read('js/receipt-reprint.js');
  assert.match(s,/showVoid:false/);
  assert.match(s,/window\.rtToggleSalesVoid=/);
  assert.match(s,/VOID disembunyikan/);
  const html=read('index.html');
  assert.match(html,/id="rtSalesShowVoid"/);
  assert.match(html,/id="rtSalesVoidNote"/);
  assert.doesNotMatch(s,/\.delete\(|\.update\(|\.insert\(/,'hiding is display only');
});

test('Booking: a booking whose Job Card was cancelled belongs to Sejarah',()=>{
  const b=read('js/bookings.js');
  assert.match(b,/const jobCancelled=!!r\.job&&String\(r\.job\.status\|\|''\)\.toUpperCase\(\)==='CANCELLED'/);
  assert.match(b,/state\.filter==='HISTORY' \? \(jobCancelled\|\|/);
  assert.match(b,/: jobCancelled \? false/);
});

test('cleanup script: dry run by default, needs the dry-run numbers, never touches ledgers / audit rows',()=>{
  const sql=read('cleanup_test_data_2026_10_05.sql');
  assert.match(sql,/v_apply\s+boolean\s+:=\s+false;/,'dry run by default');
  assert.match(sql,/v_expect_invoices\s+int\s+:=\s+null;/);
  assert.match(sql,/raise exception 'STOPPED: the counts differ/);
  assert.match(sql,/raise exception '%', v_msg;/,'dry run cancels itself with an error');
  assert.match(sql,/v_child_name ~\* '\(ledger\|movement\|audit\)'/,'ledger / audit tables are blocked, not purged');
  assert.doesNotMatch(sql,/\bdelete\s+from\s+(public\.)?(audit_logs|stock_movements|cash_movements|stock_balances)\b/i);
  assert.doesNotMatch(sql,/\btruncate\b|\bdrop\s+table\b/i);
  assert.match(sql,/upper\(coalesce\(i\.status, ''\)\) = 'VOID'/);
  assert.match(sql,/upper\(coalesce\(j\.status, ''\)\) = 'CANCELLED'/);
  assert.match(sql,/SYSTEM_TEST_DATA_PURGE/,'the purge itself is recorded');
  assert.doesNotMatch(sql,/status\s*=\s*'PAID'|status\) = 'PAID'/,'never selects PAID invoices');
});
