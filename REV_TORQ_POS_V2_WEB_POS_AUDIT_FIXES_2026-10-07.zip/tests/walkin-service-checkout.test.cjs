const fs=require('fs');
const p=require('path');
const src=fs.readFileSync(p.join(__dirname,'..','js','v36-4-9-pos-cash-canonical.js'),'utf8');
const ok=[];
function t(name,cond){ if(!cond){console.error('FAIL',name);process.exitCode=1;} else {console.log('PASS',name);ok.push(name);} }
t('normal sale branch accepts standalone service/labour',/if\(!activeJob\)\s*\{/.test(src));
t('standalone service sends SERVICE or LABOUR item_type',/item_type\s*:\s*serviceItem\s*\?/.test(src)||/standaloneType/.test(src));
t('standalone service sends unit_price',/unit_price\s*:\s*Number\(i\.price/.test(src));
t('JOB_CONTEXT is only required in active-job branch',!/if\(!activeJob&&!hasService\)/.test(src));
if(!process.exitCode) console.log(`OK ${ok.length} checks`);
