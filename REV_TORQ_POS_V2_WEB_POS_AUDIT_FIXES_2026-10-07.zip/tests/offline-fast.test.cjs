const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
function scripts(html){return [...html.matchAll(/<script src="(js\/[^"?]+)(?:\?[^"]*)?"><\/script>/g)].map(m=>m[1]);}
function pngSize(p){const b=fs.readFileSync(path.join(root,p));assert.equal(b.slice(1,4).toString(),'PNG');return [b.readUInt32BE(16),b.readUInt32BE(20)];}

test('installable app: manifest, icons and iOS meta are in place',()=>{
  const html=read('index.html');
  assert.match(html,/<link rel="manifest" href="manifest\.webmanifest">/);
  assert.match(html,/<meta name="apple-mobile-web-app-capable" content="yes">/);
  assert.match(html,/<link rel="apple-touch-icon" href="icons\/apple-touch-icon\.png">/);
  const m=JSON.parse(read('manifest.webmanifest'));
  assert.equal(m.display,'standalone');assert.equal(m.start_url,'./index.html');assert.equal(m.scope,'./');
  for(const i of m.icons){const [w,h]=pngSize(i.src);assert.equal(w+'x'+h,i.sizes,i.src);}
  assert.ok(m.icons.some(i=>i.purpose==='maskable'));
  assert.deepEqual(pngSize('icons/apple-touch-icon.png'),[180,180]);
});

test('service worker: app files only, network-first page, never another origin or an API',()=>{
  const sw=read('sw-notify.js');
  assert.match(sw,/if\(req\.method!=='GET'\|\|!sameOrigin\(req\.url\)\)return;/);
  assert.doesNotMatch(sw,/supabase|\/rest\/v1|\/auth\/v1/i);
  assert.match(sw,/var NAV_TIMEOUT=3000;/);
  assert.match(sw,/res\.status>=500\)throw/,'a server error never replaces the saved page');
  assert.match(sw,/res\.status===200&&res\.type==='basic'/);
  assert.match(sw,/function pruneOldVersions/);
  assert.match(sw,/notificationclick/,'booking notifications still handled');
  assert.match(sw,/d\.type==='reset'/);
  const build=sw.match(/var BUILD='([^']+)'/)[1];
  assert.equal(read('js/rt-offline.js').match(/var BUILD='([^']+)'/)[1],build,'worker and page agree on the build id');
});

test('rt-offline.js loads early, rt-polish.js stays last, nothing else changed in order',()=>{
  const list=scripts(read('index.html'));
  assert.ok(list.includes('js/rt-offline.js'));
  assert.ok(list.indexOf('js/supabase-bridge.js')<list.indexOf('js/rt-offline.js'));
  assert.ok(list.indexOf('js/rt-offline.js')<list.indexOf('js/supabase-auth.js'),'ready before the session is restored');
  assert.equal(list[list.length-1],'js/rt-polish.js');
});

test('a dropped connection no longer logs anyone out; the server saying no still does',()=>{
  const a=read('js/supabase-auth.js');
  const r=a.slice(a.indexOf('window.restoreSession=function'));
  const catchBlock=r.slice(r.indexOf('}catch(err){'),r.indexOf('if(ticket!==epoch||busy)return;\n    if(!pair)'));
  assert.ok(catchBlock.indexOf('isNetworkError(err)')>=0&&catchBlock.indexOf('isNetworkError(err)')<catchBlock.indexOf('revokeLocalSession()'),'network errors are handled before the sign-out');
  assert.match(a,/const OFFLINE_ROLES=new Set\(\['owner','super_admin','admin','pos','staff','cashier'\]\);/,'workshop roles have no offline POS');
  assert.match(a,/const OFFLINE_PROFILE_MAX_AGE=7\*24\*3600\*1000;/);
  assert.match(a,/if\(!key\|\|!localStorage\.getItem\(key\)\)return null;/,'logged out on this device = no offline start');
  const shell=a.slice(a.indexOf('function enterOfflineShell'),a.indexOf('let leaving=null;'));
  assert.doesNotMatch(shell,/\bverified\s*=/,'the offline shell never becomes a verified (admin) session');
  assert.match(a,/clearProfile\(\);\n  forgetOfflineProfile\(\);/,'sign-out forgets the offline profile');
  assert.match(a,/forgetOfflineProfile\(\);\n  try\{if\(window\.rtStore/);
  const b=read('js/supabase-bridge.js');
  assert.match(b,/navigator\.onLine===false\)\{rtNetSignal\('fail'\);throw new TypeError\('Failed to fetch'\);\}/,'no 3x retry when there is no network at all');
});

test('POS opens from the saved list; cost prices never stored; sale lock cannot be bypassed',()=>{
  const html=read('index.html');
  assert.match(html,/window\.rtPosCache\.read\(company\)\.then\(saved =>/,'cache is read in parallel, not awaited before the network');
  assert.doesNotMatch(html,/await window\.rtPosCache\.read/);
  assert.match(html,/const rowsPromise = rtPosFetchAll/,'products start downloading before the location lookup returns');
  assert.match(html,/window\.rtPosProductsLoadedAt = Date\.now\(\);\n            window\.rtPosCacheAt = 0;/,'a network load marks the list fresh');
  const o=read('js/rt-offline.js');
  assert.match(o,/c\.cost=0;c\.costPrice=0;c\.cost_price=0;/);
  assert.match(o,/closest\('#btnCheckout'\)[\s\S]{0,200}stopImmediatePropagation/,'BAYAR is stopped before the page handler');
  assert.match(o,/wrapOnce\('posCheckout'/);
  assert.match(o,/id!=='pos'/,'offline shell: POS only');
  const d=read('js/rt-dual-client.js');
  assert.match(d,/const REFRESH_MIN_MS = 60000;/);
  assert.match(d,/if\(view==='pos'\) fns\.push\('loadPOS'\)/);
});

test('rtStore / rtPerf never throw, even when IndexedDB / storage are missing',async()=>{
  const src=read('js/rt-offline.js');
  const store={};
  const sandbox={window:{},document:{addEventListener(){},getElementById(){return null;},createElement(){return {classList:{toggle(){}},setAttribute(){},querySelector(){return {addEventListener(){}};},addEventListener(){}};},body:{appendChild(){},classList:{toggle(){}}}},
    navigator:{onLine:true},location:{search:'',pathname:'/',hostname:'example.com',protocol:'https:',origin:'https://example.com',href:'https://example.com/'},
    localStorage:{getItem:k=>store[k]||null,setItem:(k,v)=>{store[k]=v;},removeItem:k=>{delete store[k];}},
    setTimeout:(f)=>0,setInterval:()=>0,performance:{getEntriesByType:()=>[]},console,Date,JSON,Promise,URL,Object,Array,String,Math};
  sandbox.window=sandbox;sandbox.window.addEventListener=()=>{};sandbox.window.matchMedia=()=>({matches:false});
  vm.createContext(sandbox);
  vm.runInContext(src,sandbox);
  assert.equal(await sandbox.rtStore.get('x'),null,'no IndexedDB: get resolves null');
  assert.equal(await sandbox.rtStore.set('x',1),false,'no IndexedDB: set resolves false');
  assert.equal(await sandbox.rtPosCache.read('c1'),null);
  assert.equal(await sandbox.rtPosCache.write('c1',[]),false,'empty list is not saved');
  sandbox.rtPerf.mark('a',120.4);sandbox.rtPerf.mark('a',80,{source:'cache'});
  const s=sandbox.rtPerf.summary('a');
  assert.deepEqual([s.count,s.avg,s.last,s.max,s.source],[2,100,80,120,'cache']);
  sandbox.rtPerf.net('https://x.supabase.co/rest/v1/rpc/rt_post_pos_sale_idempotent',50);
  sandbox.rtPerf.net('https://x.supabase.co/rest/v1/products?select=*',50);
  assert.equal(sandbox.rtPerf.list().filter(x=>/^rpc:/.test(x.n)).length,1,'only sale RPCs are timed');
});
