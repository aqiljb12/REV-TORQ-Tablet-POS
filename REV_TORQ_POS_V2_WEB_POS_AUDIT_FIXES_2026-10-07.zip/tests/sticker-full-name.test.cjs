const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const {TextEncoder}=require('node:util');
const root=path.resolve(__dirname,'..');

function loadHardware(){
  const src=fs.readFileSync(path.join(root,'js/web-hardware.js'),'utf8');
  const sandbox={
    window:{},
    document:{
      getElementById(){return null;},
      addEventListener(){},
      createElement(){return {getContext(){return null;},style:{},classList:{},appendChild(){},remove(){}};},
      documentElement:{},
      body:{appendChild(){}}
    },
    navigator:{}, location:{href:'https://example.test/'}, performance:{now:()=>0},
    MutationObserver:class{observe(){}},
    TextEncoder, Blob, File:class{}, URL, setTimeout(){}, clearTimeout(){}, console
  };
  sandbox.window=sandbox;
  sandbox.window.addEventListener=()=>{};
  vm.createContext(sandbox);
  vm.runInContext(src,sandbox);
  return sandbox.rtWebHardware;
}

function fakeCtx(){
  return {
    font:'900 25px Arial',
    measureText(text){
      const m=/(\d+(?:\.\d+)?)px/.exec(this.font)||[0,'25'];
      const size=Number(m[1]);
      return {width:String(text).length*size*0.56};
    }
  };
}

test('50x30 label keeps the full product name with no ellipsis and max 3 lines',()=>{
  const hw=loadHardware();
  assert.equal(typeof hw.fitLabelName,'function','fitLabelName helper must be exported for the label renderer');
  const name='RKM REAR SPROCKET Y100 428 38T HEAVY DUTY';
  const ctx=fakeCtx();
  const fit=hw.fitLabelName(ctx,name,376,{startSize:25,minSize:10,maxLines:3,lineHeightRatio:1.04});
  assert.ok(fit.lines.length>=2 && fit.lines.length<=3);
  assert.equal(fit.lines.join(' '),name,'every word must remain on the label');
  assert.ok(!fit.lines.some(x=>/[.…]$/.test(x)),'name must never end with ellipsis');
  ctx.font=`900 ${fit.fontSize}px Arial`;
  for(const line of fit.lines) assert.ok(ctx.measureText(line).width<=376+0.01,`line too wide: ${line}`);
});

test('a long unbroken model code is split instead of clipped',()=>{
  const hw=loadHardware();
  const ctx=fakeCtx();
  const name='SUPERLONGMODELCODE1234567890ABCDEFG';
  const fit=hw.fitLabelName(ctx,name,250,{startSize:22,minSize:8,maxLines:3,lineHeightRatio:1.04});
  assert.equal(fit.lines.join(''),name);
  assert.ok(fit.lines.length<=3);
  assert.ok(!fit.lines.join('').includes('…'));
});
