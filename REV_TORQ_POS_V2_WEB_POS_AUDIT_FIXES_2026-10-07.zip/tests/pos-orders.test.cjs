const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const park=read('js/rt-park.js');

test('Pesanan serentak: held orders are chips under the cart header, one tap swaps, nothing is sent anywhere',()=>{
  assert.match(park,/head\.parentNode\.insertBefore\(s,head\.nextSibling\)/,'strip sits right under .rt-cart-head');
  assert.match(park,/data-ot="new"/);
  assert.match(park,/data-ot="swap"/);
  assert.match(park,/resume\(b\.getAttribute\('data-id'\),\{noConfirm:true,quiet:true\}\)/,'swap asks no question; the current order is parked, not lost');
  assert.match(park,/if\(!swap\|\|opts\.noConfirm\)\{go\(\);return;\}/);
  assert.doesNotMatch(park,/supabaseClient|\.rpc\(|\bfetch\(|\.from\(/,'device-local only');
  assert.match(park,/if\(n&&!window\.rtActiveJob\)html\+='<button type="button" class="rt-ot-new"/,'a Job Card cart is never parked from the strip');
  assert.match(park,/var show=list\.length>0\|\|\(n>0&&roomForStrip\(\)\);/);
  assert.match(park,/\(window\.innerWidth\|\|0\)>=1200\|\|\(window\.innerHeight\|\|0\)>=800/,'short screens keep the pause button only until something waits');
});

test('payment method and amount travel with the order; the next customer starts on TUNAI',()=>{
  assert.match(park,/payMethod:payMethod\(\),received:payMethod\(\)==='CASH'\?inputVal\('posAmountReceived'\):0/,'snapshot keeps both');
  assert.match(park,/hadOffer:s\.hadOffer,payMethod:s\.payMethod,received:s\.received/,'a parked order stores both');
  assert.match(park,/setPay\(pm\);\n    if\(pm==='CASH'&&num\(state\.received\)>0\)setInput\('posAmountReceived',state\.received,'input'\);/,'resume restores them');
  assert.match(park,/setPay\('CASH'\);   \/\/ the next customer must not inherit/,'parking resets to TUNAI');
  assert.match(park,/window\.posClearCart=w;/,'any cart clear (sale done, trash, park) resets to TUNAI right away');
  assert.match(park,/payMethod\(\),checkoutBusy\(\)\|\|pendingSale\(\)\]\);/,'the refresh draft notices a method change');
  assert.match(park,/sahkan semula bayaran QR/,'QR must be confirmed again after resuming');
});

test('chips are touch sized and scroll, and the stylesheet / script are cache-busted',()=>{
  const css=read('css/rt-polish.css');
  assert.match(css,/\.rt-ot\{[^}]*min-height:40px/);
  assert.match(css,/\.rt-ot-new\{[^}]*min-height:40px/);
  assert.match(css,/\.rt-ot-scroll\{[^}]*overflow-x:auto/);
  assert.match(css,/\.rt-order-tabs\.hidden\{display:none!important\}/);
  const html=read('index.html');
  assert.match(html,/js\/rt-park\.js\?v=[\w.-]+/);
  assert.match(html,/css\/rt-polish\.css\?v=[\w.-]+/);
  const list=[...html.matchAll(/<script src="(js\/[^"?]+)(?:\?[^"]*)?"><\/script>/g)].map(m=>m[1]);
  assert.equal(list[list.length-1],'js/rt-polish.js','rt-polish.js stays last');
});
