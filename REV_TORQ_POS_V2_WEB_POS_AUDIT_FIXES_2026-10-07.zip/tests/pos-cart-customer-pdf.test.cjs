const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
const R=require(path.join(root,'js/rt-receipt-pdf.js'));

const sample=()=>({shopName:'REV TORQ WORKSHOP',address:'No 1, Jalan Maju\nKajang',phone:'012-345 6789',regNo:'123',invNo:'INV-0042',
  dateText:'7/10/2026, 2:21 PM',cashier:'AQIL',customerName:'Ahmad Faizal',customerPhone:'0123456789',
  items:[{name:'Shell Advance AX7 1L Minyak Enjin Motosikal 4T Fully Synthetic',qty:2,price:28,gross:56,discount:0,total:56},
         {name:'Rantai DID 428H',qty:1,price:65,gross:65,discount:5,total:60}],
  rows:[['Subtotal asal',121],['Diskaun item',-5]],total:116,method:'TRANSFER',received:116,balance:0,points:{balance:221,earned:93}});
const asText=bytes=>Buffer.from(bytes).toString('latin1');

test('receipt PDF: a real, valid PDF (header, xref offsets, trailer, one page 80 mm wide)',()=>{
  const t=asText(R.buildReceiptPdfBytes(sample(),new Date(2026,9,7,14,21,5)));
  assert.match(t,/^%PDF-1\.4\n/);
  assert.match(t,/%%EOF\n$/);
  assert.match(t,/\/MediaBox \[0 0 226\.77 [\d.]+\]/);
  assert.match(t,/\/BaseFont \/Courier /);
  assert.match(t,/\/Count 1 /);
  const xr=t.indexOf('xref\n');assert.ok(xr>0);
  assert.equal(Number(/startxref\n(\d+)\n/.exec(t)[1]),xr);
  const rows=t.slice(xr).split('\n').slice(3).filter(l=>/^\d{10} 00000 n $/.test(l));
  assert.ok(rows.length>=7);
  rows.forEach((l,i)=>assert.ok(t.slice(Number(l.slice(0,10))).startsWith((i+1)+' 0 obj'),'object '+(i+1)+' offset'));
});

test('receipt PDF: the sale, the customer, the total and the points are all in it',()=>{
  const t=asText(R.buildReceiptPdfBytes(sample()));
  for(const s of ['INV-0042','Ahmad Faizal','0123456789','JUMLAH','RM 116.00','TRANSFER','Rantai DID 428H','Diskaun item: -5.00 \\(asal 65.00\\)','POINT REV TORQ','Point baru','+93','Jumlah point','221','Terima kasih'])
    assert.ok(t.includes(s),s);
});

test('receipt PDF: no points block without points; walk-in has no customer lines',()=>{
  const d=sample();d.points=null;d.customerName='';d.customerPhone='';
  const t=asText(R.buildReceiptPdfBytes(d));
  assert.ok(!t.includes('POINT REV TORQ')&&!t.includes('Pelanggan')&&!t.includes('Telefon'));
  assert.ok(t.includes('INV-0042'));
});

test('receipt PDF: body text never runs past 42 columns; long names wrap; long words are cut',()=>{
  const d=sample();d.items[0].name='Supercalifragilisticexpialidocious_'.repeat(3);
  const lines=R.layoutReceipt(d).filter(l=>l.s===8.2);
  assert.ok(lines.length>10);
  lines.forEach(l=>assert.ok(l.t.length<=42,JSON.stringify(l.t)));
  assert.equal(R.cols(8.2),42);
});

test('receipt PDF: only characters a PDF Courier font can show; brackets are escaped; no stray bytes',()=>{
  assert.equal(R.clean('Café “x” – 中文…'),'Café "x" - ??...');
  const d=sample();d.items[0].name='Part (A) \\ B';
  const t=asText(R.buildReceiptPdfBytes(d));
  assert.ok(t.includes('Part \\(A\\) \\\\ B'));
  assert.ok(!/[^\x00-\xff]/.test(t));
});

test('receipt PDF: a very long receipt is split over pages (no page taller than a PDF viewer allows)',()=>{
  const d=sample();d.items=Array.from({length:500},(_,i)=>({name:'Item '+i,qty:1,price:1,gross:1,discount:0,total:1}));
  const t=asText(R.buildReceiptPdfBytes(d));
  const pages=Number(/\/Count (\d+)/.exec(t)[1]);
  assert.ok(pages>=2,'pages '+pages);
  [...t.matchAll(/\/MediaBox \[0 0 [\d.]+ ([\d.]+)\]/g)].forEach(m=>assert.ok(Number(m[1])<14400));
});

test('PDF module is device-only: no network, one read-only member summary, plain ES2017',()=>{
  const src=read('js/rt-receipt-pdf.js');
  assert.doesNotMatch(src,/supabaseClient|\.from\(|\bfetch\(|XMLHttpRequest|sendBeacon|\.rpc\(/);
  const rpcs=[...src.matchAll(/supabaseRpc\('([a-z_]+)'/g)].map(m=>m[1]);
  assert.deepEqual([...new Set(rpcs)],['rt_pos_customer_member_summary']);
  assert.doesNotMatch(src,/[\w)\]]\?\.[\w[(]/,'no optional chaining (older iPad Safari)');
  assert.doesNotMatch(src,/\?\?[^=]/,'no nullish coalescing');
  assert.match(src,/AbortError/,'closing the share sheet is not an error');
});

test('receipt screen: PDF button next to WhatsApp, script before rt-polish.js, rt-polish.js still last',()=>{
  const html=read('index.html');
  assert.match(html,/id="rtReceiptPdfBtn"[^>]*rtReceiptPdf/);
  assert.match(html,/id="rtReceiptWaBtn"/,'text WhatsApp is kept');
  const list=[...html.matchAll(/<script src="(js\/[^"?]+)(?:\?[^"]*)?"><\/script>/g)].map(m=>m[1]);
  assert.ok(list.indexOf('js/rt-receipt-pdf.js')>0);
  assert.ok(list.indexOf('js/rt-receipt-pdf.js')<list.indexOf('js/rt-polish.js'));
  assert.equal(list[list.length-1],'js/rt-polish.js');
  assert.match(html,/js\/rt-receipt-pdf\.js\?v=[\w.-]+/);
  assert.match(html,/js\/pos\.js\?v=[\w.-]+/);
});

test('pos.js hands the PDF the same figures the receipt shows; WhatsApp text and checkout are untouched',()=>{
  const pos=read('js/pos.js');
  assert.match(pos,/window\.__rtLastReceiptData\s*=\s*\{/);
  for(const k of ['shopName','invNo','dateText','customerName','customerPhone','customerId','items:','rows:','total,','method,','received,','balance,','points: null'])
    assert.ok(pos.includes(k),k);
  assert.match(pos,/window\.__rtLastReceiptText\s*=\s*shareLines\.join/);
  assert.match(pos,/const url = 'https:\/\/wa\.me\/' \+ to \+ '\?text='/);
});

test('rt-polish.js: points pill, 2-line customer bar, backdrop flag, Enter on phone, Subtotal hidden when it repeats JUMLAH, receipt points hook',()=>{
  const js=read('js/rt-polish.js');
  assert.match(js,/class="rt-pts/);
  assert.match(js,/rt-cust-l1/);
  assert.match(js,/classList\.toggle\('rt-open',open\)/);
  assert.match(js,/rtPosMemberPhone[\s\S]{0,200}key==='Enter'[\s\S]{0,120}rtPosMemberFind/);
  assert.match(js,/posSubtotal[\s\S]{0,200}is-zero/);
  assert.match(js,/rtReceiptAfterRender/);
  assert.match(js,/window\.rtReceiptPhone=/);
});

test('stylesheet: wide cart on laptops, short-screen compaction, customer dialog with 16 px+ inputs, receipt PDF button',()=>{
  const css=read('css/rt-polish.css');
  assert.match(css,/@media \(min-width:1280px\)\{#view-pos \.rt-pos-workspace\{grid-template-columns:minmax\(0,1fr\) 496px!important\}\}/);
  assert.match(css,/@media \(min-width:1500px\)\{#view-pos \.rt-pos-workspace\{grid-template-columns:minmax\(0,1fr\) 520px!important\}\}/);
  assert.match(css,/@media \(min-width:901px\) and \(max-height:830px\)\{/);
  assert.match(css,/#view-pos \.rt-cust-panel\{position:fixed;/);
  assert.match(css,/#view-pos \.rt-cust-bar\.rt-open::before\{/);
  assert.match(css,/#view-pos \.rt-cust-panel \.rt-search-box input\{[^}]*font-size:16px!important/);
  assert.match(css,/#view-pos \.rt-pos-member-row input\{[^}]*font-size:18px!important/);
  assert.match(css,/#view-pos \.rt-pts\{/);
  assert.match(css,/#rtReceiptPdfBtn/);
  assert.match(css,/#view-pos \.rt-pos-member-row\{display:grid;grid-template-columns:1fr 1fr/);
  assert.match(css,/#view-pos \.rt-cart-list\{min-height:150px!important\}/);
});
