const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const sql=read('migration_2026_10_05_override_audit.sql');

function scripts(html){return [...html.matchAll(/<script src="(js\/[^"?]+)(?:\?[^"]*)?"><\/script>/g)].map(m=>m[1]);}

test('override + audit scripts are loaded, and rt-polish.js stays the last script',()=>{
  const html=read('index.html');
  const list=scripts(html);
  for(const f of ['js/rt-audit.js','js/rt-audit-view.js','js/rt-override.js'])assert.ok(list.includes(f),f+' is loaded');
  assert.ok(list.indexOf('js/supabase-bridge.js')<list.indexOf('js/rt-audit.js'),'audit writer loads after the Supabase client');
  assert.ok(list.indexOf('js/rt-audit-view.js')<list.indexOf('js/rt-override.js'),'viewer before override page');
  assert.equal(list[list.length-1],'js/rt-polish.js','rt-polish.js must remain last');
  assert.ok(list.indexOf('js/rt-override.js')<list.indexOf('js/rt-polish.js'));
  assert.doesNotMatch(html,/rtOverrideUnlockBtn/,'the old no-op "AKTIFKAN OVERRIDE" modal is gone');
  assert.match(html,/window\.rtOverride\.openPage/,'menu opens the real Override page');
});

test('nothing in the app hard-deletes: bridge refuses, only the audited PART replace remains',()=>{
  const bridge=read('js/supabase-bridge.js');
  assert.match(bridge,/async delete\(\)\{throw new Error\('Padam terus tidak dibenarkan/);
  const hits=[];
  for(const f of fs.readdirSync(path.join(root,'js')).filter(f=>f.endsWith('.js'))){
    const s=read('js/'+f);
    for(const m of s.matchAll(/\.from\('([a-z_]+)'\)[^;\n]*\.delete\(\)/g))hits.push(f+':'+m[1]);
  }
  assert.deepEqual(hits,['stable-fixes.js:job_card_items'],'only the Job Card PART replace deletes (and it is audited with before/after)');
  const sf=read('js/stable-fixes.js');
  assert.match(sf,/JOB_EDIT_PAID/);
  assert.match(sf,/partsBefore/);
});

test('paid Job Cards cannot be edited without an Override session; failure to check refuses',()=>{
  const sf=read('js/stable-fixes.js');
  assert.match(sf,/if\(paidR\.error\)throw paidR\.error;/,'cannot tell if paid -> refuse');
  assert.match(sf,/window\.rtOverride\.ensure\(/);
  assert.match(sf,/if\(e&&e\.rtSilent\)\{return;\}/,'cancelling the dialog is silent');
  const i=sf.indexOf('overrideInfo=await window.rtOverride.ensure(');
  assert.ok(i>0&&i<sf.indexOf("stage='update job_cards'"),'override check happens before any write');
});

test('rt-override.js only talks to the server through the audited RPCs',()=>{
  const o=read('js/rt-override.js');
  assert.doesNotMatch(o,/\.insert\(|\.update\(|\.upsert\(|\.delete\(/,'no direct writes from the Override UI');
  const rpcs=[...new Set([...o.matchAll(/rpc\('([a-z_]+)'/g)].map(m=>m[1]))].sort();
  assert.deepEqual(rpcs,['get_staff_login_email','rt_admin_override_action','rt_admin_override_begin','rt_admin_override_end','rt_override_ready']);
  assert.match(o,/persistSession:false/,'PIN check uses a throw-away client, not the real session');
  assert.match(o,/NOT_INSTALLED/,'fail closed when the SQL script is missing');
  const v=read('js/rt-audit-view.js');
  assert.doesNotMatch(v,/\.insert\(|\.update\(|\.upsert\(|\.delete\(|\.rpc\(/,'viewer is read only');
});

test('audit writer: one trusted path, never silently drops a record',()=>{
  const core=read('js/core.js');
  assert.match(core,/window\.rtAuditWrite/,'logAudit delegates to the trusted writer');
  const a=read('js/rt-audit.js');
  assert.match(a,/rpc\('rt_audit_log'/);
  assert.match(a,/rt_audit_outbox_v1/,'failed writes wait in a local outbox');
  assert.match(a,/permanent\(err\)/,'rejected (reserved / invalid) actions are not retried forever');
  assert.doesNotMatch(a,/timestamp\s*:/,'no non-existent timestamp column');
});

test('SQL: every security definer function pins search_path; nothing is granted to anon',()=>{
  const defs=[...sql.matchAll(/create or replace function public\.([a-z_]+)\([\s\S]*?\n(?:\$function\$|\$\$);/g)];
  assert.ok(defs.length>=8,'functions found: '+defs.length);
  for(const d of defs){
    if(/security definer/i.test(d[0]))assert.match(d[0],/set search_path\s*=\s*public,\s*pg_temp/i,d[1]+' pins search_path');
  }
  assert.doesNotMatch(sql,/^\s*grant [^;]*\bto\b[^;]*\banon\b/im,'no grant to anon');
  assert.match(sql,/revoke all on function public\.rt_admin_override_action[^;]*from public, anon/i);
  for(const fn of ['rt_override_ready','rt_audit_log','rt_admin_override_begin','rt_admin_override_end','rt_admin_override_action'])
    assert.match(sql,new RegExp('grant execute on function public\\.'+fn+'\\('),fn+' granted to authenticated');
});

test('SQL: roles, reason, session and archive-not-delete rules are in the script',()=>{
  assert.match(sql,/not in \('owner',\s*'admin',\s*'super_admin'\) then raise exception 'ADMIN_ONLY'/);
  assert.match(sql,/char_length\(v_reason\) < 8 then raise exception 'REASON_REQUIRED'/);
  assert.match(sql,/least\(greatest\(coalesce\(p_minutes,10\),1\),30\)/,'session capped at 30 min');
  for(const code of ['OVERRIDE_SESSION_REQUIRED','OVERRIDE_SESSION_INVALID','OVERRIDE_SESSION_ENDED','OVERRIDE_EXPIRED','CUSTOMER_HAS_VEHICLES','CUSTOMER_HAS_OPEN_JOBS','VEHICLE_HAS_OPEN_JOBS','PRODUCT_HAS_STOCK','PRODUCT_IN_OPEN_JOB','JOB_ALREADY_PAID','ALREADY_ARCHIVED'])
    assert.match(sql,new RegExp(code),code);
  const action=sql.slice(sql.indexOf('create or replace function public.rt_admin_override_action'),sql.indexOf('create or replace function public.rt_audit_row_change'));
  assert.doesNotMatch(action,/\bdelete\s+from\b/i,'the override action never DELETEs');
  assert.match(action,/set active = false/);
  assert.match(action,/status = 'CANCELLED'/);
  assert.match(action,/before_data, after_data, metadata/,'before/after/reason written in the same transaction');
  assert.match(sql,/audit_logs_guard/,'audit_logs is append-only');
  assert.match(sql,/revoke (?:update, delete, truncate|delete, truncate)[^;]*on [^;]*(?:audit_logs|invoices)/i);
  assert.match(sql,/-- PART 6/,'rollback block present');
  assert.match(sql,/-- PART 0/,'diagnostics first');
});

test('audit viewer helpers: CSV is formula-safe, changes are computed, ROW_ rows are readable',()=>{
  const src=read('js/rt-audit-view.js');
  const sandbox={window:{},document:{addEventListener(){},getElementById(){return null;},querySelectorAll(){return [];},querySelector(){return null;}},Intl,console,Date,URL:{},Blob:function(){}};
  sandbox.window.supabaseClient=null;
  vm.createContext(sandbox);
  vm.runInContext(src,sandbox);
  const v=sandbox.window.rtAuditView;
  assert.ok(v&&typeof v.csv==='function');
  const csv=v.csv([{id:'1',created_at:'2026-10-05T01:02:03Z',staff_id:null,action:'TEST',entity_type:'customers',metadata:{details:"=HYPERLINK(\"http://x\")",reason:'+1',role:'admin'},before_data:{a:1},after_data:{a:2}}]);
  assert.equal(csv.charCodeAt(0),0xFEFF,'BOM for Excel');
  assert.match(csv,/"'=HYPERLINK\(""http:\/\/x""\)"/,'formula neutralised and quotes escaped');
  assert.match(csv,/"'\+1"/);
  assert.deepEqual(JSON.parse(JSON.stringify(v.changes({before_data:{a:1,b:2,updated_at:'x'},after_data:{a:1,b:3,updated_at:'y'}}))),[{k:'b',from:2,to:3}],'updated_at ignored');
  assert.match(v.summary({action:'ROW_DELETE',entity_type:'customers',before_data:{name:'Ali'},metadata:{source:'db_trigger'}}),/customers Ali.*terus pada pangkalan data/);
  assert.match(v.summary({action:'OVERRIDE_CUSTOMER_ARCHIVE',metadata:{label:'Ali',reason:'Salah key-in'}}),/Ali.*Sebab: Salah key-in/);
  assert.equal(v.actionLabel('OVERRIDE_JOB_CARD_CANCEL'),'Batal Job Card');
  assert.equal(v.actor({staff_id:null,metadata:{db_user:'postgres'}}),'DB: postgres');
});

test('archived customers / vehicles are hidden where staff pick them',()=>{
  assert.match(read('js/customers.js'),/if \(d\.active === false\) continue;/);
  assert.match(read('js/customers.js'),/\.filter\(v => v\.active !== false\)/);
  assert.match(read('js/jobcards.js'),/rows\.filter\(c=>c\.active!==false\)/);
  assert.match(read('index.html'),/if\(d\.active===false\)return;/);
  const qs=read('js/rt-quick-search.js');
  assert.match(qs,/x\.active!==false/);
  assert.match(qs,/if\(can\('jobcard'\)&&!j\.paid\)/,'no BUKA on a paid job');
});

test('logout ends the Override session first',()=>{
  const a=read('js/supabase-auth.js');
  assert.match(a,/rtOverrideBeforeLogout/);
  const lo=a.slice(a.indexOf('window.handleLogout'));
  assert.ok(lo.indexOf('rtOverrideBeforeLogout')<lo.indexOf('++epoch;clearProfile();'),'before the login is cleared');
  assert.match(a,/'rt_override_v2'/,'local session forgotten on clearProfile');
});
