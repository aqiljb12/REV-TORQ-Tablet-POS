const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const rule=(css,sel)=>{const m=css.match(new RegExp(sel.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\{[^\\n]*\\}'));return m?m[0]:'';};

test('POS card shows the whole product name: no line clamp, no hidden overflow',()=>{
  const css=read('css/rt-polish.css');
  const name=rule(css,'#view-pos .rt-pos-card .rt-prod-name');
  assert.ok(name,'rule exists');
  assert.doesNotMatch(name,/line-clamp|overflow:hidden|text-overflow/);
  assert.match(name,/overflow:visible/);
  assert.match(name,/overflow-wrap:anywhere/);
  const sku=rule(css,'#view-pos .rt-pos-card .rt-prod-sku');
  assert.doesNotMatch(sku,/text-overflow|white-space:nowrap|overflow:hidden/,'SKU is shown in full too');
  assert.match(css,/\.rt-prod-name\.nl-xl\{font-size:11\.5px/);
});

test('card template: hover title and a size class from the name length',()=>{
  const html=read('index.html');
  assert.match(html,/const nameCls=nameLen>56\?' nl-xl':nameLen>36\?' nl-l':nameLen>22\?' nl-m':'';/);
  assert.match(html,/data-sku="\$\{sku\}" role="button" tabindex="0" title="\$\{name\}"/);
  assert.match(html,/<div class="rt-prod-name\$\{nameCls\}">\$\{name\}<\/div>/);
});

test('cart line, quick search, reorder list, override list wrap instead of cutting',()=>{
  const css=read('css/rt-polish.css');
  assert.doesNotMatch(rule(css,'#view-pos .rt-cart-row .item-title'),/line-clamp|overflow:hidden/);
  for(const sel of ['.rt-qs-main b','.rt-ro-main b','.rt-ov-main b']){
    const r=rule(css,sel);assert.ok(r,sel);
    assert.doesNotMatch(r,/white-space:nowrap|text-overflow:ellipsis/,sel);
  }
});

test('receipt and part pickers no longer use the truncate class on product names',()=>{
  assert.doesNotMatch(read('js/pos.js'),/flex-1 truncate pr-2">\$\{i\.name/);
  assert.doesNotMatch(read('js/jobcards.js'),/truncate">\$\{jcPartEsc\(p\.name\)/);
  assert.doesNotMatch(read('js/mechanic.js'),/truncate">\$\{p\.name\}/);
  const html=read('index.html');
  // these files are bumped again by later releases, so only require that they carry a version
  for(const f of ['js/pos.js','js/jobcards.js','js/mechanic.js','css/rt-polish.css'])
    assert.match(html,new RegExp(f.replace('.','\\.')+'\\?v=[\\w.-]+'),f+' cache-busted');
});
