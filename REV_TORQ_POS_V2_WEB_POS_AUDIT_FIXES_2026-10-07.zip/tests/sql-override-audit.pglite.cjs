/* OPTIONAL self-check for migration_2026_10_05_override_audit.sql. It does NOT touch Supabase:
   it runs the script on a throw-away in-memory Postgres (PGlite) with a stand-in schema derived
   from how the POS uses the tables, then checks the behaviour (roles, sessions, archive rules,
   append-only audit log, idempotency, rollback).
   Usage:  npm i --no-save @electric-sql/pglite  &&  node tests/sql-override-audit.pglite.cjs
   The stand-in schema is NOT your real schema: always run PART 0 of the SQL file first. */
const fs=require('fs'),path=require('path');
const {PGlite}=require('@electric-sql/pglite');
const sqlFile=path.resolve(process.argv[2]||path.join(__dirname,'..','migration_2026_10_05_override_audit.sql'));
const results=[];const ok=(n,c,i='')=>results.push({n,pass:!!c,i:String(i)});

const U={own:'00000000-0000-4000-8000-0000000000a1',adm:'00000000-0000-4000-8000-0000000000a2',cash:'00000000-0000-4000-8000-0000000000a3',other:'00000000-0000-4000-8000-0000000000a4',none:'00000000-0000-4000-8000-0000000000ff'};
const C1='11111111-1111-4111-8111-111111111111',C2='22222222-2222-4222-8222-222222222222',L1='33333333-3333-4333-8333-333333333333';
const S={own:'10000000-0000-4000-8000-000000000001',adm:'10000000-0000-4000-8000-000000000002',cash:'10000000-0000-4000-8000-000000000003',other:'10000000-0000-4000-8000-000000000004'};

const SCHEMA=`
create schema auth;
create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub', true),'')::uuid $$;
create role anon nologin; create role authenticated nologin;
grant usage on schema public to anon, authenticated; grant usage on schema auth to anon, authenticated;
create table public.staff(id uuid primary key, company_id uuid not null, location_id uuid, staff_code text, name text, role text, active boolean default true, removed_from_active_list boolean default false, auth_user_id uuid, updated_at timestamptz);
create table public.customers(id uuid primary key default gen_random_uuid(), company_id uuid not null, name text, phone text, active boolean default true, updated_at timestamptz);
create table public.vehicles(id uuid primary key default gen_random_uuid(), company_id uuid not null, customer_id uuid, plate_no text, brand text, model text, active boolean default true);
create table public.products(id uuid primary key default gen_random_uuid(), company_id uuid not null, sku text, name text, active boolean default true, min_stock numeric, sell_price numeric);
create table public.stock_balances(product_id uuid, location_id uuid, quantity numeric);
create table public.suppliers(id uuid primary key default gen_random_uuid(), company_id uuid not null, name text, active boolean default true);
create table public.job_cards(id uuid primary key default gen_random_uuid(), company_id uuid not null, job_no text, customer_id uuid, vehicle_id uuid, status text);
create table public.job_card_items(id uuid primary key default gen_random_uuid(), company_id uuid not null, job_card_id uuid, product_id uuid, item_type text, quantity numeric, status text default 'ACTIVE');
create table public.invoices(id uuid primary key default gen_random_uuid(), company_id uuid not null, job_card_id uuid, status text, payment_status text, transaction_id uuid, total numeric, updated_at timestamptz);
create table public.payments(id uuid primary key default gen_random_uuid(), company_id uuid not null, invoice_id uuid, amount numeric);
create table public.stock_movements(id uuid primary key default gen_random_uuid(), company_id uuid not null, product_id uuid, quantity numeric);
create table public.bookings(id uuid primary key default gen_random_uuid(), company_id uuid not null, customer_id uuid, vehicle_id uuid, status text);
create table public.app_settings(id uuid primary key default gen_random_uuid(), company_id uuid not null, setting_key text, setting_value jsonb);
create table public.audit_logs(id uuid primary key default gen_random_uuid(), company_id uuid, location_id uuid, transaction_id uuid, staff_id uuid, action text not null, entity_type text, entity_id uuid, before_data jsonb, after_data jsonb, metadata jsonb default '{}'::jsonb, created_at timestamptz default now());
create function public.rt_staff_context() returns table(staff_id uuid, company_id uuid, location_id uuid, role text) language sql stable security definer set search_path=public as $$
  select s.id, s.company_id, s.location_id, s.role from public.staff s where s.auth_user_id = auth.uid() and s.active $$;
grant all on all tables in schema public to anon, authenticated;
grant execute on all functions in schema public to anon, authenticated;
insert into public.staff(id,company_id,location_id,staff_code,name,role,auth_user_id) values
 ('${S.own}','${C1}','${L1}','OWN','Owner','owner','${U.own}'),
 ('${S.adm}','${C1}','${L1}','ADM','Admin','admin','${U.adm}'),
 ('${S.cash}','${C1}','${L1}','CSH','Kaunter','cashier','${U.cash}'),
 ('${S.other}','${C2}',null,'OTH','Lain Syarikat','admin','${U.other}');
`;

(async()=>{
  const db=new PGlite();
  await db.exec(SCHEMA);
  const as=async(user,fn)=>{await db.exec("reset role");await db.exec("set role authenticated");await db.query("select set_config('request.jwt.claim.sub',$1,false)",[user]);try{return await fn();}finally{await db.exec("reset role");}};
  const q=(sql,p)=>db.query(sql,p).then(r=>r.rows);
  const fails=async(fn)=>{try{await fn();return null;}catch(e){return e.message||String(e);}};
  const audit=(where='true',p=[])=>q(`select * from public.audit_logs where ${where} order by created_at, id`,p);

  // ---- seed business data (as superuser)
  const prodA='aaaaaaaa-0000-4000-8000-000000000001',prodStock='aaaaaaaa-0000-4000-8000-000000000002';
  await db.exec(`
   insert into public.customers(id,company_id,name,phone) values ('c0000000-0000-4000-8000-000000000001','${C1}','Ahmad','0123'),('c0000000-0000-4000-8000-000000000002','${C1}','Siti','0198'),('c0000000-0000-4000-8000-000000000003','${C2}','Orang Lain','011'),('c0000000-0000-4000-8000-000000000004','${C1}','Ujian Tiada Motor','0100');
   insert into public.vehicles(id,company_id,customer_id,plate_no,brand,model) values ('d0000000-0000-4000-8000-000000000001','${C1}','c0000000-0000-4000-8000-000000000001','JXX 1234','Yamaha','NVX'),('d0000000-0000-4000-8000-000000000002','${C1}','c0000000-0000-4000-8000-000000000002','WVB 8821','Honda','RS150');
   insert into public.products(id,company_id,sku,name) values ('${prodA}','${C1}','MO-1','Minyak 1L'),('${prodStock}','${C1}','SP-1','Plug');
   insert into public.stock_balances values ('${prodA}','${L1}',0),('${prodStock}','${L1}',5);
   insert into public.suppliers(id,company_id,name) values ('e0000000-0000-4000-8000-000000000001','${C1}','Alat Maju');
   insert into public.job_cards(id,company_id,job_no,customer_id,vehicle_id,status) values
     ('f0000000-0000-4000-8000-000000000001','${C1}','JOB-OPEN','c0000000-0000-4000-8000-000000000001','d0000000-0000-4000-8000-000000000001','IN_PROGRESS'),
     ('f0000000-0000-4000-8000-000000000002','${C1}','JOB-PAID','c0000000-0000-4000-8000-000000000002','d0000000-0000-4000-8000-000000000002','COMPLETED'),
     ('f0000000-0000-4000-8000-000000000003','${C1}','JOB-FREE','c0000000-0000-4000-8000-000000000002','d0000000-0000-4000-8000-000000000002','OPEN');
   insert into public.invoices(id,company_id,job_card_id,status,payment_status,total) values ('b0000000-0000-4000-8000-000000000001','${C1}','f0000000-0000-4000-8000-000000000002','PAID','PAID',100);
   insert into public.job_card_items(id,company_id,job_card_id,product_id,item_type,quantity) values ('90000000-0000-4000-8000-000000000001','${C1}','f0000000-0000-4000-8000-000000000001','${prodA}','PART',1);
   insert into public.payments(id,company_id,invoice_id,amount) values ('a0000000-0000-4000-8000-000000000001','${C1}','b0000000-0000-4000-8000-000000000001',100);
   insert into public.bookings(id,company_id,customer_id,vehicle_id,status) values ('bb000000-0000-4000-8000-000000000001','${C1}','c0000000-0000-4000-8000-000000000004',null,'NEW');
  `);
  // a row written BEFORE the migration, to prove old data is untouched
  await db.exec(`insert into public.audit_logs(company_id,action,metadata) values ('${C1}','UPDATE_JOB','{}')`);

  // ---- run the migration
  const sql=fs.readFileSync(sqlFile,'utf8');
  const err1=await fails(()=>db.exec(sql));
  ok('migration runs without error',err1===null,err1);
  const err2=await fails(()=>db.exec(sql));
  ok('migration is re-runnable (idempotent)',err2===null,err2);
  ok('old audit rows kept',(await audit("action='UPDATE_JOB'")).length===1);

  // ===== rt_override_ready
  ok('ready() works for staff',(await as(U.cash,()=>q('select public.rt_override_ready() as r')))[0].r.ready===true);

  // ===== rt_audit_log
  const r1=await as(U.cash,()=>q("select public.rt_audit_log('UPDATE_CUSTOMER','Updated customer C1','customers',null,'{\"name\":\"a\"}','{\"name\":\"b\"}','{\"role\":\"owner\",\"source\":\"forged\",\"client_ref\":\"x1\"}') as id"));
  const row1=(await audit('id=$1',[r1[0].id]))[0];
  ok('audit_log: actor + company from server',row1.staff_id===S.cash&&row1.company_id===C1&&row1.location_id===L1);
  ok('audit_log: role/source cannot be forged',row1.metadata.role==='cashier'&&row1.metadata.source==='web'&&row1.metadata.client_ref==='x1'&&row1.metadata.details==='Updated customer C1');
  ok('audit_log: before/after stored',row1.before_data.name==='a'&&row1.after_data.name==='b');
  ok('audit_log: reserved OVERRIDE_ refused',/ACTION_RESERVED/.test(await as(U.adm,()=>fails(()=>q("select public.rt_audit_log('OVERRIDE_BEGIN','x')")))||''));
  ok('audit_log: reserved ROW_/ADMIN_ refused',/ACTION_RESERVED/.test(await as(U.adm,()=>fails(()=>q("select public.rt_audit_log('ROW_DELETE','x')")))||'')&&/ACTION_RESERVED/.test(await as(U.adm,()=>fails(()=>q("select public.rt_audit_log('ADMIN_STAFF_REMOVE','x')")))||''));
  ok('audit_log: bad action name refused',/ACTION_INVALID/.test(await as(U.adm,()=>fails(()=>q("select public.rt_audit_log('bad action!','x')")))||''));
  ok('audit_log: not a staff member refused',/STAFF_ONLY/.test(await as(U.none,()=>fails(()=>q("select public.rt_audit_log('CREATE_JOB','x')")))||''));
  ok('audit_log: no login refused',/AUTH_REQUIRED/.test(await as('',()=>fails(()=>q("select public.rt_audit_log('CREATE_JOB','x')")))||''));
  ok('audit_log: oversized payload refused',/PAYLOAD_TOO_LARGE/.test(await as(U.adm,()=>fails(()=>q("select public.rt_audit_log('CREATE_JOB','x',null,null,null,null,jsonb_build_object('a',repeat('x',9000)))")))||''));

  // ===== override begin
  ok('begin: cashier refused',/ADMIN_ONLY/.test(await as(U.cash,()=>fails(()=>q("select public.rt_admin_override_begin('Betulkan rekod ujian')")))||''));
  ok('begin: short reason refused',/REASON_REQUIRED/.test(await as(U.adm,()=>fails(()=>q("select public.rt_admin_override_begin('salah')")))||''));
  const b1=(await as(U.adm,()=>q("select public.rt_admin_override_begin('Betulkan rekod ujian',10) as r")))[0].r;
  ok('begin: returns session',!!b1.session_id&&b1.minutes===10&&new Date(b1.expires_at)>new Date());
  const brow=(await audit('id=$1',[b1.session_id]))[0];
  ok('begin: audited with reason, actor, role',brow.action==='OVERRIDE_BEGIN'&&brow.staff_id===S.adm&&brow.metadata.reason==='Betulkan rekod ujian'&&brow.metadata.role==='admin');
  const b30=(await as(U.own,()=>q("select public.rt_admin_override_begin('Pembetulan oleh owner',999) as r")))[0].r;
  ok('begin: minutes capped at 30',b30.minutes===30);
  const bnew=(await as(U.adm,()=>q("select public.rt_admin_override_begin('Sesi kedua selepas pertama',5) as r")))[0].r;
  ok('begin: previous session closed (replaced)',(await audit("action='OVERRIDE_END' and metadata->>'session_id'=$1",[b1.session_id]))[0]?.metadata.ended_by==='replaced');
  const S1=bnew.session_id;

  // ===== override action: guards
  const act=(user,sess,ent,id,a,reason='Rekod ujian dipadam')=>as(user,()=>q('select public.rt_admin_override_action($1,$2,$3,$4,$5) as r',[sess,ent,id,a,reason]));
  const code=async(p)=>{const m=await fails(()=>p);return m;};
  ok('action: cashier refused',/ADMIN_ONLY/.test(await code(act(U.cash,S1,'CUSTOMER','c0000000-0000-4000-8000-000000000004','ARCHIVE'))||''));
  ok('action: no session refused',/OVERRIDE_SESSION_REQUIRED/.test(await code(act(U.adm,null,'CUSTOMER','c0000000-0000-4000-8000-000000000004','ARCHIVE'))||''));
  ok('action: replaced session refused',/OVERRIDE_SESSION_ENDED/.test(await code(act(U.adm,b1.session_id,'CUSTOMER','c0000000-0000-4000-8000-000000000004','ARCHIVE'))||''));
  ok("action: someone else's session refused",/OVERRIDE_SESSION_INVALID/.test(await code(act(U.adm,b30.session_id,'CUSTOMER','c0000000-0000-4000-8000-000000000004','ARCHIVE'))||''));
  ok('action: short reason refused',/REASON_REQUIRED/.test(await code(act(U.adm,S1,'CUSTOMER','c0000000-0000-4000-8000-000000000004','ARCHIVE','x'))||''));
  ok('action: bad entity / action refused',/ENTITY_INVALID/.test(await code(act(U.adm,S1,'INVOICE','c0000000-0000-4000-8000-000000000004','ARCHIVE'))||'')&&/ACTION_INVALID/.test(await code(act(U.adm,S1,'CUSTOMER','c0000000-0000-4000-8000-000000000004','DELETE'))||'')&&/ACTION_INVALID/.test(await code(act(U.adm,S1,'JOB_CARD','f0000000-0000-4000-8000-000000000003','ARCHIVE'))||''));
  ok('action: other company record not found',/RECORD_NOT_FOUND/.test(await code(act(U.adm,S1,'CUSTOMER','c0000000-0000-4000-8000-000000000003','ARCHIVE'))||''));
  // expired session (simulate: superuser edits the trail after switching the guard off)
  await db.exec("alter table public.audit_logs disable trigger rt_audit_logs_guard");
  const bexp=(await as(U.own,()=>q("select public.rt_admin_override_begin('Sesi akan tamat segera',5) as r")))[0].r;
  await db.query("update public.audit_logs set metadata=jsonb_set(metadata,'{expires_at}',to_jsonb((now()-interval '1 minute')::text)) where id=$1",[bexp.session_id]);
  await db.exec("alter table public.audit_logs enable trigger rt_audit_logs_guard");
  ok('action: expired session refused',/OVERRIDE_EXPIRED/.test(await code(act(U.own,bexp.session_id,'CUSTOMER','c0000000-0000-4000-8000-000000000004','ARCHIVE'))||''));

  // ===== override action: business rules
  ok('customer with active vehicle blocked',/CUSTOMER_HAS_VEHICLES/.test(await code(act(U.adm,S1,'CUSTOMER','c0000000-0000-4000-8000-000000000001','ARCHIVE'))||''));
  ok('customer with pending booking blocked',/CUSTOMER_HAS_BOOKINGS/.test(await code(act(U.adm,S1,'CUSTOMER','c0000000-0000-4000-8000-000000000004','ARCHIVE'))||''));
  ok('vehicle with open job blocked',/VEHICLE_HAS_OPEN_JOBS/.test(await code(act(U.adm,S1,'VEHICLE','d0000000-0000-4000-8000-000000000001','ARCHIVE'))||''));
  ok('product with stock blocked',/PRODUCT_HAS_STOCK/.test(await code(act(U.adm,S1,'PRODUCT',prodStock,'ARCHIVE'))||''));
  ok('product in an open job blocked',/PRODUCT_IN_OPEN_JOB/.test(await code(act(U.adm,S1,'PRODUCT',prodA,'ARCHIVE'))||''));
  ok('paid job cannot be cancelled',/JOB_ALREADY_PAID/.test(await code(act(U.adm,S1,'JOB_CARD','f0000000-0000-4000-8000-000000000002','CANCEL'))||''));
  ok('nothing changed by the blocked attempts',(await q("select count(*)::int as n from public.customers where active=false"))[0].n===0&&(await q("select count(*)::int as n from public.job_cards where status='CANCELLED'"))[0].n===0);

  // success paths
  await db.exec("update public.bookings set status='CANCELLED' where id='bb000000-0000-4000-8000-000000000001'");
  const before=(await audit()).length;
  const a1=(await act(U.adm,S1,'CUSTOMER','c0000000-0000-4000-8000-000000000004','ARCHIVE','Rekod ujian, tiada transaksi'))[0].r;
  ok('archive customer ok',a1.ok===true&&a1.label==='Ujian Tiada Motor'&&(await q("select active from public.customers where id='c0000000-0000-4000-8000-000000000004'"))[0].active===false);
  const arow=(await audit('id=$1',[a1.audit_id]))[0];
  ok('archive: before/after + reason + session in the audit row',arow.action==='OVERRIDE_CUSTOMER_ARCHIVE'&&arow.before_data.active===true&&arow.after_data.active===false&&arow.metadata.reason==='Rekod ujian, tiada transaksi'&&arow.metadata.override_session===S1&&arow.staff_id===S.adm&&arow.entity_type==='customers');
  ok('archive: exactly one audit row (trigger not duplicating)',(await audit()).length===before+1);
  ok('archive again refused',/ALREADY_ARCHIVED/.test(await code(act(U.adm,S1,'CUSTOMER','c0000000-0000-4000-8000-000000000004','ARCHIVE'))||''));
  ok('restore customer ok',(await act(U.adm,S1,'CUSTOMER','c0000000-0000-4000-8000-000000000004','RESTORE','Salah arkib, pulihkan'))[0].r.ok===true&&(await q("select active from public.customers where id='c0000000-0000-4000-8000-000000000004'"))[0].active===true);
  ok('restore active refused',/ALREADY_ACTIVE/.test(await code(act(U.adm,S1,'CUSTOMER','c0000000-0000-4000-8000-000000000004','RESTORE'))||''));
  ok('archive supplier ok',(await act(U.adm,S1,'SUPPLIER','e0000000-0000-4000-8000-000000000001','ARCHIVE'))[0].r.ok===true);
  ok('archive product with no stock / no open job ok',(await q("update public.job_card_items set status='REMOVED' where id='90000000-0000-4000-8000-000000000001' returning id")).length===1&&(await act(U.adm,S1,'PRODUCT',prodA,'ARCHIVE'))[0].r.ok===true&&(await q("select active from public.products where id=$1",[prodA]))[0].active===false);
  const cj=(await act(U.adm,S1,'JOB_CARD','f0000000-0000-4000-8000-000000000003','CANCEL','Pelanggan batal servis'))[0].r;
  ok('cancel unpaid job ok',cj.ok===true&&(await q("select status from public.job_cards where id='f0000000-0000-4000-8000-000000000003'"))[0].status==='CANCELLED');
  ok('cancel again refused',/JOB_ALREADY_CANCELLED/.test(await code(act(U.adm,S1,'JOB_CARD','f0000000-0000-4000-8000-000000000003','CANCEL'))||''));
  const bo=(await as(U.own,()=>q("select public.rt_admin_override_begin('Pembetulan oleh owner lagi',10) as r")))[0].r;
  ok('owner can restore too',(await act(U.own,bo.session_id,'SUPPLIER','e0000000-0000-4000-8000-000000000001','RESTORE','Pulihkan pembekal'))[0].r.ok===true);
  // end
  ok('end: other staff refused',/OVERRIDE_SESSION_INVALID/.test(await as(U.adm,()=>fails(()=>q("select public.rt_admin_override_end($1)",[bo.session_id])))||''));
  const e1=(await as(U.adm,()=>q("select public.rt_admin_override_end($1,'user') as r",[S1])))[0].r;
  ok('end: ok + audited',e1.ok===true&&(await audit("action='OVERRIDE_END' and metadata->>'session_id'=$1 and metadata->>'ended_by'='user'",[S1])).length===1);
  ok('end: idempotent',(await as(U.adm,()=>q("select public.rt_admin_override_end($1) as r",[S1])))[0].r.already===true&&(await audit("action='OVERRIDE_END' and metadata->>'session_id'=$1",[S1])).length===1);
  ok('action after end refused',/OVERRIDE_SESSION_ENDED/.test(await code(act(U.adm,S1,'SUPPLIER','e0000000-0000-4000-8000-000000000001','ARCHIVE'))||''));

  // ===== row triggers
  const n0=(await audit("action like 'ROW_%'")).length;
  await as(U.adm,()=>q("update public.customers set name='Ahmad Faizal', phone='0124' where id='c0000000-0000-4000-8000-000000000001'"));
  const ru=(await audit("action='ROW_UPDATE' and entity_type='customers'")).pop();
  ok('direct update is recorded with changed fields only',ru&&ru.before_data.name==='Ahmad'&&ru.after_data.name==='Ahmad Faizal'&&ru.before_data.phone==='0123'&&ru.after_data.phone==='0124'&&!('active' in ru.after_data)&&ru.staff_id===S.adm&&ru.metadata.source==='db_trigger');
  await as(U.adm,()=>q("update public.customers set updated_at=now() where id='c0000000-0000-4000-8000-000000000001'"));
  ok('updated_at-only change not logged',(await audit("action like 'ROW_%'")).length===n0+1);
  await db.exec("update public.invoices set transaction_id='99999999-9999-4999-8999-999999999999' where id='b0000000-0000-4000-8000-000000000001'");
  ok('transaction_id re-key not logged',(await audit("action like 'ROW_%'")).length===n0+1);
  await db.exec("update public.invoices set status='VOID' where id='b0000000-0000-4000-8000-000000000001'");
  ok('invoice status change logged',(await audit("action='ROW_UPDATE' and entity_type='invoices'")).length===1);
  await db.exec("update public.app_settings set setting_value='{}' where false");
  await db.exec(`insert into public.app_settings(company_id,setting_key,setting_value) values ('${C1}','qr','{"img":"a"}')`);
  await db.exec(`update public.app_settings set setting_value=jsonb_build_object('img',repeat('x',9000)) where setting_key='qr'`);
  const rs=(await audit("action='ROW_UPDATE' and entity_type='app_settings'")).pop();
  ok('huge values are truncated in the trail',rs&&rs.after_data.setting_value._truncated===true);
  const id1=(await q("insert into public.job_card_items(company_id,job_card_id,product_id,item_type,quantity) values ($1,'f0000000-0000-4000-8000-000000000001',$2,'PART',2) returning id",[C1,prodA]))[0].id;
  await as(U.adm,()=>q("delete from public.job_card_items where id=$1",[id1]));
  const rd=(await audit("action='ROW_DELETE' and entity_type='job_card_items'")).pop();
  ok('job item delete still allowed and keeps a snapshot',rd&&rd.before_data.quantity==2&&rd.before_data.product_id===prodA&&rd.entity_id===id1);

  // ===== audit_logs append-only
  const arid=(await audit("action='UPDATE_CUSTOMER'"))[0].id;
  ok('authenticated cannot DELETE audit_logs (privilege)',/permission denied/.test(await as(U.own,()=>fails(()=>q("delete from public.audit_logs where id=$1",[arid])))||''));
  ok('authenticated cannot UPDATE audit_logs (privilege)',/permission denied/.test(await as(U.own,()=>fails(()=>q("update public.audit_logs set action='X' where id=$1",[arid])))||''));
  ok('authenticated cannot TRUNCATE audit_logs',/permission denied/.test(await as(U.own,()=>fails(()=>q("truncate public.audit_logs")))||''));
  ok('even the table owner cannot DELETE (trigger)',/AUDIT_LOG_IMMUTABLE/.test(await fails(()=>q("delete from public.audit_logs where id=$1",[arid]))||''));
  ok('even the table owner cannot edit other columns',/AUDIT_LOG_IMMUTABLE/.test(await fails(()=>q("update public.audit_logs set action='X' where id=$1",[arid]))||''));
  ok('owner cannot TRUNCATE (trigger)',/AUDIT_LOG_IMMUTABLE/.test(await fails(()=>q("truncate public.audit_logs"))||''));
  ok('transaction_id re-key still allowed (Job checkout)',(await fails(()=>q("update public.audit_logs set transaction_id='88888888-8888-4888-8888-888888888888' where id=$1",[arid])))===null);
  ok('audit rows still all there',(await audit()).length>20);

  // ===== hard-delete lock on money / stock / staff tables
  for(const [t,w] of [['invoices',"id='b0000000-0000-4000-8000-000000000001'"],['payments',"id='a0000000-0000-4000-8000-000000000001'"],['staff',`id='${S.cash}'`]]){
    ok(`authenticated cannot DELETE ${t}`,/permission denied/.test(await as(U.own,()=>fails(()=>q(`delete from public.${t} where ${w}`)))||''));
  }
  ok('authenticated can still SELECT / UPDATE normal data',(await as(U.cash,()=>q("select count(*)::int as n from public.customers")))[0].n>0);
  ok('definer RPCs still work after the lock (override archive)',(await as(U.adm,async()=>{const s=(await q("select public.rt_admin_override_begin('Sesi selepas kunci',5) as r"))[0].r;return q("select public.rt_admin_override_action($1,'SUPPLIER','e0000000-0000-4000-8000-000000000001','ARCHIVE','Uji selepas kunci') as r",[s.session_id]);}))[0].r.ok===true);

  // ===== Job checkout style: a SECURITY DEFINER function re-keys audit_logs.transaction_id after the lock
  await db.exec(`create function public.test_job_rekey(p_old uuid, p_new uuid) returns int language plpgsql security definer set search_path=public as $$
     declare n int; begin update public.audit_logs set transaction_id=p_new where transaction_id=p_old; get diagnostics n=row_count; return n; end $$;
     grant execute on function public.test_job_rekey(uuid,uuid) to authenticated;`);
  await db.exec("insert into public.audit_logs(company_id,action,entity_type,transaction_id) values ('"+C1+"','CREATE_INVOICE','INVOICE','77777777-7777-4777-8777-777777777777')");
  ok('definer function can still re-key transaction_id (Job checkout keeps working)',(await as(U.cash,()=>q("select public.test_job_rekey('77777777-7777-4777-8777-777777777777','66666666-6666-4666-8666-666666666666') as n")))[0].n===1);
  await db.exec("create function public.test_invoker_edit() returns void language plpgsql as $$ begin update public.audit_logs set action='X' where false; end $$; grant execute on function public.test_invoker_edit() to authenticated;");
  ok('an INVOKER function that edits audit_logs is refused (what PART 0e warns about)',/permission denied/.test(await as(U.cash,()=>fails(()=>q("select public.test_invoker_edit()")))||''));

  // ===== PART 0 diagnostics are runnable as written
  const head=sql.slice(sql.indexOf('-- PART 0'),sql.indexOf('\nbegin;'));
  const chunks=head.split(/\n-- 0[a-e]\./).slice(1);
  ok('five diagnostics found',chunks.length===5,chunks.length);
  for(const [i,ch] of chunks.entries()){
    const lines=ch.split('\n');const at=lines.findIndex(l=>l.startsWith('-- select'));
    const dsql=lines.slice(at).filter(l=>l.startsWith('--')).map(l=>l.replace(/^-- ?/,'')).join('\n');
    const de=await fails(()=>q(dsql));
    ok('diagnostic 0'+'abcde'[i]+' runs',de===null,de+' :: '+dsql.slice(0,80));
  }

  // ===== anon
  await db.exec("reset role");await db.exec("set role anon");
  ok('anon cannot call the RPCs',/permission denied/.test(await fails(()=>q("select public.rt_audit_log('CREATE_JOB','x')"))||'')&&/permission denied/.test(await fails(()=>q("select public.rt_admin_override_begin('abcdefghij')"))||''));
  await db.exec("reset role");

  // ===== missing-column safety: the migration refuses to run on a different audit_logs
  const db2=new PGlite();
  await db2.exec(SCHEMA.replace('before_data jsonb, after_data jsonb,',''));
  const e3=await fails(()=>db2.exec(sql));
  await fails(()=>db2.exec('rollback'));   // a failed script leaves its BEGIN open (the SQL editor discards it)
  ok('refuses to run if audit_logs lacks columns (nothing changed)',/AUDIT_LOGS_COLUMNS_MISSING.*after_data.*before_data|AUDIT_LOGS_COLUMNS_MISSING.*before_data.*after_data/.test(e3||'')&&(await db2.query("select count(*)::int as n from pg_proc where proname like 'rt_admin_override%'")).rows[0].n===0,e3);

  // ===== rollback block works
  const rb=sql.slice(sql.indexOf('-- PART 6'));
  const rbSql=rb.split('\n').filter(l=>l.startsWith('-- ')&&!l.startsWith('-- ====')&&!/^-- PART 6/.test(l)).map(l=>l.slice(3)).join('\n');
  const e4=await fails(()=>db.exec(rbSql));
  if(e4)await fails(()=>db.exec('rollback'));
  ok('rollback block runs',e4===null,e4);
  ok('after rollback: functions gone, triggers gone, audit rows kept',(await q("select count(*)::int as n from pg_proc where proname in ('rt_admin_override_action','rt_audit_log')"))[0].n===0&&(await q("select count(*)::int as n from pg_trigger where tgname in ('rt_audit_row_change','rt_audit_logs_guard') and not tgisinternal"))[0].n===0&&(await audit()).length>20);

  for(const r of results)console.log((r.pass?'PASS':'FAIL')+' '+r.n+(r.pass?'':'  :: '+r.i));
  console.log(`\n${results.filter(r=>r.pass).length}/${results.length} passed`);
  process.exit(results.every(r=>r.pass)?0:1);
})().catch(e=>{console.error('HARNESS ERROR',e);process.exit(2);});
