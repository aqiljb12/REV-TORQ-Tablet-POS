const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(root,f),'utf8');

test('POS customer dialog has an add-motorcycle box (plate, model, SIMPAN), hidden until a customer is chosen',()=>{
  const html=read('index.html');
  assert.match(html,/id="rtVehAdd" class="rt-veh-add" hidden/);
  for(const id of ['rtVehPlate','rtVehModel','rtVehSave'])assert.ok(html.includes('id="'+id+'"'),id);
  assert.match(html,/id="rtVehPlate"[^>]*autocapitalize="characters"/);
  const js=read('js/rt-polish.js');
  assert.match(js,/vadd\.hidden=!c\|\|!!job/,'hidden without a customer and in Job mode');
});

test('the motorcycle is saved exactly like the Pelanggan page saves it (same db handle, same fields, audit)',()=>{
  const js=read('js/rt-polish.js');
  const cust=read('js/customers.js');
  assert.match(js,/db\.collection\('vehicles'\)\.doc\(id\)\.set\(\{vehicleId:id,customerId:cid,plateNo:plate,model:model,active:true,createdAt:/);
  assert.match(cust,/db\.collection\("vehicles"\)\.doc\(vId\)\.set\(\{\s*vehicleId: vId,\s*customerId: cid,\s*plateNo: plate,\s*model: model,\s*active: true/);
  assert.match(js,/logAudit\('CREATE_VEHICLE'/);
  const body=js.slice(js.indexOf('function saveVehicle'),js.indexOf('function bindVehicleAdd'));
  assert.doesNotMatch(body,/\.rpc\(|supabaseRpc|\bfetch\(|\.insert\(|\.delete\(|\.update\(/,'no other write path');
});

test('nothing is written without SIMPAN; plate is normalised; same plate is not added twice; failure keeps the text',()=>{
  const js=read('js/rt-polish.js');
  assert.match(js,/function normPlate\(v\)\{return String\(v==null\?'':v\)\.toUpperCase\(\)/);
  assert.match(js,/btn\.addEventListener\('click',saveVehicle\)/);
  assert.match(js,/plateKey\(v\.plate\)===plateKey\(plate\)/);
  assert.match(js,/Motosikal tidak dapat disimpan/);
  assert.match(js,/if\(vehSaving\)return;/,'double tap cannot write twice');
  const css=read('css/rt-polish.css');
  assert.match(css,/#view-pos \.rt-veh-add-row input\{[^}]*font-size:16px!important/);
  assert.match(css,/#view-pos \.rt-veh-add\[hidden\]\{display:none!important\}/);
});

test('the plate goes with the sale only when one is picked (the plain sale payload is unchanged)',()=>{
  assert.doesNotMatch(read('js/rt-polish.js'),/p_vehicle_id/,'the polish layer never builds the sale');
  assert.match(read('js/v36-4-9-pos-cash-canonical.js'),/else\{args\.p_discount=disc;if\(vehicleId\)args\.p_vehicle_id=vehicleId;/);
});
