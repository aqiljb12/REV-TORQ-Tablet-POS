from pathlib import Path
import re

css = Path(__file__).resolve().parents[1] / 'css' / 'rt-polish.css'
text = css.read_text(encoding='utf-8')

# Regression: on phone the inventory toolbar switches to flex-column.
# The iPad flex-basis values (220/260px) must be reset or they become vertical height.
mobile_blocks = re.findall(r'@media\s*\(max-width:640px\)\s*\{(.*?)\n\}', text, flags=re.S)
joined = '\n'.join(mobile_blocks)

assert re.search(r'#view-inventory\s+\.rt-inv-left>\.relative\s*\{[^}]*flex\s*:\s*0\s+0\s+auto', joined), \
    'phone search block must not keep fixed flex-basis'
assert re.search(r'#view-inventory\s+\.rt-inv-left>\.flex\s*\{[^}]*flex\s*:\s*0\s+0\s+auto', joined), \
    'phone scanner block must not keep fixed flex-basis'
assert re.search(r'#view-inventory\s+\.rt-inv-left>\.relative\s*\{[^}]*min-width\s*:\s*0', joined), \
    'phone search block must allow shrinking'

index = (Path(__file__).resolve().parents[1] / 'index.html').read_text(encoding='utf-8')
m = re.search(r'css/rt-polish\.css\?v=([^"\']+)', index)
assert m, 'rt-polish.css must use a cache-busting version'
assert m.group(1) != '2.3.0-ipad', 'phone fix must not use the pre-fix iPad-only CSS cache key'
