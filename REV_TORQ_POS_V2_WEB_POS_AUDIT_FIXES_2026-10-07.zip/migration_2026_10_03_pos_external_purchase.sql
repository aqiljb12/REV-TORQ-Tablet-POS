-- REV TORQ POS V2 — Barang Luar / emergency purchase
-- Live Supabase function used by js/external-purchase.js.
create or replace function public.rt_pos_external_purchase(
  p_product_id uuid default null,
  p_name text default null,
  p_sku text default null,
  p_category text default 'BARANG LUAR',
  p_cost_price numeric default 0,
  p_sell_price numeric default 0,
  p_qty_buy numeric default 1,
  p_source_name text default null,
  p_location_id uuid default null,
  p_job_card_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  v_staff record;
  v_product public.products%rowtype;
  v_location uuid;
  v_job_location uuid;
  v_qty numeric;
  v_cost numeric;
  v_sell numeric;
  v_sku text;
  v_name text;
  v_category text;
  v_source text;
  v_barcode text;
  v_before numeric := 0;
  v_after numeric := 0;
  v_tx uuid := gen_random_uuid();
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into v_staff from public.rt_staff_context() limit 1;
  if v_staff.staff_id is null then raise exception 'STAFF_ONLY'; end if;
  if lower(coalesce(v_staff.role,'')) not in ('owner','admin','super_admin','manager','storekeeper','stor','cashier','pos') then
    raise exception 'EXTERNAL_PURCHASE_ROLE_NOT_ALLOWED';
  end if;

  v_qty := greatest(0,coalesce(p_qty_buy,0));
  v_cost := greatest(0,coalesce(p_cost_price,0));
  v_sell := greatest(0,coalesce(p_sell_price,0));
  if v_qty <= 0 then raise exception 'INVALID_QTY'; end if;

  v_source := nullif(trim(coalesce(p_source_name,'')),'');
  v_name := trim(coalesce(p_name,''));
  v_category := upper(coalesce(nullif(trim(coalesce(p_category,'')),''),'BARANG LUAR'));

  if p_job_card_id is not null then
    select j.location_id into v_job_location from public.job_cards j
    where j.id=p_job_card_id and j.company_id=v_staff.company_id limit 1;
    if not found then raise exception 'JOB_CARD_NOT_FOUND'; end if;
  end if;

  v_location := coalesce(p_location_id,v_job_location,v_staff.location_id);
  if v_location is null then
    select l.id into v_location from public.locations l
    where l.company_id=v_staff.company_id and l.active=true
    order by l.code nulls last,l.created_at limit 1;
  end if;
  if v_location is null or not exists(
    select 1 from public.locations l where l.id=v_location and l.company_id=v_staff.company_id and l.active=true
  ) then raise exception 'LOCATION_NOT_FOUND'; end if;

  if p_product_id is not null then
    select * into v_product from public.products p
    where p.id=p_product_id and p.company_id=v_staff.company_id and p.active=true for update;
    if v_product.id is null then raise exception 'PRODUCT_NOT_FOUND'; end if;
    update public.products set cost_price=v_cost,sell_price=v_sell,updated_at=now()
    where id=v_product.id returning * into v_product;
  else
    if v_name='' then raise exception 'NAME_REQUIRED'; end if;
    v_sku := upper(trim(coalesce(p_sku,'')));
    if v_sku='' then
      loop
        v_sku := 'LUAR-'||to_char(clock_timestamp(),'YYMMDD')||'-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,6));
        exit when not exists(select 1 from public.products p where p.company_id=v_staff.company_id and p.sku=v_sku);
      end loop;
    elsif exists(select 1 from public.products p where p.company_id=v_staff.company_id and p.sku=v_sku) then
      raise exception 'SKU_EXISTS:%',v_sku;
    end if;

    loop
      v_barcode := 'RT'||lpad(nextval('public.rt_internal_barcode_seq'::regclass)::text,10,'0');
      exit when not exists(select 1 from public.products p where p.company_id=v_staff.company_id and p.barcode=v_barcode);
    end loop;

    insert into public.products(company_id,sku,barcode,name,category,unit,cost_price,sell_price,min_stock,active,notes)
    values(v_staff.company_id,v_sku,v_barcode,v_name,v_category,'pcs',v_cost,v_sell,0,true,
      case when v_source is null then null else 'Beli luar: '||v_source end)
    returning * into v_product;
  end if;

  insert into public.stock_balances(product_id,location_id,quantity,reserved_quantity,updated_at)
  values(v_product.id,v_location,0,0,now())
  on conflict(product_id,location_id) do nothing;

  select coalesce(sb.quantity,0) into v_before from public.stock_balances sb
  where sb.product_id=v_product.id and sb.location_id=v_location for update;

  v_after := v_before + v_qty;
  update public.stock_balances set quantity=v_after,updated_at=now()
  where product_id=v_product.id and location_id=v_location;

  insert into public.stock_movements(company_id,location_id,product_id,transaction_id,movement_type,quantity,unit_cost,reference_type,reference_id,staff_id)
  values(v_staff.company_id,v_location,v_product.id,v_tx,'PURCHASE',v_qty,v_cost,'EXTERNAL_PURCHASE',p_job_card_id,v_staff.staff_id);

  insert into public.audit_logs(company_id,location_id,transaction_id,staff_id,action,entity_type,entity_id,metadata)
  values(v_staff.company_id,v_location,v_tx,v_staff.staff_id,'EXTERNAL_PURCHASE','PRODUCT',v_product.id,
    jsonb_build_object('source_name',v_source,'qty_buy',v_qty,'cost_price',v_cost,'sell_price',v_sell,
      'before_stock',v_before,'after_stock',v_after,'job_card_id',p_job_card_id,'sku',v_product.sku));

  return jsonb_build_object('id',v_product.id,'sku',v_product.sku,'barcode',v_product.barcode,'name',v_product.name,
    'category',v_product.category,'cost_price',v_product.cost_price,'sell_price',v_product.sell_price,'stock',v_after,
    'purchased_qty',v_qty,'source_name',v_source,'location_id',v_location,'transaction_id',v_tx);
end;
$function$;

revoke all on function public.rt_pos_external_purchase(uuid,text,text,text,numeric,numeric,numeric,text,uuid,uuid) from public;
revoke all on function public.rt_pos_external_purchase(uuid,text,text,text,numeric,numeric,numeric,text,uuid,uuid) from anon;
grant execute on function public.rt_pos_external_purchase(uuid,text,text,text,numeric,numeric,numeric,text,uuid,uuid) to authenticated;
