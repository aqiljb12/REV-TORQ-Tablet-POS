-- REV TORQ POS V2 — OVERRIDE + AUDIT (2026-10-05)
--
-- WHAT THIS DOES
--   * One trusted audit writer (rt_audit_log): the actor, company and role come
--     from the logged-in staff row on the server, never from the browser.
--   * A real Override Mode: rt_admin_override_begin / _end / _action.
--     An admin / owner / super_admin must give a reason, the action only works
--     inside an active (max 30 min) override session, nothing is ever DELETEd
--     (customers, vehicles, products, suppliers are ARCHIVED; job cards are
--     CANCELLED) and every action writes before/after + reason to audit_logs
--     in the same transaction.
--   * audit_logs becomes append-only (nobody, not even admin, can edit or delete
--     a row; the only allowed change is the transaction_id re-key that
--     rt_post_job_pos_sale_idempotent already performs).
--   * Row-level audit triggers: even a change made outside the POS (browser
--     console, another app, SQL editor with a staff JWT) leaves a record.
--   * Hard DELETE is revoked on invoices / payments / stock / cash / staff tables.
--
-- HOW TO RUN (Supabase -> SQL Editor)
--   1. Run PART 0 on its own first. It only reads. Check the result:
--        - audit_logs must have the columns listed in the check below
--        - "delete policies" / "functions that delete" tell you what could be
--          affected by PART 3 (invoker functions that DELETE would break).
--   2. Take a backup / try on a copy of the project first.
--   3. Run PART 1 + 2 + 3 (everything between BEGIN and COMMIT) in one go.
--      It is one transaction: if anything fails, nothing is changed.
--   4. PART 4 (master tables) and PART 5 (stop forged audit rows) are optional
--      and commented out. Read the notes before enabling them.
--   Rollback: PART 6 (commented).
--
-- This file does NOT change any existing function, table, column or policy.
-- The POS keeps working without it (Override tools stay locked and the app
-- tells the cashier/admin what is missing).

-- =====================================================================
-- PART 0 — DIAGNOSTICS (read-only; run separately, before anything else)
-- =====================================================================
-- 0a. Columns this script relies on (expect 11+ rows incl. before_data/after_data/metadata)
-- select column_name, data_type, is_nullable, column_default
-- from information_schema.columns
-- where table_schema='public' and table_name='audit_logs' order by ordinal_position;
--
-- 0b. What has been written to the audit trail so far (client actions such as
--     UPDATE_JOB / CREATE_CUSTOMER missing here = they were never recorded)
-- select action, count(*) as rows, max(created_at) as last_seen
-- from public.audit_logs group by action order by last_seen desc nulls last limit 60;
--
-- 0c. Policies that allow DELETE
-- select tablename, policyname, cmd, roles, qual from pg_policies
-- where schemaname='public' and cmd in ('DELETE','ALL') order by tablename, policyname;
--
-- 0d. Who is allowed to DELETE / UPDATE / TRUNCATE what
-- select table_name, grantee, string_agg(privilege_type, ', ' order by privilege_type) as privileges
-- from information_schema.role_table_grants
-- where table_schema='public' and grantee in ('anon','authenticated')
--   and privilege_type in ('DELETE','UPDATE','TRUNCATE')
-- group by table_name, grantee order by table_name, grantee;
--
-- 0e. Functions whose body deletes from a table PART 3 locks, or edits audit_logs (PART 2).
--     security_definer = true is safe (runs as owner). security_definer = false would stop
--     working. (rt_post_job_pos_sale_idempotent edits audit_logs.transaction_id: it is a
--     security definer function and the guard allows exactly that one change.)
-- select p.proname, p.prosecdef as security_definer
-- from pg_proc p join pg_namespace n on n.oid=p.pronamespace
-- where n.nspname='public' and p.prokind='f'
--   and (pg_get_functiondef(p.oid) ~* '\mdelete\s+from\s+(public\.)?(invoices|invoice_items|payments|stock_movements|cash_movements|cash_drawers|staff|audit_logs)\M'
--        or pg_get_functiondef(p.oid) ~* '\mupdate\s+(public\.)?audit_logs\M')
-- order by 1;

begin;

-- =====================================================================
-- PART 1 — AUDIT WRITER, OVERRIDE SESSION, OVERRIDE ACTIONS, ROW TRIGGERS
-- =====================================================================

-- Fail early (and change nothing) if audit_logs does not look as expected.
do $check$
declare missing text;
begin
  select string_agg(c, ', ') into missing
  from unnest(array['id','company_id','location_id','transaction_id','staff_id','action',
                    'entity_type','entity_id','before_data','after_data','metadata','created_at']) c
  where not exists (select 1 from information_schema.columns
                    where table_schema='public' and table_name='audit_logs' and column_name=c);
  if missing is not null then
    raise exception 'AUDIT_LOGS_COLUMNS_MISSING: %', missing;
  end if;
end
$check$;

create or replace function public.rt_override_ready()
returns jsonb
language sql
stable
set search_path = public, pg_temp
as $$ select jsonb_build_object('ready', true, 'version', 1) $$;

-- Cap very large JSON values so one settings image cannot bloat the audit trail.
create or replace function public.rt_audit_trim(p_json jsonb)
returns jsonb
language plpgsql
immutable
set search_path = public, pg_temp
as $function$
declare k text; v jsonb; out jsonb := '{}'::jsonb;
begin
  if p_json is null or jsonb_typeof(p_json) <> 'object' then return p_json; end if;
  for k, v in select * from jsonb_each(p_json) loop
    if length(v::text) > 4000 then
      out := out || jsonb_build_object(k, jsonb_build_object('_truncated', true, 'length', length(v::text)));
    else
      out := out || jsonb_build_object(k, v);
    end if;
  end loop;
  return out;
end;
$function$;

-- ---------------------------------------------------------------------
-- Trusted audit writer. The browser sends only what happened; WHO did it
-- comes from the session. Reserved prefixes cannot be forged by the browser.
-- ---------------------------------------------------------------------
create or replace function public.rt_audit_log(
  p_action text,
  p_details text default null,
  p_entity_type text default null,
  p_entity_id uuid default null,
  p_before jsonb default null,
  p_after jsonb default null,
  p_meta jsonb default '{}'::jsonb
)
returns uuid
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  ctx record;
  v_action text := upper(btrim(coalesce(p_action,'')));
  v_id uuid;
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into ctx from public.rt_staff_context() limit 1;
  if ctx.staff_id is null then raise exception 'STAFF_ONLY'; end if;
  if v_action !~ '^[A-Z][A-Z0-9_]{2,62}$' then raise exception 'ACTION_INVALID'; end if;
  if v_action ~ '^(OVERRIDE_|ADMIN_|ROW_|AUDIT_|SYSTEM_)' then raise exception 'ACTION_RESERVED'; end if;
  if pg_column_size(coalesce(p_meta,'{}'::jsonb)) > 8192
     or pg_column_size(coalesce(p_before,'{}'::jsonb)) > 32768
     or pg_column_size(coalesce(p_after,'{}'::jsonb)) > 32768 then
    raise exception 'PAYLOAD_TOO_LARGE';
  end if;
  insert into public.audit_logs(company_id, location_id, staff_id, action, entity_type, entity_id,
                                before_data, after_data, metadata)
  values (ctx.company_id, ctx.location_id, ctx.staff_id, v_action,
          nullif(left(btrim(coalesce(p_entity_type,'')), 64), ''), p_entity_id,
          p_before, p_after,
          -- server values are applied last, so the browser cannot override them
          coalesce(case when jsonb_typeof(p_meta)='object' then p_meta end, '{}'::jsonb)
            || jsonb_build_object('details', left(p_details, 2000), 'role', ctx.role, 'source', 'web'))
  returning id into v_id;
  return v_id;
end;
$function$;

-- ---------------------------------------------------------------------
-- Override session (stored in the audit trail itself: OVERRIDE_BEGIN row,
-- closed by an OVERRIDE_END row or by expiry).
-- ---------------------------------------------------------------------
create or replace function public.rt_override_require_session(
  p_session_id uuid, p_staff_id uuid, p_company_id uuid
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare b public.audit_logs%rowtype;
begin
  if p_session_id is null then raise exception 'OVERRIDE_SESSION_REQUIRED'; end if;
  select * into b from public.audit_logs
  where id = p_session_id and action = 'OVERRIDE_BEGIN'
    and staff_id = p_staff_id and company_id = p_company_id;
  if b.id is null then raise exception 'OVERRIDE_SESSION_INVALID'; end if;
  if exists (select 1 from public.audit_logs e
             where e.action = 'OVERRIDE_END' and e.staff_id = p_staff_id and e.company_id = p_company_id
               and e.metadata->>'session_id' = p_session_id::text) then
    raise exception 'OVERRIDE_SESSION_ENDED';
  end if;
  if coalesce((b.metadata->>'expires_at')::timestamptz, '-infinity'::timestamptz) <= now() then
    raise exception 'OVERRIDE_EXPIRED';
  end if;
  return b.metadata;
end;
$function$;

create or replace function public.rt_admin_override_begin(p_reason text, p_minutes integer default 10)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  ctx record;
  v_reason text := btrim(coalesce(p_reason,''));
  v_min integer := least(greatest(coalesce(p_minutes,10),1),30);
  v_exp timestamptz;
  v_id uuid;
  o record;
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into ctx from public.rt_staff_context() limit 1;
  if ctx.staff_id is null then raise exception 'STAFF_ONLY'; end if;
  if lower(coalesce(ctx.role,'')) not in ('owner','admin','super_admin') then raise exception 'ADMIN_ONLY'; end if;
  if char_length(v_reason) < 8 then raise exception 'REASON_REQUIRED'; end if;
  v_reason := left(v_reason, 300);

  -- one active session per person: close the previous one explicitly
  for o in
    select b.id from public.audit_logs b
    where b.action = 'OVERRIDE_BEGIN' and b.staff_id = ctx.staff_id and b.company_id = ctx.company_id
      and (b.metadata->>'expires_at')::timestamptz > now()
      and not exists (select 1 from public.audit_logs e
                      where e.action = 'OVERRIDE_END' and e.metadata->>'session_id' = b.id::text)
  loop
    insert into public.audit_logs(company_id, location_id, staff_id, action, entity_type, entity_id, metadata)
    values (ctx.company_id, ctx.location_id, ctx.staff_id, 'OVERRIDE_END', 'OVERRIDE', o.id,
            jsonb_build_object('session_id', o.id, 'ended_by', 'replaced', 'role', ctx.role, 'source', 'web'));
  end loop;

  v_exp := now() + make_interval(mins => v_min);
  insert into public.audit_logs(company_id, location_id, staff_id, action, entity_type, entity_id, metadata)
  values (ctx.company_id, ctx.location_id, ctx.staff_id, 'OVERRIDE_BEGIN', 'OVERRIDE', null,
          jsonb_build_object('reason', v_reason, 'minutes', v_min, 'expires_at', v_exp,
                             'role', ctx.role, 'source', 'web'))
  returning id into v_id;

  return jsonb_build_object('session_id', v_id, 'expires_at', v_exp, 'minutes', v_min, 'reason', v_reason);
end;
$function$;

create or replace function public.rt_admin_override_end(p_session_id uuid, p_ended_by text default 'user')
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare ctx record; b public.audit_logs%rowtype;
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into ctx from public.rt_staff_context() limit 1;
  if ctx.staff_id is null then raise exception 'STAFF_ONLY'; end if;
  select * into b from public.audit_logs
  where id = p_session_id and action = 'OVERRIDE_BEGIN'
    and staff_id = ctx.staff_id and company_id = ctx.company_id;
  if b.id is null then raise exception 'OVERRIDE_SESSION_INVALID'; end if;
  if exists (select 1 from public.audit_logs e
             where e.action = 'OVERRIDE_END' and e.staff_id = ctx.staff_id
               and e.metadata->>'session_id' = p_session_id::text) then
    return jsonb_build_object('ok', true, 'already', true);
  end if;
  insert into public.audit_logs(company_id, location_id, staff_id, action, entity_type, entity_id, metadata)
  values (ctx.company_id, ctx.location_id, ctx.staff_id, 'OVERRIDE_END', 'OVERRIDE', p_session_id,
          jsonb_build_object('session_id', p_session_id,
                             'ended_by', case when lower(coalesce(p_ended_by,''))='timeout' then 'timeout' else 'user' end,
                             'role', ctx.role, 'source', 'web'));
  return jsonb_build_object('ok', true);
end;
$function$;

-- ---------------------------------------------------------------------
-- The only way to "remove" something as admin: ARCHIVE / RESTORE / CANCEL.
-- Never DELETE. Blocked while the record is still in use.
-- ---------------------------------------------------------------------
create or replace function public.rt_admin_override_action(
  p_session_id uuid, p_entity text, p_id uuid, p_action text, p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  ctx record;
  v_entity text := upper(btrim(coalesce(p_entity,'')));
  v_action text := upper(btrim(coalesce(p_action,'')));
  v_reason text := btrim(coalesce(p_reason,''));
  v_table text;
  v_before jsonb;
  v_after jsonb;
  v_label text;
  v_audit uuid;
  v_sess jsonb;
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into ctx from public.rt_staff_context() limit 1;
  if ctx.staff_id is null then raise exception 'STAFF_ONLY'; end if;
  if lower(coalesce(ctx.role,'')) not in ('owner','admin','super_admin') then raise exception 'ADMIN_ONLY'; end if;
  v_sess := public.rt_override_require_session(p_session_id, ctx.staff_id, ctx.company_id);
  if char_length(v_reason) < 8 then raise exception 'REASON_REQUIRED'; end if;
  v_reason := left(v_reason, 300);

  v_table := case v_entity
    when 'CUSTOMER' then 'customers' when 'VEHICLE' then 'vehicles' when 'PRODUCT' then 'products'
    when 'SUPPLIER' then 'suppliers' when 'JOB_CARD' then 'job_cards' else null end;
  if v_table is null then raise exception 'ENTITY_INVALID'; end if;
  if v_entity = 'JOB_CARD' then
    if v_action <> 'CANCEL' then raise exception 'ACTION_INVALID'; end if;
  elsif v_action not in ('ARCHIVE','RESTORE') then
    raise exception 'ACTION_INVALID';
  end if;

  -- tell the row trigger this change is already audited here (no duplicate row)
  perform set_config('rt.override_action', '1', true);

  execute format('select to_jsonb(t) from public.%I t where t.id = $1 and t.company_id = $2 for update', v_table)
    into v_before using p_id, ctx.company_id;
  if v_before is null then raise exception 'RECORD_NOT_FOUND'; end if;

  if v_action = 'ARCHIVE' then
    if coalesce((v_before->>'active')::boolean, true) = false then raise exception 'ALREADY_ARCHIVED'; end if;
    if v_entity = 'CUSTOMER' then
      if exists (select 1 from public.vehicles v where v.customer_id = p_id and v.company_id = ctx.company_id
                 and coalesce(v.active, true)) then raise exception 'CUSTOMER_HAS_VEHICLES'; end if;
      if exists (select 1 from public.job_cards j where j.customer_id = p_id and j.company_id = ctx.company_id
                 and j.status in ('OPEN','IN_PROGRESS','WAITING_PARTS','COMPLETED')
                 and not exists (select 1 from public.invoices i where i.job_card_id = j.id and i.company_id = j.company_id
                                 and i.status = 'PAID' and i.payment_status = 'PAID')) then
        raise exception 'CUSTOMER_HAS_OPEN_JOBS';
      end if;
      if exists (select 1 from public.bookings b where b.customer_id = p_id and b.company_id = ctx.company_id
                 and b.status in ('NEW','CONFIRMED')) then raise exception 'CUSTOMER_HAS_BOOKINGS'; end if;
    elsif v_entity = 'VEHICLE' then
      if exists (select 1 from public.job_cards j where j.vehicle_id = p_id and j.company_id = ctx.company_id
                 and j.status in ('OPEN','IN_PROGRESS','WAITING_PARTS','COMPLETED')
                 and not exists (select 1 from public.invoices i where i.job_card_id = j.id and i.company_id = j.company_id
                                 and i.status = 'PAID' and i.payment_status = 'PAID')) then
        raise exception 'VEHICLE_HAS_OPEN_JOBS';
      end if;
      if exists (select 1 from public.bookings b where b.vehicle_id = p_id and b.company_id = ctx.company_id
                 and b.status in ('NEW','CONFIRMED')) then raise exception 'VEHICLE_HAS_BOOKINGS'; end if;
    elsif v_entity = 'PRODUCT' then
      if coalesce((select sum(s.quantity) from public.stock_balances s where s.product_id = p_id), 0) <> 0 then
        raise exception 'PRODUCT_HAS_STOCK';
      end if;
      if exists (select 1 from public.job_card_items it join public.job_cards j on j.id = it.job_card_id
                 where it.product_id = p_id and it.company_id = ctx.company_id and it.status = 'ACTIVE'
                   and j.status in ('OPEN','IN_PROGRESS','WAITING_PARTS','COMPLETED')
                   and not exists (select 1 from public.invoices i where i.job_card_id = j.id and i.company_id = j.company_id
                                   and i.status = 'PAID' and i.payment_status = 'PAID')) then
        raise exception 'PRODUCT_IN_OPEN_JOB';
      end if;
    end if;
    execute format('update public.%I set active = false where id = $1 and company_id = $2', v_table) using p_id, ctx.company_id;
  elsif v_action = 'RESTORE' then
    if coalesce((v_before->>'active')::boolean, true) = true then raise exception 'ALREADY_ACTIVE'; end if;
    execute format('update public.%I set active = true where id = $1 and company_id = $2', v_table) using p_id, ctx.company_id;
  else -- CANCEL (job card)
    if v_before->>'status' = 'CANCELLED' then raise exception 'JOB_ALREADY_CANCELLED'; end if;
    if exists (select 1 from public.invoices i where i.job_card_id = p_id and i.company_id = ctx.company_id
               and i.status = 'PAID' and i.payment_status = 'PAID') then raise exception 'JOB_ALREADY_PAID'; end if;
    update public.job_cards set status = 'CANCELLED' where id = p_id and company_id = ctx.company_id;
  end if;

  execute format('select to_jsonb(t) from public.%I t where t.id = $1', v_table) into v_after using p_id;
  v_label := case v_entity
    when 'PRODUCT' then concat_ws(' · ', v_before->>'sku', v_before->>'name')
    when 'VEHICLE' then concat_ws(' · ', v_before->>'plate_no', concat_ws(' ', v_before->>'brand', v_before->>'model'))
    when 'JOB_CARD' then v_before->>'job_no'
    else v_before->>'name' end;

  insert into public.audit_logs(company_id, location_id, staff_id, action, entity_type, entity_id,
                                before_data, after_data, metadata)
  values (ctx.company_id, ctx.location_id, ctx.staff_id, 'OVERRIDE_' || v_entity || '_' || v_action, v_table, p_id,
          public.rt_audit_trim(v_before), public.rt_audit_trim(v_after),
          jsonb_build_object('reason', v_reason, 'override_session', p_session_id, 'label', v_label,
                             'role', ctx.role, 'source', 'web'))
  returning id into v_audit;

  return jsonb_build_object('ok', true, 'audit_id', v_audit, 'entity', v_entity, 'id', p_id,
                            'action', v_action, 'label', v_label);
end;
$function$;

-- ---------------------------------------------------------------------
-- Row-level audit: anything that changes / deletes a row is recorded, even if
-- it did not come through the POS screens. Frequent noise-only updates
-- (updated_at, transaction_id re-key) are skipped.
-- UPDATE: if the audit write fails the update still succeeds (warning).
-- DELETE: if the audit write fails the delete is refused.
-- ---------------------------------------------------------------------
create or replace function public.rt_audit_row_change()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  v_old jsonb := to_jsonb(old);
  v_new jsonb;
  v_from jsonb := '{}'::jsonb;
  v_to jsonb := '{}'::jsonb;
  k text;
  v_actor uuid;
  v_role text;
  v_company uuid;
  v_id uuid;
begin
  if current_setting('rt.override_action', true) = '1' then return null; end if;  -- already audited by the RPC

  if tg_op = 'UPDATE' then
    v_new := to_jsonb(new);
    for k in select jsonb_object_keys(v_new) loop
      if k in ('updated_at', 'transaction_id') then continue; end if;
      if v_old->k is distinct from v_new->k then
        v_from := v_from || jsonb_build_object(k, v_old->k);
        v_to := v_to || jsonb_build_object(k, v_new->k);
      end if;
    end loop;
    if v_to = '{}'::jsonb then return null; end if;   -- nothing meaningful changed
  end if;

  begin
    select s.staff_id, s.role into v_actor, v_role from public.rt_staff_context() s limit 1;
  exception when others then
    v_actor := null; v_role := null;
  end;
  v_company := nullif(coalesce(v_old->>'company_id', v_new->>'company_id'), '')::uuid;
  v_id := case when coalesce(v_old->>'id','') ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
               then (v_old->>'id')::uuid end;

  begin
    insert into public.audit_logs(company_id, staff_id, action, entity_type, entity_id, before_data, after_data, metadata)
    values (v_company, v_actor, 'ROW_' || tg_op, tg_table_name, v_id,
            case when tg_op = 'DELETE' then public.rt_audit_trim(v_old) else public.rt_audit_trim(v_from) end,
            case when tg_op = 'DELETE' then null else public.rt_audit_trim(v_to) end,
            jsonb_build_object('source', 'db_trigger', 'db_user', session_user, 'role', v_role,
                               'changed', case when tg_op = 'UPDATE' then (select jsonb_agg(x) from jsonb_object_keys(v_to) x) end));
  exception when others then
    if tg_op = 'DELETE' then raise; end if;
    raise warning 'rt_audit_row_change(%): %', tg_table_name, sqlerrm;
  end;
  return null;
end;
$function$;

do $attach$
declare t text;
begin
  -- master data: audit UPDATE and DELETE
  foreach t in array array['customers','vehicles','products','suppliers','job_cards','staff','app_settings','invoices','bookings'] loop
    if to_regclass('public.' || t) is not null
       and exists (select 1 from information_schema.columns
                   where table_schema = 'public' and table_name = t and column_name = 'company_id') then
      execute format('drop trigger if exists rt_audit_row_change on public.%I', t);
      execute format('create trigger rt_audit_row_change after update or delete on public.%I for each row execute function public.rt_audit_row_change()', t);
    else
      raise notice 'rt_audit_row_change: skipped % (table or company_id column not found)', t;
    end if;
  end loop;
  -- ledgers and job items: audit DELETE (a deleted row is kept as a snapshot)
  foreach t in array array['invoice_items','payments','stock_movements','cash_movements','cash_drawers','job_card_items'] loop
    if to_regclass('public.' || t) is not null
       and exists (select 1 from information_schema.columns
                   where table_schema = 'public' and table_name = t and column_name = 'company_id') then
      execute format('drop trigger if exists rt_audit_row_change on public.%I', t);
      execute format('create trigger rt_audit_row_change after delete on public.%I for each row execute function public.rt_audit_row_change()', t);
    else
      raise notice 'rt_audit_row_change: skipped % (table or company_id column not found)', t;
    end if;
  end loop;
end
$attach$;

-- Function privileges: only signed-in staff can call the public ones.
revoke all on function public.rt_override_ready() from public, anon;
revoke all on function public.rt_audit_log(text, text, text, uuid, jsonb, jsonb, jsonb) from public, anon;
revoke all on function public.rt_admin_override_begin(text, integer) from public, anon;
revoke all on function public.rt_admin_override_end(uuid, text) from public, anon;
revoke all on function public.rt_admin_override_action(uuid, text, uuid, text, text) from public, anon;
revoke all on function public.rt_override_require_session(uuid, uuid, uuid) from public, anon, authenticated;
revoke all on function public.rt_audit_row_change() from public, anon, authenticated;
grant execute on function public.rt_override_ready() to authenticated;
grant execute on function public.rt_audit_log(text, text, text, uuid, jsonb, jsonb, jsonb) to authenticated;
grant execute on function public.rt_admin_override_begin(text, integer) to authenticated;
grant execute on function public.rt_admin_override_end(uuid, text) to authenticated;
grant execute on function public.rt_admin_override_action(uuid, text, uuid, text, text) to authenticated;

-- =====================================================================
-- PART 2 — audit_logs is append-only
--   * DELETE / TRUNCATE are always refused.
--   * UPDATE is refused unless ONLY transaction_id changes (that is the re-key
--     rt_post_job_pos_sale_idempotent does during a Job checkout).
--   * The table owner / project owner can still disable the trigger on purpose.
-- =====================================================================
create or replace function public.rt_audit_logs_guard()
returns trigger
language plpgsql
set search_path = public, pg_temp
as $function$
begin
  if tg_op = 'UPDATE'
     and (to_jsonb(new) - 'transaction_id') is not distinct from (to_jsonb(old) - 'transaction_id') then
    return new;
  end if;
  raise exception 'AUDIT_LOG_IMMUTABLE';
end;
$function$;

drop trigger if exists rt_audit_logs_guard on public.audit_logs;
create trigger rt_audit_logs_guard before update or delete on public.audit_logs
  for each row execute function public.rt_audit_logs_guard();
drop trigger if exists rt_audit_logs_guard_truncate on public.audit_logs;
create trigger rt_audit_logs_guard_truncate before truncate on public.audit_logs
  for each statement execute function public.rt_audit_logs_guard();

revoke update, delete, truncate on public.audit_logs from anon, authenticated;

-- =====================================================================
-- PART 3 — no hard DELETE on money, stock, cash and staff records
--   (corrections are done with VOID / reversal entries / the staff RPC).
--   Check PART 0e first: an invoker function that DELETEs from these tables
--   would be refused after this.
-- =====================================================================
do $lock$
declare t text;
begin
  foreach t in array array['invoices','invoice_items','payments','stock_movements','cash_movements','cash_drawers','staff'] loop
    if to_regclass('public.' || t) is not null then
      execute format('revoke delete, truncate on public.%I from anon, authenticated', t);
    end if;
  end loop;
end
$lock$;

commit;

-- =====================================================================
-- PART 4 (OPTIONAL) — no hard DELETE on master data either.
--   The POS never deletes these (it archives). BUT the Customer app or the
--   Accounting app that share this database might. Confirm with PART 0c/0e and
--   those apps first, then un-comment.
-- =====================================================================
-- do $lock2$
-- declare t text;
-- begin
--   foreach t in array array['customers','vehicles','products','suppliers','job_cards','bookings','grn','app_settings'] loop
--     if to_regclass('public.' || t) is not null then
--       execute format('revoke delete, truncate on public.%I from anon, authenticated', t);
--     end if;
--   end loop;
-- end
-- $lock2$;

-- =====================================================================
-- PART 5 (OPTIONAL) — stop forged audit rows.
--   After the app uses rt_audit_log everywhere (this release does), browsers
--   no longer need to INSERT into audit_logs directly. Older APK / cached tabs
--   still do, so only enable this once every device runs the new web build.
-- =====================================================================
-- revoke insert on public.audit_logs from anon, authenticated;

-- =====================================================================
-- PART 6 — ROLLBACK (commented). Keeps all audit rows already written.
-- =====================================================================
-- begin;
-- drop trigger if exists rt_audit_logs_guard on public.audit_logs;
-- drop trigger if exists rt_audit_logs_guard_truncate on public.audit_logs;
-- do $rb$ declare t text; begin
--   foreach t in array array['customers','vehicles','products','suppliers','job_cards','staff','app_settings','invoices','bookings',
--                            'invoice_items','payments','stock_movements','cash_movements','cash_drawers','job_card_items'] loop
--     if to_regclass('public.' || t) is not null then execute format('drop trigger if exists rt_audit_row_change on public.%I', t); end if;
--   end loop; end $rb$;
-- grant update, delete on public.audit_logs to authenticated;   -- only if it had them before (see PART 0d)
-- do $rb2$ declare t text; begin   -- only if these tables had DELETE for authenticated before (see PART 0d)
--   foreach t in array array['invoices','invoice_items','payments','stock_movements','cash_movements','cash_drawers','staff'] loop
--     if to_regclass('public.' || t) is not null then execute format('grant delete on public.%I to authenticated', t); end if;
--   end loop; end $rb2$;
-- drop function if exists public.rt_admin_override_action(uuid, text, uuid, text, text);
-- drop function if exists public.rt_admin_override_end(uuid, text);
-- drop function if exists public.rt_admin_override_begin(text, integer);
-- drop function if exists public.rt_override_require_session(uuid, uuid, uuid);
-- drop function if exists public.rt_audit_log(text, text, text, uuid, jsonb, jsonb, jsonb);
-- drop function if exists public.rt_audit_row_change();
-- drop function if exists public.rt_audit_logs_guard();
-- drop function if exists public.rt_audit_trim(jsonb);
-- drop function if exists public.rt_override_ready();
-- commit;
