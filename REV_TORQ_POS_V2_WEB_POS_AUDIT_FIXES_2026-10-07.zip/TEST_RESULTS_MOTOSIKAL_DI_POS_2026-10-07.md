# Verification — add a motorcycle plate in the POS customer dialog (2026-10-07)

## Automated
- Node test suite: **148 / 149 passed**. 4 new tests in `tests/pos-add-vehicle.test.cjs`: the box exists and is hidden without a customer / in Job mode; the write uses the same
  `db.collection('vehicles').doc(id).set({vehicleId, customerId, plateNo, model, active, createdAt})` as the Pelanggan page plus the `CREATE_VEHICLE` audit record, and no other
  write path (no RPC, insert, update, delete); nothing is written before SIMPAN, plate normalised, same plate not added twice, double tap guarded, refusal keeps the text;
  checkout still sends no vehicle. The one failure is the old "root / APK assets / WAB_DEPLOY identical" check (no Android folder in the web build).

## Browser run with a simulated backend (Chromium; laptop 1366×768, iPad 1024×768, portrait 820×1180, phone 390×844)
- Add motorcycle: **72 / 72** — no box for a walk-in without a customer; box shown under "Tiada motosikal" for a member made from a phone number; inputs 16 px+ and 48 px+ tall,
  box inside the dialog; plate upper-cased while typing; Enter moves plate → model → saves; exactly one `vehicles` row written for that customer (plate "VAB 1234", model,
  active, company set); chip shown and selected, customer bar shows "VAB 1234 · Yamaha NVX"; inputs cleared; toast; same plate again (other spacing / case) writes nothing;
  empty plate writes nothing and asks for it; second bike with no model accepted and selected; a refused write shows the error, keeps the text, button usable, nothing written;
  bar keeps the bike after closing; no request leaves the app; no page errors.
- Regression (same build): cart room / customer dialog 182 / 182, receipt PDF + points 57 / 57, Pesanan serentak 84 / 84, Gantung 31 / 31, POS 54 / 54, WhatsApp 15 / 15,
  Papan Bengkel 25 / 25, Carian pantas 25 / 25, Pesan stok 28 / 28, Booking 28 / 28, full names 63 / 63, tidy-ups 26 / 26, Override + audit 109 / 109, offline / fast 59 / 59,
  customer list, scanner overlay guard, job-checkout heal, job part product id, native bridge.

## Not verified
- Your real database: whether the cashier role may insert into `vehicles` (the same permission the Pelanggan page needs). If it is refused the POS shows the message and nothing is saved.
- The iPad keyboard (Chromium cannot show it): inputs are 16 px+ so iPad should not zoom; please try on the iPad.
- The plate is kept on the customer, not on the sale: the checkout does not send a vehicle (unchanged).
