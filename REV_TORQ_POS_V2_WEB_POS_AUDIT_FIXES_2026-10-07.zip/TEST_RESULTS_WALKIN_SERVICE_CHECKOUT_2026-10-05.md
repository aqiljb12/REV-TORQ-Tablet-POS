# REV TORQ POS — Walk-in Service/Labour Checkout Fix

Date: 2026-10-05

## Root cause
The canonical checkout treated any cart containing a SERVICE line as a Job Card checkout. A normal walk-in cart containing Labour Service therefore entered the Job branch and failed with `JOB_CONTEXT | Job Card tidak dijumpai.`

## Fix
- Job checkout is now selected only when `window.rtActiveJob` exists.
- Normal walk-in checkout can include product + standalone SERVICE/LABOUR lines.
- Standalone labour/service lines are sent to `rt_post_pos_sale` with `item_type`, `unit_price`, quantity, discount and description.
- CAJ LAIN remains blocked for Job Card checkout, but is allowed for ordinary POS checkout.
- Asset/service-worker versions bumped to avoid stale cached checkout code.

## Verification
- Live Supabase `rt_post_pos_sale` accepted a mixed product + LABOUR transaction inside a transaction and it was rolled back.
- `tests/walkin-service-checkout.test.cjs`: 4/4 pass.
- Existing offline-fast: 6/6 pass.
- Existing hide-cancelled: 3/3 pass.
- Existing override-audit: 10/10 pass.
- Existing sticker-full-name: 2/2 pass.
- JavaScript syntax checks pass for changed files.
