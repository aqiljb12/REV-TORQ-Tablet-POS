# Verification — REV TORQ POS V2 WEB UPGRADE (2026-10-02)

## Automated

- Node test suite (84 existing V2 tests + 8 web-upgrade + 4 booking-alert + 2 customer-list tests): **97 / 98 passed**.
  The one failure is the "root / APK assets / WAB_DEPLOY identical" check: expected, the APK copy was deliberately not updated (web only).
  New tests cover: bulk product load (read-only, paging past 1000 rows), no CDN references, every Font Awesome font shipped,
  Tailwind last in `<head>`, park/resume never touches Supabase and is blocked while a sale is processing/pending or for Job Cards,
  voucher/promo amount never parked as a manual discount, WhatsApp number normalisation, scanner popup guard, 1024 px top bar.
  The 8 new tests fail on the 2026-10-02 LABEL build (they test the new behaviour).

## Browser run with a simulated backend (headless Chromium, not shipped)

- 54 / 54 existing POS flows (cash/QR checkout, promo, customer, Job → POS, VOID, reprint, cashier role, drawer, inventory filter),
  0 page errors, **0 requests to any outside host** (everything loads from the app folder).
- Product load: 53 requests → 3 requests; 2.1 s → 0.09 s at 40 ms simulated latency. Loaded data identical to the old loader.
- Compiled Tailwind: every class present in the live screens (799 class names across all views, modals, phone/tablet) exists in `css/tailwind.css`;
  rebuilding with `tailwind.config.cjs` gives a byte-identical file.
- Gantung order: 31 / 31 checks — park, list, swap resume, checkout after resume (one invoice), price change / stock re-check,
  blocked while processing / pending / Job Card, voucher discount not carried, draft restore after refresh, no restore with a pending sale,
  no restore + warning when the app closed during BAYAR, cart head on one line at 1024 px.
- WhatsApp: 15 / 15 checks — member sale opens `wa.me/60…` directly, walk-in number dialog (invalid number rejected, typed number used,
  "Pilih dalam WhatsApp" fallback), reprint uses the customer's number.
- Scanner gun (U4-B): scan behind receipt / confirm / parked list is ignored and cannot press the dialog button (the 2026-10-02 LABEL build
  added the item behind the receipt); scan with no popup still adds. No popup stays "open" after closing it (4 screen sizes × 13 popups).
- Simulated APK bridge (`RevTorqAndroid`): native scan, HID Enter, inventory lookup still work.
- Booking alerts (added later on 2026-10-02): 28 / 28 checks — badge for waiting bookings without a popup on first run, new booking -> card + chime + badge,
  no repeat, LIHAT opens that booking's detail, two at once, mute, confirmed booking leaves the count, the real 30 s check, refresh (no replay,
  new ones still alert), cashier role sends no booking query, logout clears, tablet notification through `sw-notify.js` (no fetch handler),
  scanner gun still adds while the card is shown. All other flows above re-run after this change: same results.
- Customer list fix: customer with 6 motorcycles + a very long name + a name containing HTML, at 390, 800, 1024 and 1280 px:
  0 chips overlapping the buttons (before: 2–4 per screen), 0 buttons cut off (before: up to 10 on phone/portrait), no sideways scroll,
  HTML in a name shown as text (before: it ran). Search still filters. All other flows re-run: same results; Tailwind classes 811/811 present.

## Not verified

- Real Supabase login, RLS/RPC behaviour and real sales/stock data.
- Physical tablet, real U4-B scanner, real WhatsApp app, thermal printer, real browser notification permission prompt / sound on the tablet.
- APK build (not part of this release).

Recommended check on the tablet before use: login → POS opens → scan (gun) → GANTUNG → new sale → SAMBUNG → BAYAR TUNAI →
WHATSAPP (member) → refresh page with items in cart (troli dipulihkan) → reprint from Jualan → WhatsApp.
