# Sticker Full Product Name — Test Results — 2026-10-05

- New regression test created first and confirmed RED before implementation.
- `node --test tests/*.test.cjs`: **21/21 passed**.
- `python tests/test_inventory_mobile_css.py`: **passed**.
- `node --check js/*.js`: **passed for all application JS files**.
- CT221D renderer regression: no ellipsis truncation; full product name preserved; max 3 lines for the tested 50×30 layout.
- Long unbroken model-code regression: split across lines without clipping/truncation.
- No Supabase SQL migration required.
