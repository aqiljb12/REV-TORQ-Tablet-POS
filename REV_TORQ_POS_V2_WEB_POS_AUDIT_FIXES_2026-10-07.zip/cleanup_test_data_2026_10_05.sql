-- REV TORQ POS V2 — CLEAN UP TEST DATA (2026-10-05)
--
-- WHAT IT REMOVES (and nothing else)
--   * VOID invoices created before the cut-off, with their invoice lines, payments and any
--     other rows that point at them through a foreign key.
--   * CANCELLED Job Cards created before the cut-off, with their lines. A cancelled Job Card
--     is kept if it still has an invoice that is not being removed (for example a PAID one).
--   * The booking behind a removed Job Card (switch off below if you want to keep bookings).
--
-- WHAT IT NEVER TOUCHES
--   * PAID invoices, open Job Cards, customers, vehicles, items, staff, settings.
--   * Stock and cash ledgers (stock_movements, cash_movements): a VOID already put the stock
--     back and reversed the cash, so those rows stay true to what physically happened.
--     Their reference to the removed invoice simply points at nothing.
--   * audit_logs. The purge itself is written there (SYSTEM_TEST_DATA_PURGE) with the counts
--     and the invoice / job numbers. If migration_2026_10_05_override_audit.sql is installed,
--     every deleted row also gets its own ROW_DELETE record.
--   If a table whose name contains ledger / movement / audit has a FOREIGN KEY to one of these
--   rows (for example a loyalty ledger), the script stops with BLOCKED and changes nothing.
--   Any OTHER table that points at them by foreign key is cleaned too (the dry run lists them).
--
-- HOW TO RUN (Supabase -> SQL Editor; it runs as the database owner, the POS app cannot do this)
--   0. Take a backup first (Database -> Backups) — this cannot be undone.
--   1. DRY RUN: run this whole file as it is. It deletes inside a transaction, counts what
--      went, then cancels everything with an error that starts "DRY RUN". Nothing is deleted.
--      Read the numbers and the invoice / job lists in that message.
--      Too many? Lower v_before (for example '2026-10-01') and run the dry run again.
--   2. REAL RUN: set v_apply := true and type the two numbers from the dry run into
--      v_expect_invoices and v_expect_jobs. If the real counts differ the script stops.
--      Run again. The last query shows the record that was written.
--   Never run it twice on the same settings expecting the same result: the second run finds nothing.
--
-- NOT TESTED ON YOUR REAL SCHEMA. I only ran it on a stand-in schema in a local Postgres.

-- helper (temporary, disappears when the session ends): delete rows + everything that points at them
create or replace function pg_temp.rt_purge(p_table regclass, p_ids text[], p_depth int default 0)
returns jsonb
language plpgsql
as $f$
declare
  fk record;
  v_n bigint;
  v_child_ids text[];
  v_res jsonb := '{}'::jsonb;
  v_sub jsonb;
  k text;
  v text;
  v_child_name text;
  v_has_id boolean;
begin
  if p_depth > 8 then raise exception 'BLOCKED: foreign keys go more than 8 levels deep from %', p_table; end if;
  if p_ids is null or cardinality(p_ids) = 0 then return v_res; end if;

  for fk in
    select c.conrelid as child_oid, a.attname as col, pa.attname as refcol
    from pg_constraint c
    join pg_attribute a  on a.attrelid  = c.conrelid  and a.attnum  = c.conkey[1]
    join pg_attribute pa on pa.attrelid = c.confrelid and pa.attnum = c.confkey[1]
    where c.contype = 'f' and c.confrelid = p_table and cardinality(c.conkey) = 1
  loop
    continue when fk.refcol <> 'id';
    select relname into v_child_name from pg_class where oid = fk.child_oid;
    execute format('select count(*) from %s where %I::text = any($1)', fk.child_oid::regclass, fk.col) into v_n using p_ids;
    continue when v_n = 0;
    if v_child_name ~* '(ledger|movement|audit)' then
      raise exception 'BLOCKED: % row(s) in % point at these records (column %). That table is a ledger / audit trail and is never purged. Nothing was changed.',
        v_n, v_child_name, fk.col;
    end if;
    select exists (select 1 from pg_attribute where attrelid = fk.child_oid and attname = 'id' and not attisdropped) into v_has_id;
    if v_has_id then
      execute format('select coalesce(array_agg(id::text), ''{}''::text[]) from %s where %I::text = any($1)', fk.child_oid::regclass, fk.col)
        into v_child_ids using p_ids;
      v_sub := pg_temp.rt_purge(fk.child_oid::regclass, v_child_ids, p_depth + 1);
      for k, v in select * from jsonb_each_text(v_sub) loop
        v_res := jsonb_set(v_res, array[k], to_jsonb(coalesce((v_res->>k)::bigint, 0) + v::bigint));
      end loop;
    else
      execute format('delete from %s where %I::text = any($1)', fk.child_oid::regclass, fk.col) using p_ids;
      get diagnostics v_n = row_count;
      v_res := jsonb_set(v_res, array[v_child_name], to_jsonb(coalesce((v_res->>v_child_name)::bigint, 0) + v_n));
    end if;
  end loop;

  execute format('delete from %s where id::text = any($1)', p_table) using p_ids;
  get diagnostics v_n = row_count;
  select relname into v_child_name from pg_class where oid = p_table::oid;
  v_res := jsonb_set(v_res, array[v_child_name], to_jsonb(coalesce((v_res->>v_child_name)::bigint, 0) + v_n));
  return v_res;
end;
$f$;

do $purge$
declare
  -- ============================ SETTINGS (change only these) ============================
  v_apply            boolean     := false;        -- false = DRY RUN (nothing is deleted). true = delete for real.
  v_before           timestamptz := now();        -- only rows created BEFORE this moment (e.g. '2026-10-01')
  v_do_void          boolean     := true;         -- VOID invoices
  v_do_jobs          boolean     := true;         -- CANCELLED Job Cards
  v_do_bookings      boolean     := true;         -- the booking behind a removed Job Card
  v_expect_invoices  int         := null;         -- REAL RUN only: number from the dry run
  v_expect_jobs      int         := null;         -- REAL RUN only: number from the dry run
  -- ======================================================================================
  v_inv text[] := '{}';  v_job text[] := '{}';  v_bk text[] := '{}';
  v_res jsonb := '{}'::jsonb;  v_part jsonb;
  v_inv_nos text;  v_job_nos text;  v_bk_nos text;
  v_companies uuid[] := '{}';  c uuid;
  k text;  v text;  v_lines text := '';  v_msg text;  v_audit_note text := '';
begin
  if v_do_void then
    select coalesce(array_agg(i.id::text), '{}') into v_inv
    from public.invoices i
    where upper(coalesce(i.status, '')) = 'VOID' and i.created_at < v_before;
  end if;

  if v_do_jobs then
    -- a cancelled job is only removed when every invoice on it is also being removed
    select coalesce(array_agg(j.id::text), '{}') into v_job
    from public.job_cards j
    where upper(coalesce(j.status, '')) = 'CANCELLED' and j.created_at < v_before
      and not exists (select 1 from public.invoices i
                      where i.job_card_id = j.id and not (i.id::text = any(v_inv)));
  end if;

  if v_do_bookings and cardinality(v_job) > 0 then
    select coalesce(array_agg(b.id::text), '{}') into v_bk
    from public.bookings b
    where b.id in (select j.booking_id from public.job_cards j where j.id::text = any(v_job) and j.booking_id is not null)
      and not exists (select 1 from public.job_cards j2 where j2.booking_id = b.id and not (j2.id::text = any(v_job)));
  end if;

  -- what will be written to the audit record (read BEFORE deleting)
  select string_agg(x.invoice_no, ', ' order by x.created_at) into v_inv_nos
    from (select invoice_no, created_at from public.invoices where id::text = any(v_inv) order by created_at limit 40) x;
  select string_agg(x.job_no, ', ' order by x.created_at) into v_job_nos
    from (select job_no, created_at from public.job_cards where id::text = any(v_job) order by created_at limit 40) x;
  select string_agg(x.booking_no, ', ' order by x.created_at) into v_bk_nos
    from (select booking_no, created_at from public.bookings where id::text = any(v_bk) order by created_at limit 40) x;
  select coalesce(array_agg(distinct x.company_id), '{}') into v_companies
    from (select company_id from public.invoices where id::text = any(v_inv)
          union select company_id from public.job_cards where id::text = any(v_job)) x
    where x.company_id is not null;

  if v_apply and (v_expect_invoices is distinct from cardinality(v_inv) or v_expect_jobs is distinct from cardinality(v_job)) then
    raise exception 'STOPPED: the counts differ from what you typed. Found % VOID invoice(s) and % cancelled Job Card(s), you expected % and %. Nothing was deleted. Run the dry run again.',
      cardinality(v_inv), cardinality(v_job), v_expect_invoices, v_expect_jobs;
  end if;

  -- delete: invoices first, then the Job Cards, then their bookings
  v_part := pg_temp.rt_purge('public.invoices'::regclass, v_inv);
  for k, v in select * from jsonb_each_text(v_part) loop v_res := jsonb_set(v_res, array[k], to_jsonb(coalesce((v_res->>k)::bigint, 0) + v::bigint)); end loop;
  v_part := pg_temp.rt_purge('public.job_cards'::regclass, v_job);
  for k, v in select * from jsonb_each_text(v_part) loop v_res := jsonb_set(v_res, array[k], to_jsonb(coalesce((v_res->>k)::bigint, 0) + v::bigint)); end loop;
  v_part := pg_temp.rt_purge('public.bookings'::regclass, v_bk);
  for k, v in select * from jsonb_each_text(v_part) loop v_res := jsonb_set(v_res, array[k], to_jsonb(coalesce((v_res->>k)::bigint, 0) + v::bigint)); end loop;

  for k, v in select * from jsonb_each_text(v_res) order by 1 loop
    v_lines := v_lines || format(E'  %s: %s\n', rpad(k, 22), v);
  end loop;

  if v_apply then
    foreach c in array v_companies loop
      begin
        insert into public.audit_logs(company_id, action, entity_type, metadata)
        values (c, 'SYSTEM_TEST_DATA_PURGE', 'purge',
                jsonb_build_object('source', 'sql_editor', 'cutoff', v_before, 'deleted', v_res,
                                   'invoice_nos', v_inv_nos, 'job_nos', v_job_nos, 'booking_nos', v_bk_nos));
      exception when others then
        v_audit_note := v_audit_note || format(E'\n(!) Could not write the summary record for company %: %', c, sqlerrm);
      end;
    end loop;
    raise notice E'DONE. Deleted:\n%\nInvoices: %\nJob Cards: %\nBookings: %\n%', v_lines, coalesce(v_inv_nos, '-'), coalesce(v_job_nos, '-'), coalesce(v_bk_nos, '-'), v_audit_note;
  else
    v_msg := format(E'DRY RUN — NOTHING WAS DELETED (this error is how the script cancels itself).\n'
      || E'Cut-off: created before %s\n'
      || E'Would delete:\n%s\n'
      || E'VOID invoices: %s  |  cancelled Job Cards: %s  |  bookings: %s\n'
      || E'Invoices (first 40): %s\nJob Cards (first 40): %s\nBookings (first 40): %s\n\n'
      || E'To run for real: v_apply := true, v_expect_invoices := %s, v_expect_jobs := %s',
      v_before, coalesce(nullif(v_lines, ''), E'  (nothing matches)\n'),
      cardinality(v_inv), cardinality(v_job), cardinality(v_bk),
      coalesce(v_inv_nos, '-'), coalesce(v_job_nos, '-'), coalesce(v_bk_nos, '-'),
      cardinality(v_inv), cardinality(v_job));
    raise exception '%', v_msg;
  end if;
end
$purge$;

-- real run only: shows the record that was just written (empty on a dry run)
select created_at, action, metadata->'deleted' as deleted, metadata->>'invoice_nos' as invoice_nos, metadata->>'job_nos' as job_nos
from public.audit_logs where action = 'SYSTEM_TEST_DATA_PURGE' order by created_at desc limit 3;
