# Verification — bigger cart, customer & points, receipt PDF (2026-10-08)

## Automated
- Node test suite: **144 / 145 passed**. 11 new tests in `tests/pos-cart-customer-pdf.test.cjs`: the PDF is a valid PDF (header, xref offsets,
  trailer, 80 mm page), it holds the sale / customer / total / points, no points block for walk-in and reprint, 42-column limit, brackets
  escaped, only Latin-1 bytes, very long receipts split over pages, the module never touches the network except one read-only member summary and
  uses no syntax newer than ES2017, button + script order (`rt-polish.js` still last), pos.js data hand-over, wide-cart / short-screen / dialog CSS.
  Two older tests pinned exact `?v=` strings of files that changed in this release; they now only require a version.
  The one failure is the old "root / APK assets / WAB_DEPLOY identical" check (no Android folder in the web build).
- PDF checked with poppler (`pdfinfo`, `pdftotext`, `pdftoppm`): opens, 1 page, text selectable, layout as designed; a 130-item receipt is one valid page.

## Browser run with a simulated backend (Chromium; laptop 1366×768 / 1536×864 / 1280×800, iPad 1024×768 / 1080×810 / 1180×820 / 1366×1024 / portrait, phone)
- Cart room / customer dialog / points: **182 / 182** — BAYAR fully on screen; cart head one row (buttons inside it); item list 227 px at 1366×768
  (it was 114 px: under two lines) and 3 lines visible at once on laptops; a cart line is ≤ 72 px on wide screens; customer name not cut and "128 POINT"
  pill visible; Subtotal line hidden while it only repeats JUMLAH, back when there is a discount; item discount box still changes the total;
  customer dialog inside the screen, 16 px+ inputs 48 px+ tall, points ≥ 15 px, Enter in the phone box = CARI / DAFTAR, tap on the dimmed area closes it and adds nothing
  to the cart, Escape closes it; voucher box 16 px / 44 px+; with a held order the strip shows and the list keeps 150 px+; no sideways scroll; no page errors.
  The same checks run on the previous build FAIL (list 114 px, 3-line bar, 10 px points, …), so they do test the change.
- Receipt PDF / points: **57 / 57** (laptop, iPad, phone) — PDF button visible; receipt data has items, customer, phone; "221 POINT +93 baru" on the receipt;
  points line in the WhatsApp text (before the thank-you line); WHATSAPP still opens wa.me/<customer number>; PDF handed to the share sheet as `Resit-….pdf`
  (application/pdf) with the customer's name / number in the share text; the file is a real PDF holding INV no., JUMLAH and points; no share support → PDF downloaded
  and the customer's chat opens; closing the share sheet does nothing; walk-in has no points anywhere and WHATSAPP still asks for a number; reprint has no points block
  and its PDF works; no page errors.
- Regression (same build): Pesanan serentak 84 / 84, Gantung 31 / 31, POS 54 / 54 (0 outside requests), WhatsApp 15 / 15, Papan Bengkel 25 / 25,
  Carian pantas 25 / 25, Pesan stok 28 / 28, Booking 28 / 28, full product names 63 / 63, tidy-ups 26 / 26, Override + audit 109 / 109, offline / fast 59 / 59,
  customer list, scanner overlay guard, job-checkout heal, job part product id, native bridge.
- One real bug found by the regression and fixed before release: with an order on hold the cart head wrapped to two rows (the "orders on hold" badge did not fit) and the
  strip covered the lower half of its buttons. The badge now sits at the end of the strip; the head stays one row at every size.

## Not verified
- A real iPad keyboard: input boxes are 16 px+ (no zoom) and the dialog is anchored at the top of the screen so the keyboard should not cover it, but Chromium cannot show the iOS keyboard. Please try on the iPad.
- The WhatsApp share sheet on iOS / Windows: tested with a stand-in `navigator.share`. On iOS WhatsApp receives the file but the customer's number cannot be pre-selected (iOS limit); the text WHATSAPP button still goes straight to the number.
- Points "+N" on your real database: it is the member balance after the sale minus the balance shown before paying, read with the existing read-only summary. The simulated backend returns a fixed balance, so I changed it in the test to 128 → 221 to check the display; your real trigger was not run.
- Your real product names / shop address on the PDF (the test shop has no address, so the address block is skipped).
