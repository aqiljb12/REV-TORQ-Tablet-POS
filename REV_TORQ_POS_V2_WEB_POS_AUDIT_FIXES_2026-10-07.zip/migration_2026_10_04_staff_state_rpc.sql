create or replace function public.rt_admin_set_staff_state(
  p_staff_id uuid,
  p_action text
)
returns jsonb
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  v_admin record;
  v_target public.staff%rowtype;
  v_action text := upper(trim(coalesce(p_action,'')));
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;

  select * into v_admin from public.rt_staff_context() limit 1;
  if v_admin.staff_id is null then raise exception 'STAFF_ONLY'; end if;
  if lower(coalesce(v_admin.role,'')) not in ('owner','admin','super_admin') then
    raise exception 'ADMIN_ONLY';
  end if;

  select * into v_target
  from public.staff
  where id=p_staff_id and company_id=v_admin.company_id
  for update;
  if v_target.id is null then raise exception 'STAFF_NOT_FOUND'; end if;

  if v_action='DEACTIVATE' then
    update public.staff
    set active=false,
        removed_from_active_list=false,
        blocked_at=now(),
        blocked_by=v_admin.staff_id,
        left_at=current_date,
        updated_at=now()
    where id=v_target.id;
  elsif v_action='REACTIVATE' then
    update public.staff
    set active=true,
        removed_from_active_list=false,
        blocked_at=null,
        blocked_by=null,
        left_at=null,
        updated_at=now()
    where id=v_target.id;
  elsif v_action='REMOVE' then
    update public.staff
    set active=false,
        removed_from_active_list=true,
        blocked_at=coalesce(blocked_at,now()),
        blocked_by=coalesce(blocked_by,v_admin.staff_id),
        left_at=coalesce(left_at,current_date),
        updated_at=now()
    where id=v_target.id;
  else
    raise exception 'INVALID_ACTION';
  end if;

  select * into v_target from public.staff where id=v_target.id;

  insert into public.audit_logs(
    company_id,location_id,staff_id,action,entity_type,entity_id,before_data,after_data,metadata
  ) values(
    v_admin.company_id,
    coalesce(v_admin.location_id,v_target.location_id),
    v_admin.staff_id,
    'ADMIN_STAFF_'||v_action,
    'STAFF',
    v_target.id,
    null,
    to_jsonb(v_target),
    jsonb_build_object('staff_code',v_target.staff_code,'action',v_action)
  );

  return jsonb_build_object(
    'id',v_target.id,
    'staff_code',v_target.staff_code,
    'active',v_target.active,
    'removed_from_active_list',v_target.removed_from_active_list,
    'blocked_at',v_target.blocked_at,
    'left_at',v_target.left_at
  );
end;
$function$;

revoke all on function public.rt_admin_set_staff_state(uuid,text) from public;
revoke all on function public.rt_admin_set_staff_state(uuid,text) from anon;
grant execute on function public.rt_admin_set_staff_state(uuid,text) to authenticated;
