/* REV TORQ POS V2 — Barang Luar / standby stock from POS */
(function(){
'use strict';
const $=id=>document.getElementById(id);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const core=()=>window.RTExternalPurchaseCore;
let selected=null,searchTimer=null;

function toast(msg,type='info'){try{window.showToast?.(msg,type);}catch(_){} }
function activeJob(){return window.rtActiveJob||null;}
function money(v){return 'RM '+Number(v||0).toFixed(2);}

function ensureButton(){
  const pick=$('rtPickJobBtn'); if(!pick||$('rtExternalPurchaseBtn'))return;
  const b=document.createElement('button');
  b.type='button'; b.id='rtExternalPurchaseBtn'; b.textContent='+ BELI LUAR';
  b.title='Beli barang luar / masuk stok / guna pada Job Card';
  b.addEventListener('click',()=>window.rtOpenExternalPurchase?.());
  pick.insertAdjacentElement('afterend',b);
}

function ensureModal(){
  let m=$('rtExternalPurchaseModal'); if(m)return m;
  m=document.createElement('div');m.id='rtExternalPurchaseModal';m.className='rt-ext-modal';
  m.innerHTML=`<div class="rt-ext-card" role="dialog" aria-modal="true" aria-labelledby="rtExtTitle">
    <div class="rt-ext-head"><div><h3 id="rtExtTitle">Beli Barang Luar</h3><p id="rtExtSubtitle">Restock segera atau guna terus pada pelanggan.</p></div><button type="button" class="rt-ext-x" id="rtExtClose">✕</button></div>
    <div class="rt-ext-body">
      <div class="rt-ext-mode"><button type="button" id="rtExtModeNew" class="active">ITEM BARU</button><button type="button" id="rtExtModeExisting">ITEM INVENTORI</button></div>
      <div id="rtExtExistingBox" class="rt-ext-field" hidden><label>Cari item inventory</label><input id="rtExtSearch" autocomplete="off" placeholder="Nama / SKU / barcode"><div id="rtExtSearchResults" class="rt-ext-search-results"></div><div id="rtExtSelected" class="rt-ext-selected" hidden></div></div>
      <div class="rt-ext-grid"><div class="rt-ext-field"><label>Nama barang</label><input id="rtExtName" autocomplete="off" placeholder="Contoh: Brake Pad ADV160"></div><div class="rt-ext-field"><label>SKU (optional)</label><input id="rtExtSku" autocomplete="off" placeholder="Kosong = auto LUAR-..."></div></div>
      <div class="rt-ext-grid"><div class="rt-ext-field"><label>Kategori</label><input id="rtExtCategory" value="BARANG LUAR" autocomplete="off"></div><div class="rt-ext-field"><label>Kedai / sumber beli (optional)</label><input id="rtExtSource" autocomplete="off" placeholder="Contoh: Kedai ABC / Shopee"></div></div>
      <div class="rt-ext-grid three"><div class="rt-ext-field"><label>Qty beli</label><input id="rtExtQtyBuy" type="number" min="1" step="1" value="1" inputmode="numeric"></div><div class="rt-ext-field"><label id="rtExtUseLabel">Tambah troli sekarang</label><input id="rtExtQtyUse" type="number" min="0" step="1" value="0" inputmode="numeric"></div><div class="rt-ext-field"><label>Baki standby</label><input id="rtExtQtyRemain" type="number" value="1" readonly></div></div>
      <div class="rt-ext-grid"><div class="rt-ext-field"><label>Harga beli / unit</label><input id="rtExtCost" type="number" min="0" step="0.01" value="0" inputmode="decimal"></div><div class="rt-ext-field"><label>Harga jual customer / unit</label><input id="rtExtSell" type="number" min="0" step="0.01" value="0" inputmode="decimal"></div></div>
      <div id="rtExtSummary" class="rt-ext-summary"></div><div id="rtExtStatus" class="rt-ext-status"></div>
      <div class="rt-ext-actions"><button type="button" class="rt-ext-cancel" id="rtExtCancel">BATAL</button><button type="button" class="rt-ext-save" id="rtExtSave">SIMPAN BELIAN</button></div>
    </div></div>`;
  document.body.appendChild(m);
  $('rtExtClose').onclick=close;$('rtExtCancel').onclick=close;$('rtExtSave').onclick=save;
  $('rtExtModeNew').onclick=()=>setMode('new');$('rtExtModeExisting').onclick=()=>setMode('existing');
  $('rtExtSearch').addEventListener('input',e=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>searchProducts(e.target.value),180);});
  ['rtExtQtyBuy','rtExtQtyUse','rtExtCost','rtExtSell'].forEach(id=>$(id).addEventListener('input',syncSummary));
  m.addEventListener('click',e=>{if(e.target===m)close();});
  return m;
}

function setStatus(text='',kind=''){
  const s=$('rtExtStatus');if(!s)return;s.textContent=text;s.className='rt-ext-status'+(kind?' '+kind:'');
}
function setMode(mode){
  selected=null;
  const existing=mode==='existing';
  $('rtExtModeNew').classList.toggle('active',!existing);$('rtExtModeExisting').classList.toggle('active',existing);
  $('rtExtExistingBox').hidden=!existing;$('rtExtSelected').hidden=true;$('rtExtSearchResults').innerHTML='';
  $('rtExtName').readOnly=existing;$('rtExtSku').readOnly=existing;
  if(existing){$('rtExtName').value='';$('rtExtSku').value='';$('rtExtCost').value='0';$('rtExtSell').value='0';setTimeout(()=>$('rtExtSearch').focus(),20)}
  else setTimeout(()=>$('rtExtName').focus(),20);
  syncSummary();
}
function fillSelected(p){
  selected=p;
  $('rtExtName').value=p.name||'';$('rtExtSku').value=p.sku||'';$('rtExtCategory').value=p.category||'BARANG LUAR';
  $('rtExtCost').value=Number(p.cost_price??p.cost??0).toFixed(2);$('rtExtSell').value=Number(p.sell_price??p.price??0).toFixed(2);
  const box=$('rtExtSelected');box.hidden=false;box.innerHTML=`<button type="button" id="rtExtUnselect">Tukar</button>${esc(p.name||p.sku)}<br><small>${esc(p.sku||'')} · stok ${Number(p.stock||0)}</small>`;
  $('rtExtUnselect').onclick=()=>{selected=null;box.hidden=true;$('rtExtSearch').value='';$('rtExtName').value='';$('rtExtSku').value='';};
  $('rtExtSearchResults').innerHTML='';syncSummary();
}
async function ctx(){
  if(typeof window.rtContext==='function')return await window.rtContext();
  const p=window.currentProfile||{};return {companyId:p.companyId||p.company_id||null,locationId:p.locationId||p.location_id||null};
}
async function searchProducts(term){
  const out=$('rtExtSearchResults'); if(!out)return;
  const q=String(term||'').trim().toLowerCase();if(q.length<2){out.innerHTML='';return;}
  let items=[];
  const local=[...(window.posProducts||[]),...(window.rtInventoryCache||[])];
  const seen=new Set();
  for(const p of local){
    const key=String(p.id||p.sku||'');if(!key||seen.has(key))continue;
    if([p.name,p.sku,p.barcode].some(v=>String(v||'').toLowerCase().includes(q))){seen.add(key);items.push(p);}
    if(items.length>=12)break;
  }
  if(items.length<6&&window.sb){
    try{
      const c=await ctx();
      const exact=await window.sb.from('products').select('id,sku,name,category,barcode,cost_price,sell_price,active').eq('company_id',c.companyId).eq('active',true).eq('sku',q.toUpperCase()).limit(1);
      const named=await window.sb.from('products').select('id,sku,name,category,barcode,cost_price,sell_price,active').eq('company_id',c.companyId).eq('active',true).ilike('name','%'+q.replace(/[%_]/g,'')+'%').limit(10);
      for(const p of [...(exact.data||[]),...(named.data||[])])if(!seen.has(p.id)){seen.add(p.id);items.push(p)}
      if(items.length){const ids=items.map(x=>x.id).filter(Boolean);if(ids.length&&c.locationId){const b=await window.sb.from('stock_balances').select('product_id,quantity').eq('location_id',c.locationId).in('product_id',ids);const map={};(b.data||[]).forEach(x=>map[x.product_id]=Number(x.quantity||0));items=items.map(x=>({...x,stock:Number(x.stock??map[x.id]??0)}));}}
    }catch(e){console.warn('external purchase search',e);}
  }
  out.innerHTML=items.slice(0,12).map((p,i)=>`<button type="button" class="rt-ext-result" data-idx="${i}"><b>${esc(p.name||p.sku)}</b><small>${esc(p.sku||'')} · stok ${Number(p.stock||0)} · ${money(p.sell_price??p.price)}</small></button>`).join('')||'<div style="padding:12px;font-size:12px;color:#94a3b8">Item tak jumpa. Guna ITEM BARU.</div>';
  out.querySelectorAll('[data-idx]').forEach(b=>b.onclick=()=>fillSelected(items[Number(b.dataset.idx)]));
}
function syncSummary(){
  const buy=Math.max(0,Math.floor(Number($('rtExtQtyBuy')?.value||0))),use=Math.max(0,Math.floor(Number($('rtExtQtyUse')?.value||0)));
  const rem=Math.max(0,buy-use);if($('rtExtQtyRemain'))$('rtExtQtyRemain').value=String(rem);
  const job=activeJob();if($('rtExtUseLabel'))$('rtExtUseLabel').textContent=job?'Guna pada job sekarang':'Tambah troli sekarang';
  const cost=Math.max(0,Number($('rtExtCost')?.value||0));
  const box=$('rtExtSummary');if(box)box.innerHTML=`Beli <strong>${buy||0}</strong> unit (${money(buy*cost)}). ${use>0?`<strong>${Math.min(use,buy)}</strong> masuk ${job?'Job Card':'troli'}, `:''}<strong>${rem}</strong> unit kekal standby dalam stok.`;
}
function reset(){
  selected=null;setMode('new');
  $('rtExtName').value='';$('rtExtSku').value='';$('rtExtCategory').value='BARANG LUAR';$('rtExtSource').value='';$('rtExtQtyBuy').value='1';$('rtExtQtyUse').value=activeJob()?'1':'0';$('rtExtCost').value='0';$('rtExtSell').value='0';$('rtExtSearch').value='';$('rtExtSearchResults').innerHTML='';$('rtExtSelected').hidden=true;setStatus('');syncSummary();
}
function open(){
  const m=ensureModal();reset();m.classList.add('is-open');document.body.style.overflow='hidden';
}
function close(){const m=$('rtExternalPurchaseModal');if(m)m.classList.remove('is-open');document.body.style.overflow='';}

async function save(){
  const btn=$('rtExtSave');if(!btn)return;
  try{
    if(!core())throw new Error('Modul Barang Luar belum sedia.');
    const draft=core().normalizeDraft({
      productId:selected?.id||null,name:$('rtExtName').value,sku:$('rtExtSku').value,category:$('rtExtCategory').value,
      qtyBuy:$('rtExtQtyBuy').value,qtyUse:$('rtExtQtyUse').value,cost:$('rtExtCost').value,sell:$('rtExtSell').value,sourceName:$('rtExtSource').value
    });
    btn.disabled=true;btn.textContent='MENYIMPAN...';setStatus('Rekod belian + stok sedang disimpan...');
    const c=await ctx();
    const args={
      p_product_id:draft.productId,p_name:draft.productId?null:draft.name,p_sku:draft.productId?null:(draft.sku||null),
      p_category:draft.category,p_cost_price:draft.cost,p_sell_price:draft.sell,p_qty_buy:draft.qtyBuy,
      p_source_name:draft.sourceName||null,p_location_id:activeJob()?.locationId||c.locationId||null,p_job_card_id:activeJob()?.jobCardId||null
    };
    const raw=await window.supabaseRpc('rt_pos_external_purchase',args);
    const product=Array.isArray(raw)?raw[0]:raw;
    if(!product?.id)throw new Error('Produk tidak dipulangkan oleh server.');
    if(draft.qtyUse>0){
      const next=core().mergeCart(window.rtGetPosCart?.()||[],product,draft.qtyUse,draft.sourceName);
      window.rtSetPosCart?.(next);
    }
    setStatus(`Stok masuk ${draft.qtyBuy} unit${draft.qtyUse?` · ${draft.qtyUse} masuk ${activeJob()?'Job Card':'troli'}`:''}.`,'ok');
    toast(draft.qtyUse>0?`Barang luar disimpan · ${draft.qtyUse} masuk ${activeJob()?'Job Card':'troli'} · baki ${draft.stockRemainder} stok.`:`Barang luar disimpan · ${draft.qtyBuy} unit masuk stok.`,'success');
    try{await window.loadPOS?.();}catch(_){} try{await window.loadInventory?.({silent:true});}catch(_){}
    setTimeout(close,450);
  }catch(e){console.error('rt external purchase',e);setStatus(e?.message||String(e),'error');toast(e?.message||String(e),'error');}
  finally{btn.disabled=false;btn.textContent='SIMPAN BELIAN';}
}

window.rtOpenExternalPurchase=open;
window.rtCloseExternalPurchase=close;
function boot(){ensureButton();ensureModal();syncSummary();}
window.addEventListener('load',()=>setTimeout(boot,700));
setInterval(ensureButton,1600);
})();
