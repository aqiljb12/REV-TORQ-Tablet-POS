/* REV TORQ POS V2 — counter safety + speed fixes found in the POS audit (2026-10-07).
   Everything here runs in the browser in front of the existing checkout; the sale itself is still posted only by the
   canonical checkout (js/v36-4-9-pos-cash-canonical.js) through the existing RPCs. This file only:
     1. checks the cart against the live price / stock list right before BAYAR (read-only) and says what changed;
     2. asks the cashier to confirm TRANSFER / KAD was really received (like QR), with an optional reference;
     3. asks "betul?" for a big manual discount;
     4. keeps the product search forgiving (words in any order, paste / dictation, Enter on a name);
     5. tidies typed numbers (1,000 / Caj Lain with 3 decimals);
     6. after a sale updates stock on screen at once and only re-reads the changed products.
   Plain ES2017 (older iPad Safari). Loaded after payment-qr.js and before js/rt-polish.js. */
(function(w){
  'use strict';
  var d=w.document;
  var $=function(id){return d.getElementById(id);};
  function num(v){var n=Number(v);return isFinite(n)?n:0;}
  function r2(v){return Math.round((num(v)+Number.EPSILON)*100)/100;}
  function money(v){return 'RM '+num(v).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});}
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
  function toast(m,t){try{if(w.showToast)w.showToast(m,t||'info');}catch(_){}}
  function cart(){try{return (w.rtGetPosCart&&w.rtGetPosCart())||[];}catch(_){return [];}}
  function method(){return String(w.posPayMethod||'CASH').toUpperCase();}
  function isService(i){return !!(i&&(i.service||String(i.itemType||'').toUpperCase()==='SERVICE'||/^(SERVICE|JOBSERVICE|JOBLABOUR)-/.test(String(i.sku||''))));}

  // ------------------------------------------------------------------ small dialog (same look as rtConfirm, with a list)
  function listDialog(title,intro,rows,okText,cancelText){
    return new Promise(function(resolve){
      var old=$('rtPosFixDialog');if(old)old.remove();
      var m=d.createElement('div');
      m.id='rtPosFixDialog';m.className='rt-confirm-backdrop';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');
      m.innerHTML='<div class="rt-confirm-box"><h3>'+esc(title)+'</h3>'+(intro?'<p>'+esc(intro)+'</p>':'')+
        '<ul class="rt-fix-list">'+rows.map(function(r){return '<li>'+r+'</li>';}).join('')+'</ul>'+
        '<div class="rt-confirm-actions"><button type="button" class="rt-btn rt-btn-secondary" data-act="no">'+esc(cancelText||'BATAL')+'</button>'+
        (okText?'<button type="button" class="rt-btn rt-btn-primary" data-act="yes">'+esc(okText)+'</button>':'')+'</div></div>';
      d.body.appendChild(m);
      var done=function(v){d.removeEventListener('keydown',onKey,true);m.remove();resolve(v);};
      var onKey=function(e){if(e.key==='Escape'){e.preventDefault();done(false);}};
      d.addEventListener('keydown',onKey,true);
      m.addEventListener('click',function(e){
        var b=e.target.closest?e.target.closest('[data-act]'):null;
        if(b)done(b.getAttribute('data-act')==='yes');else if(e.target===m)done(false);
      });
    });
  }

  // ------------------------------------------------------------------ 1. live price / stock check before BAYAR
  var locCache={company:'',id:''};
  function companyId(){return (w.currentProfile&&w.currentProfile.companyId)||'';}
  async function locationId(sb,company){
    if(locCache.company===company&&locCache.id)return locCache.id;
    var r=await sb.from('locations').select('id').eq('active',true).eq('company_id',company).order('code').limit(1).maybeSingle();
    if(r.error)throw r.error;
    locCache={company:company,id:r.data?r.data.id:''};
    return locCache.id;
  }
  // Returns [] when the cart still matches the live list, else the lines that differ.
  async function liveDiff(){
    var c=cart(),sb=w.supabaseClient,company=companyId();
    if(!c.length||!sb||!company)return [];
    var lines=c.filter(function(i){return !isService(i);});
    if(!lines.length)return [];
    var ids=[],skus=[];
    lines.forEach(function(i){var id=i.productId||i.product_id;if(id)ids.push(String(id));else if(i.sku)skus.push(String(i.sku).toUpperCase());});
    var rows=[];
    var jobs=[];
    if(ids.length)jobs.push(sb.from('products').select('id,sku,name,sell_price,active').eq('company_id',company).in('id',ids));
    if(skus.length)jobs.push(sb.from('products').select('id,sku,name,sell_price,active').eq('company_id',company).in('sku',skus));
    var res=await Promise.all(jobs);
    res.forEach(function(r){if(r.error)throw r.error;(r.data||[]).forEach(function(p){rows.push(p);});});
    var byId={},bySku={};
    rows.forEach(function(p){byId[String(p.id)]=p;bySku[String(p.sku||'').toUpperCase()]=p;});
    var loc=await locationId(sb,company);
    var stock={};
    if(loc&&rows.length){
      var sr=await sb.from('stock_balances').select('product_id,quantity').eq('location_id',loc).in('product_id',rows.map(function(p){return p.id;}));
      if(sr.error)throw sr.error;
      (sr.data||[]).forEach(function(b){stock[String(b.product_id)]=num(b.quantity);});
    }
    var out=[];
    lines.forEach(function(i){
      var p=(i.productId||i.product_id)?byId[String(i.productId||i.product_id)]:bySku[String(i.sku||'').toUpperCase()];
      var name=i.name||i.sku;
      if(!p||p.active===false){out.push({sku:i.sku,name:name,kind:'gone'});return;}
      var price=r2(p.sell_price),have=num(stock[String(p.id)]);
      if(Math.abs(price-r2(i.price))>0.004)out.push({sku:i.sku,name:name,kind:'price',from:r2(i.price),to:price});
      if(loc&&num(i.qty)>have)out.push({sku:i.sku,name:name,kind:'stock',have:have,want:num(i.qty)});
    });
    return out;
  }
  function applyDiff(diff){
    var c=cart().slice();
    diff.forEach(function(x){
      var idx=c.findIndex(function(i){return String(i.sku)===String(x.sku);});
      if(idx<0)return;
      if(x.kind==='gone'){c.splice(idx,1);return;}
      if(x.kind==='price'){c[idx].price=x.to;
        if(w.RTPosDiscountModel)c[idx].discount=w.RTPosDiscountModel.normalizeLineDiscount(c[idx].discount,c[idx].qty,c[idx].price);}
      if(x.kind==='stock'){
        if(x.have<=0)c.splice(idx,1);else{c[idx].qty=x.have;c[idx].maxStock=x.have;
          if(w.RTPosDiscountModel)c[idx].discount=w.RTPosDiscountModel.normalizeLineDiscount(c[idx].discount,c[idx].qty,c[idx].price);}
      }
    });
    if(typeof w.rtSetPosCart==='function')w.rtSetPosCart(c);
  }
  function describe(x){
    var n='<b>'+esc(x.name)+'</b>';
    if(x.kind==='price')return n+': harga RM '+x.from.toFixed(2)+' &rarr; <b>RM '+x.to.toFixed(2)+'</b>';
    if(x.kind==='stock')return n+': stok tinggal <b>'+x.have+'</b> (dalam troli '+x.want+')';
    return n+': sudah tidak aktif / dibuang';
  }
  async function livePreflight(){
    var pending=null;try{pending=sessionStorage.getItem('rt_pos_pending_sale_v1');}catch(_){}
    if(pending||w.rtActiveJob)return true;                  // a sale being re-confirmed, or a Job Card: never touch
    var diff;
    try{diff=await liveDiff();}
    catch(e){console.warn('POS live check skipped',e);return true;}   // a failed read never blocks a sale: the server is still the judge
    if(!diff.length)return true;
    var ok=await listDialog('Harga / stok berubah','Troli tidak sama dengan senarai terkini. Semak dengan pelanggan sebelum bayar.',diff.map(describe),'KEMAS KINI TROLI','BATAL');
    if(ok){
      applyDiff(diff);
      toast('Troli dikemas kini. Semak jumlah, kemudian tekan BAYAR.','success');
    }
    try{if(typeof w.loadPOS==='function')w.loadPOS();}catch(_){}
    return false;
  }
  w.rtPosLiveDiff=liveDiff;

  // ------------------------------------------------------------------ 2. TRANSFER / KAD confirmation + reference
  var confirmedTotal=null;
  function needsConfirm(){var m=method();return m==='TRANSFER'||m==='CARD';}
  function totalNow(){
    if(typeof w.rtPosCheckoutTotal==='function')return r2(w.rtPosCheckoutTotal());
    return r2(String(($('posTotal')||{}).textContent||'').replace(/[^0-9.\-]/g,''));
  }
  function payConfirmed(){
    var cb=$('rtPayConfirm');
    return !needsConfirm()||(!!cb&&cb.checked&&confirmedTotal!==null&&Math.abs(confirmedTotal-totalNow())<0.005);
  }
  w.rtPayConfirmPending=function(){return needsConfirm()&&!payConfirmed();};
  w.rtPayRef=function(){var e=$('rtPayRef');return needsConfirm()&&e?String(e.value||'').replace(/\s+/g,' ').trim().slice(0,40):'';};
  function renderPayPanel(){
    var p=$('rtPayConfirmPanel');if(!p)return;
    var show=needsConfirm();
    p.classList.toggle('hidden',!show);
    if(!show)return;
    var isCard=method()==='CARD';
    var t=$('rtPayConfirmText');if(t)t.textContent=isCard?'Saya telah semak bayaran KAD berjaya (slip / terminal)':'Saya telah semak pemindahan bank diterima';
    var ref=$('rtPayRef');if(ref)ref.placeholder=isCard?'4 digit akhir kad / no. kelulusan (pilihan)':'No. rujukan pindahan (pilihan)';
    p.classList.toggle('is-confirmed',payConfirmed());
  }
  function resetPay(){
    confirmedTotal=null;
    var cb=$('rtPayConfirm');if(cb)cb.checked=false;
    var ref=$('rtPayRef');if(ref)ref.value='';
    renderPayPanel();
  }
  function watchTotal(){
    // the amount changed after "sudah semak": the cashier must confirm the new amount
    var cb=$('rtPayConfirm');
    if(cb&&cb.checked&&needsConfirm()&&confirmedTotal!==null&&Math.abs(confirmedTotal-totalNow())>=0.005){
      cb.checked=false;confirmedTotal=null;renderPayPanel();
      toast('Jumlah berubah. Sahkan bayaran semula.','info');
    }
  }
  // each function is wrapped once: later scripts wrap over ours, so a flag on the function itself is not enough
  var wrapped={method:false,calc:false,checkout:false};
  function wrapMethod(){
    var o=w.posSetPaymentMethod;
    if(wrapped.method||typeof o!=='function')return;
    wrapped.method=true;
    w.posSetPaymentMethod=function(m){var r=o.apply(this,arguments);resetPay();return r;};
  }
  function wrapCalc(){
    var o=w.posCalculateTotal;
    if(wrapped.calc||typeof o!=='function')return;
    wrapped.calc=true;
    w.posCalculateTotal=function(){var r=o.apply(this,arguments);try{watchTotal();}catch(_){}return r;};
  }
  function bindPayPanel(){
    var cb=$('rtPayConfirm');
    if(!cb||cb.dataset.rtFix==='1')return;
    cb.dataset.rtFix='1';
    cb.addEventListener('change',function(){
      confirmedTotal=cb.checked?totalNow():null;
      renderPayPanel();
      if(typeof w.rtSyncCashTender==='function')w.rtSyncCashTender();
      try{d.dispatchEvent(new Event('rt-pay-confirm'));}catch(_){}
    });
  }

  // ------------------------------------------------------------------ 3. big manual discount: "betul?"
  var BIG_PCT=0.2,BIG_MIN=10;               // more than 20 % of the bill and at least RM 10
  function bigDiscount(){
    if(!w.RTPosDiscountModel)return null;
    var promo=w.rtGetActivePromo?w.rtGetActivePromo():null,voucher=w.rtPosGetActiveVoucher?w.rtPosGetActiveVoucher():null;
    var order=(promo||voucher)?0:num(($('posDiscount')||{}).value);
    var t=w.RTPosDiscountModel.cartTotals(cart(),order);
    var amount=r2(t.itemDiscount+t.orderDiscount);
    if(t.grossSubtotal<=0||amount<BIG_MIN)return null;
    var pct=amount/t.grossSubtotal;
    return pct>BIG_PCT?{amount:amount,pct:Math.round(pct*100),gross:t.grossSubtotal}:null;
  }

  // ------------------------------------------------------------------ the gate in front of the canonical checkout
  function wrapCheckout(){
    var orig=w.posCheckout;
    if(wrapped.checkout||typeof orig!=='function')return;
    wrapped.checkout=true;
    var busy=false;
    var f=function(){
      var self=this,args=arguments;
      if(busy)return;
      var pending=null;try{pending=sessionStorage.getItem('rt_pos_pending_sale_v1');}catch(_){}
      if(pending)return orig.apply(self,args);          // re-confirming an uncertain sale: straight through
      if(!cart().length)return orig.apply(self,args);
      if(needsConfirm()&&!payConfirmed()){
        toast(method()==='CARD'?'Tandakan: bayaran KAD sudah berjaya, dahulu.':'Tandakan: pemindahan bank sudah diterima, dahulu.','error');
        var p=$('rtPayConfirmPanel');if(p&&p.scrollIntoView){try{p.scrollIntoView({block:'nearest'});}catch(_){}}
        return;
      }
      busy=true;
      var btn=$('btnCheckout');
      return (async function(){
        try{
          // cheap local checks first, so the cashier hears about them at once
          if(w.rtPaymentQr&&typeof w.rtPaymentQr.readyForCheckout==='function'&&!w.rtPaymentQr.readyForCheckout())return orig.apply(self,args);   // the QR gate explains itself
          var big=bigDiscount();
          if(big){
            var yes=await w.rtConfirm({title:'Diskaun besar',message:'Diskaun '+money(big.amount)+' ('+big.pct+'%) daripada '+money(big.gross)+'. Betul?',confirmText:'YA, TERUSKAN',cancelText:'BATAL'});
            if(!yes)return;
          }
          if(btn){btn.disabled=true;btn.setAttribute('data-rt-checking','1');}
          var ok;
          try{ok=await livePreflight();}finally{if(btn){btn.removeAttribute('data-rt-checking');btn.disabled=false;}}
          if(!ok)return;
          return orig.apply(self,args);
        }catch(e){
          console.warn('POS gate',e);
          return orig.apply(self,args);                 // never trap a sale behind a bug in the gate
        }finally{busy=false;}
      })();
    };
    w.posCheckout=f;
  }

  // ------------------------------------------------------------------ 4. forgiving product search
  function bindSearch(){
    var q=$('posSearch');
    if(!q||q.dataset.rtFix==='1')return;
    q.dataset.rtFix='1';
    // paste / dictation / autofill fire "input" but not "keyup"
    q.addEventListener('input',function(){if(typeof w.posFilterProducts==='function')w.posFilterProducts(q.value);});
  }
  function find(code){
    code=String(code||'').trim().toLowerCase();
    return (w.posProducts||[]).filter(function(p){return String(p.sku||'').toLowerCase()===code||String(p.barcode||'').toLowerCase()===code;})[0]||null;
  }
  // Enter in the search box: scanner gun (exact SKU / barcode) or a typed name.
  w.rtPosSearchEnter=async function(text){
    var v=String(text||'').trim();
    if(!v)return false;
    if(find(v)||typeof w.rtPosMatches!=='function'||typeof w.rtPosTokens!=='function')return w.rtSelectScannedSku(v);
    var tokens=w.rtPosTokens(v);
    var hits=(w.posProducts||[]).filter(function(p){return w.rtPosMatches(p,tokens);});
    if(hits.length===1)return w.rtSelectScannedSku(hits[0].sku);
    if(hits.length>1){toast(hits.length+' barang sepadan. Pilih dari senarai.','info');return false;}
    return w.rtSelectScannedSku(v);                          // not in the list: the barcode may be new
  };

  // ------------------------------------------------------------------ 5. typed numbers
  function bindNumbers(){
    d.addEventListener('input',function(e){
      var t=e.target;
      if(!t||t.id!=='posAmountReceived')return;
      // 1,000 / 12,500.50 -> thousands commas are not part of the number
      if(/^\d{1,3}(,\d{3})+(\.\d{0,2})?$/.test(t.value))t.value=t.value.replace(/,/g,'');
    },true);
    d.addEventListener('change',function(e){
      var t=e.target;
      if(!t)return;
      if(t.id==='posAmountReceived'&&/^\d+,\d{1,2}$/.test(t.value)){t.value=t.value.replace(',','.');try{t.dispatchEvent(new Event('input',{bubbles:true}));}catch(_){}}
      if(t.id==='rtOtherCharge'){
        var raw=num(t.value),rounded=Math.max(0,r2(raw));
        if(String(t.value)!==''&&Math.abs(raw*100-Math.round(raw*100))>1e-6){t.value=rounded.toFixed(2);toast('Caj lain dibundarkan kepada '+money(rounded)+'.','info');if(typeof w.posCalculateTotal==='function')w.posCalculateTotal();}
      }
    },true);
  }

  // ------------------------------------------------------------------ 6. after a sale: stock on screen at once, re-read only what was sold
  var lastFull=0;
  function patchProduct(sku,fn){
    var seen=[];
    [w.posProducts].concat(typeof allProducts!=='undefined'?[allProducts]:[]).forEach(function(list){
      (list||[]).forEach(function(p){if(String(p.sku)===String(sku)&&seen.indexOf(p)<0){seen.push(p);fn(p);}});
    });
  }
  function redraw(){
    var q=$('posSearch');
    try{
      if(q&&q.value&&typeof w.posFilterProducts==='function')w.posFilterProducts(q.value);
      else if(typeof w.renderPosGrid==='function'&&w.posProducts)w.renderPosGrid(w.posProducts);
    }catch(e){console.warn('redraw',e);}
  }
  w.rtPosAfterSale=async function(sold){
    try{
      var lines=(sold||[]).filter(function(i){return !isService(i);});
      lines.forEach(function(i){patchProduct(i.sku,function(p){p.stock=Math.max(0,num(p.stock)-num(i.qty));});});
      redraw();
      var sb=w.supabaseClient,company=companyId();
      var ids=lines.map(function(i){return i.productId||i.product_id;}).filter(Boolean);
      if(sb&&company&&ids.length){
        var loc=await locationId(sb,company);
        var jobs=[sb.from('products').select('id,sku,sell_price').eq('company_id',company).in('id',ids)];
        if(loc)jobs.push(sb.from('stock_balances').select('product_id,quantity').eq('location_id',loc).in('product_id',ids));
        var res=await Promise.all(jobs);
        var prods=res[0].data||[],bal=(res[1]&&res[1].data)||[];
        var stock={};bal.forEach(function(b){stock[String(b.product_id)]=num(b.quantity);});
        prods.forEach(function(p){
          patchProduct(p.sku,function(x){
            x.price=num(p.sell_price);x.sellPrice=num(p.sell_price);
            if(loc&&stock[String(p.id)]!==undefined)x.stock=Math.max(0,stock[String(p.id)]);
          });
        });
        redraw();
      }
      // everything else (other devices' sales, new items) is re-read at most every 5 minutes
      if(Date.now()-lastFull>300000&&Date.now()-(w.rtPosProductsLoadedAt||0)>300000){lastFull=Date.now();if(typeof w.loadPOS==='function')w.loadPOS();}
    }catch(e){
      console.warn('after-sale refresh, falling back to a full reload',e);
      try{if(typeof w.loadPOS==='function')w.loadPOS();}catch(_){}
    }
  };

  // ------------------------------------------------------------------ boot
  function boot(){
    wrapMethod();wrapCalc();wrapCheckout();bindPayPanel();bindSearch();bindNumbers();renderPayPanel();
  }
  if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',boot);else boot();
  w.addEventListener('load',function(){setTimeout(boot,300);setTimeout(boot,1500);});
})(window);
