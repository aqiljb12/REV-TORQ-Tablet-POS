/* REV TORQ RC7 - Canonical Inventory list/search/edit + scanner focus + sticker action */
(function(){
'use strict';
const $=id=>document.getElementById(id);
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);}
async function getCompany(){
  if(typeof window.companyId==='function')return await window.companyId();
  const p=window.currentProfile||{}; return p.companyId||p.company_id||null;
}
async function getLocation(){
  if(typeof window.locationId==='function')return await window.locationId();
  const p=window.currentProfile||{}; return p.locationId||p.location_id||null;
}
function money(v){return typeof formatMoney==='function'?formatMoney(v||0):'RM '+Number(v||0).toFixed(2);}
function cacheFind(code){
  const q=String(code||'').trim().toLowerCase();
  if(!q)return null;
  return (window.rtInventoryCache||[]).find(p=>String(p.barcode||'').toLowerCase()===q || String(p.sku||'').toLowerCase()===q)||null;
}
function focusInventoryRow(item,code){
  const search=$('searchInventory');
  if(search){search.value=String(code||item.barcode||item.sku||''); if(typeof filterTable==='function')filterTable('tblInventory',search.value);}
  setTimeout(()=>{
    document.querySelectorAll('#tblInventory tbody tr').forEach(r=>{r.style.outline='';r.style.background='';});
    const row=Array.from(document.querySelectorAll('#tblInventory tbody tr[data-product-id]')).find(r=>String(r.dataset.productId||'')===String(item.id||''));
    if(row){row.style.outline='3px solid #22c55e';row.style.background='#f0fdf4';row.scrollIntoView({behavior:'smooth',block:'center'});setTimeout(()=>{row.style.outline='';},2400);}
  },40);
}

let inventoryLoaded=false, inventoryRequest=0;
window.loadInventory=async function(options={}){
  const tbody=document.querySelector('#tblInventory tbody');
  if(!tbody)return;
  const request=++inventoryRequest;
  const silent=inventoryLoaded||!!(options&&options.silent);
  if(!silent)tbody.innerHTML='<tr><td colspan="9" class="text-center p-6 text-slate-400">Memuatkan inventori...</td></tr>';
  try{
    const company=await getCompany(), location=await getLocation();
    if(!company)throw new Error('Company tidak dijumpai.');
    // V2 web: page through products and read this location's stock in one go
    // (the old `.in(all product ids)` URL grew with every item and stopped at 1000 rows).
    const fetchAll=typeof window.rtPosFetchAll==='function'?window.rtPosFetchAll:async build=>{const r=await build();if(r.error)throw r.error;return r.data||[];};
    const [products,balances]=await Promise.all([
      fetchAll(()=>sb.from('products')
        .select('id,sku,name,category,barcode,rack_location,cost_price,sell_price,min_stock,active,unit')
        .eq('company_id',company)
        .order('sku',{ascending:true})),
      location?fetchAll(()=>sb.from('stock_balances').select('product_id,quantity').eq('location_id',location).order('product_id',{ascending:true})):Promise.resolve([])
    ]);
    const stockMap={};balances.forEach(x=>stockMap[x.product_id]=Number(x.quantity||0));
    const freshCache=products.map(d=>({...d,stock:Number(stockMap[d.id]||0)}));

    const rows=freshCache.map(d=>{
      const stock=Number(d.stock||0), min=Number(d.min_stock??5);
      // V2 polish: explicit stock status (IN STOCK / LOW STOCK / OUT OF STOCK) for the badge + filter.
      const stockStatus=stock<=0?'out':stock<=min?'low':'ok';
      const stockLabel=stockStatus==='out'?'HABIS':stockStatus==='low'?'STOK RENDAH':'ADA STOK';
      const bc=d.barcode||'';
      return `<tr data-product-id="${esc(d.id)}" data-sku="${esc(d.sku)}" data-barcode="${esc(bc)}" data-stock-status="${stockStatus}" class="hover:bg-slate-50 border-b border-slate-100">
        <td class="p-4 font-mono font-bold text-indigo-700">${esc(d.sku||'-')}</td>
        <td class="p-4 font-bold text-slate-800">${esc(d.name||'-')}</td>
        <td class="p-4 text-xs font-mono"><span class="bg-slate-100 px-2 py-1 rounded border border-slate-200">${esc(d.category||'-')}</span></td>
        <td class="p-4 font-mono text-xs ${bc?'text-slate-600':'text-amber-600 font-bold'}">${esc(bc||'AUTO BILA SAVE')}</td>
        <td class="p-4 font-mono text-xs font-bold text-indigo-600">${esc(d.rack_location||'-')}</td>
        <td class="p-4 font-mono text-right text-slate-500">${money(d.cost_price||0)}</td>
        <td class="p-4 font-mono text-right font-bold text-slate-800">${money(d.sell_price||0)}</td>
        <td class="p-4 text-center"><div class="rt-stock-cell is-${stockStatus}"><b>${stock}</b><span>${stockLabel}</span></div></td>
        <td class="p-4 text-right space-x-1">
          ${d.active===false?'<span class="text-xs bg-red-50 text-red-500 px-2 py-1 rounded mr-1 border border-red-100">TIDAK AKTIF</span>':''}
          <button onclick="window.rtOpenStickerForSku('${esc(d.sku)}')" class="text-violet-700 text-[11px] font-black px-2 py-1 rounded-lg bg-violet-50 border border-violet-100">STIKER</button>
          <button onclick="window.openStockAdjustment('${esc(d.sku)}')" class="text-emerald-600 text-[11px] font-black px-2 py-1 rounded-lg bg-emerald-50 border border-emerald-100">STOK</button>
          <button onclick="window.editInventory('${esc(d.sku)}')" class="text-indigo-600 text-[11px] font-black px-2 py-1 rounded-lg bg-indigo-50 border border-indigo-100">EDIT</button>
        </td>
      </tr>`;
    }).join('');
    if(request!==inventoryRequest)return;
    window.rtInventoryCache=freshCache;
    tbody.innerHTML=rows||'<tr><td colspan="9" class="text-center p-8 text-slate-400">Tiada item inventori</td></tr>';
    inventoryLoaded=true;
    try{if(typeof window.rtApplyInventoryFilter==='function')window.rtApplyInventoryFilter(freshCache);}catch(_){ }
    try{if(window.feather)feather.replace();}catch(_){ }
  }catch(e){
    console.error('loadInventory canonical',e);
    if(request===inventoryRequest&&!inventoryLoaded)tbody.innerHTML='<tr><td colspan="9" class="text-center p-6 text-red-500">Ralat: '+esc(e.message||e)+'</td></tr>';
  }
};

window.rtInventoryListBarcodeLookup=async function(value){
  const code=String(value||'').trim();
  if(!code)return;
  try{
    let d=cacheFind(code);
    if(!d){
      const company=await getCompany();
      let r=await sb.from('products').select('id,sku,name,category,barcode,rack_location,cost_price,sell_price,min_stock,active').eq('company_id',company).eq('barcode',code).limit(1).maybeSingle();
      if(r.error)throw r.error;
      d=r.data||null;
      if(!d){
        r=await sb.from('products').select('id,sku,name,category,barcode,rack_location,cost_price,sell_price,min_stock,active').eq('company_id',company).eq('sku',code.toUpperCase()).limit(1).maybeSingle();
        if(r.error)throw r.error;
        d=r.data||null;
      }
    }
    if(d){
      focusInventoryRow(d,code);
      if(typeof showToast==='function')showToast(`Jumpa: ${d.sku} • ${d.name}`,'success');
      return d;
    }
    window.openNewInventory?.();
    window.rtPendingInventoryBarcode=code;
    setTimeout(()=>{const el=$('invBarcode');if(el){if(window.rtSetNativeInputValue)window.rtSetNativeInputValue(el,code,{uppercase:true,rebuild:true});else{el.value=code;el.dispatchEvent(new Event('input',{bubbles:true}));}}},60);
    if(typeof showToast==='function')showToast('Barcode belum ada. Borang item baru dibuka.','info');
    return null;
  }catch(e){console.error('inventoryBarcodeLookup',e);if(typeof showToast==='function')showToast(e.message||String(e),'error');return null;}
};

// V38.6.16 stable lookup owns the public export: known barcode -> Stock Adjustment; unknown -> Add Item.
if(typeof window.inventoryBarcodeLookup!=='function' || !window.RT_STABLE_V362){
  window.inventoryBarcodeLookup=window.rtInventoryListBarcodeLookup;
}

window.editInventory=async function(sku){
  try{
    const company=await getCompany();
    const r=await sb.from('products').select('id,sku,name,category,barcode,rack_location,cost_price,sell_price,min_stock,active').eq('company_id',company).eq('sku',String(sku).trim().toUpperCase()).maybeSingle();
    if(r.error)throw r.error;if(!r.data)throw new Error('Item tidak ditemui.');
    const d=r.data;
    $('invIsEdit').value='true';
    const setText=(id,value,uppercase=false)=>{const el=$(id);if(!el)return;if(window.rtSetNativeInputValue)window.rtSetNativeInputValue(el,value,{uppercase,rebuild:true,dispatch:false});else el.value=uppercase?String(value??'').toUpperCase():String(value??'');};
    setText('invSku',d.sku,true);$('invSku').disabled=true;
    $('invCat').value=d.category||'SPAREPART';setText('invName',d.name||'');
    setText('invBarcode',d.barcode||'',true);setText('invRackCode',d.rack_location||'',true);
    $('invCost').value=d.cost_price??0;$('invPrice').value=d.sell_price??0;$('invMinStock').value=d.min_stock??5;
    $('invActive').value=d.active===false?'false':'true';
    $('invStockGroup').style.display='none';$('invStock').readOnly=true;
    if(typeof window.openInventoryPage==='function')window.openInventoryPage('Kemaskini Inventori','Semak dan kemaskini maklumat item inventori.');
  }catch(e){console.error('editInventory canonical',e);if(typeof showToast==='function')showToast(e.message||String(e),'error');}
};
})();
