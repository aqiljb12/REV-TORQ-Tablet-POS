/* REV TORQ POS V2 WEB — fast start + offline level 1.
   What it gives you:
   * rtStore      a small IndexedDB store on this iPad (never throws; if the browser refuses, features just switch off).
   * rtPosCache   the last POS product list (without cost prices) so POS opens at once; the fresh list replaces it a moment later.
   * rtPerf       timings of POS open / product load / sale RPCs, shown in Tetapan > Diagnostik.
   * Offline bar  amber strip when there is no internet (or the app started without a verified login).
   * BAYAR lock   a sale needs the server: while offline BAYAR says so and does nothing. Cart and Gantung keep working.
   * The app shell cache lives in sw-notify.js; this file registers it, warms it, and can reset it.
   Selling offline is NOT supported on purpose (stock, invoice numbers, vouchers and the cash drawer live on the server).
   Plain ES2017 for Safari on iPad. Keep BUILD equal to sw-notify.js. */
(function(){
  'use strict';
  var BUILD='2026-10-06-offline2';
  var PERF_KEY='rt_perf_v1',PERF_MAX=80;
  var swInfo=null,swReg=null;

  function $(id){return document.getElementById(id);}
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
  function toast(m,t){try{if(window.showToast)window.showToast(m,t||'info');}catch(_){}}
  function offline(){return navigator.onLine===false;}
  function isStaticUrl(u){try{var x=new URL(u);return x.origin===location.origin&&/\.(?:js|css|png|jpe?g|svg|webp|ico|gif|woff2?|ttf|otf|eot|json|webmanifest)$/i.test(x.pathname);}catch(_){return false;}}

  // ------------------------------------------------------------ reset (?rt_reset=1)
  function resetAll(){
    var jobs=[];
    try{if('serviceWorker' in navigator)jobs.push(navigator.serviceWorker.getRegistrations().then(function(rs){return Promise.all(rs.map(function(r){return r.unregister();}));}));}catch(_){}
    try{if(window.caches)jobs.push(caches.keys().then(function(ks){return Promise.all(ks.filter(function(k){return /^rt-shell-/.test(k);}).map(function(k){return caches.delete(k);}));}));}catch(_){}
    try{jobs.push(new Promise(function(res){var r=indexedDB.deleteDatabase('rt_offline_v1');r.onsuccess=r.onerror=r.onblocked=function(){res();};}));}catch(_){}
    try{localStorage.removeItem(PERF_KEY);}catch(_){}
    return Promise.all(jobs.map(function(p){return Promise.resolve(p).catch(function(){});}));
  }
  window.rtResetAppCache=resetAll;
  if(/[?&]rt_reset=1(?:&|$)/.test(location.search)){
    resetAll().then(function(){location.replace(location.pathname);});
    return;
  }

  // ------------------------------------------------------------ rtStore (IndexedDB)
  var dbPromise=null;
  function openDb(){
    if(dbPromise)return dbPromise;
    dbPromise=new Promise(function(resolve){
      var done=false;function fin(v){if(!done){done=true;resolve(v);}}
      setTimeout(function(){fin(null);},4000);          // Safari can leave IndexedDB hanging: never wait forever
      try{
        var rq=indexedDB.open('rt_offline_v1',1);
        rq.onupgradeneeded=function(){try{rq.result.createObjectStore('kv');}catch(_){}};
        rq.onsuccess=function(){fin(rq.result);};
        rq.onerror=rq.onblocked=function(){fin(null);};
      }catch(_){fin(null);}
    });
    return dbPromise;
  }
  function run(mode,fn){
    return openDb().then(function(db){
      if(!db)return null;
      return new Promise(function(resolve){
        try{
          var t=db.transaction('kv',mode),req=fn(t.objectStore('kv'));
          t.oncomplete=function(){resolve(req&&req.result!==undefined?req.result:true);};
          t.onerror=t.onabort=function(){resolve(null);};
        }catch(_){resolve(null);}
      });
    });
  }
  window.rtStore={
    get:function(k){return run('readonly',function(s){return s.get(k);}).then(function(v){return v===true?null:v;});},
    set:function(k,v){return run('readwrite',function(s){return s.put(v,k);}).then(function(r){return r!==null;});},
    del:function(k){return run('readwrite',function(s){return s.delete(k);});},
    clear:function(){return run('readwrite',function(s){return s.clear();});}
  };

  // ------------------------------------------------------------ rtPerf
  function perfRead(){try{var a=JSON.parse(localStorage.getItem(PERF_KEY)||'[]');return Array.isArray(a)?a:[];}catch(_){return [];}}
  window.rtPerf={
    mark:function(name,ms,extra){
      try{
        var a=perfRead();a.push({n:name,ms:Math.round(ms),at:Date.now(),x:extra||null});
        localStorage.setItem(PERF_KEY,JSON.stringify(a.slice(-PERF_MAX)));
      }catch(_){}
    },
    // called by the Supabase fetch wrapper: only sale RPCs are recorded
    net:function(url,ms){
      var m=/\/rest\/v1\/rpc\/(rt_(?:post|pos)_[a-z_]+)/.exec(String(url));
      if(m)window.rtPerf.mark('rpc:'+m[1],ms);
    },
    list:perfRead,
    summary:function(name){
      var a=perfRead().filter(function(x){return x.n===name;});
      if(!a.length)return null;
      var sum=0,max=0;a.forEach(function(x){sum+=x.ms;if(x.ms>max)max=x.ms;});
      var last=a[a.length-1];
      return {count:a.length,avg:Math.round(sum/a.length),max:max,last:last.ms,source:last.x&&last.x.source||''};
    }
  };

  // ------------------------------------------------------------ POS product cache
  function slim(items){
    return items.map(function(p){
      var c=Object.assign({},p);
      // cost prices are not needed to sell and should not sit on the tablet
      c.cost=0;c.costPrice=0;c.cost_price=0;
      return c;
    });
  }
  window.rtPosCache={
    read:function(company){
      if(!company)return Promise.resolve(null);
      return window.rtStore.get('pos_products:'+company).then(function(v){
        return v&&v.company===company&&Array.isArray(v.items)&&v.items.length?v:null;
      });
    },
    write:function(company,items){
      if(!company||!Array.isArray(items)||!items.length)return Promise.resolve(false);
      return window.rtStore.set('pos_products:'+company,{company:company,at:Date.now(),items:slim(items)});
    },
    clear:function(){return window.rtStore.clear();}
  };

  // ------------------------------------------------------------ offline bar + BAYAR lock
  function blocked(){return offline()||window.rtOfflineShell===true;}
  function bar(){
    var b=$('rtOfflineBar');
    if(!b){
      b=document.createElement('div');b.id='rtOfflineBar';b.className='rt-off-bar hidden';b.setAttribute('role','status');
      b.innerHTML='<span class="rt-off-dot"></span><b id="rtOfflineTitle">OFFLINE</b><span id="rtOfflineMsg"></span><button type="button" id="rtOfflineRetry">CUBA SAMBUNG</button>';
      document.body.appendChild(b);
      b.querySelector('#rtOfflineRetry').addEventListener('click',function(){checkNow(true);});
    }
    return b;
  }
  function paint(){
    if(!document.body)return;
    var shell=window.rtOfflineShell===true,off=offline(),show=(off||shell)&&!!window.currentProfile;
    var b=bar();
    b.classList.toggle('hidden',!show);
    document.body.classList.toggle('rt-off-on',show);
    document.body.classList.toggle('rt-offline',blocked());
    if(show){
      var t=$('rtOfflineTitle'),m=$('rtOfflineMsg');
      if(t)t.textContent=off?'OFFLINE':'MENYAMBUNG';
      if(m)m.textContent=off
        ?'Troli dan Gantung boleh digunakan · BAYAR dikunci sehingga internet kembali'
        :'Menyahkan login ke server · BAYAR dikunci sehingga selesai';
    }
  }
  function warnBlocked(){
    toast(offline()
      ?'Tiada internet. Troli disimpan. BAYAR hanya boleh bila internet kembali.'
      :'Login belum disahkan ke server. Tunggu sebentar, kemudian cuba BAYAR.','error');
  }
  document.addEventListener('click',function(ev){
    var t=ev.target&&ev.target.closest?ev.target.closest('#btnCheckout'):null;
    if(!t||!blocked())return;
    ev.preventDefault();ev.stopImmediatePropagation();warnBlocked();
  },true);
  function wrapOnce(name,make){
    var o=window[name];
    if(typeof o!=='function'||o.__rtOff)return;
    var w=make(o);w.__rtOff=true;window[name]=w;
  }
  function wrapAll(){
    wrapOnce('posCheckout',function(o){return function(){if(blocked()){warnBlocked();return Promise.resolve();}return o.apply(this,arguments);};});
    // offline start: only the POS screen exists (everything else needs the server)
    wrapOnce('switchView',function(o){return function(id){
      if(window.rtOfflineShell===true&&id!=='pos'){toast('Perlu internet untuk halaman ini. Hanya POS tersedia dalam mod offline.','error');return;}
      return o.apply(this,arguments);
    };});
    wrapOnce('loadSettings',function(o){return function(){var r=o.apply(this,arguments);Promise.resolve(r).then(function(){renderDiag();},function(){renderDiag();});return r;};});
  }

  // ------------------------------------------------------------ coming back online
  function checkNow(manual){
    if(offline()){if(manual)toast('Masih tiada internet.','info');paint();return Promise.resolve(false);}
    if(window.rtOfflineShell===true&&typeof window.rtLeaveOfflineShell==='function'){
      return window.rtLeaveOfflineShell().then(function(ok){
        paint();
        if(ok){
          toast('Internet kembali. Login disahkan, data dikemas kini.','success');
          try{if(typeof window.rtRefreshSharedState==='function')window.rtRefreshSharedState(true);}catch(_){}
        }else if(manual)toast('Belum dapat menghubungi server. Cuba lagi sebentar.','info');
        return ok;
      });
    }
    paint();return Promise.resolve(true);
  }
  window.addEventListener('online',function(){paint();setTimeout(function(){checkNow(false);},800);});
  window.addEventListener('offline',paint);
  window.addEventListener('rt-offline-shell',function(){paint();wrapAll();});
  setInterval(function(){wrapAll();paint();if(window.rtOfflineShell===true&&!offline())checkNow(false);},10000);
  window.addEventListener('load',function(){setTimeout(function(){wrapAll();paint();},300);});

  // ------------------------------------------------------------ service worker
  function sameOriginStaticEntries(){
    try{return performance.getEntriesByType('resource').map(function(r){return r.name;}).filter(isStaticUrl);}catch(_){return [];}
  }
  function warm(reg){
    var w=reg&&(reg.active||reg.waiting||reg.installing);
    if(!w)return;
    var urls=sameOriginStaticEntries();
    urls.push(new URL('manifest.webmanifest',location.href).href);
    try{w.postMessage({type:'warm',urls:urls});}catch(_){}
  }
  function registerSw(){
    if(!('serviceWorker' in navigator))return;
    var host=location.hostname;
    if(location.protocol!=='https:'&&host!=='localhost'&&host!=='127.0.0.1')return;
    if(host==='appassets.androidplatform.net'||window.RevTorqNative)return;
    var hadController=!!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener('controllerchange',function(){
      if(hadController)toast('Versi app baharu sudah sedia. Muat semula bila selesai jualan.','info');
      hadController=true;
    });
    navigator.serviceWorker.addEventListener('message',function(e){
      var d=e.data||{};
      if(d.type==='rt-sw-info'){swInfo=d;var e=$('rtDiagSw');if(e)e.textContent=d.files+' fail';}
    });
    navigator.serviceWorker.register('sw-notify.js').then(function(reg){swReg=reg;}).catch(function(){});
    navigator.serviceWorker.ready.then(function(reg){
      swReg=reg;
      setTimeout(function(){warm(reg);askInfo();},3500);
    }).catch(function(){});
    try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist();}catch(_){}
  }
  function askInfo(){
    try{var c=navigator.serviceWorker&&navigator.serviceWorker.controller;if(c)c.postMessage({type:'info'});}catch(_){}
  }
  registerSw();

  // ------------------------------------------------------------ Tetapan > Diagnostik
  function ms(v){return v==null?'-':v+' ms';}
  function sumLine(label,name){
    var s=window.rtPerf.summary(name);
    return '<div class="rt-diag-row"><span>'+esc(label)+'</span><b>'+(s?esc('terakhir '+ms(s.last)+' · purata '+ms(s.avg)+' · '+s.count+' kali'+(s.source?' · '+s.source:'')):'belum ada')+'</b></div>';
  }
  function renderDiag(){
    var box=$('rtDiagBody');if(!box)return;
    var p=window.currentProfile||{};
    var mode=window.rtOfflineShell?'OFFLINE (belum disahkan)':offline()?'OFFLINE':'ONLINE';
    var rows=[];
    rows.push('<div class="rt-diag-row"><span>Versi app</span><b>'+esc(BUILD)+'</b></div>');
    rows.push('<div class="rt-diag-row"><span>Sambungan</span><b>'+esc(mode)+'</b></div>');
    rows.push('<div class="rt-diag-row"><span>Dipasang sebagai app</span><b>'+(window.matchMedia&&window.matchMedia('(display-mode: standalone)').matches||navigator.standalone?'Ya':'Belum (Share → Add to Home Screen)')+'</b></div>');
    rows.push('<div class="rt-diag-row"><span>Cache app (service worker)</span><b id="rtDiagSw">'+(('serviceWorker' in navigator)?(navigator.serviceWorker.controller?(swInfo?esc(swInfo.files+' fail'):'aktif'):'belum aktif (muat semula sekali)'):'tidak disokong')+'</b></div>');
    rows.push('<div class="rt-diag-row"><span>Barang tersimpan di iPad</span><b id="rtDiagProducts">…</b></div>');
    rows.push('<div class="rt-diag-row"><span>Storan</span><b id="rtDiagStorage">…</b></div>');
    rows.push(sumLine('Buka POS (paparan pertama)','pos_first_render'));
    rows.push(sumLine('Muat senarai barang (rangkaian)','pos_load'));
    rows.push(sumLine('Checkout (RPC jualan)','rpc:rt_post_pos_sale_idempotent'));
    rows.push(sumLine('Checkout Job (RPC)','rpc:rt_post_job_pos_sale_idempotent'));
    box.innerHTML=rows.join('');
    window.rtPosCache.read(p.companyId).then(function(v){
      var e=$('rtDiagProducts');if(!e)return;
      e.textContent=v?v.items.length+' item · '+new Date(v.at).toLocaleString('ms-MY'):'belum ada';
    });
    try{
      if(navigator.storage&&navigator.storage.estimate)navigator.storage.estimate().then(function(x){
        var e=$('rtDiagStorage');if(e)e.textContent=(x.usage/1048576).toFixed(1)+' MB daripada '+Math.round(x.quota/1048576)+' MB';
      });else{var s=$('rtDiagStorage');if(s)s.textContent='-';}
    }catch(_){}
    askInfo();
  }
  window.rtRenderDiag=renderDiag;
  document.addEventListener('click',function(ev){
    var t=ev.target&&ev.target.closest?ev.target.closest('[data-rt-diag]'):null;
    if(!t)return;
    var a=t.getAttribute('data-rt-diag');
    if(a==='refresh')renderDiag();
    else if(a==='reset'){
      if(!window.confirm('Kosongkan cache app dan senarai barang tersimpan di iPad ini? Login dan data di pelayan TIDAK terjejas. App dimuat semula.'))return;
      resetAll().then(function(){location.reload();});
    }
  });
  window.rtOfflineInfo={build:BUILD,blocked:blocked,paint:paint,checkNow:checkNow};
})();
