/* REV TORQ POS V2 WEB — Inventori: tidy toolbar menu + Senarai Pesan Stok.
   Read-only. The reorder list is built from the inventory already loaded on
   this page (window.rtInventoryCache: products + stock at this location), using
   the same "low" rule as the stock badges (stock <= minimum). It only produces
   text for WhatsApp / copy / print; it never changes stock or creates a GRN.
   Plain ES2017 for Safari on iPad. */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  var SUP_KEY='rt_reorder_supplier_v1';
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
  function num(v){var n=Number(v);return isFinite(n)?n:0;}
  function money(v){return 'RM '+num(v).toFixed(2);}
  function toast(m,t){try{if(window.showToast)window.showToast(m,t||'success');}catch(_){}}
  function feather(){try{if(window.feather)window.feather.replace();}catch(_){}}
  function company(){var p=window.currentProfile||{};return p.companyId||null;}
  function read(k){try{return localStorage.getItem(k);}catch(_){return null;}}
  function write(k,v){try{if(v)localStorage.setItem(k,v);else localStorage.removeItem(k);}catch(_){}}

  // ---------------------------------------------------------------- LAGI menu
  function menuOpen(open){
    var m=$('rtInvMoreMenu'),b=$('rtInvMoreBtn');if(!m)return;
    var on=typeof open==='boolean'?open:m.hidden;
    m.hidden=!on;if(b)b.setAttribute('aria-expanded',on?'true':'false');
  }
  window.rtToggleInvMenu=function(){menuOpen();};
  document.addEventListener('click',function(e){
    var m=$('rtInvMoreMenu');if(!m||m.hidden)return;
    var wrap=m.parentElement;
    if(wrap&&wrap.contains(e.target)&&!m.contains(e.target))return; // the LAGI button itself toggles
    if(m.contains(e.target)&&e.target.closest&&e.target.closest('button')){setTimeout(function(){menuOpen(false);},0);return;}
    if(!wrap||!wrap.contains(e.target))menuOpen(false);
  },true);
  document.addEventListener('keydown',function(e){if(e.key==='Escape')menuOpen(false);});

  // ---------------------------------------------------------------- reorder data
  function needs(){
    var list=(window.rtInventoryCache||[]).filter(function(p){return p.active!==false;});
    return list.filter(function(p){var min=p.min_stock==null?5:num(p.min_stock);return num(p.stock)<=min;})
      .map(function(p){
        var stock=num(p.stock),min=p.min_stock==null?5:num(p.min_stock);
        // Suggestion: top up to twice the minimum (at least one more than the minimum).
        var target=Math.max(min*2,min+1);
        return {id:p.id,sku:p.sku||'',name:p.name||p.sku||'',category:p.category||'',rack:p.rack_location||'',unit:String(p.unit||'pcs').toLowerCase(),
          stock:stock,min:min,cost:num(p.cost_price),out:stock<=0,qty:Math.max(1,target-stock)};
      })
      .sort(function(a,b){return (a.out===b.out?0:a.out?-1:1)||String(a.category).localeCompare(String(b.category))||String(a.name).localeCompare(String(b.name));});
  }
  function syncCount(){
    var b=$('rtReorderCount');if(!b)return;
    var n=Array.isArray(window.rtInventoryCache)?needs().length:0;
    b.hidden=!n;if(b.textContent!==String(n))b.textContent=String(n);
    var btn=$('rtReorderBtn');if(btn)btn.classList.toggle('has-items',n>0);
  }

  // ---------------------------------------------------------------- modal
  var st={rows:[],qty:{},off:{},filter:'all',suppliers:[],shop:''};
  function supplier(){var id=($('rtReorderSupplier')||{}).value||'';return st.suppliers.filter(function(s){return String(s.id)===String(id);})[0]||null;}
  function chosen(){return st.rows.filter(function(r){return !st.off[r.id]&&num(st.qty[r.id])>0&&(st.filter==='all'||(st.filter==='out'?r.out:!r.out));});}
  function fmtDate(){try{return new Intl.DateTimeFormat('ms-MY',{timeZone:'Asia/Kuala_Lumpur',day:'2-digit',month:'short',year:'numeric'}).format(new Date());}catch(_){return new Date().toLocaleDateString();}}
  function message(){
    var s=supplier(),items=chosen();
    var lines=['*PESANAN STOK — '+(st.shop||'REV TORQ')+'*','Tarikh: '+fmtDate()];
    if(s)lines.push('Kepada: '+s.name);
    lines.push('');
    items.forEach(function(r,i){lines.push((i+1)+'. '+r.name+(r.sku?' ('+r.sku+')':'')+' — '+num(st.qty[r.id])+' '+r.unit);});
    lines.push('','Jumlah: '+items.length+' item','Terima kasih.');
    return lines.join('\n');
  }
  function render(){
    var body=$('rtReorderBody');if(!body)return;
    var all=st.rows,outN=all.filter(function(r){return r.out;}).length,lowN=all.length-outN;
    var shown=all.filter(function(r){return st.filter==='all'||(st.filter==='out'?r.out:!r.out);});
    var chips='<div class="rt-ro-chips" role="group" aria-label="Tapis">'+
      [['all','Semua',all.length],['out','Habis',outN],['low','Stok rendah',lowN]].map(function(c){return '<button type="button" data-ro-filter="'+c[0]+'"'+(st.filter===c[0]?' class="active"':'')+'>'+c[1]+' <b>'+c[2]+'</b></button>';}).join('')+'</div>';
    var list=shown.length?shown.map(function(r){
      var off=!!st.off[r.id];
      return '<div class="rt-ro-row'+(off?' is-off':'')+'" data-id="'+esc(r.id)+'">'+
        '<label class="rt-ro-check"><input type="checkbox" data-ro="toggle"'+(off?'':' checked')+' aria-label="Pesan '+esc(r.name)+'"></label>'+
        '<div class="rt-ro-main"><b>'+esc(r.name)+'</b><small>'+esc([r.sku,r.rack?('Rak '+r.rack):'',r.category].filter(Boolean).join(' · '))+'</small></div>'+
        '<div class="rt-ro-stock'+(r.out?' is-out':'')+'"><b>'+esc(r.stock)+'</b><small>min '+esc(r.min)+'</small></div>'+
        '<div class="rt-ro-qty"><button type="button" data-ro="minus" aria-label="Kurang">−</button><input type="number" inputmode="numeric" min="0" step="1" data-ro="qty" value="'+esc(num(st.qty[r.id]))+'" aria-label="Kuantiti pesan"><button type="button" data-ro="plus" aria-label="Tambah">+</button></div>'+
      '</div>';
    }).join(''):'<div class="rt-ro-empty">'+(all.length?'Tiada item dalam tapisan ini.':'Semua stok mencukupi. Tiada yang perlu dipesan.')+'</div>';
    body.innerHTML=chips+list;
    syncFoot();
  }
  function syncFoot(){
    var items=chosen(),cost=items.reduce(function(s,r){return s+num(st.qty[r.id])*r.cost;},0);
    var f=$('rtReorderSummary');if(f)f.innerHTML='<b>'+items.length+'</b> item dipilih'+(cost>0?' · anggaran kos <b>'+money(cost)+'</b>':'');
    [].forEach.call(document.querySelectorAll('#rtReorderModal [data-ro-act]'),function(b){b.disabled=!items.length;});
    var s=supplier(),wa=$('rtReorderWa');
    if(wa)wa.innerHTML='<i data-feather="message-circle"></i>'+(s&&s.phone&&waNumber(s.phone)?'WHATSAPP '+esc(s.name.split(' ')[0].toUpperCase()):'WHATSAPP');
    feather();
  }
  function waNumber(v){return typeof window.rtWhatsAppNumber==='function'?window.rtWhatsAppNumber(v):'';}
  function close(){var m=$('rtReorderModal');if(m)m.remove();document.documentElement.classList.remove('rt-qs-open');}
  function loadSuppliers(){
    var sb=window.supabaseClient,c=company();
    if(!sb||!c)return Promise.resolve([]);
    return Promise.resolve(sb.from('suppliers').select('id,name,phone,active').eq('company_id',c).order('name',{ascending:true}).limit(200))
      .then(function(r){if(r.error)throw r.error;return (r.data||[]).filter(function(x){return x.active!==false&&x.name;});})
      .catch(function(){return [];});
  }
  function loadShop(){
    if(window.rtWorkshopProfile&&window.rtWorkshopProfile.workshopName)return Promise.resolve(window.rtWorkshopProfile.workshopName);
    try{
      if(window.db&&typeof window.db.collection==='function')return Promise.resolve(window.db.collection('settings').doc('workshop').get())
        .then(function(snap){var d=snap&&snap.exists?snap.data()||{}:{};return d.workshopName||'';}).catch(function(){return '';});
    }catch(_){}
    return Promise.resolve('');
  }
  window.rtOpenReorderList=function(){
    menuOpen(false);
    var start=function(){
      st.rows=needs();st.qty={};st.off={};st.filter='all';
      st.rows.forEach(function(r){st.qty[r.id]=r.qty;});
      close();
      var m=document.createElement('div');
      m.id='rtReorderModal';m.className='rt-qs-backdrop rt-ro-backdrop';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');m.setAttribute('aria-label','Senarai pesan stok');
      m.innerHTML='<div class="rt-qs-panel rt-ro-panel">'+
        '<div class="rt-ro-head"><div><h3>Senarai Pesan Stok</h3><p>Barang habis / stok rendah (stok ≤ minimum). Cadangan kuantiti = isi semula ke 2× minimum — boleh diubah.</p></div><button type="button" class="rt-qs-close" data-ro="close">TUTUP</button></div>'+
        '<div class="rt-ro-sup"><label for="rtReorderSupplier">Pembekal</label><select id="rtReorderSupplier"><option value="">— Pilih pembekal (pilihan) —</option></select></div>'+
        '<div class="rt-ro-body" id="rtReorderBody"></div>'+
        '<div class="rt-ro-foot"><div id="rtReorderSummary" class="rt-ro-summary"></div><div class="rt-ro-actions">'+
          '<button type="button" class="rt-qs-btn" data-ro-act="print"><i data-feather="printer"></i>CETAK</button>'+
          '<button type="button" class="rt-qs-btn" data-ro-act="copy"><i data-feather="copy"></i>SALIN</button>'+
          '<button type="button" class="rt-qs-btn wa" id="rtReorderWa" data-ro-act="wa"><i data-feather="message-circle"></i>WHATSAPP</button>'+
        '</div></div></div>';
      document.body.appendChild(m);
      document.documentElement.classList.add('rt-qs-open');
      m.addEventListener('click',onClick);
      m.addEventListener('input',onInput);
      m.addEventListener('change',onInput);
      render();
      loadShop().then(function(n){st.shop=n||st.shop;});
      loadSuppliers().then(function(list){
        st.suppliers=list;var sel=$('rtReorderSupplier');if(!sel)return;
        sel.innerHTML='<option value="">— Pilih pembekal (pilihan) —</option>'+list.map(function(s){return '<option value="'+esc(s.id)+'">'+esc(s.name)+(s.phone?' · '+esc(s.phone):'')+'</option>';}).join('');
        var saved=read(SUP_KEY+':'+company());if(saved&&list.some(function(s){return String(s.id)===saved;}))sel.value=saved;
        syncFoot();
      });
    };
    if(Array.isArray(window.rtInventoryCache))start();
    else if(typeof window.loadInventory==='function'){toast('Memuatkan inventori…','info');Promise.resolve(window.loadInventory({silent:true})).then(start);}
  };
  function rowOf(el){var r=el.closest?el.closest('[data-id]'):null;return r?r.getAttribute('data-id'):null;}
  function onInput(e){
    var t=e.target;
    if(t.id==='rtReorderSupplier'){write(SUP_KEY+':'+company(),t.value);syncFoot();return;}
    var id=rowOf(t);if(!id)return;
    if(t.getAttribute('data-ro')==='qty'){st.qty[id]=Math.max(0,Math.floor(num(t.value)));if(e.type==='change')t.value=st.qty[id];syncFoot();}
    else if(t.getAttribute('data-ro')==='toggle'){st.off[id]=!t.checked;var row=t.closest('.rt-ro-row');if(row)row.classList.toggle('is-off',!t.checked);syncFoot();}
  }
  function onClick(e){
    var m=$('rtReorderModal');
    if(e.target===m){close();return;}
    var f=e.target.closest?e.target.closest('[data-ro-filter]'):null;
    if(f){st.filter=f.getAttribute('data-ro-filter');render();return;}
    var b=e.target.closest?e.target.closest('[data-ro],[data-ro-act]'):null;if(!b||b.disabled)return;
    var a=b.getAttribute('data-ro'),act=b.getAttribute('data-ro-act');
    if(a==='close'){close();return;}
    if(a==='minus'||a==='plus'){
      var id=rowOf(b);if(!id)return;
      st.qty[id]=Math.max(0,num(st.qty[id])+(a==='plus'?1:-1));
      var inp=b.parentElement.querySelector('input');if(inp)inp.value=st.qty[id];
      syncFoot();return;
    }
    if(act==='wa')sendWa();else if(act==='copy')copyText();else if(act==='print')printList();
  }
  function sendWa(){
    var s=supplier(),to=s&&s.phone?waNumber(s.phone):'';
    var url='https://wa.me/'+to+'?text='+encodeURIComponent(message());
    var w=null;try{w=window.open(url,'_blank','noopener');}catch(_){}
    if(!w)location.href=url;
  }
  function copyText(){
    var text=message();
    var done=function(){toast('Senarai disalin. Tampal di WhatsApp / e-mel.','success');};
    var fallback=function(){
      var ta=document.createElement('textarea');ta.value=text;ta.setAttribute('readonly','');ta.style.position='fixed';ta.style.top='-1000px';document.body.appendChild(ta);
      ta.select();try{ta.setSelectionRange(0,text.length);}catch(_){}
      var ok=false;try{ok=document.execCommand('copy');}catch(_){}
      ta.remove();if(ok)done();else toast('Tidak dapat menyalin. Guna butang WhatsApp.','error');
    };
    if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(text).then(done,fallback);else fallback();
  }
  function printList(){
    var s=supplier(),items=chosen();
    var rowsHtml=items.map(function(r,i){return '<tr><td>'+(i+1)+'</td><td><b>'+esc(r.name)+'</b><br><small>'+esc([r.sku,r.rack?('Rak '+r.rack):''].filter(Boolean).join(' · '))+'</small></td><td class="n">'+esc(r.stock)+'</td><td class="n">'+esc(num(st.qty[r.id]))+' '+esc(r.unit)+'</td></tr>';}).join('');
    var html='<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pesanan Stok</title><style>body{font-family:-apple-system,Segoe UI,Arial,sans-serif;margin:24px;color:#111}h1{font-size:20px;margin:0}p{margin:4px 0 14px;color:#555;font-size:13px}table{width:100%;border-collapse:collapse;font-size:13px}th,td{border-bottom:1px solid #ddd;padding:8px 6px;text-align:left;vertical-align:top}th{font-size:11px;text-transform:uppercase;color:#555}.n{text-align:right;white-space:nowrap}small{color:#666}</style></head><body>'+
      '<h1>Pesanan Stok — '+esc(st.shop||'REV TORQ')+'</h1><p>Tarikh: '+esc(fmtDate())+(s?' · Kepada: '+esc(s.name)+(s.phone?' ('+esc(s.phone)+')':''):'')+' · '+items.length+' item</p>'+
      '<table><thead><tr><th>#</th><th>Barang</th><th class="n">Stok</th><th class="n">Pesan</th></tr></thead><tbody>'+rowsHtml+'</tbody></table>'+
      '<script>window.onload=function(){setTimeout(function(){window.print();},250);};<\/script></body></html>';
    var w=null;try{w=window.open('','_blank');}catch(_){}
    if(!w){toast('Browser sekat tetingkap cetak. Guna SALIN atau WHATSAPP.','error');return;}
    w.document.open();w.document.write(html);w.document.close();
  }

  // ---------------------------------------------------------------- wiring
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&$('rtReorderModal'))close();});
  setInterval(function(){if(window.__rtActiveView==='inventory')syncCount();},1000);
  window.rtReorderNeeds=needs;
})();
