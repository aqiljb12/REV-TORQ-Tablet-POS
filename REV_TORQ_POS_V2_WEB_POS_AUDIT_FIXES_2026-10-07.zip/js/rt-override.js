/* REV TORQ POS V2 WEB — Override (admin / owner).
   Override is no longer a switch. To do anything that changes or removes a record:
     1. the admin re-enters their own PIN and gives a REASON (min. 8 letters),
     2. the server opens a time-boxed session (5-30 min) and writes OVERRIDE_BEGIN,
     3. every action inside it is checked by the server again and writes who / when /
        why / before / after to audit_logs in the same transaction,
     4. nothing is ever deleted: customers, vehicles, items and suppliers are
        ARCHIVED (can be restored), Job Cards are CANCELLED. Paid jobs cannot be cancelled.
   If the SQL script (migration_2026_10_05_override_audit.sql) has not been run, Override
   stays locked (fail closed): the page says so and nothing is changed.

   window.rtOverride = { status, ensure, begin, end, act, openPage, ready }
   Plain ES2017 for Safari on iPad. */
(function(){
  'use strict';
  var SKEY='rt_override_v2';
  var CODES={
    NOT_INSTALLED:'Override belum aktif di pelayan. Jalankan migration_2026_10_05_override_audit.sql di Supabase dahulu.',
    AUTH_REQUIRED:'Sesi login tamat. Sila login semula.',
    STAFF_ONLY:'Akaun ini bukan akaun staf.',
    ADMIN_ONLY:'Hanya Admin / Owner boleh guna Override.',
    REASON_REQUIRED:'Sebab diperlukan (sekurang-kurangnya 8 huruf).',
    ACTION_INVALID:'Tindakan tidak dibenarkan untuk jenis rekod ini.',
    ENTITY_INVALID:'Jenis rekod tidak dikenali.',
    RECORD_NOT_FOUND:'Rekod tidak dijumpai.',
    OVERRIDE_SESSION_REQUIRED:'Override belum diaktifkan.',
    OVERRIDE_SESSION_INVALID:'Sesi Override tidak sah. Aktifkan semula.',
    OVERRIDE_SESSION_ENDED:'Sesi Override sudah ditamatkan. Aktifkan semula.',
    OVERRIDE_EXPIRED:'Sesi Override sudah tamat masa. Aktifkan semula.',
    ALREADY_ARCHIVED:'Rekod ini sudah diarkibkan.',
    ALREADY_ACTIVE:'Rekod ini sudah aktif.',
    CUSTOMER_HAS_VEHICLES:'Pelanggan masih ada kenderaan aktif. Arkibkan kenderaan dahulu.',
    CUSTOMER_HAS_OPEN_JOBS:'Pelanggan masih ada Job Card yang belum selesai / belum dibayar.',
    CUSTOMER_HAS_BOOKINGS:'Pelanggan masih ada tempahan (booking) aktif.',
    VEHICLE_HAS_OPEN_JOBS:'Kenderaan ini masih ada Job Card yang belum selesai / belum dibayar.',
    VEHICLE_HAS_BOOKINGS:'Kenderaan ini masih ada tempahan (booking) aktif.',
    PRODUCT_HAS_STOCK:'Item masih ada baki stok. Laraskan stok kepada 0 dahulu.',
    PRODUCT_IN_OPEN_JOB:'Item masih digunakan dalam Job Card yang belum selesai / belum dibayar.',
    JOB_ALREADY_CANCELLED:'Job Card ini sudah dibatalkan.',
    JOB_ALREADY_PAID:'Job Card ini sudah dibayar. Guna VOID invois, bukan batal Job.',
    PAYLOAD_TOO_LARGE:'Data terlalu besar untuk direkodkan.'
  };
  var KNOWN=Object.keys(CODES);
  var ENT={
    CUSTOMER:{label:'Pelanggan',one:'pelanggan',table:'customers'},
    VEHICLE:{label:'Kenderaan',one:'kenderaan',table:'vehicles'},
    PRODUCT:{label:'Item',one:'item',table:'products'},
    SUPPLIER:{label:'Pembekal',one:'pembekal',table:'suppliers'},
    JOB_CARD:{label:'Job Card',one:'Job Card',table:'job_cards'}
  };
  var REASONS=['Salah key-in','Rekod pendua','Pelanggan minta batal','Tidak lagi digunakan'];
  var st={sess:null,ready:'unknown',readyAt:0,tick:null,dlg:null,tab:'CUSTOMER',archived:false,q:'',rows:[],loading:false,error:'',req:0,timer:null,recent:null};

  function $(id){return document.getElementById(id);}
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
  function toast(m,t){try{if(window.showToast)window.showToast(m,t||'info');}catch(_){}}
  function feather(){try{if(window.feather)window.feather.replace();}catch(_){}}
  function sb(){return window.supabaseClient||null;}
  function prof(){return window.currentProfile||null;}
  function isAdmin(){try{return typeof window.rtHasAdminAccess==='function'&&!!window.rtHasAdminAccess();}catch(_){return false;}}
  function likeEsc(s){return String(s).replace(/[\\%_]/g,'\\$&');}
  function missingFn(e){var m=String(e&&(e.message||e.details||e.hint)||'');return !!(e&&(e.code==='PGRST202'||e.code==='42883'))||/could not find the function|function .* does not exist/i.test(m);}
  function network(e){var m=String(e&&e.message||e||'');return /failed to fetch|networkerror|network request failed|load failed|timeout|aborted/i.test(m)||(e&&e.name==='TypeError');}
  function codeOf(e){var m=String(e&&(e.message||e.details||e)||'');for(var i=0;i<KNOWN.length;i++)if(m.indexOf(KNOWN[i])>=0)return KNOWN[i];return '';}
  function msgOf(e){
    var c=codeOf(e);if(c)return CODES[c];
    if(missingFn(e))return CODES.NOT_INSTALLED;
    if(network(e))return 'Tiada sambungan ke pelayan. Cuba lagi.';
    return String(e&&e.message||e||'Ralat tidak diketahui.');
  }
  function silent(msg){var e=new Error(msg||'Dibatalkan.');e.rtSilent=true;return e;}
  function pad(n){return (n<10?'0':'')+n;}
  function clock(ms){var s=Math.max(0,Math.ceil(ms/1000));return pad(Math.floor(s/60))+':'+pad(s%60);}

  // ------------------------------------------------------------ session
  function loadSess(){
    try{
      var o=JSON.parse(sessionStorage.getItem(SKEY)||'null'),p=prof();
      if(o&&o.id&&o.exp>Date.now()&&p&&o.staff===p.staffUuid)return o;
      if(o)sessionStorage.removeItem(SKEY);
    }catch(_){}
    return null;
  }
  function saveSess(){try{if(st.sess)sessionStorage.setItem(SKEY,JSON.stringify(st.sess));else sessionStorage.removeItem(SKEY);}catch(_){}}
  function active(){
    if(st.sess&&st.sess.exp<=Date.now()){var s=st.sess;st.sess=null;saveSess();endRemote(s.id,'timeout');paint();}
    return !!st.sess;
  }
  function endRemote(id,by){
    var c=sb();if(!c||!id)return Promise.resolve(false);
    return Promise.resolve(c.rpc('rt_admin_override_end',{p_session_id:id,p_ended_by:by==='timeout'?'timeout':'user'}))
      .then(function(r){if(r&&r.error)throw r.error;return true;}).catch(function(e){console.warn('override end',e);return false;});
  }
  function status(){
    var on=active();
    return {active:on,sessionId:on?st.sess.id:null,reason:on?st.sess.reason:'',remainingMs:on?Math.max(0,st.sess.exp-Date.now()):0,ready:st.ready};
  }

  // ------------------------------------------------------------ server checks
  function ready(force){
    if(st.ready==='yes'&&!force)return Promise.resolve(true);
    if(st.ready==='no'&&!force&&Date.now()-st.readyAt<300000)return Promise.resolve(false);
    var c=sb();if(!c)return Promise.reject(new Error('Failed to fetch'));
    return Promise.resolve(c.rpc('rt_override_ready')).then(function(r){
      if(r&&r.error){
        if(missingFn(r.error)){st.ready='no';st.readyAt=Date.now();return false;}
        throw r.error;
      }
      st.ready=(r.data&&r.data.ready)?'yes':'no';st.readyAt=Date.now();return st.ready==='yes';
    });
  }
  // Re-check the admin's own PIN with a throw-away client, so the real session is untouched.
  function verifyPin(pin){
    var c=sb(),p=prof(),u=window.currentUser;
    if(!c||!p||!u||!window.supabase||typeof window.supabase.createClient!=='function')return Promise.reject(new Error('Pengesahan PIN tidak tersedia. Muat semula aplikasi.'));
    if(!pin)return Promise.reject(new Error('Masukkan PIN / kata laluan anda.'));
    return Promise.resolve(c.rpc('get_staff_login_email',{p_staff_id:p.staffId})).then(function(r){
      if(r.error||!r.data)throw new Error('PIN tidak betul.');
      var tmp=window.supabase.createClient(c.supabaseUrl,c.supabaseKey,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false,storageKey:'rt-override-verify'}});
      return Promise.resolve(tmp.auth.signInWithPassword({email:String(r.data).trim(),password:String(pin)})).then(function(a){
        var ok=!!(a&&!a.error&&a.data&&a.data.user&&a.data.user.id===u.id);
        try{Promise.resolve(tmp.auth.signOut({scope:'local'})).catch(function(){});}catch(_){}
        if(!ok){
          if(a&&a.error&&/rate|too many|limit/i.test(String(a.error.message||'')))throw new Error('Terlalu banyak percubaan. Tunggu sebentar.');
          throw new Error('PIN tidak betul.');
        }
      });
    });
  }
  function begin(reason,minutes,pin){
    if(!isAdmin())return Promise.reject(new Error('ADMIN_ONLY'));
    var r=String(reason||'').trim();
    if(r.length<8)return Promise.reject(new Error('REASON_REQUIRED'));
    var mins=Math.min(Math.max(parseInt(minutes,10)||10,1),30);
    return ready().then(function(ok){
      if(!ok)throw new Error('NOT_INSTALLED');
      return verifyPin(pin);
    }).then(function(){
      return sb().rpc('rt_admin_override_begin',{p_reason:r,p_minutes:mins});
    }).then(function(res){
      if(res.error)throw res.error;
      var d=res.data||{};if(!d.session_id)throw new Error('OVERRIDE_SESSION_INVALID');
      var m=Number(d.minutes||mins)||mins;
      st.sess={id:d.session_id,exp:Date.now()+m*60000,reason:String(d.reason||r),minutes:m,staff:prof().staffUuid};
      saveSess();startTick();paint();
      return {sessionId:st.sess.id,reason:st.sess.reason};
    });
  }
  function end(by){
    var s=st.sess;if(!s)return Promise.resolve(false);
    st.sess=null;saveSess();paint();
    return endRemote(s.id,by);
  }
  function act(entity,id,action,reason){
    if(!active())return Promise.reject(new Error('OVERRIDE_SESSION_REQUIRED'));
    return Promise.resolve(sb().rpc('rt_admin_override_action',{p_session_id:st.sess.id,p_entity:entity,p_id:id,p_action:action,p_reason:reason}))
      .then(function(r){if(r.error)throw r.error;return r.data;})
      .catch(function(e){
        var c=codeOf(e);
        if(c==='OVERRIDE_EXPIRED'||c==='OVERRIDE_SESSION_ENDED'||c==='OVERRIDE_SESSION_INVALID'){st.sess=null;saveSess();paint();}
        throw e;
      });
  }
  // Resolves with {sessionId, reason} once an Override session is running; rejects (rtSilent) if cancelled.
  function ensure(opts){
    opts=opts||{};
    if(!isAdmin())return Promise.reject(new Error('Hanya Admin / Owner boleh melakukan ini dalam Override.'));
    if(active())return Promise.resolve({sessionId:st.sess.id,reason:st.sess.reason});
    return openDialog(opts);
  }

  // ------------------------------------------------------------ banner + clock
  function bar(){
    var b=$('rtOverrideBar');
    if(!b){
      b=document.createElement('div');b.id='rtOverrideBar';b.className='rt-ov-bar hidden';b.setAttribute('role','status');
      b.innerHTML='<span class="rt-ov-bar-dot"></span><span class="rt-ov-bar-text">OVERRIDE AKTIF</span><b id="rtOverrideBarTime">--:--</b><button type="button" id="rtOverrideBarEnd">TAMATKAN</button>';
      document.body.appendChild(b);
      b.querySelector('#rtOverrideBarEnd').addEventListener('click',function(){end('user').then(function(){toast('Override ditamatkan.','success');});});
    }
    return b;
  }
  function paint(){
    var b=bar(),on=!!(st.sess&&prof());
    b.classList.toggle('hidden',!on);
    document.body.classList.toggle('rt-ov-on',on);
    if(on)b.title='Sebab: '+st.sess.reason;
    if(on){
      var left=st.sess.exp-Date.now();
      var t=$('rtOverrideBarTime');if(t)t.textContent=clock(left);
      b.classList.toggle('is-low',left<=60000);
    }
    paintPage();
  }
  function startTick(){
    if(st.tick)return;
    st.tick=setInterval(function(){
      if(!prof()){ // logged out: forget the session on this tablet (the server one expires on its own)
        if(st.sess){st.sess=null;saveSess();}
        closeDialogs();paint();return;
      }
      if(st.sess&&st.sess.exp<=Date.now()){
        var s=st.sess;st.sess=null;saveSess();endRemote(s.id,'timeout');
        toast('Sesi Override tamat masa.','info');closeDialogs();
      }
      paint();
    },1000);
  }

  // ------------------------------------------------------------ dialogs
  function closeDialogs(){
    ['rtOverrideModal','rtOverrideConfirm'].forEach(function(id){var m=$(id);if(m&&m.parentNode)m.parentNode.removeChild(m);});
    var d=st.dlg;st.dlg=null;if(d&&d.reject)d.reject(silent());
  }
  function shell(id,label,inner){
    var m=document.createElement('div');
    m.id=id;m.className='rt-ov-backdrop';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');m.setAttribute('aria-label',label);
    m.innerHTML='<div class="rt-ov-dialog">'+inner+'</div>';
    document.body.appendChild(m);return m;
  }
  function reasonChips(){return '<div class="rt-ov-chips">'+REASONS.map(function(r){return '<button type="button" data-chip="'+esc(r)+'">'+esc(r)+'</button>';}).join('')+'</div>';}
  function wireChips(m,ta){
    Array.prototype.forEach.call(m.querySelectorAll('[data-chip]'),function(b){
      b.addEventListener('click',function(){ta.value=b.getAttribute('data-chip');ta.dispatchEvent(new Event('input'));ta.focus();});
    });
  }
  // The activation dialog: reason + duration + the admin's own PIN.
  function openDialog(opts){
    if(st.dlg)return st.dlg.promise;
    var d={};
    d.promise=new Promise(function(res,rej){d.resolve=res;d.reject=rej;});
    st.dlg=d;
    var m=shell('rtOverrideModal','Aktifkan Override',
      '<div class="rt-ov-eyebrow">ADMIN / OWNER SAHAJA</div>'+
      '<h3>'+esc(opts.title||'Aktifkan Override')+'</h3>'+
      (opts.message?'<p class="rt-ov-lead">'+esc(opts.message)+'</p>':'')+
      '<div id="rtOvNotReady" class="rt-ov-warn hidden">'+esc(CODES.NOT_INSTALLED)+'</div>'+
      '<label class="rt-ov-label" for="rtOvReason">Sebab (wajib, min. 8 huruf)</label>'+
      '<textarea id="rtOvReason" rows="2" maxlength="300" placeholder="Contoh: Salah key-in harga, pelanggan pendua"></textarea>'+reasonChips()+
      '<div class="rt-ov-grid">'+
        '<div><label class="rt-ov-label" for="rtOvMins">Tempoh</label><select id="rtOvMins"><option value="5">5 minit</option><option value="10" selected>10 minit</option><option value="15">15 minit</option><option value="30">30 minit</option></select></div>'+
        '<div><label class="rt-ov-label" for="rtOvPin">PIN / kata laluan anda</label><input id="rtOvPin" type="password" autocomplete="current-password" autocapitalize="off" autocorrect="off"></div>'+
      '</div>'+
      '<div id="rtOvErr" class="rt-ov-err" role="alert"></div>'+
      '<p class="rt-ov-note">Setiap tindakan dalam Override direkodkan: siapa, bila, sebab, sebelum dan selepas. Tiada rekod dipadam — hanya diarkibkan atau dibatalkan.</p>'+
      '<div class="rt-ov-actions"><button type="button" class="rt-btn rt-btn-secondary" data-ov="cancel">BATAL</button><button type="button" class="rt-btn rt-btn-primary" data-ov="ok" id="rtOvOk">AKTIFKAN OVERRIDE</button></div>');
    var ta=m.querySelector('#rtOvReason'),pin=m.querySelector('#rtOvPin'),ok=m.querySelector('#rtOvOk'),err=m.querySelector('#rtOvErr');
    wireChips(m,ta);
    function finish(fn){if(st.dlg===d)st.dlg=null;if(m.parentNode)m.parentNode.removeChild(m);fn();}
    m.querySelector('[data-ov="cancel"]').addEventListener('click',function(){finish(function(){d.reject(silent());});});
    function submit(){
      err.textContent='';
      var reason=ta.value.trim();
      if(reason.length<8){err.textContent=CODES.REASON_REQUIRED;ta.focus();return;}
      if(!pin.value){err.textContent='Masukkan PIN / kata laluan anda.';pin.focus();return;}
      ok.disabled=true;ok.textContent='MENGESAHKAN…';
      begin(reason,m.querySelector('#rtOvMins').value,pin.value).then(function(info){
        pin.value='';
        finish(function(){toast('Override diaktifkan.','success');d.resolve(info);});
      }).catch(function(e){
        pin.value='';ok.disabled=false;ok.textContent='AKTIFKAN OVERRIDE';
        err.textContent=msgOf(e);
        if(codeOf(e)==='NOT_INSTALLED'||missingFn(e)){var nr=m.querySelector('#rtOvNotReady');if(nr)nr.classList.remove('hidden');}
        else pin.focus();
      });
    }
    ok.addEventListener('click',submit);
    pin.addEventListener('keydown',function(ev){if(ev.key==='Enter'){ev.preventDefault();submit();}});
    m.addEventListener('keydown',function(ev){if(ev.key==='Escape'&&!ok.disabled){finish(function(){d.reject(silent());});}});
    ready().then(function(yes){
      if(!yes){var nr=m.querySelector('#rtOvNotReady');if(nr)nr.classList.remove('hidden');ok.disabled=true;}
    },function(){/* offline: begin() will report it */});
    setTimeout(function(){try{ta.focus();}catch(_){}},60);
    return d.promise;
  }
  // Second confirmation for the actual archive / cancel: asks for the reason of THIS change.
  function confirmAction(spec){
    return new Promise(function(resolve){
      var m=shell('rtOverrideConfirm',spec.title,
        '<div class="rt-ov-eyebrow">'+esc(spec.eyebrow||'SAHKAN TINDAKAN')+'</div>'+
        '<h3>'+esc(spec.title)+'</h3>'+
        '<div class="rt-ov-target"><b>'+esc(spec.label)+'</b><small>'+esc(spec.sub||'')+'</small></div>'+
        '<p class="rt-ov-lead">'+esc(spec.note)+'</p>'+
        '<label class="rt-ov-label" for="rtOvActReason">Sebab (wajib, min. 8 huruf)</label>'+
        '<textarea id="rtOvActReason" rows="2" maxlength="300"></textarea>'+reasonChips()+
        '<div id="rtOvActErr" class="rt-ov-err" role="alert"></div>'+
        '<div class="rt-ov-actions"><button type="button" class="rt-btn rt-btn-secondary" data-ov="cancel">BATAL</button><button type="button" class="rt-btn rt-btn-primary" data-ov="ok">'+esc(spec.button)+'</button></div>');
      var ta=m.querySelector('#rtOvActReason'),err=m.querySelector('#rtOvActErr');
      wireChips(m,ta);
      function done(v){if(m.parentNode)m.parentNode.removeChild(m);resolve(v);}
      m.querySelector('[data-ov="cancel"]').addEventListener('click',function(){done(null);});
      m.querySelector('[data-ov="ok"]').addEventListener('click',function(){
        var r=ta.value.trim();
        if(r.length<8){err.textContent=CODES.REASON_REQUIRED;ta.focus();return;}
        done(r);
      });
      m.addEventListener('keydown',function(ev){if(ev.key==='Escape')done(null);});
      setTimeout(function(){try{ta.focus();}catch(_){}},60);
    });
  }

  // ------------------------------------------------------------ override page
  function page(){return $('view-override');}
  function who(){var p=prof()||{};return p.name||p.staffId||'';}
  function build(){
    var v=page();if(!v)return;
    if(!isAdmin()){v.innerHTML='<div class="rt-ov-wrap"><div class="rt-ov-card"><b>Akses Admin / Owner sahaja.</b></div></div>';return;}
    v.innerHTML=
      '<div class="rt-ov-wrap">'+
        '<div class="rt-ov-head"><div class="rt-ov-eyebrow">ADMIN / OWNER SAHAJA</div><h3>Override / Audit</h3>'+
        '<p>Pembetulan rekod dengan jejak audit. Tiada rekod dipadam terus: ia diarkibkan atau dibatalkan, dengan sebab, dan boleh disemak semula.</p></div>'+
        '<div class="rt-ov-card" id="rtOvStatus"></div>'+
        '<div class="rt-ov-card"><div class="rt-ov-card-title">Arkib / Batal Rekod</div>'+
          '<div class="rt-ov-tabs" id="rtOvTabs" role="tablist">'+Object.keys(ENT).map(function(k){return '<button type="button" role="tab" data-ov-tab="'+k+'">'+esc(ENT[k].label)+'</button>';}).join('')+'</div>'+
          '<div class="rt-ov-search"><input id="rtOvSearch" type="search" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" placeholder="Cari…">'+
          '<label class="rt-ov-check" id="rtOvArchWrap"><input type="checkbox" id="rtOvArch"> Tunjuk yang sudah diarkib</label></div>'+
          '<div id="rtOvList" class="rt-ov-list"></div></div>'+
        '<div class="rt-ov-card"><div class="rt-ov-card-title">Aktiviti Override terkini</div><div id="rtOvRecent" class="rt-ov-recent"></div>'+
          '<div class="rt-ov-links"><button type="button" class="rt-btn rt-btn-secondary" data-ov-go="audit">LIHAT SEMUA LOG</button></div></div>'+
        '<div class="rt-ov-card rt-ov-row2"><div><b>Sejarah Jualan &amp; Void</b><small>Semak invois, cetak semula atau VOID dengan sebab.</small></div>'+
          '<button type="button" class="rt-btn rt-btn-dark" data-ov-go="history">BUKA REKOD</button></div>'+
      '</div>';
    paintPage();syncTabs();loadList();loadRecent();
  }
  function paintPage(){
    var box=$('rtOvStatus');if(!box)return;
    var on=!!st.sess;
    var notReady=st.ready==='no';
    var html;
    if(on){
      html='<div class="rt-ov-state is-on"><span class="rt-ov-dot"></span><div><b>Override AKTIF</b><small>Baki <span id="rtOvLeft">'+clock(st.sess.exp-Date.now())+'</span> · '+esc(who())+'</small><small class="rt-ov-reason">Sebab: '+esc(st.sess.reason)+'</small></div></div>'+
        '<button type="button" class="rt-btn rt-btn-dark" data-ov-go="end">TAMATKAN</button>';
    }else{
      html='<div class="rt-ov-state"><span class="rt-ov-dot"></span><div><b>Override tidak aktif</b><small>Aktifkan dengan PIN anda dan sebab. Ia tamat sendiri dalam 5–30 minit.</small></div></div>'+
        '<button type="button" class="rt-btn rt-btn-primary" data-ov-go="begin">AKTIFKAN OVERRIDE</button>';
    }
    if(notReady)html+='<div class="rt-ov-warn rt-ov-warn-wide">'+esc(CODES.NOT_INSTALLED)+'</div>';
    if(box.getAttribute('data-sig')!==html){box.innerHTML=html;box.setAttribute('data-sig',html);}
    else{var l=$('rtOvLeft');if(l&&st.sess)l.textContent=clock(st.sess.exp-Date.now());}
  }
  function syncTabs(){
    Array.prototype.forEach.call(document.querySelectorAll('#rtOvTabs [data-ov-tab]'),function(b){
      var on=b.getAttribute('data-ov-tab')===st.tab;b.classList.toggle('active',on);b.setAttribute('aria-selected',on?'true':'false');
    });
    var w=$('rtOvArchWrap');if(w)w.classList.toggle('hidden',st.tab==='JOB_CARD');
    var s=$('rtOvSearch');if(s&&s.value!==st.q)s.value=st.q;
  }
  function rows(r){if(r&&r.error)throw r.error;return (r&&r.data)||[];}
  function platePattern(q){var c=String(q).toUpperCase().match(/[A-Z]+|[0-9]+/g)||[];return c.length?'%'+c.map(likeEsc).join('%')+'%':'';}
  function uniq(lists){var seen={},out=[];lists.forEach(function(l){l.forEach(function(x){if(x&&!seen[x.id]){seen[x.id]=1;out.push(x);}});});return out;}
  function fetchRows(){
    var c=sb(),co=(prof()||{}).companyId,q=st.q.trim(),e=st.tab,LIM=60;
    if(!c||!co)return Promise.reject(new Error('Failed to fetch'));
    function base(table,cols){return c.from(table).select(cols).eq('company_id',co);}
    var like=q?'%'+likeEsc(q)+'%':'';
    var jobs;
    if(e==='CUSTOMER'){
      var d=q.replace(/\D/g,'');
      var phoneOnly=q&&/^[\d\s+\-().]+$/.test(q)&&d.length>=3;
      var cq=base('customers','id,name,phone,customer_code,active');
      cq=phoneOnly?cq.ilike('phone','%'+d+'%'):(q?cq.ilike('name',like):cq);
      jobs=[Promise.resolve(cq.order('name',{ascending:true}).limit(LIM)).then(rows)];
    }else if(e==='VEHICLE'){
      var vq=base('vehicles','id,customer_id,plate_no,brand,model,active');
      var pat=platePattern(q);if(pat)vq=vq.ilike('plate_no',pat);
      jobs=[Promise.resolve(vq.order('plate_no',{ascending:true}).limit(LIM)).then(rows)];
    }else if(e==='PRODUCT'){
      var a=base('products','id,sku,name,category,active'),b=base('products','id,sku,name,category,active');
      if(q){jobs=[Promise.resolve(a.ilike('sku',like).order('sku',{ascending:true}).limit(LIM)).then(rows),Promise.resolve(b.ilike('name',like).order('sku',{ascending:true}).limit(LIM)).then(rows)];}
      else jobs=[Promise.resolve(a.order('sku',{ascending:true}).limit(LIM)).then(rows)];
    }else if(e==='SUPPLIER'){
      var sq=base('suppliers','id,name,phone,active');if(q)sq=sq.ilike('name',like);
      jobs=[Promise.resolve(sq.order('name',{ascending:true}).limit(LIM)).then(rows)];
    }else{
      var jq=base('job_cards','id,job_no,status,customer_id,vehicle_id,actual_total,estimated_total,created_at');if(q)jq=jq.ilike('job_no','%'+likeEsc(q.toUpperCase())+'%');
      jobs=[Promise.resolve(jq.order('created_at',{ascending:false}).limit(LIM)).then(rows)];
    }
    return Promise.all(jobs).then(function(l){
      var list=uniq(l);
      if(e!=='JOB_CARD'&&!st.archived)list=list.filter(function(x){return x.active!==false;});
      list=list.slice(0,30);
      return decorate(e,list);
    });
  }
  // names for vehicles / job cards, paid flag for job cards (best effort: never blocks the list)
  function decorate(e,list){
    var c=sb(),co=prof().companyId;
    function ids(k){var s={};list.forEach(function(x){if(x[k])s[x[k]]=1;});return Object.keys(s);}
    function soft(p){return Promise.resolve(p).then(function(r){return rows(r);}).catch(function(){return [];});}
    if(e==='VEHICLE'||e==='JOB_CARD'){
      var cids=ids('customer_id'),vids=ids('vehicle_id'),jids=e==='JOB_CARD'?list.map(function(x){return x.id;}):[];
      return Promise.all([
        cids.length?soft(c.from('customers').select('id,name').eq('company_id',co).in('id',cids)):[],
        vids.length?soft(c.from('vehicles').select('id,plate_no').eq('company_id',co).in('id',vids)):[],
        jids.length?soft(c.from('invoices').select('job_card_id').eq('company_id',co).eq('status','PAID').eq('payment_status','PAID').in('job_card_id',jids)):[]
      ]).then(function(x){
        var cm={},vm={},pm={};x[0].forEach(function(r){cm[r.id]=r.name;});x[1].forEach(function(r){vm[r.id]=r.plate_no;});x[2].forEach(function(r){pm[r.job_card_id]=1;});
        list.forEach(function(r){r._owner=cm[r.customer_id]||'';r._plate=vm[r.vehicle_id]||'';r._paid=!!pm[r.id];});
        return list;
      });
    }
    return Promise.resolve(list);
  }
  var JOB_LABEL={OPEN:'Baru',IN_PROGRESS:'Sedang dibaiki',WAITING_PARTS:'Tunggu barang',COMPLETED:'Siap',CLOSED:'Ditutup',CANCELLED:'Dibatalkan'};
  function describe(e,r){
    if(e==='CUSTOMER')return {title:r.name||'-',sub:[r.phone,r.customer_code].filter(Boolean).join(' · ')};
    if(e==='VEHICLE')return {title:r.plate_no||'-',sub:[[r.brand,r.model].filter(Boolean).join(' '),r._owner].filter(Boolean).join(' · ')};
    if(e==='PRODUCT')return {title:r.name||r.sku||'-',sub:[r.sku,r.category].filter(Boolean).join(' · ')};
    if(e==='SUPPLIER')return {title:r.name||'-',sub:r.phone||''};
    var tot=Number(r.actual_total||r.estimated_total||0);
    return {title:r.job_no||'-',sub:[r._plate,r._owner,tot?'RM '+tot.toFixed(2):''].filter(Boolean).join(' · ')};
  }
  function rowHtml(e,r){
    var d=describe(e,r),chip='',btn='';
    if(e==='JOB_CARD'){
      var s=String(r.status||'').toUpperCase();
      chip='<span class="rt-ov-chip '+(s==='CANCELLED'?'is-off':'')+'">'+esc(r._paid?'Dibayar':(JOB_LABEL[s]||s||'-'))+'</span>';
      if(s!=='CANCELLED'&&!r._paid)btn='<button type="button" class="rt-btn rt-btn-secondary rt-ov-act" data-ov-act="CANCEL" data-id="'+esc(r.id)+'">BATAL JOB</button>';
    }else{
      var off=r.active===false;
      chip='<span class="rt-ov-chip '+(off?'is-off':'is-on')+'">'+(off?'DIARKIB':'AKTIF')+'</span>';
      btn=off?'<button type="button" class="rt-btn rt-btn-secondary rt-ov-act" data-ov-act="RESTORE" data-id="'+esc(r.id)+'">PULIHKAN</button>'
             :'<button type="button" class="rt-btn rt-btn-secondary rt-ov-act" data-ov-act="ARCHIVE" data-id="'+esc(r.id)+'">ARKIB</button>';
    }
    return '<div class="rt-ov-item"><div class="rt-ov-main"><b>'+esc(d.title)+'</b><small>'+esc(d.sub)+'</small></div>'+chip+btn+'</div>';
  }
  function paintList(){
    var box=$('rtOvList');if(!box)return;
    if(st.loading){box.innerHTML='<div class="rt-ov-empty">Memuatkan…</div>';return;}
    if(st.error){box.innerHTML='<div class="rt-ov-empty is-err">'+esc(st.error)+'</div>';return;}
    if(!st.rows.length){box.innerHTML='<div class="rt-ov-empty">Tiada rekod'+(st.q?' untuk "'+esc(st.q)+'"':'')+'.</div>';return;}
    box.innerHTML=st.rows.map(function(r){return rowHtml(st.tab,r);}).join('');
  }
  function loadList(){
    var n=++st.req;st.loading=true;st.error='';paintList();
    fetchRows().then(function(l){if(n!==st.req)return;st.rows=l;st.loading=false;paintList();},function(e){if(n!==st.req)return;st.rows=[];st.loading=false;st.error='Tidak dapat memuatkan senarai: '+msgOf(e);paintList();});
  }
  function loadRecent(){
    var box=$('rtOvRecent');if(!box)return;
    var av=window.rtAuditView;
    if(!av||typeof av.fetch!=='function'){box.innerHTML='<div class="rt-ov-empty">Log tidak tersedia.</div>';return;}
    box.innerHTML='<div class="rt-ov-empty">Memuatkan…</div>';
    av.fetch({group:'override',limit:8}).then(function(res){
      var b=$('rtOvRecent');if(!b)return;
      if(!res.rows.length){b.innerHTML='<div class="rt-ov-empty">Belum ada aktiviti Override.</div>';return;}
      b.innerHTML=res.rows.map(function(r){
        return '<div class="rt-ov-log"><span class="rt-ov-log-when">'+esc(av.when(r.created_at))+'</span><b>'+esc(av.actionLabel(r.action))+'</b>'+
          '<span class="rt-ov-log-who">'+esc(av.actor(r))+'</span><small>'+esc(av.summary(r))+'</small></div>';
      }).join('');
    },function(e){var b=$('rtOvRecent');if(b)b.innerHTML='<div class="rt-ov-empty is-err">'+esc(msgOf(e))+'</div>';});
  }
  function afterChange(e){
    if(e==='CUSTOMER'&&typeof window.rtLoadPosCustomers==='function')try{window.rtLoadPosCustomers();}catch(_){}
    if(e==='PRODUCT'&&Array.isArray(window.posProducts)){/* POS reloads active items next time it opens */}
  }
  function doAction(kind,id){
    var e=st.tab,r=st.rows.filter(function(x){return x.id===id;})[0];
    if(!r)return;
    var d=describe(e,r),what=ENT[e].one;
    var spec={
      ARCHIVE:{title:'Arkibkan '+what+'?',button:'ARKIBKAN',note:'Rekod TIDAK dipadam. Ia hanya disembunyikan daripada senarai dan pilihan, dan boleh dipulihkan di sini. Jualan dan sejarah lama tidak berubah.'},
      RESTORE:{title:'Pulihkan '+what+'?',button:'PULIHKAN',note:'Rekod akan muncul semula dalam senarai dan pilihan.'},
      CANCEL:{title:'Batalkan Job Card?',button:'BATALKAN JOB',note:'Job akan ditanda DIBATALKAN dan hilang daripada papan bengkel. Job yang sudah dibayar tidak boleh dibatalkan (guna VOID invois).'}
    }[kind];
    if(!spec)return;
    ensure({title:'Aktifkan Override',message:'Untuk '+spec.button.toLowerCase()+' "'+d.title+'", Override mesti diaktifkan dahulu.'}).then(function(){
      return confirmAction({title:spec.title,eyebrow:'OVERRIDE · '+ENT[e].label.toUpperCase(),label:d.title,sub:d.sub,note:spec.note,button:spec.button});
    }).then(function(reason){
      if(!reason)return;
      return act(e,id,kind,reason).then(function(res){
        toast((res&&res.label?res.label+': ':'')+({ARCHIVE:'diarkibkan',RESTORE:'dipulihkan',CANCEL:'Job dibatalkan'}[kind])+'. Direkodkan dalam log.','success');
        afterChange(e);loadList();loadRecent();
      });
    }).catch(function(err){
      if(err&&err.rtSilent)return;
      toast(msgOf(err),'error');
      if(codeOf(err).indexOf('OVERRIDE_')===0)paintPage();
      else loadList();
    });
  }
  function onClick(ev){
    var t=ev.target&&ev.target.closest?ev.target.closest('[data-ov-go],[data-ov-act],[data-ov-tab]'):null;
    if(!t||!page()||!page().contains(t))return;
    var go=t.getAttribute('data-ov-go'),a=t.getAttribute('data-ov-act'),tab=t.getAttribute('data-ov-tab');
    if(tab){st.tab=tab;st.q='';st.archived=false;var cb=$('rtOvArch');if(cb)cb.checked=false;syncTabs();loadList();return;}
    if(a){doAction(a,t.getAttribute('data-id'));return;}
    if(go==='begin')ensure({title:'Aktifkan Override'}).catch(function(e){if(!(e&&e.rtSilent))toast(msgOf(e),'error');});
    else if(go==='end')end('user').then(function(ok){toast(ok?'Override ditamatkan.':'Override ditamatkan di tablet ini. Sesi di pelayan tamat sendiri.','success');});
    else if(go==='audit'&&typeof window.switchView==='function')window.switchView('audit');
    else if(go==='history'&&typeof window.rtOpenPosHistory==='function')window.rtOpenPosHistory(true);
  }
  function onInput(ev){
    var t=ev.target;if(!t||!page()||!page().contains(t))return;
    if(t.id==='rtOvSearch'){st.q=t.value;clearTimeout(st.timer);st.timer=setTimeout(loadList,280);}
    else if(t.id==='rtOvArch'){st.archived=!!t.checked;loadList();}
  }
  function openPage(){
    if(!isAdmin()){toast('Akses Admin sahaja','error');return;}
    if(typeof window.switchView==='function')window.switchView('override');
  }
  // called by switchView('override')
  window.rtLoadOverride=function(){
    st.tab='CUSTOMER';st.q='';st.archived=false;
    build();
    ready().then(paintPage,function(){});
  };

  // ------------------------------------------------------------ wiring
  window.rtOverride={status:status,ensure:ensure,begin:begin,end:end,act:act,openPage:openPage,ready:ready,message:msgOf};
  window.rtOverrideBeforeLogout=function(){
    if(!st.sess)return Promise.resolve();
    return Promise.race([end('user'),new Promise(function(r){setTimeout(r,2000);})]);
  };
  document.addEventListener('click',onClick);
  document.addEventListener('input',onInput);
  document.addEventListener('change',onInput);
  function init(){
    st.sess=loadSess();
    if(st.sess)startTick();
    paint();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
  // the profile arrives after login: pick up a session that survived a page refresh
  setInterval(function(){if(!st.sess&&prof()){var s=loadSess();if(s){st.sess=s;startTick();paint();}}},3000);
})();
