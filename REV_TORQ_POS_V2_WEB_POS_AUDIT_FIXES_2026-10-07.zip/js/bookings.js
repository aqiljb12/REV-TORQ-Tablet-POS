// REV TORQ POS v1.0.1 — Workshop Booking administration
(function(){
'use strict';

const sb=()=>window.supabaseClient;
const esc=v=>String(v??'').replace(/[&<>'"]/g,m=>({ '&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;' }[m]));
const state={rows:[],filter:'NEW',search:'',busy:new Set(),wired:false};
const statusLabel=s=>({NEW:'Menunggu',CONFIRMED:'Disahkan',ARRIVED:'Tiba',CONVERTED_TO_JOB:'Job Dibuka',COMPLETED:'Selesai',CANCELLED:'Dibatalkan',NO_SHOW:'Tidak Hadir'}[String(s||'').toUpperCase()]||String(s||'-'));
const todayMY=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kuala_Lumpur',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const toast=(msg,type='info')=>{ if(typeof window.showToast==='function') window.showToast(msg,type); else alert(msg); };

function companyId(){
  const p=window.currentProfile||window.currentUserProfile||{};
  return p.companyId||p.company_id||null;
}

function formatDate(v){
  if(!v)return '-';
  try{return new Intl.DateTimeFormat('ms-MY',{timeZone:'Asia/Kuala_Lumpur',day:'2-digit',month:'short',year:'numeric'}).format(new Date(`${v}T00:00:00+08:00`));}
  catch(_){return String(v);}
}
function formatTime(v){return v?String(v).slice(0,5):'-';}
function statusClass(s){
  s=String(s||'').toUpperCase();
  if(s==='NEW') return 'bg-amber-100 text-amber-700';
  if(s==='CONFIRMED') return 'bg-emerald-100 text-emerald-700';
  if(s==='COMPLETED') return 'bg-indigo-100 text-indigo-700';
  if(s==='CANCELLED'||s==='NO_SHOW') return 'bg-red-100 text-red-700';
  return 'bg-slate-100 text-slate-700';
}
function errorMessage(error){
  const raw=String(error?.message||error||'').toUpperCase();
  const map=[
    ['BOOKING_CANCELLED','Booking ini sudah dibatalkan.'],
    ['BOOKING_COMPLETED','Booking ini sudah selesai.'],
    ['BOOKING_ADMIN_REQUIRED','Hanya Owner / Super Admin / Admin boleh urus booking.'],
    ['STAFF_NOT_FOUND','Akaun staff tidak ditemui atau tidak aktif.'],
    ['BOOKING_CUSTOMER_VEHICLE_REQUIRED','Booking ini tiada pautan customer atau motor yang sah.'],
    ['BOOKING_NOT_FOUND','Booking tidak ditemui.'],
    ['BOOKING_NOT_PENDING','Booking ini bukan lagi dalam status menunggu.'],
    ['BOOKING_FULL','Kapasiti booking pada tarikh itu sudah penuh.'],
    ['BOOKING_DUPLICATE','Customer/motor ini sudah ada booking pada slot tersebut.'],
    ['BOOKING_TIME_PAST','Tarikh atau masa baru sudah lepas.'],
    ['BOOKING_SLOT_REQUIRED','Tarikh dan masa diperlukan.'],
    ['REJECTION_REASON_REQUIRED','Sebab penolakan diperlukan.'],
    ['COMPANY_MISMATCH','Booking ini bukan milik company semasa.'],
    ['WORKSHOP_BOOKING_REQUIRED','Tindakan ini hanya untuk Workshop Booking.']
  ];
  for(const [key,msg] of map) if(raw.includes(key)) return msg;
  return error?.message||String(error||'Ralat tidak diketahui.');
}

async function fetchRows(){
  const c=companyId();
  if(!c) throw new Error('Company profile belum tersedia.');
  const client=sb();
  if(!client) throw new Error('Supabase client belum tersedia.');

  const r=await client.from('bookings')
    .select('id,booking_no,company_id,customer_id,vehicle_id,customer_name,customer_phone,vehicle_plate,requested_service,preferred_date,preferred_time,notes,source,status,booking_department,created_at,updated_at')
    .eq('company_id',c)
    .eq('booking_department','WORKSHOP')
    .order('preferred_date',{ascending:true})
    .order('preferred_time',{ascending:true})
    .limit(500);
  if(r.error) throw r.error;

  const rows=r.data||[];
  const ids=rows.map(x=>x.id);
  const vehicleIds=[...new Set(rows.map(x=>x.vehicle_id).filter(Boolean))];

  const j=ids.length
    ? await client.from('job_cards').select('id,booking_id,job_no,status').in('booking_id',ids)
    : {data:[],error:null};
  if(j.error) throw j.error;
  const jobs=new Map((j.data||[]).map(x=>[x.booking_id,x]));

  let vehicles=new Map();
  if(vehicleIds.length){
    const v=await client.from('vehicles').select('id,plate_no,make,model').in('id',vehicleIds);
    if(!v.error) vehicles=new Map((v.data||[]).map(x=>[x.id,x]));
  }

  return rows.map(x=>({...x,job:jobs.get(x.id)||null,vehicle:vehicles.get(x.vehicle_id)||null}));
}

function visibleRows(){
  const q=state.search.trim().toLowerCase();
  const day=todayMY();
  return state.rows.filter(r=>{
    const s=String(r.status||'').toUpperCase();
    // Its Job Card was cancelled: nothing left to do, so it belongs to Sejarah, not Disahkan / Hari Ini.
    const jobCancelled=!!r.job&&String(r.job.status||'').toUpperCase()==='CANCELLED';
    const statusOK=state.filter==='HISTORY' ? (jobCancelled||['COMPLETED','CANCELLED','NO_SHOW','ARRIVED','CONVERTED_TO_JOB'].includes(s))
      : jobCancelled ? false
      : state.filter==='TODAY' ? r.preferred_date===day
      : s===state.filter;
    const motor=[r.vehicle?.make,r.vehicle?.model,r.vehicle?.plate_no,r.vehicle_plate].filter(Boolean).join(' ');
    const hay=[r.booking_no,r.customer_name,r.customer_phone,motor,r.requested_service].join(' ').toLowerCase();
    return statusOK && (!q||hay.includes(q));
  });
}

function updateFilterButtons(){
  document.querySelectorAll('[data-booking-filter]').forEach(btn=>{
    const active=btn.dataset.bookingFilter===state.filter;
    btn.classList.toggle('bg-slate-900',active);
    btn.classList.toggle('text-white',active);
    btn.classList.toggle('bg-white',!active);
    btn.classList.toggle('border',!active);
    btn.classList.toggle('border-slate-200',!active);
  });
}

function updatePendingBadge(){
  const count=state.rows.filter(r=>String(r.status||'').toUpperCase()==='NEW').length;
  const el=document.getElementById('bookingPendingBadge');
  if(el) el.textContent=`${count} MENUNGGU`;
}

function renderRows(){
  const body=document.querySelector('#tblBookings tbody');
  if(!body)return;
  const rows=visibleRows();
  if(!rows.length){
    body.innerHTML='<tr><td colspan="8" class="p-10 text-center text-slate-400 text-sm">Tiada booking untuk paparan ini.</td></tr>';
    return;
  }
  body.innerHTML=rows.map(r=>{
    const motor=[r.vehicle?.make,r.vehicle?.model].filter(Boolean).join(' ')||'Motor';
    const plate=r.vehicle?.plate_no||r.vehicle_plate||'-';
    const job=r.job;
    const status=String(r.status||'').toUpperCase();
    const jobHtml=job
      ? `<button type="button" onclick="openBookingJob('${esc(job.job_no)}')" class="text-indigo-700 font-black hover:underline">${esc(job.job_no)}</button><div class="text-[10px] text-slate-400 mt-1">${esc(job.status||'-')}</div>`
      : '<span class="text-xs text-slate-400">Belum dibuka</span>';
    const action=status==='CONFIRMED' && job
      ? `<button type="button" onclick="openBookingJob('${esc(job.job_no)}')" class="px-3 py-2 rounded-lg bg-indigo-50 text-indigo-700 font-black text-xs">Buka Job</button>`
      : `<button type="button" onclick="openBookingDetail('${esc(r.id)}')" class="px-3 py-2 rounded-lg bg-slate-900 text-white font-black text-xs">Butiran</button>`;
    return `<tr class="hover:bg-slate-50/70">
      <td class="p-4"><div class="font-black text-slate-900">${esc(r.booking_no||'-')}</div><div class="text-[10px] text-slate-400 mt-1">${esc(String(r.source||'-').toUpperCase())}</div></td>
      <td class="p-4"><div class="font-bold text-slate-900">${esc(r.customer_name||'-')}</div><div class="text-xs text-slate-500 mt-1">${esc(r.customer_phone||'-')}</div></td>
      <td class="p-4"><div class="font-bold text-slate-900">${esc(motor)}</div><div class="text-xs font-mono text-slate-500 mt-1">${esc(plate)}</div></td>
      <td class="p-4 max-w-[220px]"><div class="font-semibold text-slate-800 truncate" title="${esc(r.requested_service||'')}">${esc(r.requested_service||'-')}</div></td>
      <td class="p-4"><div class="font-bold text-slate-900">${esc(formatDate(r.preferred_date))}</div><div class="text-xs text-slate-500 mt-1">${esc(formatTime(r.preferred_time))}</div></td>
      <td class="p-4"><span class="px-2.5 py-1 rounded-full text-[10px] font-black ${statusClass(status)}">${esc(statusLabel(status))}</span></td>
      <td class="p-4">${jobHtml}</td>
      <td class="p-4 text-right">${action}</td>
    </tr>`;
  }).join('');
}

function rowById(id){return state.rows.find(r=>String(r.id)===String(id))||null;}

function renderDetail(row){
  const el=document.getElementById('bookingDetailContent');
  if(!el)return;
  const status=String(row.status||'').toUpperCase();
  const motor=[row.vehicle?.make,row.vehicle?.model].filter(Boolean).join(' ')||'-';
  const plate=row.vehicle?.plate_no||row.vehicle_plate||'-';
  const job=row.job;
  const item=(label,value)=>`<div class="rounded-xl bg-slate-50 p-3"><div class="text-[10px] uppercase tracking-wide font-black text-slate-400">${esc(label)}</div><div class="text-sm font-bold text-slate-900 mt-1 whitespace-pre-wrap">${esc(value||'-')}</div></div>`;
  let actions='';
  if(status==='NEW'){
    actions=`<div class="mt-5 border-t border-slate-200 pt-5">
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-2">
        <button type="button" onclick="confirmWorkshopBooking('${esc(row.id)}')" class="py-3 rounded-xl bg-emerald-600 text-white text-xs font-black">SAHKAN BOOKING</button>
        <button type="button" onclick="rejectWorkshopBooking('${esc(row.id)}')" class="py-3 rounded-xl bg-red-50 text-red-700 border border-red-200 text-xs font-black">TOLAK</button>
        <button type="button" onclick="document.getElementById('bookingRescheduleBox').classList.toggle('hidden')" class="py-3 rounded-xl bg-white text-slate-700 border border-slate-200 text-xs font-black">UBAH SLOT</button>
      </div>
      <div id="bookingRescheduleBox" class="hidden mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200">
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <label class="text-xs font-bold text-slate-600">Tarikh<input type="date" id="bookingNewDate" value="${esc(row.preferred_date||'')}" class="mt-1 w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-sm"></label>
          <label class="text-xs font-bold text-slate-600">Masa<input type="time" id="bookingNewTime" value="${esc(formatTime(row.preferred_time)==='-'?'':formatTime(row.preferred_time))}" class="mt-1 w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-sm"></label>
        </div>
        <label class="block text-xs font-bold text-slate-600 mt-3">Nota staff<textarea id="bookingSlotNote" rows="2" class="mt-1 w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-sm" placeholder="Contoh: slot dipinda selepas hubungi customer"></textarea></label>
        <button type="button" onclick="rescheduleWorkshopBooking('${esc(row.id)}')" class="mt-3 w-full py-3 rounded-xl bg-slate-900 text-white text-xs font-black">SIMPAN SLOT BARU</button>
      </div>
    </div>`;
  }else if(job){
    actions=`<div class="mt-5 border-t border-slate-200 pt-5"><button type="button" onclick="openBookingJob('${esc(job.job_no)}')" class="w-full py-3 rounded-xl bg-indigo-600 text-white text-xs font-black">BUKA JOB CARD ${esc(job.job_no)}</button></div>`;
  }
  el.innerHTML=`
    <div class="flex items-start justify-between gap-4 mb-4">
      <div><div class="text-[10px] uppercase tracking-wider font-black text-slate-400">Booking</div><div class="text-xl font-black text-slate-900">${esc(row.booking_no||'-')}</div></div>
      <span class="px-3 py-1.5 rounded-full text-[10px] font-black ${statusClass(status)}">${esc(statusLabel(status))}</span>
    </div>
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
      ${item('Customer',row.customer_name)}${item('Telefon',row.customer_phone)}
      ${item('Motor',motor)}${item('Plat',plate)}
      ${item('Servis',row.requested_service)}${item('Slot',`${formatDate(row.preferred_date)} • ${formatTime(row.preferred_time)}`)}
      <div class="sm:col-span-2">${item('Nota',row.notes)}</div>
      <div class="sm:col-span-2">${item('Job Card',job?`${job.job_no} • ${job.status}`:'Belum dibuka')}</div>
    </div>${actions}`;
}

function openModal(){
  const modal=document.getElementById('bookingDetailModal');
  if(!modal)return;
  modal.classList.remove('hidden');
  modal.classList.add('flex');
}

function closeModal(){
  const modal=document.getElementById('bookingDetailModal');
  if(!modal)return;
  modal.classList.add('hidden');
  modal.classList.remove('flex');
}

async function mutate(id,work){
  if(state.busy.has(id))return;
  state.busy.add(id);
  try{return await work();}
  finally{state.busy.delete(id);}
}

async function reloadAndPreserveDetail(id){
  await window.loadBookings();
  const row=rowById(id);
  if(row){renderDetail(row);openModal();}else closeModal();
}

window.loadBookings=async function(){
  try{
    state.rows=await fetchRows();
    updatePendingBadge();
    updateFilterButtons();
    renderRows();
    wireOnce();
    if(window.feather)window.feather.replace();
  }catch(error){
    console.error('REV TORQ BOOKING LOAD',error);
    toast('Booking gagal dimuatkan: '+errorMessage(error),'error');
  }
};

window.openBookingDetail=function(id){
  const row=rowById(id);
  if(!row)return toast('Booking tidak ditemui dalam senarai semasa.','error');
  renderDetail(row);
  openModal();
  if(window.feather)window.feather.replace();
};

window.closeBookingDetail=closeModal;

window.confirmWorkshopBooking=function(id){
  return mutate(id,async()=>{
    try{
      if(!confirm('Sahkan booking ini dan buka Job Card OPEN?'))return;
      const r=await sb().rpc('rt_staff_confirm_workshop_booking',{p_booking_id:id});
      if(r.error)throw r.error;
      toast(`Booking disahkan • ${r.data?.job_no||'Job Card dibuka'}`,'success');
      await reloadAndPreserveDetail(id);
    }catch(error){toast(errorMessage(error),'error');}
  });
};

window.rejectWorkshopBooking=function(id){
  return mutate(id,async()=>{
    try{
      const reason=prompt('Sebab booking ditolak / dibatalkan:');
      if(reason===null)return;
      if(!reason.trim())return toast('Sebab penolakan diperlukan.','error');
      if(!confirm('Batalkan booking ini?'))return;
      const r=await sb().rpc('rt_staff_reject_workshop_booking',{p_booking_id:id,p_reason:reason.trim()});
      if(r.error)throw r.error;
      toast('Booking dibatalkan.','success');
      await reloadAndPreserveDetail(id);
    }catch(error){toast(errorMessage(error),'error');}
  });
};

window.rescheduleWorkshopBooking=function(id){
  return mutate(id,async()=>{
    try{
      const date=document.getElementById('bookingNewDate')?.value||'';
      const time=document.getElementById('bookingNewTime')?.value||'';
      const note=document.getElementById('bookingSlotNote')?.value.trim()||'';
      if(!date||!time)return toast('Pilih tarikh dan masa baru.','error');
      const r=await sb().rpc('rt_staff_reschedule_workshop_booking',{
        p_booking_id:id,
        p_preferred_date:date,
        p_preferred_time:time,
        p_staff_note:note||null
      });
      if(r.error)throw r.error;
      toast('Slot booking dikemas kini. Booking masih menunggu pengesahan.','success');
      await reloadAndPreserveDetail(id);
    }catch(error){toast(errorMessage(error),'error');}
  });
};

window.openBookingJob=function(jobNo){
  if(!jobNo)return;
  window.closeBookingDetail?.();
  window.switchView('jobcard');
  setTimeout(()=>window.editJobCard?.(jobNo),120);
};

function wireOnce(){
  if(state.wired)return;
  state.wired=true;
  const search=document.getElementById('bookingSearch');
  if(search)search.addEventListener('input',()=>{state.search=search.value||'';renderRows();});
  const bar=document.getElementById('bookingFilterBar');
  if(bar)bar.addEventListener('click',e=>{
    const btn=e.target.closest('[data-booking-filter]');
    if(!btn)return;
    state.filter=btn.dataset.bookingFilter||'NEW';
    updateFilterButtons();
    renderRows();
  });
  const modal=document.getElementById('bookingDetailModal');
  if(modal)modal.addEventListener('click',e=>{if(e.target===modal)closeModal();});
}

})();
