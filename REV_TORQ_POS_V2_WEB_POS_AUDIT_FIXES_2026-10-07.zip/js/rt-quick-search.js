/* REV TORQ POS V2 WEB — Carian pantas (quick search).
   One box for plate, phone, customer name, invoice no, job no or product.
   Read-only: it queries existing tables (customers, vehicles, job_cards,
   invoices) and the existing receipt-history RPC under the same RLS as the
   rest of the POS. Products come from the list already loaded for POS.
   Opens from the "Cari" button (sidebar / header) or Cmd/Ctrl+K.
   Plain ES2017 for Safari on iPad. */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  var DEBOUNCE=280;
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
  function num(v){var n=Number(v);return isFinite(n)?n:0;}
  function money(v){return 'RM '+num(v).toFixed(2);}
  function toast(m,t){try{if(window.showToast)window.showToast(m,t||'success');}catch(_){}}
  function feather(){try{if(window.feather)window.feather.replace();}catch(_){}}
  function can(view){return !!document.querySelector('#mainNav [data-view="'+view+'"]');}
  function company(){var p=window.currentProfile||{};return p.companyId||null;}
  function sb(){return window.supabaseClient||null;}
  function likeEsc(s){return String(s).replace(/[\\%_]/g,'\\$&');}
  function rows(r){if(r&&r.error)throw r.error;return (r&&r.data)||[];}
  function safe(p){return Promise.resolve(p).catch(function(e){console.warn('quick search',e&&e.message||e);return [];});}
  function fmtDate(v){
    if(!v)return '';
    try{return new Intl.DateTimeFormat('ms-MY',{timeZone:'Asia/Kuala_Lumpur',day:'2-digit',month:'short',year:'numeric'}).format(new Date(v));}catch(_){return String(v).slice(0,10);}
  }
  var JOB_LABEL={OPEN:'Baru',IN_PROGRESS:'Sedang dibaiki',WAITING_PARTS:'Tunggu barang',COMPLETED:'Siap',CLOSED:'Ditutup',CANCELLED:'Batal'};
  function jobChip(j){
    if(j.paid)return '<span class="rt-qs-chip is-paid">Dibayar</span>';
    var s=String(j.status||'').toUpperCase();
    return '<span class="rt-qs-chip is-'+esc(s.toLowerCase())+'">'+esc(JOB_LABEL[s]||s||'-')+'</span>';
  }
  // "JXX1234", "jxx 1234" and "JXX-1234" all find "JXX 1234".
  function platePattern(q){var c=String(q).toUpperCase().match(/[A-Z]+|[0-9]+/g)||[];return c.length?'%'+c.map(likeEsc).join('%')+'%':'';}
  // customers.phone_normalized holds 60XXXXXXXXX; typed 012-345 6789 -> "12345 6789" part.
  function phoneDigits(q){
    if(!/^\+?[\d\s\-().]+$/.test(String(q).trim()))return ''; // only when the text is a phone number
    var d=String(q).replace(/\D/g,'');if(d.length<4)return '';return /^0/.test(d)?d.slice(1):d;
  }

  // ---------------------------------------------------------------- data
  function findCustomers(c,q){
    var out=[],s=sb();
    var jobs=[];
    if(/[a-z]/i.test(q)&&q.length>=2)jobs.push(safe(s.from('customers').select('id,name,phone,customer_code,active').eq('company_id',c).ilike('name','%'+likeEsc(q)+'%').order('name',{ascending:true}).limit(6).then(rows)));
    var d=phoneDigits(q);
    if(d)jobs.push(Promise.resolve(s.from('customers').select('id,name,phone,customer_code,active').eq('company_id',c).ilike('phone_normalized','%'+d+'%').limit(6)).then(function(r){
      if(r&&r.error)return safe(s.from('customers').select('id,name,phone,customer_code,active').eq('company_id',c).ilike('phone','%'+d+'%').limit(6).then(rows));
      return rows(r);
    }).catch(function(){return [];}));
    return Promise.all(jobs).then(function(lists){
      var seen={};lists.forEach(function(l){l.forEach(function(x){if(!seen[x.id]){seen[x.id]=1;out.push(x);}});});
      return out.filter(function(x){return x.active!==false;}).slice(0,8);
    });
  }
  function findVehicles(c,q){
    var pat=platePattern(q);
    if(!pat||String(q).replace(/[^a-z0-9]/gi,'').length<2)return Promise.resolve([]);
    return safe(sb().from('vehicles').select('id,customer_id,plate_no,brand,model,active').eq('company_id',c).ilike('plate_no',pat).limit(8).then(rows))
      .then(function(l){return l.filter(function(v){return v.active!==false;});});
  }
  function findJobs(c,q,vehicleIds){
    var s=sb(),jobs=[],cols='id,job_no,status,customer_id,vehicle_id,actual_total,estimated_total,created_at';
    if(/\d/.test(q)||/^job/i.test(q))jobs.push(safe(s.from('job_cards').select(cols).eq('company_id',c).ilike('job_no','%'+likeEsc(String(q).toUpperCase())+'%').order('created_at',{ascending:false}).limit(5).then(rows)));
    if(vehicleIds&&vehicleIds.length)jobs.push(safe(s.from('job_cards').select(cols).eq('company_id',c).in('vehicle_id',vehicleIds).order('created_at',{ascending:false}).limit(6).then(rows)));
    return Promise.all(jobs).then(function(lists){
      var seen={},out=[];lists.forEach(function(l){l.forEach(function(x){if(!seen[x.id]&&String(x.status||'').toUpperCase()!=='CANCELLED'){seen[x.id]=1;out.push(x);}});});
      return out.slice(0,6);
    });
  }
  function findInvoices(q,limit){
    if(typeof window.supabaseRpc!=='function')return Promise.resolve([]);
    return safe(window.supabaseRpc('rt_staff_receipt_history',{p_search:q,p_limit:limit||5,p_offset:0}).then(function(d){return Array.isArray(d)?d:[];}));
  }
  function productsList(){
    var a=window.posProducts;
    if(Array.isArray(a)&&a.length)return a.map(function(p){return {sku:p.sku,name:p.name,barcode:p.barcode||'',category:p.category||'',stock:num(p.stock),price:num(p.price!=null?p.price:p.sellPrice),rack:p.rackCode||p.rack_location||''};});
    a=window.rtInventoryCache;
    if(Array.isArray(a))return a.filter(function(p){return p.active!==false;}).map(function(p){return {sku:p.sku,name:p.name,barcode:p.barcode||'',category:p.category||'',stock:num(p.stock),price:num(p.sell_price),rack:p.rack_location||''};});
    return [];
  }
  function findProducts(q){
    var x=String(q).trim().toLowerCase();if(x.length<2)return [];
    var list=productsList(),exact=[],part=[];
    list.forEach(function(p){
      var sku=String(p.sku||'').toLowerCase(),bc=String(p.barcode||'').toLowerCase();
      if(sku===x||bc===x)exact.push(p);
      else if((p.name+' '+p.sku+' '+p.barcode+' '+p.category).toLowerCase().indexOf(x)>=0)part.push(p);
    });
    return exact.concat(part).slice(0,6);
  }
  // Owner names, plates and paid state for job / vehicle rows.
  function enrich(c,vehicles,jobs){
    var s=sb();
    var custIds={},vehIds={},jobIds=jobs.map(function(j){return j.id;});
    vehicles.forEach(function(v){if(v.customer_id)custIds[v.customer_id]=1;});
    jobs.forEach(function(j){if(j.customer_id)custIds[j.customer_id]=1;if(j.vehicle_id)vehIds[j.vehicle_id]=1;});
    vehicles.forEach(function(v){delete vehIds[v.id];});
    var cids=Object.keys(custIds),vids=Object.keys(vehIds);
    return Promise.all([
      cids.length?safe(s.from('customers').select('id,name,phone').eq('company_id',c).in('id',cids).then(rows)):[],
      vids.length?safe(s.from('vehicles').select('id,plate_no,brand,model').eq('company_id',c).in('id',vids).then(rows)):[],
      jobIds.length?safe(s.from('invoices').select('job_card_id').eq('company_id',c).eq('status','PAID').in('job_card_id',jobIds).then(rows)):[]
    ]).then(function(r){
      var cm={},vm={},paid={};
      r[0].forEach(function(x){cm[x.id]=x;});
      vehicles.concat(r[1]).forEach(function(x){vm[x.id]=x;});
      r[2].forEach(function(x){paid[x.job_card_id]=1;});
      vehicles.forEach(function(v){v.owner=cm[v.customer_id]||null;});
      jobs.forEach(function(j){j.owner=cm[j.customer_id]||null;j.vehicle=vm[j.vehicle_id]||null;j.paid=!!paid[j.id];});
    });
  }

  // ---------------------------------------------------------------- UI shell
  var state={req:0,timer:null,last:null,q:''};
  function modal(){return $('rtQsModal');}
  function open(prefill){
    var m=modal();
    if(!m){
      m=document.createElement('div');
      m.id='rtQsModal';m.className='rt-qs-backdrop';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');m.setAttribute('aria-label','Carian pantas');
      m.innerHTML='<div class="rt-qs-panel">'+
        '<div class="rt-qs-bar"><i data-feather="search"></i>'+
        '<input id="rtQsInput" type="search" enterkeyhint="search" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" placeholder="Plat, telefon, nama, no. invois, no. job atau barang">'+
        '<button type="button" class="rt-qs-close" data-qs="close">TUTUP</button></div>'+
        '<div class="rt-qs-body" id="rtQsBody"></div></div>';
      document.body.appendChild(m);
      m.addEventListener('click',onClick);
      var input=m.querySelector('#rtQsInput');
      input.addEventListener('input',function(){schedule(input.value);});
      input.addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();clearTimeout(state.timer);run(input.value);}});
      feather();
    }
    m.hidden=false;document.documentElement.classList.add('rt-qs-open');
    var inp=$('rtQsInput');
    if(typeof prefill==='string'){inp.value=prefill;}
    // Focus inside the tap itself so iPad shows the keyboard.
    try{inp.focus();inp.select();}catch(_){}
    if(inp.value.trim())run(inp.value);else showTips();
  }
  function close(){
    var m=modal();if(!m)return;
    m.hidden=true;document.documentElement.classList.remove('rt-qs-open');
    try{if(document.activeElement)document.activeElement.blur();}catch(_){}
  }
  window.rtOpenQuickSearch=open;
  window.rtCloseQuickSearch=close;
  function body(html){var b=$('rtQsBody');if(b){b.innerHTML=html;b.scrollTop=0;}feather();}
  function showTips(){
    body('<div class="rt-qs-tips"><b>Cari apa sahaja</b><ul>'+
      '<li><span>Plat motor</span><code>JXX1234</code></li>'+
      '<li><span>Telefon</span><code>0123456789</code></li>'+
      '<li><span>No. invois</span><code>INV2610…</code></li>'+
      '<li><span>No. job</span><code>JOB-…</code></li>'+
      '<li><span>Barang / SKU / barcode</span><code>brake pad</code></li></ul>'+
      '<p>Pada iPad dengan papan kekunci: <kbd>⌘</kbd> + <kbd>K</kbd></p></div>');
  }
  function schedule(q){clearTimeout(state.timer);state.timer=setTimeout(function(){run(q);},DEBOUNCE);}

  // ---------------------------------------------------------------- search
  function run(raw){
    var q=String(raw||'').trim();state.q=q;
    var req=++state.req;
    if(q.length<2){showTips();return;}
    var c=company();
    var prods=findProducts(q);
    if(!c||!sb()){render(req,q,{customers:[],vehicles:[],jobs:[],invoices:[],products:prods},false);return;}
    body('<div class="rt-qs-loading">Mencari “'+esc(q)+'”…</div>');
    var invQ=(q.length>=3&&(/\d/.test(q)||/^inv/i.test(q)))?findInvoices(q,5):Promise.resolve([]);
    Promise.all([findCustomers(c,q),findVehicles(c,q),invQ]).then(function(r){
      var customers=r[0],vehicles=r[1],invoices=r[2];
      return findJobs(c,q,vehicles.map(function(v){return v.id;})).then(function(jobs){
        return enrich(c,vehicles,jobs).then(function(){return {customers:customers,vehicles:vehicles,jobs:jobs,invoices:invoices,products:prods};});
      });
    }).then(function(res){render(req,q,res,true);})
      .catch(function(e){if(req===state.req)body('<div class="rt-qs-empty">Carian gagal: '+esc(e&&e.message||e)+'</div>');});
  }
  function render(req,q,res,online){
    if(req!==state.req)return;
    state.last=res;
    var groups=[];
    if(res.vehicles.length)groups.push({key:'veh',title:'MOTOR',html:res.vehicles.map(function(v){
      var model=[v.brand,v.model].filter(Boolean).join(' ');
      return '<button type="button" class="rt-qs-row" data-qs="customer" data-id="'+esc(v.customer_id||'')+'" data-veh="'+esc(v.id)+'">'+
        '<span class="rt-qs-plate">'+esc(v.plate_no||'-')+'</span><span class="rt-qs-main"><b>'+esc(model||'Motor')+'</b><small>'+esc(v.owner?(v.owner.name+(v.owner.phone?' · '+v.owner.phone:'')):'Pemilik tidak dijumpai')+'</small></span><i data-feather="chevron-right"></i></button>';
    }).join('')});
    if(res.customers.length)groups.push({key:'cust',title:'PELANGGAN',html:res.customers.map(function(x){
      return '<button type="button" class="rt-qs-row" data-qs="customer" data-id="'+esc(x.id)+'">'+
        '<span class="rt-qs-avatar">'+esc(String(x.name||'?').trim().charAt(0).toUpperCase())+'</span><span class="rt-qs-main"><b>'+esc(x.name||'-')+'</b><small>'+esc([x.phone,x.customer_code].filter(Boolean).join(' · '))+'</small></span><i data-feather="chevron-right"></i></button>';
    }).join('')});
    if(res.jobs.length)groups.push({key:'job',title:'JOB CARD',html:res.jobs.map(jobRow).join('')});
    if(res.invoices.length)groups.push({key:'inv',title:'RESIT',html:res.invoices.map(invoiceRow).join('')});
    if(res.products.length)groups.push({key:'prod',title:'BARANG',html:res.products.map(productRow).join('')});
    // Put what the text most looks like first.
    var first=/^inv/i.test(q)?'inv':/^job/i.test(q)?'job':(res.products.length&&res.products[0]&&(String(res.products[0].sku).toLowerCase()===q.toLowerCase()||String(res.products[0].barcode).toLowerCase()===q.toLowerCase()))?'prod':null;
    if(first)groups.sort(function(a,b){return (a.key===first?0:1)-(b.key===first?0:1);});
    if(!groups.length){body('<div class="rt-qs-empty"><b>Tiada padanan untuk “'+esc(q)+'”.</b><span>Cuba plat tanpa jarak (JXX1234), nombor telefon penuh atau nama barang.</span>'+(online?'':'<span>Sesi belum sedia — hanya barang dicari.</span>')+'</div>');return;}
    body(groups.map(function(g){return '<section class="rt-qs-group"><h4>'+g.title+'</h4>'+g.html+'</section>';}).join(''));
  }
  function jobRow(j){
    var plate=j.vehicle?j.vehicle.plate_no:'',status=String(j.status||'').toUpperCase();
    var actions='';
    if(status==='COMPLETED'&&!j.paid&&can('pos'))actions+='<button type="button" class="rt-qs-btn pos" data-qs="jobpos" data-job="'+esc(j.job_no)+'">BAWA KE POS</button>';
    if(can('jobcard')&&!j.paid)actions+='<button type="button" class="rt-qs-btn" data-qs="jobopen" data-job="'+esc(j.job_no)+'">BUKA</button>';
    return '<div class="rt-qs-row is-static"><span class="rt-qs-main"><b>'+esc(j.job_no)+(plate?' · '+esc(plate):'')+'</b><small>'+esc([j.owner&&j.owner.name,fmtDate(j.created_at),money(j.actual_total!=null?j.actual_total:j.estimated_total)].filter(Boolean).join(' · '))+'</small></span>'+jobChip(j)+(actions?'<span class="rt-qs-actions">'+actions+'</span>':'')+'</div>';
  }
  function invoiceRow(r){
    var voided=String(r.status||'').toUpperCase()==='VOID';
    return '<button type="button" class="rt-qs-row" data-qs="invoice" data-id="'+esc(r.id)+'"'+(voided?' data-void="1"':'')+'>'+
      '<span class="rt-qs-main"><b>'+esc(r.invoice_no||'-')+'</b><small>'+esc([r.customer_name,r.vehicle_plate,fmtDate(r.created_at)].filter(Boolean).join(' · '))+'</small></span>'+
      (voided?'<span class="rt-qs-chip is-void">VOID</span>':'<span class="rt-qs-amount">'+money(r.total)+'</span>')+'<i data-feather="chevron-right"></i></button>';
  }
  function productRow(p){
    var st=p.stock<=0?'<span class="rt-qs-chip is-out">Habis</span>':'<span class="rt-qs-chip is-stock">Stok '+esc(p.stock)+'</span>';
    var add=can('pos')&&p.stock>0?'<button type="button" class="rt-qs-btn pos" data-qs="addcart" data-sku="'+esc(p.sku)+'">+ TROLI</button>':'';
    return '<div class="rt-qs-row is-static"><span class="rt-qs-main"><b>'+esc(p.name||p.sku)+'</b><small>'+esc([p.sku,p.rack?('Rak '+p.rack):'',p.category].filter(Boolean).join(' · '))+'</small></span>'+st+'<span class="rt-qs-amount">'+money(p.price)+'</span>'+(add?'<span class="rt-qs-actions">'+add+'</span>':'')+'</div>';
  }

  // ---------------------------------------------------------------- customer card
  function openCustomer(id,vehicleId){
    var c=company();if(!id||!c||!sb())return;
    var req=++state.req;
    body('<div class="rt-qs-loading">Memuatkan pelanggan…</div>');
    var s=sb();
    s.from('customers').select('id,name,phone,customer_code,active').eq('company_id',c).eq('id',id).maybeSingle().then(function(r){
      if(r.error)throw r.error;if(!r.data)throw new Error('Pelanggan tidak dijumpai.');
      var cust=r.data;
      return Promise.all([
        safe(s.from('vehicles').select('id,plate_no,brand,model,active').eq('company_id',c).eq('customer_id',id).then(rows)),
        safe(s.from('job_cards').select('id,job_no,status,customer_id,vehicle_id,actual_total,estimated_total,created_at').eq('company_id',c).eq('customer_id',id).order('created_at',{ascending:false}).limit(6).then(rows)),
        findInvoices(cust.phone||cust.name,20)
      ]).then(function(x){
        var vehicles=x[0].filter(function(v){return v.active!==false;}),jobs=x[1].filter(function(j){return String(j.status||'').toUpperCase()!=='CANCELLED';});
        // The receipt search also matches similar names/numbers: keep this customer's own.
        var invoices=x[2].filter(function(i){return cust.phone?String(i.customer_phone||'')===String(cust.phone):String(i.customer_name||'')===String(cust.name);}).slice(0,6);
        return enrich(c,vehicles,jobs).then(function(){return {cust:cust,vehicles:vehicles,jobs:jobs,invoices:invoices};});
      });
    }).then(function(d){
      if(req!==state.req)return;
      state.customer=d;state.customer.vehicleId=vehicleId||'';
      var cu=d.cust,wa=typeof window.rtWhatsAppNumber==='function'?window.rtWhatsAppNumber(cu.phone):'';
      var html='<button type="button" class="rt-qs-back" data-qs="back"><i data-feather="chevron-left"></i>Hasil carian</button>'+
        '<div class="rt-qs-cust"><span class="rt-qs-avatar big">'+esc(String(cu.name||'?').trim().charAt(0).toUpperCase())+'</span><div><h3>'+esc(cu.name||'-')+'</h3><small>'+esc([cu.phone,cu.customer_code].filter(Boolean).join(' · '))+'</small></div></div>'+
        '<div class="rt-qs-quick">'+
          (can('pos')?'<button type="button" class="rt-qs-btn pos big" data-qs="sell"><i data-feather="shopping-cart"></i>JUAL KEPADA PELANGGAN INI</button>':'')+
          (can('jobcard')?'<button type="button" class="rt-qs-btn big" data-qs="newjob"><i data-feather="file-plus"></i>BUKA JOB BARU</button>':'')+
          (wa?'<a class="rt-qs-btn wa big" href="https://wa.me/'+esc(wa)+'" target="_blank" rel="noopener"><i data-feather="message-circle"></i>WHATSAPP</a>':'')+
          (cu.phone?'<a class="rt-qs-btn big" href="tel:'+esc(String(cu.phone).replace(/[^\d+]/g,''))+'"><i data-feather="phone"></i>TELEFON</a>':'')+
        '</div>'+
        '<section class="rt-qs-group"><h4>MOTOR ('+d.vehicles.length+')</h4>'+(d.vehicles.length?'<div class="rt-veh-list">'+d.vehicles.map(function(v){return '<span class="rt-veh-chip'+(v.id===vehicleId?' is-hit':'')+'">'+esc([v.plate_no,[v.brand,v.model].filter(Boolean).join(' ')].filter(Boolean).join(' - '))+'</span>';}).join('')+'</div>':'<div class="rt-qs-none">Tiada motor berdaftar.</div>')+'</section>'+
        '<section class="rt-qs-group"><h4>JOB TERKINI</h4>'+(d.jobs.length?d.jobs.map(jobRow).join(''):'<div class="rt-qs-none">Tiada job.</div>')+'</section>'+
        '<section class="rt-qs-group"><h4>RESIT TERKINI</h4>'+(d.invoices.length?d.invoices.map(invoiceRow).join(''):'<div class="rt-qs-none">Tiada resit.</div>')+'</section>';
      body(html);
    }).catch(function(e){if(req===state.req)body('<button type="button" class="rt-qs-back" data-qs="back"><i data-feather="chevron-left"></i>Hasil carian</button><div class="rt-qs-empty">'+esc(e&&e.message||e)+'</div>');});
  }

  // ---------------------------------------------------------------- actions
  function onClick(e){
    var m=modal();
    if(e.target===m){close();return;}
    var el=e.target.closest?e.target.closest('[data-qs]'):null;if(!el)return;
    var a=el.getAttribute('data-qs');
    if(a==='close')close();
    else if(a==='back'){state.customer=null;var q=$('rtQsInput').value;if(state.last&&q.trim()===state.q){state.req++;render(state.req,state.q,state.last,true);}else run(q);}
    else if(a==='customer')openCustomer(el.getAttribute('data-id'),el.getAttribute('data-veh')||'');
    else if(a==='invoice'){
      if(el.getAttribute('data-void')){toast('Invois ini VOID.','error');return;}
      close();if(typeof window.rtReprintInvoice==='function')window.rtReprintInvoice(el.getAttribute('data-id'));
    }
    else if(a==='jobpos'){close();if(typeof window.rtSelectJobIntoPOS==='function')window.rtSelectJobIntoPOS(el.getAttribute('data-job'));}
    else if(a==='jobopen'){close();if(typeof window.switchView==='function')window.switchView('jobcard');if(typeof window.editJobCard==='function')window.editJobCard(el.getAttribute('data-job'));}
    else if(a==='addcart'){
      var sku=el.getAttribute('data-sku');close();
      if(window.__rtActiveView!=='pos'&&typeof window.switchView==='function')window.switchView('pos');
      if(typeof window.posAddToCart==='function'){window.posAddToCart(sku);toast('Ditambah ke troli.','success');}
    }
    else if(a==='sell')sellTo();
    else if(a==='newjob')newJobFor();
  }
  function sellTo(){
    var d=state.customer;if(!d)return;
    if(window.rtActiveJob){toast('Troli sedang guna Job Card. Selesaikan atau kosongkan dahulu.','error');return;}
    close();
    if(typeof window.switchView==='function')window.switchView('pos');
    if(typeof window.rtPosSelectCustomer==='function')window.rtPosSelectCustomer({id:d.cust.id,name:d.cust.name,phone:d.cust.phone||''});
    toast('Pelanggan dipilih: '+d.cust.name,'success');
  }
  function newJobFor(){
    var d=state.customer;if(!d||typeof window.openNewJobCard!=='function')return;
    var vid=d.vehicleId||(d.vehicles.length===1?d.vehicles[0].id:'');
    close();
    if(typeof window.switchView==='function')window.switchView('jobcard');
    Promise.resolve(window.openNewJobCard()).then(function(){
      var cs=$('jcCustomerSelect');if(!cs)return;
      if(![].some.call(cs.options,function(o){return o.value===String(d.cust.id);})){var o=document.createElement('option');o.value=d.cust.id;o.textContent=d.cust.name+(d.cust.phone?' ('+d.cust.phone+')':'');o.setAttribute('data-name',d.cust.name||'');cs.appendChild(o);}
      cs.value=String(d.cust.id);
      if(typeof window.loadCustomerVehiclesForJC==='function')return Promise.resolve(window.loadCustomerVehiclesForJC(d.cust.id)).then(function(){var vs=$('jcVehicleSelect');if(vs&&vid)vs.value=vid;});
    }).catch(function(e){toast('Job Card gagal dibuka: '+(e&&e.message||e),'error');});
  }

  // ---------------------------------------------------------------- triggers
  document.addEventListener('keydown',function(e){
    var k=String(e.key||'').toLowerCase();
    if((e.metaKey||e.ctrlKey)&&k==='k'){
      if(!company())return;
      e.preventDefault();var m=modal();if(m&&!m.hidden)close();else open();
      return;
    }
    if(k==='escape'){var mm=modal();if(mm&&!mm.hidden){e.preventDefault();if(state.customer&&$('rtQsBody').querySelector('[data-qs="back"]')){state.customer=null;run($('rtQsInput').value);}else close();}}
  },true);
})();
