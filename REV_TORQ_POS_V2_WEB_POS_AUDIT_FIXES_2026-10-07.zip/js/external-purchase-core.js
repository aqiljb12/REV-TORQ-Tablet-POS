/* REV TORQ POS V2 — external purchase core helpers */
(function(){
'use strict';

function num(v){
  const n=Number(v);
  return Number.isFinite(n)?n:0;
}
function clean(v){return String(v??'').trim();}
function money(v){return Math.round(num(v)*100)/100;}

function normalizeDraft(input={}){
  const name=clean(input.name);
  const sku=clean(input.sku).toUpperCase();
  const sourceName=clean(input.sourceName);
  const category=(clean(input.category)||'BARANG LUAR').toUpperCase();
  const qtyBuy=Math.floor(num(input.qtyBuy));
  const qtyUse=Math.floor(num(input.qtyUse));
  const cost=money(input.cost);
  const sell=money(input.sell);
  const productId=clean(input.productId)||null;

  if(!productId&&!name)throw new Error('Nama barang diperlukan.');
  if(qtyBuy<=0)throw new Error('Qty beli mesti sekurang-kurangnya 1.');
  if(qtyUse<0)throw new Error('Qty guna sekarang tidak sah.');
  if(qtyUse>qtyBuy)throw new Error('Qty guna sekarang melebihi qty yang dibeli.');
  if(cost<0||sell<0)throw new Error('Harga tidak sah.');

  return {
    productId,name,sku,sourceName,category,qtyBuy,qtyUse,cost,sell,
    stockRemainder:qtyBuy-qtyUse
  };
}

function mergeCart(cart,product,qtyUse,sourceName=''){
  const current=Array.isArray(cart)?cart.map(x=>({...x})):[];
  const qty=Math.floor(num(qtyUse));
  if(qty<=0)return current;
  if(!product?.id||!clean(product.sku))throw new Error('Produk tidak lengkap.');
  const stock=Math.max(0,num(product.stock));
  const sku=clean(product.sku).toUpperCase();
  const existing=current.find(i=>clean(i.sku).toUpperCase()===sku);
  const existingQty=Math.max(0,num(existing?.qty));
  if(existingQty+qty>stock)throw new Error('Qty troli melebihi stok semasa.');
  if(existing){
    existing.qty=existingQty+qty;
    existing.maxStock=stock;
    existing.productId=product.id;
    existing.itemType=existing.itemType||'PART';
    existing.externalPurchase=true;
    existing.externalSource=clean(sourceName)||existing.externalSource||'';
    if(product.sell_price!==undefined)existing.price=money(product.sell_price);
    if(product.name)existing.name=product.name;
    return current;
  }
  current.push({
    sku,
    name:clean(product.name)||sku,
    price:money(product.sell_price),
    qty,
    maxStock:stock,
    discount:0,
    productId:product.id,
    itemType:'PART',
    externalPurchase:true,
    externalSource:clean(sourceName)
  });
  return current;
}

window.RTExternalPurchaseCore={normalizeDraft,mergeCart};
})();
