/* REV TORQ POS V2 — one trusted audit writer.
   Replaces the old logAudit body, which lost the record it described:
   the legacy bridge dropped `details` and `role`, sent a non-existent
   `timestamp` column, and swallowed the error.

   window.rtAuditWrite(action, details, extra)
     extra = { entityType, entityId (uuid), entityKey (any text), before, after, meta }
   * Preferred path: RPC rt_audit_log (actor / company / role come from the server).
   * Fallback (SQL script not installed yet): insert of valid audit_logs columns only.
   * A record that cannot be sent (offline, session expired) goes to a local outbox
     and is retried; the cashier is told once. It is never silently dropped.
   Plain ES2017 for Safari on iPad. */
(function(){
  'use strict';
  var KEY='rt_audit_outbox_v1', MAX=200, MAX_TRIES=50, FLUSH_MS=60000;
  var state={rpc:'unknown',flushing:false,lastError:'',warnedAt:0,timer:null};

  function sb(){return window.supabaseClient||null;}
  function prof(){return window.currentProfile||null;}
  function isUuid(v){return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(v==null?'':v));}
  function boxKey(){var p=prof();return p&&p.companyId?KEY+':'+p.companyId:KEY;}
  function readBox(){try{var a=JSON.parse(localStorage.getItem(boxKey())||'[]');return Array.isArray(a)?a:[];}catch(_){return [];}}
  function writeBox(a){try{if(a.length)localStorage.setItem(boxKey(),JSON.stringify(a.slice(-MAX)));else localStorage.removeItem(boxKey());}catch(e){console.error('Audit outbox unavailable',e);}}
  function missingFn(e){var m=String(e&&(e.message||e.details||e.hint)||'');return !!(e&&(e.code==='PGRST202'||e.code==='42883'))||/could not find the function|function .* does not exist/i.test(m);}
  // These can never succeed on retry: report them, do not queue them forever.
  function permanent(e){return /ACTION_RESERVED|ACTION_INVALID|PAYLOAD_TOO_LARGE/.test(String(e&&e.message||''));}
  function network(e){var m=String(e&&e.message||e||'');return /failed to fetch|networkerror|network request failed|load failed|timeout|aborted/i.test(m)||(e&&e.name==='TypeError');}
  function ref(){return 'c'+Date.now().toString(36)+Math.random().toString(36).slice(2,8);}
  function toast(m,t){try{if(window.showToast)window.showToast(m,t||'info');}catch(_){}}

  function send(e){
    var c=sb();
    if(!c)return Promise.reject(new Error('Failed to fetch'));
    var viaRpc=state.rpc==='missing'?Promise.resolve({error:{code:'PGRST202'}}):Promise.resolve(c.rpc('rt_audit_log',{
      p_action:e.action,p_details:e.details,p_entity_type:e.entityType||null,
      p_entity_id:isUuid(e.entityId)?e.entityId:null,p_before:e.before||null,p_after:e.after||null,p_meta:e.meta||{}
    }));
    return viaRpc.then(function(r){
      if(!r.error){state.rpc='ok';return 'rpc';}
      if(missingFn(r.error)){
        state.rpc='missing';
        var p=prof()||{};
        var row={company_id:p.companyId||null,staff_id:p.staffUuid||null,location_id:p.locationId||null,
          action:e.action,entity_type:e.entityType||null,entity_id:isUuid(e.entityId)?e.entityId:null,
          before_data:e.before||null,after_data:e.after||null,
          metadata:Object.assign({},e.meta||{},{details:e.details,role:p.role||null,staff_code:p.staffId||null,source:'web'})};
        return Promise.resolve(c.from('audit_logs').insert(row)).then(function(r2){
          if(r2&&r2.error)throw r2.error;
          return 'direct';
        });
      }
      throw r.error;
    });
  }

  function queue(e,err){
    var box=readBox();box.push(e);
    if(box.length>MAX)box=box.slice(-MAX);
    writeBox(box);
    state.lastError=String(err&&err.message||err||'');
    var now=Date.now();
    if(now-state.warnedAt>300000){
      state.warnedAt=now;
      toast('Rekod audit belum dapat dihantar. Disimpan dalam tablet ini dan akan dicuba semula.','error');
    }
  }

  window.rtAuditWrite=function(action,details,extra){
    extra=extra||{};
    var p=prof()||{};
    var meta=Object.assign({},extra.meta||{});
    if(extra.entityKey!=null)meta.key=String(extra.entityKey);
    meta.client_ref=ref();meta.client_time=new Date().toISOString();
    var e={action:String(action||'').trim().toUpperCase(),details:details==null?null:String(details).slice(0,2000),
      entityType:extra.entityType||null,entityId:extra.entityId||null,before:extra.before||null,after:extra.after||null,
      meta:meta,actor:p.staffUuid||null,tries:0};
    return send(e).then(function(){schedule(2000);return true;},function(err){
      if(permanent(err)){console.error('Audit rejected by server',e.action,err);return false;}
      queue(e,err);return false;
    });
  };

  function flush(){
    if(state.flushing)return Promise.resolve();
    var p=prof();if(!p||!sb())return Promise.resolve();
    var box=readBox();if(!box.length)return Promise.resolve();
    state.flushing=true;
    var keep=[],i=0;
    function next(){
      if(i>=box.length)return Promise.resolve();
      var e=box[i++];
      // The server records the CURRENT staff as the actor, so only send entries made by this person.
      if(e.actor&&p.staffUuid&&e.actor!==p.staffUuid){keep.push(e);return next();}
      return send(e).then(next,function(err){
        if(permanent(err)){console.error('Audit dropped (rejected)',e.action,err);return next();}
        e.tries=(e.tries||0)+1;
        if(e.tries<MAX_TRIES)keep.push(e);else console.error('Audit gave up after retries',e);
        if(network(err)){keep=keep.concat(box.slice(i));i=box.length;return Promise.resolve();}
        return next();
      });
    }
    return next().then(function(){writeBox(keep);},function(){writeBox(keep.concat(box.slice(i)));}).then(function(){state.flushing=false;},function(){state.flushing=false;});
  }
  function schedule(ms){clearTimeout(state.timer);state.timer=setTimeout(flush,ms||FLUSH_MS);}
  window.rtAuditFlush=flush;
  window.rtAuditStatus=function(){
    var p=prof()||{},box=readBox();
    return {rpc:state.rpc,queued:box.length,mine:box.filter(function(e){return !e.actor||e.actor===p.staffUuid;}).length,lastError:state.lastError};
  };

  window.addEventListener('online',function(){schedule(1500);});
  document.addEventListener('visibilitychange',function(){if(!document.hidden)schedule(1500);});
  setInterval(function(){if(prof())flush();},FLUSH_MS);
  setTimeout(function(){if(prof())flush();},6000);
})();
