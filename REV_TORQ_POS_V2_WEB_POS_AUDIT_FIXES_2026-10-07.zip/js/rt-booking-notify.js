/* REV TORQ POS V2 WEB — new booking notification.
   Read-only: checks the existing `bookings` table (same RLS as the Booking page)
   every 30 s while the POS is open and alerts staff who can open Booking:
   popup card + chime + count badges, and optionally a tablet/system notification.
   No Supabase changes, no writes. Plain ES2017 for older Android WebViews. */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  var POLL_VISIBLE=30000, POLL_HIDDEN=60000, MIN_GAP=8000, SEEN_MAX=300, CARD_MS=60000;
  var SOUND_KEY='rt_booking_sound_v1';
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
  function feather(){try{if(window.feather)window.feather.replace();}catch(_){}}
  function read(k,f){try{var v=JSON.parse(localStorage.getItem(k)||'null');return v==null?f:v;}catch(_){return f;}}
  function write(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(_){}}
  function profile(){return window.currentProfile||null;}
  // Same rule as the menu: only roles that have the Booking page get alerts.
  function canSeeBookings(){return !!document.querySelector('#mainNav [data-view="booking"]');}
  function seenKey(c){return 'rt_booking_seen_v1:'+c;}
  function soundOn(){try{return localStorage.getItem(SOUND_KEY)!=='off';}catch(_){return true;}}

  function fmtDate(d){
    if(!d)return '';
    try{return new Intl.DateTimeFormat('ms-MY',{timeZone:'Asia/Kuala_Lumpur',weekday:'short',day:'2-digit',month:'short'}).format(new Date(d+'T00:00:00+08:00'));}catch(_){return String(d);}
  }
  function slot(b){return [fmtDate(b.preferred_date),b.preferred_time?String(b.preferred_time).slice(0,5):''].filter(Boolean).join(' · ');}
  function plate(b){return b.vehicle_plate||'';}

  // ---------------------------------------------------------------- polling
  var state={company:null,pending:[],count:0,timer:null,last:0,busy:false,primed:false};
  function fetchNew(company){
    var sb=window.supabaseClient;
    if(!sb)return Promise.reject(new Error('no client'));
    return sb.from('bookings')
      .select('id,booking_no,customer_name,customer_phone,vehicle_plate,requested_service,preferred_date,preferred_time,source,status,created_at')
      .eq('company_id',company).eq('booking_department','WORKSHOP').eq('status','NEW')
      .order('created_at',{ascending:false}).limit(50)
      .then(function(r){if(r.error)throw r.error;return r.data||[];});
  }
  function poll(force){
    var p=profile(),company=p&&p.companyId;
    if(!company||!canSeeBookings()){reset();return Promise.resolve();}
    if(company!==state.company){state.company=company;state.pending=[];state.count=0;state.primed=false;}
    var now=Date.now();
    // No internet / offline start: nothing to ask the server (it used to retry every 1.5 s and log a warning each time)
    if(navigator.onLine===false||window.rtOfflineShell===true)return Promise.resolve();
    if(state.busy||(!force&&now-state.last<MIN_GAP))return Promise.resolve();
    state.busy=true;state.last=now;
    return fetchNew(company).then(function(rows){
      if(company!==state.company)return;
      state.pending=rows;state.count=rows.length;
      var key=seenKey(company),seen=read(key,null),fresh=[];
      if(!Array.isArray(seen)){
        // First run on this tablet: what is already waiting only shows in the badge.
        seen=rows.map(function(b){return String(b.id);});
      }else{
        fresh=rows.filter(function(b){return seen.indexOf(String(b.id))<0;});
        fresh.forEach(function(b){seen.unshift(String(b.id));});
      }
      write(key,seen.slice(0,SEEN_MAX));
      state.primed=true;
      syncBadges();
      if(fresh.length)alertNew(fresh);
    }).catch(function(e){console.warn('booking notify',e&&e.message||e);})
      .then(function(){state.busy=false;});
  }
  function schedule(){
    clearTimeout(state.timer);
    state.timer=setTimeout(function(){poll(false).then(schedule);},document.hidden?POLL_HIDDEN:POLL_VISIBLE);
  }
  function reset(){
    if(state.company===null&&!state.count)return;
    state.company=null;state.pending=[];state.count=0;state.primed=false;
    syncBadges();closeCard();
  }
  window.rtBookingNotifyPoll=function(){return poll(true);};

  // ---------------------------------------------------------------- badges
  function badge(el,n,cls){
    if(!el)return;
    var b=el.querySelector('.'+cls);
    if(!n){if(b)b.remove();return;}
    if(!b){b=document.createElement('span');b.className=cls;el.appendChild(b);}
    var t=n>=50?'50+':String(n);
    if(b.textContent!==t)b.textContent=t;
    el.setAttribute('data-booking-count',t);
  }
  function syncBadges(){
    var n=state.count;
    badge(document.querySelector('#mainNav [data-view="booking"]'),n,'rt-nav-badge');
    var more=$('rtNavMore'),toggle=$('rtNavMoreToggle');
    // The "Lagi" group carries the count while it is folded away.
    badge(toggle,more&&more.classList.contains('hidden')&&more.querySelector('[data-view="booking"]')?n:0,'rt-nav-badge');
    [].forEach.call(document.querySelectorAll('.rt-section-tabs [data-view="booking"]'),function(t){badge(t,n,'rt-tab-badge');});
    if(!n){[].forEach.call(document.querySelectorAll('[data-booking-count]'),function(e){if(!e.querySelector('.rt-nav-badge,.rt-tab-badge'))e.removeAttribute('data-booking-count');});}
  }

  // ---------------------------------------------------------------- sound (Web Audio, no file)
  var audio=null;
  function unlockAudio(){
    if(!state.company&&!canSeeBookings())return;
    try{
      var AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;
      if(!audio)audio=new AC();
      if(audio.state==='suspended')audio.resume();
    }catch(_){}
  }
  document.addEventListener('pointerdown',unlockAudio,true);
  document.addEventListener('keydown',unlockAudio,true);
  function chime(){
    if(!soundOn())return;
    try{
      unlockAudio();if(!audio||audio.state!=='running')return;
      var t=audio.currentTime;
      [[880,0],[1175,.16],[1568,.32]].forEach(function(n){
        var o=audio.createOscillator(),g=audio.createGain();
        o.type='sine';o.frequency.value=n[0];
        g.gain.setValueAtTime(0.0001,t+n[1]);g.gain.exponentialRampToValueAtTime(0.35,t+n[1]+0.02);g.gain.exponentialRampToValueAtTime(0.0001,t+n[1]+0.45);
        o.connect(g);g.connect(audio.destination);o.start(t+n[1]);o.stop(t+n[1]+0.5);
      });
      window.__rtBookingChimes=(window.__rtBookingChimes||0)+1;
    }catch(_){}
  }

  // ---------------------------------------------------------------- popup card
  var cardTimer=null;
  function closeCard(){var c=$('rtBookingAlert');if(c)c.remove();clearTimeout(cardTimer);}
  // Sit just right of the sidebar / icon rail so the menu (and its badges) stay visible.
  function placeCard(){
    var c=$('rtBookingAlert');if(!c)return;
    var side=$('sidebar'),r=side&&side.getBoundingClientRect(),left=16;
    if(r&&r.width>0&&r.right>0&&r.right<window.innerWidth*0.5)left=Math.round(r.right)+16;
    c.style.left=left+'px';
  }
  window.addEventListener('resize',placeCard);
  function openBooking(id){
    closeCard();
    if(typeof window.switchView==='function')window.switchView('booking');
    if(!id||typeof window.loadBookings!=='function')return;
    // Make sure the list holds the new booking, then open its detail (SAHKAN / TOLAK / UBAH SLOT).
    Promise.resolve(window.loadBookings()).then(function(){
      if(window.__rtActiveView==='booking'&&typeof window.openBookingDetail==='function')window.openBookingDetail(id);
    });
  }
  window.rtOpenNewBooking=openBooking;
  function alertNew(fresh){
    closeCard();
    var first=fresh[0],more=fresh.length-1;
    var c=document.createElement('div');
    c.id='rtBookingAlert';c.className='rt-booking-alert';c.setAttribute('role','alert');
    var rows=fresh.slice(0,3).map(function(b){
      return '<div class="rt-booking-alert-row"><b>'+esc(b.customer_name||'Pelanggan')+'</b>'+(plate(b)?'<span class="rt-booking-plate">'+esc(plate(b))+'</span>':'')+
        '<small>'+esc([b.booking_no,b.requested_service].filter(Boolean).join(' · '))+'</small>'+
        '<small class="rt-booking-slot">'+esc(slot(b))+'</small></div>';
    }).join('');
    c.innerHTML='<div class="rt-booking-alert-head"><span class="rt-booking-alert-icon"><i data-feather="calendar"></i></span>'+
      '<b>'+(fresh.length>1?fresh.length+' BOOKING BARU':'BOOKING BARU')+'</b>'+
      '<button type="button" class="rt-booking-alert-mute" data-ba="mute" aria-label="Bunyi" title="Bunyi notifikasi">'+(soundOn()?'<i data-feather="volume-2"></i>':'<i data-feather="volume-x"></i>')+'</button>'+
      '<button type="button" class="rt-booking-alert-x" data-ba="close" aria-label="Tutup"><i data-feather="x"></i></button></div>'+
      rows+(fresh.length>3?'<div class="rt-booking-alert-more">+'+(fresh.length-3)+' lagi</div>':'')+
      '<button type="button" class="rt-btn rt-btn-primary rt-booking-alert-go" data-ba="open">'+(more>0?'LIHAT SEMUA BOOKING':'LIHAT &amp; SAHKAN')+'</button>';
    c.addEventListener('click',function(e){
      var b=e.target.closest?e.target.closest('[data-ba]'):null;if(!b)return;
      var a=b.getAttribute('data-ba');
      if(a==='close')closeCard();
      else if(a==='open')openBooking(more>0?null:first.id);
      else if(a==='mute'){try{localStorage.setItem(SOUND_KEY,soundOn()?'off':'on');}catch(_){}b.innerHTML=soundOn()?'<i data-feather="volume-2"></i>':'<i data-feather="volume-x"></i>';feather();syncSettings();}
    });
    document.body.appendChild(c);placeCard();feather();
    cardTimer=setTimeout(closeCard,CARD_MS);
    chime();
    systemNotify(fresh);
    // Keep the Booking page itself current when it is open.
    if(window.__rtActiveView==='booking'&&typeof window.loadBookings==='function')window.loadBookings();
  }

  // ---------------------------------------------------------------- tablet / system notification (opt-in)
  var swReg=null;
  function notifySupported(){return 'Notification' in window&&window.isSecureContext!==false;}
  var swPromise=null;
  function ensureSw(){
    if(swPromise)return swPromise;
    if(!('serviceWorker' in navigator)||(location.protocol!=='https:'&&location.hostname!=='localhost')||location.hostname==='appassets.androidplatform.net')return Promise.resolve(null);
    // Same worker as the app-shell cache (js/rt-offline.js registers it too). showNotification
    // needs an ACTIVE worker, so wait for `ready` (max 5 s) after registering.
    swPromise=navigator.serviceWorker.register('sw-notify.js').then(function(){
      return Promise.race([navigator.serviceWorker.ready,new Promise(function(r){setTimeout(function(){r(null);},5000);})]);
    }).then(function(r){swReg=r||null;if(!r)swPromise=null;return swReg;}).catch(function(){swPromise=null;return null;});
    return swPromise;
  }
  function systemNotify(fresh){
    if(!notifySupported()||Notification.permission!=='granted')return;
    var focused=!document.hidden&&(typeof document.hasFocus!=='function'||document.hasFocus());
    if(focused)return; // on screen the popup and chime are enough
    var b=fresh[0];
    var title=fresh.length>1?fresh.length+' booking baru · REV TORQ':'Booking baru · REV TORQ';
    var body=[b.customer_name,plate(b),b.requested_service,slot(b)].filter(Boolean).join(' · ');
    var opts={body:body,tag:'rt-booking',renotify:true,data:{bookingId:fresh.length>1?null:b.id}};
    var fallback=function(){
      // Desktop browsers without a worker; Android Chrome only allows the worker path.
      try{var n=new Notification(title,opts);n.onclick=function(){try{window.focus();}catch(_){}openBooking(opts.data.bookingId);n.close();};}catch(_){}
    };
    ensureSw().then(function(reg){
      if(reg&&reg.showNotification)return reg.showNotification(title,opts).catch(fallback);
      fallback();
    }).catch(fallback);
  }
  if('serviceWorker' in navigator){
    navigator.serviceWorker.addEventListener('message',function(e){
      var d=e.data||{};
      if(d.type==='rt-open-booking')openBooking(d.bookingId||null);
    });
    try{if(navigator.serviceWorker.startMessages)navigator.serviceWorker.startMessages();}catch(_){}
  }
  function requestPermission(){
    if(!notifySupported()){window.showToast&&window.showToast('Browser ini tidak menyokong notifikasi tablet.','error');return;}
    var done=false;
    var handle=function(res){
      if(done)return;done=true;
      if(res==='granted'){ensureSw();window.showToast&&window.showToast('Notifikasi tablet diaktifkan.','success');}
      else window.showToast&&window.showToast('Notifikasi tablet tidak dibenarkan oleh browser.','error');
      syncSettings();
    };
    try{var p=Notification.requestPermission(handle);if(p&&p.then)p.then(handle);}catch(_){handle('denied');}
  }

  // ---------------------------------------------------------------- Booking page controls
  function syncSettings(){
    var bar=$('rtBookingNotifyBar');if(!bar)return;
    var s=bar.querySelector('[data-bn="sound"]'),n=bar.querySelector('[data-bn="notify"]');
    if(s){s.classList.toggle('is-on',soundOn());s.innerHTML=(soundOn()?'<i data-feather="volume-2"></i>BUNYI ON':'<i data-feather="volume-x"></i>BUNYI OFF');}
    if(n){
      var perm=notifySupported()?Notification.permission:'unsupported';
      n.hidden=perm==='unsupported';
      n.disabled=perm==='granted'||perm==='denied';
      n.classList.toggle('is-on',perm==='granted');
      n.innerHTML='<i data-feather="bell"></i>'+(perm==='granted'?'NOTIFIKASI TABLET ON':perm==='denied'?'NOTIFIKASI DISEKAT (tetapan browser)':'AKTIFKAN NOTIFIKASI TABLET');
    }
    feather();
  }
  function ensureSettings(){
    var head=$('bookingPendingBadge');
    if(!head||$('rtBookingNotifyBar'))return;
    var box=head.parentElement&&head.parentElement.parentElement;if(!box)return;
    var bar=document.createElement('div');
    bar.id='rtBookingNotifyBar';bar.className='rt-booking-notify-bar';
    bar.innerHTML='<button type="button" data-bn="sound"></button><button type="button" data-bn="notify"></button>';
    bar.addEventListener('click',function(e){
      var b=e.target.closest?e.target.closest('[data-bn]'):null;if(!b)return;
      if(b.getAttribute('data-bn')==='sound'){try{localStorage.setItem(SOUND_KEY,soundOn()?'off':'on');}catch(_){}syncSettings();if(soundOn())chime();}
      else requestPermission();
    });
    box.appendChild(bar);
    syncSettings();
  }

  // ---------------------------------------------------------------- wiring
  document.addEventListener('visibilitychange',function(){if(!document.hidden){poll(false);schedule();}});
  window.addEventListener('focus',function(){poll(false);});
  function tick(){
    var p=profile();
    if(p&&p.companyId&&canSeeBookings()){
      if(!state.primed&&!state.busy&&Date.now()-state.last>=10000)poll(true);   // first look; if it fails, retry every 10 s
      // Already allowed on this tablet: have the worker active before the first alert.
      if(!swPromise&&notifySupported()&&Notification.permission==='granted')ensureSw();
      syncBadges();ensureSettings();
    }else if(state.company!==null||state.count){reset();}
  }
  setInterval(tick,1500);
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){tick();schedule();},{once:true});else{tick();schedule();}
})();
