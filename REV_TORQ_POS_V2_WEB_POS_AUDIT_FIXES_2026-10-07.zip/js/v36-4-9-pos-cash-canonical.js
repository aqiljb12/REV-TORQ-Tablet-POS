/* REV TORQ V36.4.9.11 — CANONICAL POS + CASH DRAWER
   - One final POS checkout handler loaded last.
   - Resolves staff_code (e.g. AQIL) to staff.id UUID before any FK insert.
   - Normal product-only sales use the existing transactional rt_post_pos_sale RPC.
   - Job/service sales keep the existing Job->POS flow, but use real staff UUIDs.
   - Cash drawer uses ONLY rt_cash_open / rt_cash_move / rt_cash_close; no unsafe fallback writes.
   - Opening float is recorded as a real OPENING cash movement.
*/
(function(){
  'use strict';
  const sb=window.supabaseClient;
  if(!sb)return;
  const $=id=>document.getElementById(id);
  const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  const money=v=>'RM '+Number(v||0).toLocaleString('ms-MY',{minimumFractionDigits:2,maximumFractionDigits:2});
  const err=e=>e?.message||e?.details||e?.hint||String(e);
  const toast=(m,t='success')=>{try{window.showToast?.(m,t)}catch(_){alert(m)}};
  const profile=()=>window.currentProfile||{};
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));

  async function staffRow(){
    const p=profile();
    if(p.uid){
      const r=await sb.from('staff').select('id,staff_code,name,company_id,location_id,role,active,auth_user_id').eq('auth_user_id',p.uid).eq('active',true).eq('removed_from_active_list',false).limit(1).maybeSingle();
      if(r.error)throw r.error;
      if(r.data)return r.data;
    }
    const code=String(p.staffId||p.staff_code||'').trim().toUpperCase();
    if(code){
      const r=await sb.from('staff').select('id,staff_code,name,company_id,location_id,role,active,auth_user_id').eq('staff_code',code).eq('active',true).eq('removed_from_active_list',false).limit(1).maybeSingle();
      if(r.error)throw r.error;
      if(r.data)return r.data;
    }
    throw new Error(`Staff aktif tidak dijumpai untuk login "${code||'-'}". Login/session staff perlu dipetakan.`);
  }
  async function ctx(){
    const s=await staffRow();
    let loc=s.location_id;
    if(!loc){
      const r=await sb.from('locations').select('id').eq('company_id',s.company_id).eq('active',true).order('code').limit(1).maybeSingle();
      if(r.error)throw r.error;if(!r.data)throw new Error('Lokasi bengkel aktif tidak dijumpai.');loc=r.data.id;
    }
    return {s,companyId:s.company_id,locationId:loc,staffId:s.id};
  }

  // ---------------- CASH DRAWER ----------------
  const DENOMS=[100,50,20,10,5,1,.5,.2,.1,.05];
  function cashModal(mode){
    let m=$('rtCashManageModal');
    if(m)return m;
    m=document.createElement('div');m.id='rtCashManageModal';m.className='fixed inset-0 z-[1000] hidden items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm';
    m.innerHTML=`<div class="w-full max-w-xl overflow-hidden rounded-3xl bg-white shadow-2xl">
      <div class="flex items-center justify-between border-b p-5"><div><div id="rtCashManageKicker" class="text-[10px] font-black tracking-[.18em] text-red-600">CASH DRAWER</div><h3 id="rtCashManageTitle" class="text-2xl font-black text-slate-900">Modal Permulaan</h3><p id="rtCashManageSub" class="mt-1 text-xs text-slate-500"></p></div><button type="button" id="rtCashManageClose" class="h-10 w-10 rounded-xl bg-slate-100 text-xl font-black">×</button></div>
      <div class="max-h-[72vh] overflow-auto p-5">
        <div id="rtCashExpectedBox" class="mb-4 hidden rounded-2xl bg-slate-50 p-4"><div class="flex justify-between"><span class="font-bold text-slate-500">Jangkaan sistem</span><b id="rtCashExpectedModal">RM 0.00</b></div></div>
        <label class="mb-2 block text-xs font-black uppercase tracking-wide text-slate-500">Jumlah tunai (RM)</label>
        <input id="rtCashManageAmount" type="number" min="0" step="0.01" inputmode="decimal" class="mb-4 w-full rounded-2xl border-2 border-slate-200 px-4 py-4 text-2xl font-black outline-none focus:border-red-500" placeholder="0.00">
        <button type="button" id="rtCashUseDenoms" class="mb-3 text-xs font-black text-red-600">KIRA IKUT PECAHAN DUIT</button>
        <div id="rtCashDenoms" class="hidden grid grid-cols-2 gap-2 rounded-2xl bg-slate-50 p-3 sm:grid-cols-3"></div>
        <label id="rtCashReasonLabel" class="mb-2 mt-4 block text-xs font-black uppercase tracking-wide text-slate-500">Nota / sebab</label>
        <div id="rtCashReasonPresets" class="mb-3 hidden flex flex-wrap gap-2">
          <button type="button" data-reason="Petrol / minyak kenderaan" class="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-black text-slate-700">PETROL</button>
          <button type="button" data-reason="Minuman / makan staff" class="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-black text-slate-700">MINUMAN / MAKAN</button>
          <button type="button" data-reason="Barang kedai / keperluan bengkel" class="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-black text-slate-700">BARANG KEDAI</button>
          <button type="button" data-reason="Parking / tol" class="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-black text-slate-700">PARKING / TOL</button>
          <button type="button" data-reason="Lain-lain" class="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-black text-slate-700">LAIN-LAIN</button>
        </div>
        <input id="rtCashManageReason" class="w-full rounded-2xl border border-slate-200 px-4 py-3 font-bold outline-none focus:border-red-500" placeholder="Contoh: Petrol motor runner">
      </div>
      <div class="flex gap-3 border-t bg-slate-50 p-4"><button type="button" id="rtCashManageCancel" class="flex-1 rounded-2xl border border-slate-300 bg-white px-4 py-3 font-black text-slate-600">BATAL</button><button type="button" id="rtCashManageConfirm" class="flex-1 rounded-2xl bg-red-600 px-4 py-3 font-black text-white">SAHKAN</button></div>
    </div>`;
    document.body.appendChild(m);
    const close=()=>{m.classList.add('hidden');m.classList.remove('flex')};
    $('rtCashManageClose').onclick=close;$('rtCashManageCancel').onclick=close;m.addEventListener('click',e=>{if(e.target===m)close()});
    $('rtCashReasonPresets').querySelectorAll('[data-reason]').forEach(b=>b.onclick=()=>{$('rtCashManageReason').value=b.dataset.reason||'';});
    $('rtCashUseDenoms').onclick=()=>{
      const box=$('rtCashDenoms');box.classList.toggle('hidden');
      if(!box.children.length)box.innerHTML=DENOMS.map(d=>`<label class="rounded-xl bg-white p-2"><span class="block text-[10px] font-black text-slate-500">RM ${d.toFixed(2)}</span><input data-denom="${d}" type="number" min="0" step="1" value="0" class="mt-1 w-full rounded-lg border border-slate-200 px-2 py-2 text-center font-black"></label>`).join('');
      box.querySelectorAll('input').forEach(i=>i.oninput=()=>{let total=0;box.querySelectorAll('input').forEach(x=>total+=Number(x.dataset.denom)*Math.max(0,Number(x.value)||0));$('rtCashManageAmount').value=total.toFixed(2)});
    };
    return m;
  }
  function openCashModal(){
    const m=cashModal();$('rtCashManageKicker').textContent='CASH DRAWER';$('rtCashManageTitle').textContent='Buka Peti / Modal Permulaan';$('rtCashManageSub').textContent='Masukkan jumlah tunai fizikal yang diletakkan dalam peti sebelum jualan.';$('rtCashExpectedBox').classList.add('hidden');$('rtCashReasonPresets').classList.add('hidden');$('rtCashManageReason').value='Modal awal / opening float';$('rtCashManageAmount').value='';$('rtCashManageConfirm').textContent='BUKA PETI';$('rtCashManageConfirm').dataset.mode='OPEN';$('rtCashReasonLabel').classList.remove('hidden');m.classList.remove('hidden');m.classList.add('flex');setTimeout(()=>$('rtCashManageAmount').focus(),60);
  }
  async function openCash(){
    const m=cashModal();const amount=Math.max(0,Number($('rtCashManageAmount').value)||0);if(!Number.isFinite(amount))throw new Error('Jumlah modal tidak sah.');
    const r=await sb.rpc('rt_cash_open',{p_opening_float:amount,p_drawer_code:'MAIN'});if(r.error)throw r.error;
    m.classList.add('hidden');m.classList.remove('flex');toast(`Peti dibuka. Modal permulaan ${money(amount)} direkod.`,'success');await refreshCash();
  }
  async function cashMove(type){
    const m=cashModal();$('rtCashManageKicker').textContent='CASH MANAGEMENT';$('rtCashManageTitle').textContent=type==='CASH_IN'?'Tambah Tunai':'Belanja Peti / Money Out';$('rtCashManageSub').textContent=type==='CASH_IN'?'Pay-in: tambah tunai ke peti.':'Rekod tunai yang benar-benar keluar dari peti untuk belanja operasi seperti petrol, minuman, parking atau barang kedai.';$('rtCashExpectedBox').classList.remove('hidden');const d=await getDrawer(true);if(!d)throw new Error('Peti tunai belum OPEN.');$('rtCashExpectedModal').textContent=money(d.expected_amount);$('rtCashReasonPresets').classList.toggle('hidden',type!=='CASH_OUT');$('rtCashManageReason').value=type==='CASH_IN'?'Tambah duit tukar':'';$('rtCashManageAmount').value='';$('rtCashManageConfirm').textContent=type==='CASH_IN'?'TAMBAH TUNAI':'REKOD MONEY OUT';$('rtCashManageConfirm').dataset.mode=type;$('rtCashReasonLabel').classList.remove('hidden');m.classList.remove('hidden');m.classList.add('flex');setTimeout(()=>$('rtCashManageAmount').focus(),60);
  }
  async function closeCash(){
    const d=await getDrawer(true);if(!d)throw new Error('Peti tunai belum OPEN.');
    const m=cashModal();$('rtCashManageKicker').textContent='CASH DRAWER';$('rtCashManageTitle').textContent='Tutup Akaun / Kira Tunai';$('rtCashManageSub').textContent='Kira duit fizikal dalam peti dan bandingkan dengan jangkaan sistem.';$('rtCashExpectedBox').classList.remove('hidden');$('rtCashReasonPresets').classList.add('hidden');$('rtCashExpectedModal').textContent=money(d.expected_amount);$('rtCashManageAmount').value=Number(d.expected_amount||0).toFixed(2);$('rtCashManageReason').value='';$('rtCashReasonLabel').classList.add('hidden');$('rtCashManageConfirm').textContent='TUTUP AKAUN';$('rtCashManageConfirm').dataset.mode='CLOSE';m.classList.remove('hidden');m.classList.add('flex');setTimeout(()=>$('rtCashManageAmount').focus(),60);
  }
  async function cashConfirm(){
    const mode=$('rtCashManageConfirm').dataset.mode;
    try{
      if(mode==='OPEN')return await openCash();
      if(mode==='CLOSE'){
        const actual=Math.max(0,Number($('rtCashManageAmount').value)||0);const r=await sb.rpc('rt_cash_close',{p_actual_amount:actual});if(r.error)throw r.error;const diff=Number(r.data||0);$('rtCashManageModal').classList.add('hidden');$('rtCashManageModal').classList.remove('flex');toast(`Akaun ditutup. ${diff===0?'Seimbang.':diff>0?'Lebih '+money(diff):'Kurang '+money(Math.abs(diff))}.`,'success');await refreshCash();return;
      }
      const amount=Math.max(0,Number($('rtCashManageAmount').value)||0);if(amount<=0)throw new Error('Jumlah mesti lebih daripada RM0.');const reason=String($('rtCashManageReason').value||'').trim();if(mode==='CASH_OUT'&&!reason)throw new Error('Pilih atau tulis sebab Money Out.');const r=await sb.rpc('rt_cash_move',{p_type:mode,p_amount:amount,p_reason:reason});if(r.error)throw r.error;$('rtCashManageModal').classList.add('hidden');$('rtCashManageModal').classList.remove('flex');toast(mode==='CASH_IN'?`Tunai masuk ${money(amount)} direkod.`:`Money Out ${money(amount)} direkod · ${reason}`,'success');await refreshCash();
    }catch(e){toast('Cash drawer gagal | '+err(e),'error')}
  }
  async function getDrawer(openOnly=false){
    const {companyId}=await ctx();let q=sb.from('cash_drawers').select('*').eq('company_id',companyId).eq('drawer_code','MAIN').limit(1).maybeSingle();if(openOnly)q=sb.from('cash_drawers').select('*').eq('company_id',companyId).eq('drawer_code','MAIN').eq('status','OPEN').limit(1).maybeSingle();const r=await q;if(r.error)throw r.error;return r.data;
  }
  async function refreshCash(){
    const st=$('rtCashDrawerStatus'),ex=$('rtCashDrawerExpected'),openBtn=$('rtOpenCashDrawerBtn'),inBtn=$('rtCashInBtn'),outBtn=$('rtCashOutBtn'),closeBtn=$('rtCloseCashDrawerBtn');
    if(!st||!ex)return null;
    const setUi=(isOpen,d)=>{
      st.textContent=isOpen?'OPEN':'CLOSED';
      st.classList.toggle('is-open',!!isOpen);
      st.classList.toggle('is-closed',!isOpen);
      ex.textContent=isOpen?money(d?.expected_amount||0):'RM 0.00';
      if(openBtn){openBtn.hidden=!!isOpen;openBtn.disabled=!!isOpen;openBtn.textContent='BUKA PETI / MODAL AWAL';}
      if(inBtn){inBtn.hidden=!isOpen;inBtn.disabled=!isOpen;}
      if(outBtn){outBtn.hidden=!isOpen;outBtn.disabled=!isOpen;}
      if(closeBtn){closeBtn.hidden=!isOpen;closeBtn.disabled=!isOpen;}
      const hint=$('rtCashDrawerHint');if(hint)hint.textContent=isOpen?'Peti tunai sedang aktif. Jangkaan tunai semasa dipaparkan di atas.':'Buka peti sebelum menerima bayaran TUNAI. Modal awal boleh RM0.';
    };
    try{
      const d=await getDrawer(false);const isOpen=!!d&&d.status==='OPEN';setUi(isOpen,d);
      cashRetries=0;clearTimeout(cashRetryTimer);window.rtCashDrawerError='';
      return d||null
    }catch(e){
      st.textContent='RALAT';st.classList.remove('is-open','is-closed');ex.textContent='—';console.warn('cash drawer',e);
      // a failed read (slow start, wifi blip) must not stay "RALAT" for the rest of the shift: try again by itself
      window.rtCashDrawerError=err(e);
      const hint=$('rtCashDrawerHint');if(hint)hint.textContent='Status peti tidak dapat dibaca ('+err(e)+'). Cuba semula automatik...';
      clearTimeout(cashRetryTimer);
      cashRetryTimer=setTimeout(()=>{refreshCash()},[4000,8000,15000,30000,60000][Math.min(cashRetries,4)]);
      cashRetries++;
      return null
    }
  }
  let cashRetries=0,cashRetryTimer=null;
  window.addEventListener('online',()=>{refreshCash()});
  function installCashButtons(){
    const panel=$('rtCashDrawerPanel');if(!panel||panel.dataset.v49==='1')return;panel.dataset.v49='1';
    // RC4 policy: full accounting/reporting stays in Account app, but operational petty-cash Money Out must remain beside the live cash drawer.
    panel.innerHTML=`<div class="rt-cash-drawer-head"><div><small>PETI TUNAI</small><div class="rt-cash-drawer-state"><span id="rtCashDrawerStatus">—</span><b id="rtCashDrawerExpected">RM 0.00</b></div></div></div><p id="rtCashDrawerHint">Semak status peti tunai.</p><div class="rt-cash-drawer-actions"><button type="button" id="rtOpenCashDrawerBtn" class="primary">BUKA PETI / MODAL AWAL</button><button type="button" id="rtCashOutBtn" class="cash-out">BELANJA PETI / MONEY OUT</button><button type="button" id="rtCloseCashDrawerBtn" class="danger">CLOSING / KIRA BAKI</button></div>`;
    $('rtOpenCashDrawerBtn').onclick=()=>{openCashModal()};$('rtCashOutBtn').onclick=()=>cashMove('CASH_OUT').catch(e=>toast('Money Out gagal | '+err(e),'error'));$('rtCloseCashDrawerBtn').onclick=()=>closeCash().catch(e=>toast('Tutup peti gagal | '+err(e),'error'));
    const m=cashModal();$('rtCashManageConfirm').onclick=cashConfirm;
    document.querySelectorAll('#rtQuickCash [data-cash]').forEach(b=>b.addEventListener('click',()=>{
      const inp=$('posAmountReceived'); if(!inp)return;
      const t=calcTotals().total; const v=b.dataset.cash==='exact'?t:Number(b.dataset.cash||0);
      inp.value=Math.max(0,v).toFixed(2); inp.dispatchEvent(new Event('input',{bubbles:true}));
    }));
    refreshCash();
  }

  // ---------------- POS CHECKOUT ----------------
  function cart(){return typeof window.rtGetPosCart==='function'?window.rtGetPosCart():(Array.isArray(window.posCart)?window.posCart:[])}
  function isService(i){return !!(i?.service||String(i?.itemType||'').toUpperCase()==='SERVICE')}
  function otherChargeAmount(strict=false){
    const raw=String($('rtOtherCharge')?.value??'0').trim();
    const amount=Number(raw||0);
    if(!Number.isFinite(amount)||amount<0||Math.abs(amount*100-Math.round(amount*100))>0.000001){
      if(strict)throw new Error('CAJ LAIN mesti amaun RM yang sah dengan maksimum 2 tempat perpuluhan.');
      return 0;
    }
    return Math.round(amount*100)/100;
  }
  function calcTotals(){const c=cart(),promo=window.rtGetActivePromo?.()||null,requested=promo?0:Number($('posDiscount')?.value||0);let t;if(window.RTPosDiscountModel){const x=window.RTPosDiscountModel.cartTotals(c,requested);t={sub:x.grossSubtotal,itemDiscount:x.itemDiscount,net:x.netBeforeOrderDiscount,disc:x.orderDiscount,total:x.total}}else{const sub=c.reduce((s,i)=>s+Number(i.price||0)*Number(i.qty||1),0),itemDiscount=c.reduce((s,i)=>s+Math.min(Math.max(0,Number(i.discount||0)),Number(i.price||0)*Number(i.qty||1)),0),net=Math.max(0,sub-itemDiscount),disc=Math.min(Math.max(0,requested),net);t={sub,itemDiscount,net,disc,total:Math.max(0,net-disc)}}const promoDiscount=Math.min(Math.max(0,Number(promo?.discount_amount||0)),Math.max(0,t.net)),otherCharge=otherChargeAmount();return {...t,promo,promoDiscount,otherCharge,total:Math.round((Math.max(0,t.total-promoDiscount)+otherCharge)*100)/100}}
  window.rtPosCheckoutTotal=()=>calcTotals().total;
  const pendingKey='rt_pos_pending_sale_v1';
  let checkoutBusy=false;
  function pendingSale(){try{return JSON.parse(sessionStorage.getItem(pendingKey)||'null')}catch(_){return null}}
  async function saleDetail(id){
    const r=await sb.rpc('rt_staff_receipt_detail',{p_invoice_id:id});
    if(r.error)throw r.error;
    if(!r.data||!Array.isArray(r.data.items)||!r.data.items.length||String(r.data.status).toUpperCase()==='VOID'||String(r.data.paymentStatus).toUpperCase()!=='PAID')throw new Error('Invois belum disahkan lengkap. Semak sejarah jualan sebelum mencuba lagi.');
    return r.data;
  }
  async function postProductSale(name,args,snapshot){
    const previous=pendingSale();
    const pending=previous||{id:args.p_transaction_id,name,args,cart:JSON.stringify(snapshot)};
    if(!previous)sessionStorage.setItem(pendingKey,JSON.stringify(pending));
    if(previous){
      const lookup=await sb.rpc('rt_pos_transaction_lookup',{p_transaction_id:pending.id});
      if(lookup.error)throw new Error('Semakan transaksi tertunda gagal. Jangan buat bayaran baharu: '+err(lookup.error));
      if(lookup.data)return {detail:await saleDetail(lookup.data.id),pending};
    }
    let rpc;
    try{rpc=await sb.rpc(pending.name,pending.args)}catch(e){rpc={error:e}}
    if(rpc.error){
      const check=await sb.rpc('rt_pos_transaction_lookup',{p_transaction_id:pending.id});
      if(check.error)throw new Error('Status transaksi tidak pasti. Jangan buat bayaran baharu: '+err(rpc.error));
      if(!check.data){
        // A database error is definitive; a timeout/network error can hide a commit.
        if(rpc.error?.code && rpc.error.code!=='PGRST000')sessionStorage.removeItem(pendingKey);
        throw rpc.error;
      }
      return {detail:await saleDetail(check.data.id),pending};
    }
    const row=Array.isArray(rpc.data)?rpc.data[0]:rpc.data;
    if(!row?.invoice_id||!row?.invoice_no)throw new Error('RPC tidak memulangkan invois yang sah. Semak sejarah jualan sebelum mencuba lagi.');
    return {detail:await saleDetail(row.invoice_id),row,pending};
  }
  // Product sales: stock on screen drops at once and only the sold products are re-read (js/rt-pos-fixes.js);
  // anything else falls back to the full reload that was always done.
  function afterSale(sold){
    try{
      if(typeof window.rtPosAfterSale==='function'){window.rtPosAfterSale(sold);return}
    }catch(_){}
    window.loadPOS?.();
  }
  async function checkout(){
    if(checkoutBusy)return;
    checkoutBusy=true;
    const btn=$('btnCheckout'),old=btn?.innerHTML;if(btn){btn.disabled=true;btn.innerHTML='Memproses...'}
    try{
      const c=cart().map(i=>({...i}));
      const existing=pendingSale();
      if(existing){
        const done=await postProductSale(existing.name,existing.args,c);
        if(done.pending.args.p_voucher_code){done.detail.voucherCode=done.row?.voucher_code||done.pending.args.p_voucher_code;done.detail.voucherName=done.row?.reward_name||'Loyalty Voucher'}
        window.rtPosDecorateReceipt?.(done.detail,done.pending.args.p_reference_no||'');
        if(typeof window.generateReceiptFromInvoice!=='function')throw new Error('Renderer resit tidak tersedia.');
        await window.generateReceiptFromInvoice(done.detail);
        sessionStorage.removeItem(pendingKey);
        if(JSON.stringify(cart())===done.pending.cart){if($('rtOtherCharge'))$('rtOtherCharge').value='0';window.rtSetPosCart?.([]);window.posClearCart?.();window.rtPosRemovePromo?.(false);window.rtPosRemoveVoucher?.();window.rtPosClearMember?.();if(done.pending.name==='rt_post_job_pos_sale_idempotent')window.rtActiveJob=null}
        toast(`Invois ${done.detail.invoiceNo} berjaya.`, 'success');
        await refreshCash();afterSale(c);
        return;
      }
      if(!c.length){toast('Troli kosong.','error');return}
      const otherCharge=otherChargeAmount(true);
      if(window.rtGetActivePromo?.())await window.rtRevalidateActivePromo?.();
      if(window.rtPosGetActiveVoucher?.()){
        const checked=await window.rtPosApplyVoucher?.(true);
        if(!checked)return;
      }
      const voucher=window.rtPosGetActiveVoucher?.()||null;
      const {sub,disc,total,promo,promoDiscount}=calcTotals();
      if(voucher&&promo){toast('Gunakan sama ada Promo ATAU Loyalty Voucher, bukan kedua-duanya.','error');return}
      const method=String(window.posPayMethod||'CASH').toUpperCase();let received=Number($('posAmountReceived')?.value||0);if(method!=='CASH')received=total;if(method==='CASH'&&received<total){toast('Jumlah diterima tidak mencukupi.','error');return}
      if(method==='CASH'){const d=await getDrawer(true);if(!d){toast('Peti tunai belum OPEN. Buka peti dahulu sebelum bayaran TUNAI.','error');return}}
      const activeJob=window.rtActiveJob||null;
      const hasService=c.some(isService);
      if(otherCharge>0&&activeJob)throw new Error('CAJ LAIN untuk checkout Job Card belum disokong.');
      const selectedCustomer=$('rtPosCustomerSelect')?.value||null;
      if(voucher&&!selectedCustomer)throw new Error('Voucher perlukan customer/member yang dipilih.');
      if(voucher&&String(voucher.customer_id)!==String(selectedCustomer))throw new Error('Voucher bukan milik customer yang sedang dipilih.');

      // Normal walk-in sale: products + standalone service/labour are server-side atomic.
      // A service line does NOT imply Job Card. Only rtActiveJob selects the Job checkout path.
      if(!activeJob){
        const {companyId:cmp}=await ctx();
        const items=[];
        for(const i of c){
          const serviceItem=isService(i);
          let productId=i.productId||i.product_id||null;
          const lineDiscount=window.RTPosDiscountModel?window.RTPosDiscountModel.normalizeLineDiscount(i.discount,i.qty,i.price):Number(i.discount||0);
          if(serviceItem&&!productId){
            const standaloneType=/labour|upah|kerja/i.test(String(i.name||''))?'LABOUR':'SERVICE';
            items.push({product_id:null,item_type:standaloneType,unit_price:Number(i.price||0),quantity:Number(i.qty||1),discount:lineDiscount,description:i.name||null});
            continue;
          }
          if(!productId){
            const q=await sb.from('products').select('id').eq('company_id',cmp).eq('sku',String(i.sku||'').trim().toUpperCase()).eq('active',true).limit(1).maybeSingle();
            if(q.error)throw q.error;if(!q.data)throw new Error('Produk tidak dijumpai: '+(i.name||i.sku));productId=q.data.id;
          }
          items.push({product_id:productId,item_type:serviceItem?'SERVICE':'PART',quantity:Number(i.qty||1),discount:lineDiscount,description:i.name||null});
        }
        if(otherCharge>0)items.push({product_id:null,item_type:'OTHER',other_charge:true,quantity:1,unit_price:otherCharge,discount:0,description:'CAJ LAIN'});
        const transactionId=crypto.randomUUID();
        // the motorcycle picked in the customer dialog and the TRANSFER / KAD reference typed at the counter
        const vehicleId=(selectedCustomer&&window.rtPosSelectedVehicleId)?window.rtPosSelectedVehicleId(selectedCustomer):null;
        const payRef=window.rtPayRef?window.rtPayRef():'';
        const args={p_customer_id:selectedCustomer,p_payment_method:method==='QR / DUITNOW'?'QR':method,p_amount_received:received,p_items:items,p_transaction_id:transactionId};
        const name=voucher?'rt_post_pos_sale_with_loyalty_voucher':promo?'rt_post_pos_sale_with_promo':'rt_post_pos_sale';
        if(voucher||promo)Object.assign(args,{p_vehicle_id:vehicleId,p_location_id:null,p_reference_no:payRef||null});
        if(voucher)args.p_voucher_code=voucher.code;
        else if(promo)Object.assign(args,{p_manual_discount:0,p_promotion_id:promo.promotion_id,p_promo_code:promo.promo_code||null});
        else{args.p_discount=disc;if(vehicleId)args.p_vehicle_id=vehicleId;if(payRef)args.p_reference_no=payRef;}
        const done=await postProductSale(name,args,c);
        const receipt=done.detail;
        if(voucher){receipt.voucherCode=done.row?.voucher_code||voucher.code;receipt.voucherName=done.row?.reward_name||voucher.reward_name||'Loyalty Voucher'}
        window.rtPosDecorateReceipt?.(receipt,args.p_reference_no||'');
        if(typeof window.generateReceiptFromInvoice!=='function')throw new Error('Renderer resit tidak tersedia.');
        await window.generateReceiptFromInvoice(receipt);
        sessionStorage.removeItem(pendingKey);
        toast(`Invois ${receipt.invoiceNo} berjaya${voucher?' · voucher ditebus':''}.`,'success');
        if(JSON.stringify(cart())===JSON.stringify(c)){if($('rtOtherCharge'))$('rtOtherCharge').value='0';window.rtSetPosCart?.([]);window.posClearCart?.();window.rtPosRemovePromo?.(false);window.rtPosRemoveVoucher?.();window.rtPosClearMember?.();if($('posDiscount'))$('posDiscount').value='0';if($('posAmountReceived'))$('posAmountReceived').value=''}await refreshCash();afterSale(c);return;
      }

      // Job/service POS: ONE database transaction, including voucher redemption.
      const {companyId:cmp,staffId:st}=await ctx();
      if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(st||''))) throw new Error('STAFF CONTEXT | staff.id bukan UUID. Login staff belum dipetakan dengan betul.');
      const jobId=activeJob?.jobCardId;
      if(!jobId) throw new Error('JOB CONTEXT | Job Card tidak dijumpai.');
      const saleCustomerId=activeJob?.customerId||selectedCustomer||null;
      if(voucher&&String(voucher.customer_id)!==String(saleCustomerId||''))throw new Error('Voucher bukan milik customer Job Card ini.');
      // Job checkout must also support parts added directly from the POS grid.
      // Older carts only stored SKU/name/price, so resolve a missing productId by SKU
      // before calling the canonical job-sale RPC. This avoids `Part tanpa product_id`.
      const rpcItems=[];
      for(const i of c){
        const serviceItem=isService(i);
        let productId=i.productId||i.product_id||null;
        if(!serviceItem&&!productId){
          const sku=String(i.sku||'').trim().toUpperCase();
          if(!sku)throw new Error('Part tanpa SKU/product_id: '+(i.name||'Item'));
          const q=await sb.from('products').select('id').eq('company_id',cmp).eq('sku',sku).eq('active',true).limit(1).maybeSingle();
          if(q.error)throw q.error;
          if(!q.data?.id)throw new Error('Produk Job tidak dijumpai: '+(i.name||sku));
          productId=q.data.id;
          i.productId=productId;
          // Heal the live cart line too (not only this snapshot copy), so the saved
          // pending-sale snapshot still matches the cart if the sale must be re-confirmed.
          const live=cart().find(x=>String(x.sku||'')===String(i.sku||''));
          if(live&&!live.productId)live.productId=productId;
        }
        rpcItems.push({
          product_id:productId,
          job_card_item_id:i.jobCardItemId||null,
          from_job_card:!!i.fromJobCard,
          item_type:serviceItem?'SERVICE':'PART',
          quantity:Number(i.qty||1),
          service_price:serviceItem?Number(i.price||0):null,
          discount:window.RTPosDiscountModel?window.RTPosDiscountModel.normalizeLineDiscount(i.discount,i.qty,i.price):Number(i.discount||0),
          description:i.name||null
        });
      }
      const transactionId=crypto.randomUUID();
      const args={p_transaction_id:transactionId,p_job_card_id:jobId,p_kind:voucher?'VOUCHER':promo?'PROMO':'STANDARD',p_customer_id:saleCustomerId,p_payment_method:method==='QR / DUITNOW'?'QR':method,p_amount_received:received,p_discount:disc,p_items:rpcItems,p_promotion_id:promo?.promotion_id||null,p_promo_code:promo?.promo_code||null,p_voucher_code:voucher?.code||null};
      const done=await postProductSale('rt_post_job_pos_sale_idempotent',args,c);
      const receipt=done.detail;
      if(voucher){receipt.voucherCode=done.row?.voucher_code||voucher.code;receipt.voucherName=done.row?.reward_name||voucher.reward_name||'Loyalty Voucher'}
      if(typeof window.generateReceiptFromInvoice!=='function')throw new Error('Renderer resit tidak tersedia.');
      await window.generateReceiptFromInvoice(receipt);
      sessionStorage.removeItem(pendingKey);
      toast(`Bayaran berjaya · ${receipt.invoiceNo}${voucher?' · voucher ditebus':''}`,'success');
      window.rtActiveJob=null;window.rtSetPosCart?.([]);window.posClearCart?.();window.rtPosRemovePromo?.(false);window.rtPosRemoveVoucher?.();window.rtPosClearMember?.();if($('posDiscount'))$('posDiscount').value='0';if($('posAmountReceived'))$('posAmountReceived').value='';await refreshCash();window.loadPOS?.();window.loadJobCards?.();
    }catch(e){
      console.error('REV TORQ V36.4.9 CHECKOUT',{activeJob:window.rtActiveJob,error:e});
      const message=err(e);
      if(String(message).includes('PROMO_USAGE_LIMIT_REACHED')){window.rtPosRemovePromo?.(false);toast('Promo sudah habis digunakan. Pilih promo lain atau checkout tanpa promo.','error')}
      else if(String(message).includes('VOUCHER_')){window.rtPosRemoveVoucher?.();toast('Voucher tidak boleh digunakan | '+message,'error')}
      else toast((pendingSale()?'Status checkout belum dapat disahkan; troli disimpan. Cuba semula untuk semak invois | ':'Checkout gagal | ')+message,'error');
    }
    finally{checkoutBusy=false;if(btn){btn.disabled=false;btn.innerHTML=old||'BAYAR / CHECKOUT'}window.rtSyncCashTender?.()}
  }

  // Install last so older inline/legacy handlers cannot overwrite production behavior.
  window.posCheckout=checkout;
  window.rtOpenCashDrawer=openCashModal;
  window.rtCloseCashDrawer=closeCash;
  window.rtRefreshCashDrawer=refreshCash;
  window.rtCashIn=()=>cashMove('CASH_IN');
  window.rtCashOut=()=>cashMove('CASH_OUT');
  window.rtGetCashDrawer=getDrawer;
  window.rtEnsureCashDrawerOpen=async()=>!!(await getDrawer(true)|| (openCashModal(),false));
  window.rtResolveStaffId=async()=>{const s=await staffRow();return s.id};
  window.addEventListener('load',()=>{setTimeout(()=>{installCashButtons();refreshCash()},900);setInterval(()=>{installCashButtons()},1500)});
})();
