/* REV TORQ POS V2 - Web Hardware Pilot (U4-B HID scanner + CT221D web label handoff)
 * Web-only. No native APK bridge required.
 */
(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
  const money=v=>'RM '+Number(v||0).toFixed(2);
  const mmPx=8; // 203dpi thermal printers are ~8 dots/mm.

  function visible(id){const el=$(id);return !!el&&!el.classList.contains('hidden');}
  function editable(target){return !!target&&(target.isContentEditable||['INPUT','TEXTAREA','SELECT'].includes(target.tagName));}
  function normalize(v){return String(v??'').trim().replace(/[\r\n\t ]+/g,'').toUpperCase();}
  // A popup / dialog is on top of POS (receipt, confirm, parked orders, cash drawer, ...).
  function overlayOpen(){
    const list=document.querySelectorAll('#modalOverlay,[id$="Modal"],[id$="Popover"],[id$="Dialog"],.rt-confirm-backdrop,.rt-qr-zoom,[aria-modal="true"]');
    for(const el of list){
      if(el.closest('#modalOverlay')&&el.id!=='modalOverlay')continue; // covered by the overlay check
      if(el.hidden||el.classList.contains('hidden')||!el.getClientRects().length)continue;
      const cs=getComputedStyle(el);
      if(cs.display!=='none'&&cs.visibility!=='hidden')return true;
    }
    return false;
  }
  function toast(msg,type){try{window.showToast?.(msg,type||'info');}catch(_){}}

  // -------------------------------------------------------
  // U4-B HID scanner: background scan while POS has no text field focused.
  // Existing POS/inventory focused fields continue to own their Enter handlers.
  // -------------------------------------------------------
  let hidBuffer='',hidFirst=0,hidLast=0;
  let testCapture=false;
  document.addEventListener('keydown',function(e){
    if(e.ctrlKey||e.altKey||e.metaKey||e.isComposing)return;
    if(testCapture)return; // hardware test field owns the scan.
    if(!visible('view-pos'))return;
    // Scanner typing into the POS search box that sits behind an open popup.
    if(e.key==='Enter'&&e.target&&e.target.id==='posSearch'&&overlayOpen()){e.preventDefault();e.stopPropagation();toast('Tutup tetingkap dahulu, kemudian scan semula.','error');return;}
    if(editable(e.target))return;
    const now=performance.now();
    if(e.key==='Enter'||e.key==='Tab'){
      const code=normalize(hidBuffer);
      const duration=hidFirst?now-hidFirst:99999;
      const suffixGap=hidLast?now-hidLast:99999;
      hidBuffer='';hidFirst=0;hidLast=0;
      if(code.length>=4&&duration<=1800&&suffixGap<=350){
        e.preventDefault();
        // Never add behind a popup, and never let the scanner's Enter press a dialog button.
        if(overlayOpen()){e.stopPropagation();toast('Tutup tetingkap dahulu, kemudian scan semula.','error');return;}
        Promise.resolve(window.rtSelectScannedSku?.(code)).catch(err=>console.warn('U4-B POS HID scan',err));
      }
      return;
    }
    if(e.key.length===1){
      if(!hidLast||now-hidLast>180){hidBuffer='';hidFirst=now;}
      if(!hidFirst)hidFirst=now;
      hidBuffer+=e.key;hidLast=now;
      if(hidBuffer.length>100){hidBuffer=hidBuffer.slice(-100);hidFirst=now-500;}
    }
  },true);

  // -------------------------------------------------------
  // CT221D label renderer. Main web page loads JsBarcode.
  // Produces 203dpi-ish PNG, printable HTML, or Web Share file.
  // -------------------------------------------------------
  function wrapAllText(ctx,text,maxWidth){
    const words=String(text||'').replace(/\s+/g,' ').trim().split(' ').filter(Boolean);
    const lines=[];let line='';
    const pushLongWord=word=>{
      let chunk='';
      for(const ch of word){
        const next=chunk+ch;
        if(chunk&&ctx.measureText(next).width>maxWidth){lines.push(chunk);chunk=ch;}
        else chunk=next;
      }
      return chunk;
    };
    for(const word of words){
      const next=line?line+' '+word:word;
      if(ctx.measureText(next).width<=maxWidth){line=next;continue;}
      if(line){lines.push(line);line='';}
      if(ctx.measureText(word).width<=maxWidth){line=word;continue;}
      line=pushLongWord(word);
    }
    if(line)lines.push(line);
    return lines;
  }

  // Product names must remain complete on the physical label. Prefer wrapping
  // to 2-3 lines, then reduce font size only as much as needed. Never add "...".
  function fitLabelName(ctx,text,maxWidth,opts){
    const o=opts||{};
    const clean=String(text||'ITEM').replace(/\s+/g,' ').trim().toUpperCase()||'ITEM';
    const start=Math.max(8,Number(o.startSize||25));
    const requestedMin=Math.max(6,Number(o.minSize||10));
    const hardMin=Math.min(requestedMin,6);
    const maxLines=Math.max(1,Number(o.maxLines||3));
    const ratio=Math.max(1,Number(o.lineHeightRatio||1.04));
    let last={lines:[clean],fontSize:start,lineHeight:Math.ceil(start*ratio)};
    for(let size=start;size>=hardMin;size-=1){
      ctx.font=`900 ${size}px Arial, sans-serif`;
      const lines=wrapAllText(ctx,clean,maxWidth);
      last={lines,fontSize:size,lineHeight:Math.ceil(size*ratio)};
      if(lines.length<=maxLines)return last;
    }
    return last;
  }

  function stickerOptions(){
    const size=String($('rtStickerSize')?.value||'50x30');
    const [wmm,hmm]=size.split('x').map(Number);
    return {
      wmm:Number.isFinite(wmm)?wmm:50,
      hmm:Number.isFinite(hmm)?hmm:30,
      showPrice:$('rtStickerShowPrice')?.checked!==false,
      showSku:$('rtStickerShowSku')?.checked!==false,
      qty:Math.min(100,Math.max(1,Number($('rtStickerQty')?.value||1)))
    };
  }

  function drawRevTorqMark(ctx,canvasWidth,small){
    // Compact monochrome brand mark for thermal labels. Keep branding secondary
    // so product name and barcode remain the dominant information.
    const box=small?13:15;
    const gap=small?4:5;
    const wordSize=small?10:11;
    ctx.save();
    ctx.textBaseline='middle';
    ctx.textAlign='left';
    const word='REV TORQ';
    ctx.font=`900 ${wordSize}px Arial, sans-serif`;
    const wordW=ctx.measureText(word).width;
    const total=box+gap+wordW;
    const x=Math.round((canvasWidth-total)/2);
    const y=4;
    ctx.fillStyle='#000';
    ctx.fillRect(x,y,box,box);
    ctx.fillStyle='#fff';
    ctx.font=`900 ${small?8:9}px Arial, sans-serif`;
    ctx.textAlign='center';
    ctx.fillText('RT',x+box/2,y+box/2+0.5);
    ctx.fillStyle='#000';
    ctx.textAlign='left';
    ctx.font=`900 ${wordSize}px Arial, sans-serif`;
    ctx.fillText(word,x+box+gap,y+box/2+0.5);
    ctx.restore();
    return y+box;
  }

  function buildLabelCanvas(product,options){
    if(!product?.barcode)throw new Error('Item belum ada barcode. Jana barcode dahulu.');
    if(!window.JsBarcode)throw new Error('Library barcode belum siap. Pastikan internet aktif dan refresh POS.');
    const o=options||stickerOptions();
    const canvas=document.createElement('canvas');canvas.width=Math.round(o.wmm*mmPx);canvas.height=Math.round(o.hmm*mmPx);
    const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#000';ctx.textAlign='center';ctx.textBaseline='top';
    const small=o.wmm<=40;
    const pad=small?10:12,inner=canvas.width-pad*2;

    // 1) Small REV TORQ brand mark only. Branding must not steal label space.
    const logoBottom=drawRevTorqMark(ctx,canvas.width,small);

    // 2) Product name is the main text. Keep the COMPLETE name: wrap up to
    // three lines and auto-shrink only when the full name would not fit.
    let y=logoBottom+(small?4:5);
    const nameFit=fitLabelName(
      ctx,
      String(product.name||product.sku||'ITEM'),
      inner,
      {startSize:small?20:25,minSize:small?9:10,maxLines:3,lineHeightRatio:1.04}
    );
    ctx.font=`900 ${nameFit.fontSize}px Arial, sans-serif`;
    for(const line of nameFit.lines){ctx.fillText(line,canvas.width/2,y);y+=nameFit.lineHeight;}

    // Keep short names compact so the barcode still gets maximum vertical room.
    if(nameFit.lines.length===1)y+=small?1:2;

    // 3) Price remains clear but secondary to item name and barcode.
    if(o.showPrice){
      ctx.font=`900 ${small?25:29}px Arial, sans-serif`;
      ctx.fillText(money(product.sell_price),canvas.width/2,y);
      y+=small?29:33;
    }

    // 4) Large clean Code128 barcode. Human-readable value is drawn separately
    // to avoid JsBarcode shrinking the bars to make room for its text.
    const code=String(product.barcode);
    const bc=document.createElement('canvas');
    const footerH=o.showSku?(small?17:18):(small?6:7);
    const availableH=Math.max(48,canvas.height-y-footerH-5);
    const bcHeight=Math.max(48,Math.min(small?70:82,availableH));
    window.JsBarcode(bc,code,{format:'CODE128',displayValue:false,height:bcHeight,margin:2,width:2,background:'#ffffff',lineColor:'#000000'});
    const maxBarcodeW=inner;
    const scale=Math.min(1,maxBarcodeW/bc.width);
    const drawW=Math.max(1,Math.floor(bc.width*scale));
    const drawH=Math.max(1,Math.floor(bc.height*scale));
    ctx.imageSmoothingEnabled=false;
    ctx.drawImage(bc,Math.round((canvas.width-drawW)/2),y,drawW,drawH);
    y+=drawH+2;

    // 5) Show only the useful scan code below the bars. No duplicated long name/rack.
    if(o.showSku){
      const footer=String(product.sku||code||'').trim() || code;
      ctx.font=`800 ${small?11:13}px Arial, sans-serif`;
      ctx.textAlign='center';
      ctx.fillText(footer,canvas.width/2,Math.min(y,canvas.height-(small?14:16)));
    }
    return canvas;
  }

  async function canvasBlob(canvas){return await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('Gagal hasilkan PNG label.')),'image/png',1));}
  function imageFilename(product){return `REV-TORQ-${String(product?.sku||'LABEL').replace(/[^a-z0-9_-]/gi,'_')}.png`;}
  function pdfFilename(product){return `REV-TORQ-${String(product?.sku||'LABEL').replace(/[^a-z0-9_-]/gi,'_')}-${stickerOptions().wmm}x${stickerOptions().hmm}mm.pdf`;}
  const enc=new TextEncoder();
  const ascii=s=>enc.encode(String(s));
  const b64bytes=b64=>{const bin=atob(b64);const out=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)out[i]=bin.charCodeAt(i);return out;};
  function concatBytes(chunks){const total=chunks.reduce((n,c)=>n+c.length,0);const out=new Uint8Array(total);let pos=0;for(const c of chunks){out.set(c,pos);pos+=c.length;}return out;}

  // Exact-size PDF generator for Clabel Trade -> More -> PDF Printing.
  // Each sticker copy is one PDF page with the requested physical dimensions.
  function buildLabelPdf(product,options){
    const o=options||stickerOptions();
    const canvas=buildLabelCanvas(product,o);
    const jpegData=canvas.toDataURL('image/jpeg',0.96).split(',')[1];
    const jpeg=b64bytes(jpegData);
    const wpt=(o.wmm*72/25.4).toFixed(3),hpt=(o.hmm*72/25.4).toFixed(3);
    const qty=Math.min(100,Math.max(1,Number(o.qty||1)));
    const pageNums=[],contentNums=[];let next=4;
    for(let i=0;i<qty;i++){pageNums.push(next++);contentNums.push(next++);}
    const maxObj=next-1;const chunks=[];const offsets=new Array(maxObj+1).fill(0);let total=0;
    const push=c=>{const b=typeof c==='string'?ascii(c):c;chunks.push(b);total+=b.length;};
    const obj=(n,parts)=>{offsets[n]=total;push(`${n} 0 obj\n`);for(const part of parts)push(part);push(`\nendobj\n`);};
    push(new Uint8Array([37,80,68,70,45,49,46,52,10,37,226,227,207,211,10]));
    obj(1,[`<< /Type /Catalog /Pages 2 0 R >>`]);
    obj(2,[`<< /Type /Pages /Count ${qty} /Kids [${pageNums.map(n=>n+' 0 R').join(' ')}] >>`]);
    offsets[3]=total;push(`3 0 obj\n<< /Type /XObject /Subtype /Image /Width ${canvas.width} /Height ${canvas.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.length} >>\nstream\n`);push(jpeg);push(`\nendstream\nendobj\n`);
    for(let i=0;i<qty;i++){
      const content=`q\n${wpt} 0 0 ${hpt} 0 0 cm\n/Im0 Do\nQ\n`;
      obj(pageNums[i],[`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${wpt} ${hpt}] /Resources << /XObject << /Im0 3 0 R >> >> /Contents ${contentNums[i]} 0 R >>`]);
      obj(contentNums[i],[`<< /Length ${ascii(content).length} >>\nstream\n${content}endstream`]);
    }
    const xref=total;push(`xref\n0 ${maxObj+1}\n0000000000 65535 f \n`);
    for(let i=1;i<=maxObj;i++)push(String(offsets[i]).padStart(10,'0')+' 00000 n \n');
    push(`trailer\n<< /Size ${maxObj+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`);
    return new Blob([concatBytes(chunks)],{type:'application/pdf'});
  }

  function downloadBlob(blob,name){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.download=name;a.href=url;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);}

  async function sharePdfLabel(product){
    const blob=buildLabelPdf(product,stickerOptions());const file=new File([blob],pdfFilename(product),{type:'application/pdf'});
    if(navigator.share&&(!navigator.canShare||navigator.canShare({files:[file]}))){
      await navigator.share({title:'REV TORQ CT221D Label '+(product.sku||''),text:'Simpan ke Files, kemudian Clabel Trade > More > PDF Printing.',files:[file]});
      return true;
    }
    downloadBlob(blob,file.name);
    toast('PDF label disimpan. Buka Clabel Trade > More > PDF Printing.','success');
    return false;
  }

  function downloadPdfLabel(product){const blob=buildLabelPdf(product,stickerOptions());downloadBlob(blob,pdfFilename(product));return blob;}

  function previewLabel(product){
    const host=$('rtCt221Preview');if(!host||!product?.barcode){if(host)host.innerHTML='<span class="text-xs text-slate-400">Pilih item yang ada barcode untuk preview.</span>';return;}
    try{const canvas=buildLabelCanvas(product,stickerOptions());canvas.style.maxWidth='100%';canvas.style.height='auto';canvas.className='mx-auto border border-slate-200 rounded-lg bg-white';host.innerHTML='';host.appendChild(canvas);}catch(e){host.innerHTML='<span class="text-xs text-rose-600">'+esc(e.message||e)+'</span>';}
  }

  function augmentStickerModal(){
    const modal=$('rtStickerModal');if(!modal||modal.dataset.ct221d==='1')return;
    modal.dataset.ct221d='1';
    const size=$('rtStickerSize');
    if(size){size.innerHTML='<option value="50x30">50 × 30 mm — CT221D</option><option value="40x30">40 × 30 mm</option><option value="50x40">50 × 40 mm</option>';size.value='50x30';}
    const print=$('rtStickerPrint');if(!print)return;
    print.textContent='PDF UNTUK CLABEL';
    const panel=document.createElement('div');panel.className='rounded-2xl border border-sky-200 bg-sky-50 p-3 space-y-3';
    panel.innerHTML=`<div><div class="text-[11px] font-black text-sky-900 uppercase">Clabel CT221D · Web Mode</div><p class="text-[11px] text-sky-800 mt-1">CT221D iPhone tak guna AirPrint dan Clabel tak import PNG dengan mudah. POS sekarang hasilkan PDF ikut saiz label sebenar untuk Clabel Trade > More > PDF Printing.</p></div><div id="rtCt221Preview" class="bg-white rounded-xl border border-sky-100 p-2 min-h-[84px] flex items-center justify-center"><span class="text-xs text-slate-400">Pilih item untuk preview.</span></div><div class="grid grid-cols-2 gap-2"><button type="button" id="rtCt221Share" class="py-2.5 rounded-xl bg-sky-600 text-white font-black text-xs disabled:opacity-40">SHARE / SAVE PDF</button><button type="button" id="rtCt221Download" class="py-2.5 rounded-xl bg-white border border-sky-200 text-sky-800 font-black text-xs disabled:opacity-40">DOWNLOAD PDF</button></div><div class="rounded-xl bg-white border border-sky-100 px-3 py-2 text-[10px] leading-4 text-sky-900"><b>iPhone:</b> tekan SHARE / SAVE PDF → Save to Files → Clabel Trade → More → PDF Printing → pilih PDF tadi → Print.</div>`;
    print.parentElement?.insertBefore(panel,print);
    $('rtCt221Share').onclick=async()=>{try{const p=window.rtStickerProduct;if(!p?.barcode)throw new Error('Pilih item/barcode dahulu.');await sharePdfLabel(p);}catch(e){if(e?.name!=='AbortError')toast(e.message||e,'error');}};
    $('rtCt221Download').onclick=()=>{try{const p=window.rtStickerProduct;if(!p?.barcode)throw new Error('Pilih item/barcode dahulu.');downloadPdfLabel(p);toast('PDF label disimpan. Clabel Trade > More > PDF Printing.','success');}catch(e){toast(e.message||e,'error');}};
    print.onclick=e=>{e.preventDefault();try{const p=window.rtStickerProduct;if(!p?.barcode)throw new Error('Pilih item/barcode dahulu.');sharePdfLabel(p);}catch(err){toast(err.message||err,'error');}};
    ['rtStickerSize','rtStickerShowPrice','rtStickerShowSku','rtStickerQty'].forEach(id=>$(id)?.addEventListener('change',()=>previewLabel(window.rtStickerProduct)));
    const productObserver=new MutationObserver(()=>previewLabel(window.rtStickerProduct));const selected=$('rtStickerSelected');if(selected)productObserver.observe(selected,{childList:true,subtree:true,characterData:true});
    setTimeout(()=>previewLabel(window.rtStickerProduct),60);
  }

  // -------------------------------------------------------
  // Hardware Test modal
  // -------------------------------------------------------
  function makeTestProduct(){return {sku:'RT-TEST-001',name:'RKM REAR SPROCKET Y100 428 38T HEAVY DUTY',barcode:'RTTEST001',sell_price:25.00,rack_location:'TEST'};}
  function openHardwareTest(){
    let m=$('rtHardwareTest');if(m)m.remove();
    m=document.createElement('div');m.id='rtHardwareTest';m.className='fixed inset-0 z-[600] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4';
    m.innerHTML=`<div class="bg-white rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden"><div class="p-5 border-b border-slate-100 flex items-center justify-between"><div><b class="text-lg text-slate-900">Test Hardware Web</b><p class="text-xs text-slate-500 mt-1">U4-B scanner + Clabel CT221D</p></div><button id="rtHwClose" class="w-9 h-9 rounded-xl bg-slate-100 font-bold text-slate-600">✕</button></div><div class="p-5 space-y-4 max-h-[82dvh] overflow-y-auto"><section class="rounded-2xl border border-emerald-200 bg-emerald-50 p-4"><div class="flex items-center justify-between"><div><b class="text-emerald-950">U4-B Scanner Test</b><p class="text-xs text-emerald-800 mt-1">Pair Bluetooth scanner sebagai HID/keyboard. Tekan kotak dan scan mana-mana barcode.</p></div><span id="rtHwScannerBadge" class="px-2.5 py-1 rounded-full bg-white border border-emerald-200 text-[10px] font-black text-emerald-700">MENUNGGU</span></div><input id="rtHwScannerInput" autocomplete="off" inputmode="none" class="mt-3 w-full border-2 border-emerald-300 bg-white rounded-xl px-4 py-3 font-mono text-base outline-none focus:border-emerald-600" placeholder="SCAN DI SINI"><div id="rtHwScannerResult" class="mt-2 text-xs text-emerald-900">Belum ada scan.</div></section><section class="rounded-2xl border border-sky-200 bg-sky-50 p-4"><b class="text-sky-950">CT221D Test Label</b><p class="text-xs text-sky-800 mt-1">Web hasilkan PDF label 50×30 mm khas untuk Clabel Trade > More > PDF Printing.</p><div id="rtHwLabelPreview" class="mt-3 bg-white border border-sky-100 rounded-xl p-2"></div><div class="grid grid-cols-2 gap-2 mt-3"><button id="rtHwShare" class="py-2.5 rounded-xl bg-sky-600 text-white font-black text-xs">SHARE / SAVE PDF</button><button id="rtHwDownload" class="py-2.5 rounded-xl bg-white border border-sky-200 text-sky-900 font-black text-xs">DOWNLOAD PDF</button></div></section><div class="rounded-xl bg-slate-50 border border-slate-200 p-3 text-[11px] text-slate-600"><b>Target test:</b> U4-B scan mesti keluar kod + status LULUS. CT221D: Save PDF ke Files, kemudian Clabel Trade > More > PDF Printing > pilih PDF > Print.</div></div></div>`;
    document.body.appendChild(m);
    $('rtHwClose').onclick=()=>{testCapture=false;m.remove();};m.addEventListener('click',e=>{if(e.target===m){testCapture=false;m.remove();}});
    const input=$('rtHwScannerInput');testCapture=true;let start=0,last=0,count=0;
    input.addEventListener('keydown',e=>{
      const now=performance.now();if(e.key.length===1){if(!start)start=now;last=now;count++;return;}
      if(e.key==='Enter'||e.key==='Tab'){
        e.preventDefault();const code=normalize(input.value);const duration=start?Math.max(1,now-start):0;const avg=count>1?duration/(count-1):0;
        if(code.length>=4){$('rtHwScannerBadge').textContent='LULUS';$('rtHwScannerBadge').className='px-2.5 py-1 rounded-full bg-emerald-600 text-[10px] font-black text-white';$('rtHwScannerResult').innerHTML=`Kod: <b class="font-mono">${esc(code)}</b><br>Suffix: <b>${e.key.toUpperCase()}</b> · ${count} aksara · ${Math.round(duration)} ms${avg?` · ~${Math.round(avg)} ms/key`:''}`;}
        else{$('rtHwScannerBadge').textContent='CUBA LAGI';$('rtHwScannerResult').textContent='Kod terlalu pendek / scanner belum hantar data penuh.';}
        input.value='';start=0;last=0;count=0;setTimeout(()=>input.focus(),40);
      }
    });
    const p=makeTestProduct();try{const c=buildLabelCanvas(p,{wmm:50,hmm:30,showPrice:true,showSku:true,qty:1});c.style.maxWidth='100%';c.style.height='auto';$('rtHwLabelPreview').appendChild(c);}catch(e){$('rtHwLabelPreview').textContent=e.message||e;}
    $('rtHwShare').onclick=async()=>{try{await sharePdfLabel(p);}catch(e){if(e?.name!=='AbortError')toast(e.message||e,'error');}};
    $('rtHwDownload').onclick=()=>{try{downloadBlob(buildLabelPdf(p,{wmm:50,hmm:30,showPrice:true,showSku:true,qty:1}),'REV-TORQ-CT221D-TEST-50x30mm.pdf');}catch(e){toast(e.message||e,'error');}};
    setTimeout(()=>input.focus(),100);
  }
  window.rtOpenHardwareTest=openHardwareTest;

  function addHardwareButton(){
    const view=$('view-inventory');if(!view||$('rtHardwareTestBtn'))return;
    const sticker=[...view.querySelectorAll('button')].find(b=>/PRINT STIKER/i.test(b.textContent||''));if(!sticker)return;
    const b=document.createElement('button');b.type='button';b.id='rtHardwareTestBtn';b.className='w-full lg:w-auto bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-xl font-bold flex items-center justify-center gap-2 shadow-sm active:scale-95';b.innerHTML='<span class="text-sm">⌁</span> TEST HARDWARE';b.onclick=openHardwareTest;sticker.parentElement?.insertBefore(b,sticker);
  }

  const obs=new MutationObserver(()=>{addHardwareButton();augmentStickerModal();});
  window.addEventListener('load',()=>{setTimeout(addHardwareButton,350);setTimeout(augmentStickerModal,500);obs.observe(document.documentElement,{childList:true,subtree:true});});
  window.rtWebHardware={normalize,fitLabelName,buildLabelCanvas,buildLabelPdf,sharePdfLabel,downloadPdfLabel,openHardwareTest};
})();
