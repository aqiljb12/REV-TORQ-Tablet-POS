/* REV TORQ POS V2 WEB — Papan Bengkel (workshop board) on the Job Card page.
   Shows the same jobs as the Job Card list (js/jobcards.js publishes them as
   window.rtJobRows: not cancelled, not paid) as columns by status, sized for
   iPad. A status button saves through the same path as the Job Card form
   (db.collection('job_cards').doc(jobNo).update) — no new tables or RPCs.
   Plain ES2017 for Safari on iPad. */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  var VIEW_KEY='rt_job_view_v1', REFRESH_MS=60000;
  var COLS=[
    {key:'OPEN',label:'BARU',empty:'Tiada job baru'},
    {key:'IN_PROGRESS',label:'SEDANG DIBAIKI',empty:'Tiada motor sedang dibaiki'},
    {key:'WAITING_PARTS',label:'TUNGGU BARANG',empty:'Tiada yang tunggu barang'},
    {key:'COMPLETED',label:'SIAP · TUNGGU BAYAR',empty:'Tiada motor siap'}
  ];
  var LABEL={OPEN:'Baru',IN_PROGRESS:'Sedang dibaiki',WAITING_PARTS:'Tunggu barang',COMPLETED:'Siap'};
  // Main next step for each column (big touch buttons); anything else is in the Job Card form.
  var MOVES={
    OPEN:[{to:'IN_PROGRESS',text:'MULA BAIKI',cls:'primary'}],
    IN_PROGRESS:[{to:'COMPLETED',text:'SIAP',cls:'done'},{to:'WAITING_PARTS',text:'TUNGGU BARANG',cls:''}],
    WAITING_PARTS:[{to:'IN_PROGRESS',text:'SAMBUNG BAIKI',cls:'primary'}],
    COMPLETED:[]
  };
  var state={q:'',mech:'',busy:{},updated:0};

  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
  function money(v){var n=Number(v);return 'RM '+(isFinite(n)?n:0).toFixed(2);}
  function toast(m,t){try{if(window.showToast)window.showToast(m,t||'success');}catch(_){}}
  function feather(){try{if(window.feather)window.feather.replace();}catch(_){}}
  function can(view){return !!document.querySelector('#mainNav [data-view="'+view+'"]');}
  function mode(){try{return localStorage.getItem(VIEW_KEY)==='list'?'list':'board';}catch(_){return 'board';}}
  function setMode(m){try{localStorage.setItem(VIEW_KEY,m);}catch(_){}apply();}
  function rows(){return Array.isArray(window.rtJobRows)?window.rtJobRows:[];}
  function colOf(status){
    var s=String(status||'').toUpperCase();
    if(s==='IN_PROGRESS'||s==='WAITING_PARTS')return s;
    if(s==='COMPLETED'||s==='READY'||s==='DONE'||s==='CLOSED')return 'COMPLETED';
    return 'OPEN';
  }
  // Same rule as BAWA KE POS (js/job-pos-flow.js accepts COMPLETED only and re-checks payment).
  function payable(status){return String(status||'').toUpperCase()==='COMPLETED';}
  function age(ts){
    var t=ts?new Date(ts).getTime():NaN;
    if(!isFinite(t))return {text:'',level:0};
    var m=Math.max(0,Math.round((Date.now()-t)/60000));
    var text=m<1?'baru masuk':m<60?m+' min':m<1440?Math.floor(m/60)+'j '+(m%60)+'m':Math.floor(m/1440)+' hari';
    return {text:text,level:m>=4320?2:m>=1440?1:0};
  }
  function hay(j){return [j.jobNo,j.plateNo,j.customerName,j.customerPhone,j.vehicleModel,j.assignedStaffName,j.complaint].join(' ').toLowerCase();}
  function visible(){
    var q=state.q.trim().toLowerCase();
    return rows().filter(function(j){
      if(state.mech&&String(j.assignedStaffId||'')!==state.mech)return false;
      return !q||hay(j).indexOf(q)>=0;
    });
  }

  // ---------------------------------------------------------------- render
  function card(j){
    var col=colOf(j.status),a=age(j.createdAt||j.opened_at),busy=!!state.busy[j.jobNo];
    var moves=(MOVES[col]||[]).map(function(m){
      return '<button type="button" class="rt-jb-btn '+m.cls+'" data-move="'+m.to+'"'+(busy?' disabled':'')+'>'+m.text+'</button>';
    }).join('');
    if(col==='COMPLETED'&&payable(j.status)&&can('pos'))moves+='<button type="button" class="rt-jb-btn pos" data-act="pos"'+(busy?' disabled':'')+'>BAWA KE POS</button>';
    var mech=j.assignedStaffName&&j.assignedStaffName!=='-'?j.assignedStaffName:'Tiada pomen';
    return '<article class="rt-jb-card'+(a.level?' is-age-'+a.level:'')+(busy?' is-busy':'')+'" data-job="'+esc(j.jobNo)+'">'+
      '<button type="button" class="rt-jb-main" data-act="edit" aria-label="Buka '+esc(j.jobNo)+'">'+
        '<span class="rt-jb-top"><b class="rt-jb-plate">'+esc(j.plateNo||'-')+'</b>'+(a.text?'<span class="rt-jb-age" title="Masa dalam bengkel">'+esc(a.text)+'</span>':'')+'</span>'+
        '<span class="rt-jb-model">'+esc(j.vehicleModel&&j.vehicleModel!=='-'?j.vehicleModel:'Motor')+'</span>'+
        '<span class="rt-jb-cust">'+esc(j.customerName||'-')+'</span>'+
        (j.complaint?'<span class="rt-jb-complaint">'+esc(j.complaint)+'</span>':'')+
        '<span class="rt-jb-meta"><span class="rt-jb-mech'+(mech==='Tiada pomen'?' is-none':'')+'">'+esc(mech)+'</span><span class="rt-jb-total">'+money(j.total)+'</span></span>'+
        '<span class="rt-jb-no">'+esc(j.jobNo)+'</span>'+
      '</button>'+
      (moves?'<div class="rt-jb-actions">'+moves+'</div>':'')+
    '</article>';
  }
  function render(){
    var host=$('rtJobBoard');if(!host)return;
    var all=rows(),list=visible(),by={};
    COLS.forEach(function(c){by[c.key]=[];});
    list.forEach(function(j){by[colOf(j.status)].push(j);});
    // Oldest first inside a column: the motor waiting longest is on top.
    COLS.forEach(function(c){by[c.key].sort(function(a,b){return String(a.createdAt||'')<String(b.createdAt||'')?-1:1;});});
    var inShop=all.filter(function(j){return colOf(j.status)!=='COMPLETED';}).length;
    var done=all.filter(function(j){return colOf(j.status)==='COMPLETED';});
    var doneTotal=done.reduce(function(s,j){return s+Number(j.total||0);},0);
    // Mechanic filter chips (from the jobs on the board).
    var mechs={},none=0;
    all.forEach(function(j){if(j.assignedStaffId){var k=String(j.assignedStaffId);mechs[k]=mechs[k]||{name:j.assignedStaffName||'-',n:0};mechs[k].n++;}else none++;});
    if(state.mech&&!mechs[state.mech])state.mech='';
    var chips='<button type="button" data-mech=""'+(state.mech?'':' class="active"')+'>Semua <b>'+all.length+'</b></button>'+
      Object.keys(mechs).map(function(k){return '<button type="button" data-mech="'+esc(k)+'"'+(state.mech===k?' class="active"':'')+'>'+esc(mechs[k].name)+' <b>'+mechs[k].n+'</b></button>';}).join('');
    var t=state.updated?new Date(state.updated):null;
    host.innerHTML=
      '<div class="rt-jb-head">'+
        '<div class="rt-jb-summary"><span><b>'+inShop+'</b> motor dalam bengkel</span><span class="rt-jb-sum-done"><b>'+done.length+'</b> siap tunggu bayar · '+money(doneTotal)+'</span>'+(none?'<span class="rt-jb-sum-none">'+none+' tiada pomen</span>':'')+'</div>'+
        '<div class="rt-jb-headright">'+(t?'<span class="rt-jb-updated">Dikemas kini '+String(t.getHours()).padStart(2,'0')+':'+String(t.getMinutes()).padStart(2,'0')+'</span>':'')+
          '<button type="button" class="rt-jb-refresh" data-act="refresh" aria-label="Muat semula"><i data-feather="refresh-cw"></i></button></div>'+
      '</div>'+
      (Object.keys(mechs).length?'<div class="rt-jb-mechs" role="group" aria-label="Tapis pomen">'+chips+'</div>':'')+
      '<div class="rt-jb-cols">'+COLS.map(function(c){
        var items=by[c.key];
        return '<section class="rt-jb-col is-'+c.key.toLowerCase()+'" data-status="'+c.key+'"><header><b>'+c.label+'</b><span class="rt-jb-count">'+items.length+'</span></header>'+
          '<div class="rt-jb-list">'+(items.length?items.map(card).join(''):'<div class="rt-jb-empty">'+(state.q||state.mech?'Tiada padanan':c.empty)+'</div>')+'</div></section>';
      }).join('')+'</div>';
    feather();
  }

  // ---------------------------------------------------------------- actions
  function find(jobNo){return rows().filter(function(j){return String(j.jobNo)===String(jobNo);})[0]||null;}
  function move(jobNo,status){
    var job=find(jobNo);
    if(!job||state.busy[jobNo])return;
    if(!window.db||typeof window.db.collection!=='function'){toast('Sambungan belum sedia.','error');return;}
    var oldStatus=job.status;
    state.busy[jobNo]=1;render();
    var p=window.currentProfile||{};
    // Same write as the Job Card form / pomen update (bridge resolves job_no -> id and staff).
    Promise.resolve(window.db.collection('job_cards').doc(jobNo).update({status:status,updatedAt:new Date().toISOString(),updatedBy:p.staffId||null}))
      .then(function(){
        job.status=status;
        toast(jobNo+' · '+(job.plateNo||'')+' → '+LABEL[status],'success');
        try{if(typeof window.logAudit==='function')window.logAudit('JOB_STATUS_CHANGE','Job '+jobNo+': '+(LABEL[colOf(oldStatus)]||oldStatus)+' → '+LABEL[status]+' (papan bengkel)',{entityType:'job_cards',entityId:job.id,entityKey:jobNo,before:{status:oldStatus},after:{status:status}});}catch(_){}
        if(typeof window.loadJobCards==='function')return window.loadJobCards();
      })
      .catch(function(e){toast('Status gagal dikemas kini: '+(e&&e.message||e),'error');})
      .then(function(){delete state.busy[jobNo];render();});
  }
  function onClick(e){
    var t=e.target;
    var chip=t.closest?t.closest('[data-mech]'):null;
    if(chip){state.mech=chip.getAttribute('data-mech')||'';render();return;}
    var btn=t.closest?t.closest('[data-move],[data-act]'):null;if(!btn||btn.disabled)return;
    var cardEl=btn.closest('[data-job]'),jobNo=cardEl?cardEl.getAttribute('data-job'):'';
    var act=btn.getAttribute('data-act'),to=btn.getAttribute('data-move');
    if(act==='refresh'){refresh();return;}
    if(to){move(jobNo,to);return;}
    if(act==='edit'&&typeof window.editJobCard==='function')window.editJobCard(jobNo);
    else if(act==='pos'&&typeof window.rtSelectJobIntoPOS==='function')window.rtSelectJobIntoPOS(jobNo);
  }
  function refresh(){if(typeof window.loadJobCards==='function')window.loadJobCards();}

  // ---------------------------------------------------------------- wiring
  function apply(){
    var board=$('rtJobBoard'),list=$('rtJobListWrap'),tg=$('rtJobViewToggle');
    if(!board||!list)return;
    var m=mode();
    board.hidden=m!=='board';list.hidden=m==='board';
    if(tg)[].forEach.call(tg.querySelectorAll('[data-job-view]'),function(b){
      var on=b.getAttribute('data-job-view')===m;b.classList.toggle('active',on);b.setAttribute('aria-selected',on?'true':'false');
    });
    if(m==='board')render();
  }
  function wire(){
    var board=$('rtJobBoard'),tg=$('rtJobViewToggle'),search=$('searchJobCard');
    if(board&&!board.__rtWired){board.__rtWired=1;board.addEventListener('click',onClick);}
    if(tg&&!tg.__rtWired){tg.__rtWired=1;tg.addEventListener('click',function(e){var b=e.target.closest?e.target.closest('[data-job-view]'):null;if(b)setMode(b.getAttribute('data-job-view'));});}
    if(search&&!search.__rtBoard){search.__rtBoard=1;search.addEventListener('input',function(){state.q=search.value||'';if(mode()==='board')render();});}
    apply();
  }
  document.addEventListener('rt-jobs-loaded',function(){state.updated=Date.now();if(mode()==='board')render();});
  setInterval(function(){
    if(window.__rtActiveView!=='jobcard'||document.hidden||mode()!=='board')return;
    if(document.querySelector('#jobCardModal:not(.hidden)'))return; // don't refresh under the open form
    refresh();
  },REFRESH_MS);
  document.addEventListener('visibilitychange',function(){if(!document.hidden&&window.__rtActiveView==='jobcard'&&mode()==='board')refresh();});
  window.rtRenderWorkshopBoard=render;
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',wire,{once:true});else wire();
})();
