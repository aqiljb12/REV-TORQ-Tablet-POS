/* REV TORQ POS V2 WEB — Log Sistem (audit trail viewer).
   Reads audit_logs directly (company scoped, newest first) and shows who did what,
   when, why, and what changed (before -> after). Filters: group, period, search.
   CSV export of what is on screen. Read only: the log cannot be edited here.
   Used by the "Log Sistem" page and the "Aktiviti Override terkini" card.
   Plain ES2017 for Safari on iPad. */
(function(){
  'use strict';
  var PAGE=100;
  var GROUPS=[
    {id:'all',label:'Semua',like:null},
    {id:'override',label:'Override',like:'OVERRIDE%'},
    {id:'direct',label:'Ubah / Padam terus',like:'ROW_%'},
    {id:'void',label:'Void',like:'%VOID%'},
    {id:'job',label:'Job Card',like:'%JOB%'}
  ];
  var PERIODS=[{id:'today',label:'Hari ini',days:0},{id:'7',label:'7 hari',days:7},{id:'30',label:'30 hari',days:30},{id:'all',label:'Semua',days:null}];
  var LABELS={
    OVERRIDE_BEGIN:'Override dimulakan',OVERRIDE_END:'Override ditamatkan',
    OVERRIDE_CUSTOMER_ARCHIVE:'Arkib pelanggan',OVERRIDE_CUSTOMER_RESTORE:'Pulih pelanggan',
    OVERRIDE_VEHICLE_ARCHIVE:'Arkib kenderaan',OVERRIDE_VEHICLE_RESTORE:'Pulih kenderaan',
    OVERRIDE_PRODUCT_ARCHIVE:'Arkib item',OVERRIDE_PRODUCT_RESTORE:'Pulih item',
    OVERRIDE_SUPPLIER_ARCHIVE:'Arkib pembekal',OVERRIDE_SUPPLIER_RESTORE:'Pulih pembekal',
    OVERRIDE_JOB_CARD_CANCEL:'Batal Job Card',
    ROW_DELETE:'Rekod dipadam (terus)',ROW_UPDATE:'Rekod diubah (terus)',
    JOB_EDIT_PAID:'Sunting Job sudah dibayar',UPDATE_JOB:'Kemas kini Job Card',CREATE_JOB:'Job Card baru',
    JOB_STATUS_CHANGE:'Tukar status Job',VOID_INVOICE:'VOID invois',POS_CHECKOUT:'Jualan POS',
    CREATE_CUSTOMER:'Pelanggan baru',UPDATE_CUSTOMER:'Kemas kini pelanggan',CREATE_VEHICLE:'Kenderaan baru',
    CREATE_INVENTORY:'Item baru',UPDATE_INVENTORY:'Kemas kini item',CREATE_SUPPLIER:'Pembekal baru',UPDATE_SUPPLIER:'Kemas kini pembekal'
  };
  var st={group:'all',period:'7',q:'',rows:[],staff:{},more:false,loading:false,error:'',req:0,built:false,open:{}};

  function $(id){return document.getElementById(id);}
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
  function sb(){return window.supabaseClient||null;}
  function prof(){return window.currentProfile||null;}
  function meta(r){var m=r&&r.metadata;if(typeof m==='string'){try{m=JSON.parse(m);}catch(_){m=null;}}return m&&typeof m==='object'&&!Array.isArray(m)?m:{};}
  function actionLabel(a){var k=String(a||'').toUpperCase();return LABELS[k]||k.replace(/_/g,' ').toLowerCase().replace(/^./,function(c){return c.toUpperCase();});}
  function severity(a){
    var k=String(a||'').toUpperCase();
    if(k==='ROW_DELETE'||k==='JOB_EDIT_PAID'||/VOID/.test(k))return 'is-red';
    if(/^OVERRIDE_/.test(k)||k==='ROW_UPDATE')return 'is-amber';
    return '';
  }
  function when(ts){
    if(!ts)return '-';
    try{return new Intl.DateTimeFormat('ms-MY',{timeZone:'Asia/Kuala_Lumpur',day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(ts));}catch(_){return String(ts).slice(0,16).replace('T',' ');}
  }
  function whenFull(ts){
    if(!ts)return '';
    try{return new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Kuala_Lumpur',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(new Date(ts));}catch(_){return String(ts);}
  }
  function short(v,n){var s=typeof v==='string'?v:JSON.stringify(v);if(s==null)return '';s=String(s);return s.length>(n||80)?s.slice(0,(n||80)-1)+'…':s;}
  // Short human line for one row: label / key, reason, details.
  function summary(r){
    var m=meta(r),p=[];
    if(m.label)p.push(m.label);else if(m.key)p.push(m.key);
    if(m.invoice_no)p.push('Invois '+m.invoice_no);
    if(m.job_no)p.push('Job '+m.job_no);
    if(m.sku)p.push(m.sku);
    var action=String(r.action||'').toUpperCase();
    if(action==='OVERRIDE_BEGIN'){p.push((m.minutes||'')+' minit');}
    if(action==='OVERRIDE_END')p.push(m.ended_by==='timeout'?'tamat masa':m.ended_by==='replaced'?'diganti sesi baru':'ditamatkan');
    var reason=m.reason||m.void_reason;if(reason)p.push('Sebab: '+reason);
    if(m.details&&p.length<3)p.push(m.details);
    if(/^ROW_/.test(action)){
      var row=r.before_data&&typeof r.before_data==='object'?r.before_data:(r.after_data||{});
      var nm=row.name||row.job_no||row.invoice_no||row.plate_no||row.sku||row.staff_code;
      p.unshift([r.entity_type,nm].filter(Boolean).join(' '));
      if(Array.isArray(m.changed)&&m.changed.length)p.push('medan: '+m.changed.slice(0,6).join(', '));
      if(m.source==='db_trigger')p.push('terus pada pangkalan data');
    }
    if(!p.length&&r.entity_type)p.push(r.entity_type);
    return p.join(' · ')||'-';
  }
  function actor(r){
    if(r.staff_id&&st.staff[r.staff_id])return st.staff[r.staff_id];
    var m=meta(r);
    if(!r.staff_id)return m.db_user?'DB: '+m.db_user:'Luar POS';
    return '-';
  }
  // Fields that differ between before / after (top level only).
  function changes(r){
    var b=r.before_data,a=r.after_data,out=[];
    if(b&&typeof b==='object'&&a&&typeof a==='object'){
      var keys={};Object.keys(b).forEach(function(k){keys[k]=1;});Object.keys(a).forEach(function(k){keys[k]=1;});
      Object.keys(keys).forEach(function(k){
        if(k==='updated_at')return;
        var x=JSON.stringify(b[k]),y=JSON.stringify(a[k]);
        if(x!==y)out.push({k:k,from:b[k],to:a[k]});
      });
    }else if(b&&typeof b==='object'){Object.keys(b).slice(0,12).forEach(function(k){out.push({k:k,from:b[k],to:undefined});});}
    else if(a&&typeof a==='object'){Object.keys(a).slice(0,12).forEach(function(k){out.push({k:k,from:undefined,to:a[k]});});}
    return out;
  }
  function detailHtml(r){
    var m=meta(r),ch=changes(r),h='<div class="rt-av-detail">';
    h+='<div class="rt-av-kv"><span>Masa penuh</span><b>'+esc(whenFull(r.created_at))+'</b></div>';
    if(m.role)h+='<div class="rt-av-kv"><span>Peranan</span><b>'+esc(m.role)+'</b></div>';
    if(r.entity_type)h+='<div class="rt-av-kv"><span>Jenis rekod</span><b>'+esc(r.entity_type)+(r.entity_id?' · '+esc(String(r.entity_id).slice(0,8)):'')+'</b></div>';
    if(m.reason)h+='<div class="rt-av-kv"><span>Sebab</span><b>'+esc(m.reason)+'</b></div>';
    if(m.override_session)h+='<div class="rt-av-kv"><span>Sesi Override</span><b>'+esc(String(m.override_session).slice(0,8))+'</b></div>';
    if(m.details)h+='<div class="rt-av-kv"><span>Butiran</span><b>'+esc(short(m.details,300))+'</b></div>';
    if(ch.length){
      h+='<div class="rt-av-changes"><span>Perubahan</span>'+ch.slice(0,14).map(function(c){
        return '<div><code>'+esc(c.k)+'</code> <i class="rt-av-from">'+esc(c.from===undefined?'—':short(c.from,70))+'</i> → <i class="rt-av-to">'+esc(c.to===undefined?'—':short(c.to,70))+'</i></div>';
      }).join('')+(ch.length>14?'<div class="rt-av-more">+'+(ch.length-14)+' lagi</div>':'')+'</div>';
    }
    return h+'</div>';
  }

  // ------------------------------------------------------------ data
  function sinceIso(periodId){
    var p=PERIODS.filter(function(x){return x.id===periodId;})[0];
    if(!p||p.days==null)return null;
    var d=new Date();
    if(p.days===0){d.setHours(0,0,0,0);return d.toISOString();}
    return new Date(Date.now()-p.days*86400000).toISOString();
  }
  function fetchPage(o){
    o=o||{};
    var c=sb(),p=prof();
    if(!c||!p||!p.companyId)return Promise.reject(new Error('Sesi staf belum sedia.'));
    var g=GROUPS.filter(function(x){return x.id===(o.group||'all');})[0]||GROUPS[0];
    var from=o.from||0,lim=o.limit||PAGE;
    var q=c.from('audit_logs').select('id,created_at,staff_id,action,entity_type,entity_id,before_data,after_data,metadata').eq('company_id',p.companyId);
    if(g.like)q=q.ilike('action',g.like);
    var since=o.since?sinceIso(o.since):null;if(since)q=q.gte('created_at',since);
    q=q.order('created_at',{ascending:false}).range(from,from+lim);
    return Promise.resolve(q).then(function(r){
      if(r.error)throw r.error;
      var all=r.data||[],more=all.length>lim,rows=all.slice(0,lim);
      return staffNames(rows).then(function(names){return {rows:rows,staff:names,more:more};});
    });
  }
  function staffNames(rows){
    var c=sb(),p=prof(),ids={};
    rows.forEach(function(r){if(r.staff_id)ids[r.staff_id]=1;});
    var list=Object.keys(ids).filter(function(id){return !st.staff[id];});
    if(!list.length)return Promise.resolve(st.staff);
    return Promise.resolve(c.from('staff').select('id,name,staff_code').eq('company_id',p.companyId).in('id',list)).then(function(r){
      (r.data||[]).forEach(function(s){st.staff[s.id]=s.name||s.staff_code||s.id;});
      return st.staff;
    },function(){return st.staff;});
  }
  function fetchPublic(o){return fetchPage({group:o&&o.group,limit:o&&o.limit,since:o&&o.since});}

  // ------------------------------------------------------------ page
  function host(){return $('view-audit');}
  function build(){
    var v=host();if(!v)return false;
    if(st.built&&$('rtAvPage'))return true;
    var legacy=v.querySelector('.bg-white.rounded-2xl');if(legacy)legacy.classList.add('hidden');
    var h3=v.querySelector('h3');if(h3)h3.classList.add('hidden');
    var el=document.createElement('div');el.id='rtAvPage';el.className='rt-av';
    el.innerHTML=
      '<div class="rt-ov-head"><div class="rt-ov-eyebrow">ADMIN / OWNER</div><h3>Log Sistem (Audit)</h3><p>Rekod tidak boleh diubah atau dipadam. Semak siapa buat apa, bila, kenapa, dan apa yang berubah.</p></div>'+
      '<div class="rt-av-bar">'+
        '<div class="rt-av-chips" id="rtAvGroups">'+GROUPS.map(function(g){return '<button type="button" data-av-group="'+g.id+'">'+esc(g.label)+'</button>';}).join('')+'</div>'+
        '<div class="rt-av-chips" id="rtAvPeriods">'+PERIODS.map(function(p){return '<button type="button" data-av-period="'+p.id+'">'+esc(p.label)+'</button>';}).join('')+'</div>'+
      '</div>'+
      '<div class="rt-av-tools"><input id="rtAvSearch" type="search" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" placeholder="Cari staf, tindakan, no. invois / job, sebab…">'+
        '<button type="button" class="rt-btn rt-btn-secondary" data-av-go="refresh">MUAT SEMULA</button>'+
        '<button type="button" class="rt-btn rt-btn-dark" data-av-go="csv">EKSPORT CSV</button></div>'+
      '<div id="rtAvQueue"></div>'+
      '<div class="rt-av-card"><div id="rtAvList"></div><div class="rt-av-foot" id="rtAvFoot"></div></div>';
    v.appendChild(el);st.built=true;return true;
  }
  function filtered(){
    var q=st.q.trim().toLowerCase();
    if(!q)return st.rows;
    return st.rows.filter(function(r){
      var hay=[actionLabel(r.action),r.action,actor(r),summary(r),meta(r).details||''].join(' ').toLowerCase();
      return hay.indexOf(q)>=0;
    });
  }
  function syncChips(){
    Array.prototype.forEach.call(document.querySelectorAll('#rtAvGroups [data-av-group]'),function(b){b.classList.toggle('active',b.getAttribute('data-av-group')===st.group);});
    Array.prototype.forEach.call(document.querySelectorAll('#rtAvPeriods [data-av-period]'),function(b){b.classList.toggle('active',b.getAttribute('data-av-period')===st.period);});
  }
  function paint(){
    var list=$('rtAvList'),foot=$('rtAvFoot');if(!list)return;
    syncChips();
    if(st.loading&&!st.rows.length){list.innerHTML='<div class="rt-ov-empty">Memuatkan…</div>';if(foot)foot.innerHTML='';return;}
    if(st.error){list.innerHTML='<div class="rt-ov-empty is-err">'+esc(st.error)+'</div>';if(foot)foot.innerHTML='';return;}
    var rows=filtered();
    if(!rows.length){list.innerHTML='<div class="rt-ov-empty">Tiada rekod untuk penapis ini.</div>';}
    else list.innerHTML='<div class="rt-av-scroll"><table class="rt-av-table"><thead><tr><th>Waktu</th><th>Staf</th><th>Tindakan</th><th>Rekod / Sebab</th><th></th></tr></thead><tbody>'+
      rows.map(function(r){
        var open=!!st.open[r.id];
        return '<tr class="rt-av-row"><td class="rt-av-when">'+esc(when(r.created_at))+'</td><td>'+esc(actor(r))+'</td>'+
          '<td><span class="rt-av-badge '+severity(r.action)+'">'+esc(actionLabel(r.action))+'</span></td><td class="rt-av-sum">'+esc(summary(r))+'</td>'+
          '<td><button type="button" class="rt-av-toggle" data-av-open="'+esc(r.id)+'" aria-expanded="'+(open?'true':'false')+'" aria-label="Butiran">'+(open?'−':'+')+'</button></td></tr>'+
          (open?'<tr class="rt-av-detail-row"><td colspan="5">'+detailHtml(r)+'</td></tr>':'');
      }).join('')+'</tbody></table></div>';
    if(foot)foot.innerHTML='<span>'+rows.length+' rekod dipaparkan'+(st.q?' (ditapis)':'')+'</span>'+(st.more?'<button type="button" class="rt-btn rt-btn-secondary" data-av-go="more">MUAT LAGI</button>':'');
  }
  function paintQueue(){
    var box=$('rtAvQueue');if(!box)return;
    var s=typeof window.rtAuditStatus==='function'?window.rtAuditStatus():null;
    if(s&&s.queued>0){
      box.innerHTML='<div class="rt-ov-warn rt-ov-warn-wide">'+s.queued+' rekod audit belum dihantar ke pelayan (disimpan dalam tablet ini'+(s.lastError?': '+esc(s.lastError):'')+'). <button type="button" data-av-go="flush">HANTAR SEKARANG</button></div>';
    }else box.innerHTML='';
  }
  function load(append){
    if(!build())return Promise.resolve();
    var n=++st.req;
    if(!append){st.rows=[];st.more=false;st.open={};}
    st.loading=true;st.error='';paint();paintQueue();
    return fetchPage({group:st.group,since:st.period,from:append?st.rows.length:0}).then(function(res){
      if(n!==st.req)return;
      st.rows=append?st.rows.concat(res.rows):res.rows;st.more=res.more;st.loading=false;paint();
    },function(e){
      if(n!==st.req)return;
      st.loading=false;st.error='Tidak dapat memuatkan log: '+String(e&&e.message||e);paint();
    });
  }
  // ------------------------------------------------------------ csv
  function cell(v){
    var s=v==null?'':(typeof v==='object'?JSON.stringify(v):String(v));
    if(/^[=+\-@\t\r]/.test(s))s="'"+s;     // no spreadsheet formula injection
    return '"'+s.replace(/"/g,'""')+'"';
  }
  function csv(rows){
    var head=['Waktu','Staf','Peranan','Tindakan','Kod tindakan','Jenis rekod','ID rekod','Rujukan','Sebab','Butiran','Sebelum','Selepas'];
    var lines=[head.map(cell).join(',')];
    rows.forEach(function(r){
      var m=meta(r);
      lines.push([whenFull(r.created_at),actor(r),m.role||'',actionLabel(r.action),r.action,r.entity_type||'',r.entity_id||'',m.label||m.key||m.invoice_no||m.job_no||'',m.reason||'',m.details||'',r.before_data,r.after_data].map(cell).join(','));
    });
    return '﻿'+lines.join('\r\n');
  }
  function download(){
    var rows=filtered();
    if(!rows.length){if(window.showToast)window.showToast('Tiada rekod untuk dieksport.','info');return;}
    var text=csv(rows),name='log-sistem-'+new Date().toISOString().slice(0,10)+'.csv';
    try{
      var blob=new Blob([text],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');
      a.href=url;a.download=name;document.body.appendChild(a);a.click();
      setTimeout(function(){document.body.removeChild(a);URL.revokeObjectURL(url);},1500);
    }catch(e){if(window.showToast)window.showToast('Eksport gagal: '+e.message,'error');}
    window.__rtLastAuditCsv=text;
  }

  function onClick(ev){
    var v=host();if(!v||!ev.target||!ev.target.closest)return;
    var t=ev.target.closest('[data-av-group],[data-av-period],[data-av-go],[data-av-open]');
    if(!t||!v.contains(t))return;
    if(t.hasAttribute('data-av-group')){st.group=t.getAttribute('data-av-group');load();return;}
    if(t.hasAttribute('data-av-period')){st.period=t.getAttribute('data-av-period');load();return;}
    if(t.hasAttribute('data-av-open')){var id=t.getAttribute('data-av-open');st.open[id]=!st.open[id];paint();return;}
    var go=t.getAttribute('data-av-go');
    if(go==='refresh')load();
    else if(go==='more')load(true);
    else if(go==='csv')download();
    else if(go==='flush'&&typeof window.rtAuditFlush==='function')window.rtAuditFlush().then(function(){paintQueue();load();});
  }
  function onInput(ev){var t=ev.target;if(t&&t.id==='rtAvSearch'){st.q=t.value;paint();}}
  document.addEventListener('click',onClick);
  document.addEventListener('input',onInput);

  window.rtAuditView={load:function(){return load(false);},fetch:fetchPublic,actionLabel:actionLabel,summary:summary,when:when,csv:csv,changes:changes,actor:actor};
})();
