# Verification — POS audit fixes (2026-10-07)

## Automated
- Node test suite: **161 / 162 passed**. 13 new tests in `tests/pos-audit-fixes.test.cjs`: search (every word, any order, trim, ranking — run against the real function), the "not in the list" guard,
  typed quantity, `formatMoney`, `rt-pos-fixes.js` is read-only (products / stock_balances / locations only) and ES2017, the gate (each wrapper once, pending sale / Job Card untouched,
  a failed check never blocks a sale), script order (`rt-polish.js` still last), the checkout payload (reference / motorcycle only when set; Job payload untouched; both parameters exist in the
  RPC in this build), after-sale refresh and drawer retry, customer search (read only), member name / scan fallback / Enter, receipt + PDF lines, stylesheet.
  Two older tests changed their expectation on purpose: "the plate is not sent with the sale" (it now is, when picked) and "the polish layer has exactly one Supabase read" (now vehicles + the customer search).
  The one failure is the old "root / APK assets / WAB_DEPLOY identical" check (no Android folder in the web build).

## Browser run with a simulated backend (Chromium; laptop 1366×768 / 1536×864 / 1280×800 with a mouse, short laptops 1366×657 and 1280×600, iPad 1024×768 / 1080×810 / 1180×820 / 1366×1024 / portrait, phone)
- Audit fixes: **112 / 112**
  - stale price (28 → 35: dialog names both prices, nothing sold, KEMAS KINI sets the price and the cash received, second BAYAR sells at 35; BATAL leaves the cart and refreshes the grid),
    stock shorter than the cart, product removed meanwhile, labour + product sale gets no dialog, a failed read does not block the sale, a fresh cart gets no dialog;
  - TRANSFER / KAD: panel, BAYAR refused until confirmed, confirm cleared when the amount changes, reference reaches the RPC and the payment row and the receipt / WhatsApp text / PDF, next customer back on TUNAI,
    CASH payload has no reference / vehicle keys;
  - scan of a product added elsewhere (real name, price 33, stock cap 5), inactive product refused, unknown SKU never reaches the cart;
  - customer search over 230+ customers reaches the database (name, last digits), local results show at once, choosing a remote result puts it on the sale;
  - drawer chip RALAT recovers by itself (about 5 s) and its tooltip says why;
  - search ("motul 10w40", "10w40 motul", "shell 1l", "pad honda", "brake  pad", trailing / leading spaces, paste), ranking, Enter on one / several matches / exact SKU;
  - typed quantity (24, over stock, 0, letters, + after typing);
  - short laptops: BAYAR and the RM20…RM500 row on screen, footer does not scroll, item list 186 px at 1366×657 (130 px floor at 600), "+ PELANGGAN BARU" strip kept (≤ 44 px), also with touch;
  - touch: Disk RM 40 px tall, confirm panel / dialog / qty box finger-sized on iPad 1024×768 and portrait;
  - member name sent to the RPC (spaces tidied), motorcycle + reference + name on the sale (p_vehicle_id on the invoice), receipt, WhatsApp text and PDF; walk-in and un-picked bike have none;
  - big discount: RM 30 of RM 88 asks, BATAL / YA, RM 8 and RM 6-of-16 do not;
  - numbers: "1,000" → 1000, "100,5" → 100.5, Caj Lain 5.555 → 5.56 with a message;
  - after a sale: stock on the card drops at once, no full reload, other products not touched; amounts ≥ RM 1,000 show with a comma on screen.
- Regression (same build): cart room / customer dialog 182 / 182, add motorcycle 72 / 72, receipt PDF + points 57 / 57, Pesanan serentak 88 / 88 (now also checks that a restored TRANSFER order must be confirmed again),
  Gantung 31 / 31, POS 54 / 54, WhatsApp 15 / 15, Papan Bengkel 25 / 25, Carian pantas 25 / 25, Pesan stok 28 / 28, Booking 28 / 28, full names 63 / 63, tidy-ups 26 / 26, Override + audit 109 / 109,
  offline / fast 59 / 59, customer list, scanner overlay guard, job-checkout heal, job part product id, native bridge.
- Found and fixed while testing: the grid did not redraw after a sale (stock label stale); the quantity box swallowed the tap on + / − that made it lose focus; the sale test for TRANSFER needed the new confirmation.

## Not verified
- Your real database and roles: the new reads (products, stock_balances, locations, customers) and the optional `p_vehicle_id` / `p_reference_no` on the sale RPC. The simulated backend now mimics the real RPC (price from the
  database, cash must cover the total, vehicle must belong to the customer) but it is not your server.
- A real iPad keyboard and share sheet; a real laptop screen (heights above are emulated).
- Why "Peti Tunai RALAT" showed on your laptop (only the automatic retry and the reason in the tooltip are added).
- The receipt layout for totals ≥ RM 1,000 was deliberately left as it is (fixed 64 px columns).
