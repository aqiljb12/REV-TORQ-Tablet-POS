# Verification — hide VOID / cancelled-job bookings + test-data cleanup (2026-10-05)

## Automated
- Node test suite: **115 / 116 passed** (the earlier 113 + 3 new in `tests/hide-cancelled.test.cjs`). The one failure is the old
  "root / APK assets / WAB_DEPLOY identical" check (APK is not used any more).
- Cleanup script on a real Postgres engine (PGlite, stand-in schema WITH foreign keys, override migration installed first): **27 / 27**
  - dry run: counts, invoice / job / booking lists, child tables found through foreign keys (also tables the script does not know by name),
    nothing changed, no purge record, no leftover ROW_DELETE records (fully rolled back)
  - real run refused when the typed numbers differ or are missing; nothing changed
  - real run: old VOID invoices and their lines / payments / events / tags removed; PAID invoices, recent VOIDs kept; cancelled jobs without
    remaining invoices removed, cancelled job with a PAID invoice kept, cancelled job whose VOID invoice is newer than the cut-off kept;
    booking behind a removed job removed (kept when the switch is off); stock and cash ledgers untouched;
    SYSTEM_TEST_DATA_PURGE record written; ROW_DELETE record for every deleted invoice / job / booking
  - second run on the same settings finds nothing; a ledger table with a foreign key -> BLOCKED in dry and real run, nothing deleted;
    VOID switch off -> only jobs without a remaining invoice
- Optional to run yourself: `tests/cleanup-test-data.pglite.cjs` (needs `npm i --no-save @electric-sql/pglite`).

## Browser run with a simulated backend (iPad / phone sizes)
- Hide-cancelled: **26 / 26** — VOID hidden by default with "1 VOID disembunyikan", toggle shows it (red row), choice kept after refresh,
  hidden again, search works, no sideways scroll (air + phone); booking with a cancelled Job Card is gone from Disahkan and Hari Ini and
  present in Sejarah; booking with an open job stays in Disahkan.
- Regression (same build): Override + audit 109 / 109, POS 54 / 54 (0 outside requests), Gantung 31 / 31, WhatsApp 15 / 15, Booking 28 / 28,
  Papan Bengkel 25 / 25, Carian pantas 25 / 25, Pesan stok 28 / 28, customer list, scanner overlay guard, job-checkout heal, job part product id.

## Not verified
- The cleanup script on your real Supabase schema (names of dependent tables, extra constraints, triggers). Run the dry run first.
- Real iPad / iPhone Safari.
