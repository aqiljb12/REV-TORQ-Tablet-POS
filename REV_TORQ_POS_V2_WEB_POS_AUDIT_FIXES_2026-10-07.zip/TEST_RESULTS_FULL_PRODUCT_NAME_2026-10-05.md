# Verification — full product names (2026-10-05)

## Automated
- Node test suite: **128 / 129 passed** (125 earlier incl. your sticker test + 4 new in `tests/pos-full-name.test.cjs`; one old assertion that pinned
  the exact `?v=` of pos.js / the checkout script now accepts later versions). The one failure is the old "root / APK assets / WAB_DEPLOY identical" check.
  New tests: no line clamp / hidden overflow on the card name, SKU not cut, size classes by length, hover title, cart / quick search / reorder / override
  lists wrap, receipt and part pickers no longer use `truncate`, cache versions bumped.

## Browser run with a simulated backend (Chromium; laptop 1366×768 and 1536×864, iPad 1024 / 1180 / portrait, phone)
- Full names: **63 / 63** — 8 long test names (up to 80 characters, one with no spaces) on each size: every card holds the whole name, hover title
  has it, no line clamp, nothing clipped vertically or sideways, the name ends above the price / SKU, the SKU is fully visible and inside the card,
  at most 6 lines for the longest name; the cart line shows the whole name; no sideways page scroll; quick search results wrap and are not clipped;
  the receipt item line is wrapped (no `truncate`); no page errors.
- Regression (same build): offline / fast 59 / 59, Override + audit 109 / 109, hide-VOID 26 / 26, POS 54 / 54 (0 outside requests), Gantung 31 / 31,
  WhatsApp 15 / 15, Booking 28 / 28, Papan Bengkel 25 / 25, Carian pantas 25 / 25, Pesan stok 28 / 28, strips layout 20 / 20, customer list,
  scanner overlay guard, job-checkout heal, job part product id, native bridge. Your walk-in labour checkout change is included and not modified.

## Not verified
- Your real product names and your laptop's exact screen scale: the test names are my own. Check the grid on the laptop after updating.
- Thermal receipt on paper (the receipt line is wrapped in the HTML; paper output not tested).
