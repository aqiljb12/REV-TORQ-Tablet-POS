# Verification — Pesanan serentak / 2 pelanggan sekali gus (2026-10-05)

## Automated
- Node test suite: **133 / 134 passed**. 3 new tests in `tests/pos-orders.test.cjs` (strip + one-tap swap, pay method / received travel with the order and
  next customer starts on TUNAI, touch-size + cache-busting, nothing is sent anywhere). One old assertion in `tests/pos-full-name.test.cjs` pinned the exact
  `?v=` of `rt-polish.css`; it now only requires a version. The one failure is the old "root / APK assets / WAB_DEPLOY identical" check (no Android folder in the web build).

## Browser run with a simulated backend (Chromium; laptop 1366×768 / 1536×864, iPad 1024×768 / 1180 / portrait, phone)
- Pesanan serentak: **84 / 84** — "+ PELANGGAN BARU" saves the order and opens an empty cart; held order appears as a chip with customer / first item and total;
  one tap swaps both ways with no confirm and nothing lost (lines, qty, item price / discount, customer, order discount, other charges); a TRANSFER order stays
  TRANSFER when swapped back; cash amount received comes back; QR order asks for the payment to be confirmed again; next customer always starts on TUNAI
  (after a sale, after clear cart, after "+ PELANGGAN BARU"); refresh restores cart and pay method; max 10; stock / price re-checked on resume; no button during a
  Job Card cart; chips are 40 px high and scroll sideways; strip hidden on a short screen (1024×768) unless an order is waiting; **BAYAR stays on screen at every
  size tested**; no requests leave the device while parking / swapping; no page errors.
- Regression (same build): Gantung 31 / 31, POS 54 / 54, WhatsApp 15 / 15, Booking 28 / 28, Papan Bengkel 25 / 25, Carian pantas 25 / 25, Pesan stok 28 / 28,
  full product names 63 / 63, tidy-ups 26 / 26, Override + audit 109 / 109, offline / fast 59 / 59, customer list, scanner overlay guard, job-checkout heal,
  job part product id, native bridge — all passed.

## Not verified
- The real 2-customer rush at your counter, with your real products and your real transfer flow. Please try: key in customer 1, tap "+ PELANGGAN BARU",
  serve customer 2, tap customer 1's chip, pay by transfer.
- Promo / voucher are not carried with a held order by design (they must be confirmed on the server); pick them again after resuming.
- A held order lives only on that device (laptop vs iPad do not share).
