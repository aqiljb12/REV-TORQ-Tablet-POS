# Verification — REV TORQ POS V2 WEB for iPad (2026-10-03)

## Automated

- Node test suite: **102 / 103 passed** (84 V2 tests + 8 web-upgrade + 4 booking + 2 customer-list + 5 new).
  The one failure is the old "root / APK assets / WAB_DEPLOY identical" check — not relevant now (web only, no APK).
  The 5 new tests (board, quick search, reorder list, bulk inventory load, product-id fixes) fail on the 2026-10-02 build.

## Browser run with a simulated backend (Chromium with iPad screen sizes and iPad Safari user agent; not shipped)

Sizes: iPad 9.7" 1024×768, iPad 10.2" 1080×810, iPad Air 1180×820, iPad Pro 12.9" 1366×1024, portrait 820×1180, iPad mini 744×1133, phone 390×844.

- Papan Bengkel: 25 / 25 — default view, 4 columns, cancelled/paid hidden, card details, age colours, summary, MULA BAIKI /
  TUNGGU BARANG / SAMBUNG / SIAP saved and moved, list table updated, save error shown and nothing moved, search and pomen
  filters, tap opens the Job Card form, BAWA KE POS from the board, PAPAN/SENARAI remembered, 4 columns on screen at
  1024 px, swipe on portrait, pomen login (no POS button, can mark SIAP).
- Carian pantas: 25 / 25 — Cmd+K, plate without space, phone with dashes / partial, name, invoice, product, no-match,
  + TROLI, customer card (motor, jobs, receipts, WhatsApp, phone), Escape back/close, JUAL, BUKA JOB BARU prefilled,
  receipt opens, BAWA KE POS from a job result, scanner gun into the box (cart untouched), cashier limits, phone layout.
- Inventori + Pesan Stok: 28 / 28 — TAMBAH ITEM fully on screen and no sideways scroll at 4 sizes, count = low + out,
  LAGI menu (Print Stiker, Test Hardware), list rule and order, suggested quantities, edit / untick / filter,
  supplier WhatsApp (number + message), copy, print, supplier remembered, no product / stock / GRN change.
- Inventory loader: same data as before (26/26 items); with 1 526 items and a 1 000-row API limit the old loader showed
  1 000, the new one shows all 1 526 with the right stock.
- Fixes: Job sale whose reply was lost — before, receipt shown but the 4-line Job cart stayed; now cart and Job cleared,
  still one invoice. Resumed parked order lines carry the current product id. Your productId fix: Job + grid part sale
  posts (before: "Part tanpa product_id").
- Regression: POS flows 54 / 54 (0 outside requests), Gantung 31 / 31, WhatsApp 15 / 15, Booking 28 / 28,
  customer list (0 overlaps), no popup left "open" for the scanner guard (incl. new dialogs), Tailwind classes 852 / 852.
- iPad layout: BAYAR on screen on every landscape iPad; side menu fits without scrolling ("Lagi" + badge visible).

## Not verified

- Real Supabase data and permissions (RLS) — e.g. a pomen's right to change Job Card status is the same as in the form.
- Real iPad Safari (tests used Chromium with iPad sizes), AirPrint printing, Bluetooth scanner on iPad.

Recommended check on the iPad: Job Card board → MULA BAIKI → SIAP → BAWA KE POS → BAYAR; Cari → plate → JUAL;
Inventori → PESAN STOK → WhatsApp to supplier; print one receipt through AirPrint.
