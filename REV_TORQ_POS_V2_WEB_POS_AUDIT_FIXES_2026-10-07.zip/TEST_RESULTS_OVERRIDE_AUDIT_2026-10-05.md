# Verification — REV TORQ POS V2 WEB: Override & Audit (2026-10-05)

## Automated

- Node test suite: **112 / 113 passed** (103 earlier tests + 10 new in `tests/override-audit.test.cjs`).
  The one failure is the old "root / APK assets / WAB_DEPLOY identical" check (APK is not used any more).
  The APK-only native-scanner tests are not run (the Android project is not part of the web build).
  The 10 new tests: scripts loaded and `rt-polish.js` still last; no hard delete anywhere (only the audited Job Card PART replace);
  paid-job guard before any write; Override UI only calls the four override RPCs (no direct writes); one audit writer + outbox;
  SQL: `search_path` pinned, nothing granted to `anon`, roles / reason / session / archive rules present, no DELETE in the action,
  append-only trigger, rollback block; viewer helpers (CSV formula-safe, changes, ROW_ rows); archived records hidden; logout ends the session.
- SQL script on a real Postgres engine (PGlite, stand-in schema): **80 / 80** — owner / admin / cashier / other-company roles, reason rule,
  session expiry / end / replay, every archive-blocked case, restore, job cancel (paid refused), before / after written in the same
  transaction, row triggers (no duplicate rows for RPC actions), append-only audit log incl. the `transaction_id` re-key the Job checkout
  RPC performs, DELETE/TRUNCATE revoked, idempotent re-run, refuses a different `audit_logs`, rollback block.
  Optional to run yourself: `tests/sql-override-audit.pglite.cjs` (needs `npm i --no-save @electric-sql/pglite`).

## Browser run with a simulated backend (Chromium, iPad screen sizes and iPad Safari user agent; not shipped)

- Override + audit: **109 / 109**
  - Admin: menu opens the page; inactive state; short reason / wrong PIN / cancel start nothing (no OVERRIDE_BEGIN row, PIN cleared);
    correct PIN starts it (reason, expiry, 10 min, PIN checked through a throw-away login and the real session stays signed in);
    red strip with countdown; survives a page refresh.
  - Blocked by the server with a Malay message: customer with a vehicle, item with stock, paid job; blocked actions write no record.
  - Archive vehicle, archive customer, restore customer, cancel job: row kept (never deleted), `active=false` / `CANCELLED`, one audit
    row each with before / after / reason / override session / staff.
  - Archived customer disappears from the Pelanggan page, POS customer picker and Carian pantas; paid job shows "Dibayar" with no cancel.
  - The app's data bridge refuses `.delete()`.
  - Audit viewer: new view replaces the old table; filter, search, expand row (old → new, reason), CSV (BOM, quotes, `=` `+` neutralised).
  - TAMATKAN: OVERRIDE_END (user), no action afterwards, replaying the old session id is refused by the server.
  - Owner: `ensure()` resolves with session + reason and does not ask twice; clock jumped +11 min: strip hides, timeout END written, no action;
    logout hook ends the open session.
  - SQL script missing (functions not found): page shows the warning, activation is blocked, `begin()` refuses, nothing stored,
    paid-job edit stays blocked and nothing is saved, audit write falls back to the direct insert.
  - Paid job: edit asks for Override; Cancel saves nothing and shows no error; with Override the PART rows change and one JOB_EDIT_PAID row
    holds parts before / after, reason, session. Unpaid job: no dialog, UPDATE_JOB row with before / after.
  - Pomen (Job Card only): paid job edit refused with a reason; cashier / pomen cannot open Override, and the server refuses
    begin / action for them even when called directly.
- Regression (same build, final run): POS flows 54 / 54 (0 outside requests), Gantung 31 / 31, WhatsApp 15 / 15, Booking 28 / 28,
  Papan Bengkel 25 / 25, Carian pantas 25 / 25, Pesan stok 28 / 28, customer list (0 overlaps), no popup left open for the scanner guard
  (the new dialogs have `aria-modal`), native bridge, job-checkout heal, job part product id.
- iPad layout (1024×768, 1080×810, 1180×820, 1366×1024, portrait 820×1180, phone 390×844): Override page, dialogs, audit page and POS with the
  red strip have no sideways scroll; the strip covers nothing (no button under it); BAYAR stays on screen on every landscape iPad.
- Cart header after the fix: trash button inside the panel at every size (before: 57–97 px off screen with a parked order and "+ BELI LUAR").
- Code is ES2017 (checked with a parser) for older iPad Safari.

## Not verified

- Your real Supabase: RLS, grants, existing functions, and the SQL script on your real schema. Run PART 0 first and back up.
- Real iPad Safari (tests use Chromium with iPad sizes).
- Whether `rt_admin_void_invoice` writes an audit row (function is not in the repo).
- Customer app / Accounting app behaviour with archived rows.

Recommended check on the iPad after running the SQL script: Override -> AKTIFKAN (PIN + sebab) -> Kenderaan -> ARKIB one test motor ->
Log Sistem shows "Arkib kenderaan" with the reason -> PULIHKAN -> TAMATKAN. Then open a PAID job and try to change a part: it must ask for Override.
