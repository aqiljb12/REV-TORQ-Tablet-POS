# Verification — fast start + offline level 1 (2026-10-06)

## Automated
- Node test suite: **121 / 122 passed** (the earlier 116 + 6 new in `tests/offline-fast.test.cjs`; the old "service worker never caches" test was
  rewritten to "only the app's own files"). The one failure is the old "root / APK assets / WAB_DEPLOY identical" check (APK is not used any more).
  New tests: manifest and icon sizes; service worker rules (same origin only, no API text, page network-first 3 s, 5xx never replaces the saved page,
  prunes old versions, reset message) and BUILD equal in worker and page; script order (`rt-offline.js` before the session restore, `rt-polish.js` last);
  network error handled before sign-out, workshop roles excluded, 7-day limit, no token = no offline start, offline shell never becomes a verified session;
  POS cache read in parallel (not awaited before the network), products download while the location is looked up, cost prices stripped, BAYAR stopped
  before the page handler; refresh at most once a minute for the open screen; `rtStore` / `rtPerf` never throw without IndexedDB.

## Browser run: REAL service worker, REAL IndexedDB, Chromium's real offline switch (iPad sizes; only the database is a stand-in)
- Offline / fast: **59 / 59**
  - first online run: manifest linked, iOS meta, standalone manifest with 3 icons incl. maskable; worker controls the page; app cache holds
    index.html, scripts, styles, fonts, vendor libraries, manifest and icons (72 files); the database API is never cached; product list saved
    (26 items) without cost prices; timings recorded; no offline bar while online; Diagnostik card shows version, mode, products and timings.
  - second online run with a 1.8 s slow backend: 20+ products on screen in under 2.2 s from the saved list (source "cache"), fresh list replaces it.
  - **offline start**: the app opens from the app cache; offline shell flag, profile marked offline, no admin powers; amber OFFLINE bar with the BAYAR
    message; products, prices and stock from the iPad; cost 0; chip says OFFLINE; notice is info not error; cart works; BAYAR click and direct
    `posCheckout()` do nothing but explain and create no invoice or pending sale; Gantung parks locally; other pages blocked with a message; no page errors.
  - **back online**: shell left and login verified by itself, bar hidden, BAYAR unlocked, fresh list loaded, success toast, a real sale posts again.
  - **server problems at start-up**: server error (retryable) -> shell opens and the login is KEPT, then normal when it answers; slow server (13 s)
    -> shell after ~8 s, BAYAR locked, normal when it answers; server says "invalid session" -> login screen, token, offline profile and saved
    products wiped (the old behaviour for a real rejection is kept).
  - **must NOT start offline**: pomen (no POS) is told to reconnect and stays logged in; logged-out device; profile older than 7 days.
  - **updates**: a new index.html appears at once online (network first); afterwards offline shows the updated copy; with a 6 s slow index.html
    the app opens in ~3 s from the saved copy and the slow answer still updates it; `?rt_reset=1` clears worker + caches and cleans the URL;
    Kosongkan cache app button resets and reloads.
- Layout under the red / amber strips (iPad 1024, 1080, 1180, 1366 and portrait 820; none / Override / Offline / both): **20 / 20** — BAYAR, side menu
  and Logout fully on screen, no sideways scroll. Phone, iPad mini and portrait: nothing sits under a strip on POS, Jualan, Inventori, Job Card, Pelanggan.
  (This also fixes the previous release: while Override was active BAYAR / side menu were 7 px too low on iPad.)
- Noise: one minute offline = 3 console warnings (was 49: the booking poll retried every 1.5 s) and no uncaught errors.
- Regression (same build): Override + audit 109 / 109, hide-VOID 26 / 26, POS 54 / 54, Gantung 31 / 31, WhatsApp 15 / 15, Booking 28 / 28,
  Papan Bengkel 25 / 25, Carian pantas 25 / 25, Pesan stok 28 / 28, customer list, scanner overlay guard, job-checkout heal, job part product id,
  native bridge.
- Older test scripts now start Chromium with service workers blocked (they replace the database library by request interception, which a worker bypasses);
  `offline.cjs` and the booking notification test use a real worker.

## Not verified
- A real iPad: Add to Home Screen, start from the icon, airplane mode, AirPrint and the camera scanner from the installed app.
- Real Supabase: the real SDK's behaviour offline was read in its source (expired token + no network returns a retryable error and keeps the
  stored session; that is what the shell relies on) but not run against your project.
- Timing numbers are from a fast desktop with a fake backend; use Tetapan > Diagnostik on the iPad for real figures.
