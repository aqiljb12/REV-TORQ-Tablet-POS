/* REV TORQ POS V2 — receipt as a PDF (for WhatsApp) + the customer's points on the receipt.
   Device-only: the PDF is drawn here from the numbers the receipt already shows; nothing is uploaded and no sale,
   stock or payment is touched. The points figure is read with the existing read-only member summary
   (rt_pos_customer_member_summary) after the sale; if that fails the receipt simply has no points line.
   Plain ES2017-compatible code (older iPad Safari). Loaded before js/rt-polish.js. */
(function(root){
  'use strict';

  // ------------------------------------------------------------------ layout (80 mm thermal-style page, Courier)
  var PAGE_W=226.77;                 // 80 mm in points
  var MARGIN=10;
  var FS=8.2;                        // body size: 42 columns across the usable width
  var CW=0.6;                        // Courier is monospaced: every character is 0.6 em wide
  var LINES_PER_PAGE=900;

  function cols(size){return Math.floor((PAGE_W-2*MARGIN)/(CW*size)+1e-6);}
  function num(v){var n=Number(v);return isFinite(n)?n:0;}
  function fmt(v){return num(v).toFixed(2);}
  function money(v){return 'RM '+fmt(v);}

  // PDF text is WinAnsi: keep plain ASCII and Latin-1, turn the common typographic marks into plain ones, '?' for the rest.
  function clean(s){
    s=String(s==null?'':s)
      .replace(/[‘’‛]/g,"'").replace(/[“”]/g,'"')
      .replace(/[–—]/g,'-').replace(/…/g,'...').replace(/ /g,' ')
      .replace(/[\r\n\t]+/g,' ');
    var out='';
    for(var i=0;i<s.length;i++){
      var c=s.charCodeAt(i);
      out+=((c>=32&&c<=126)||(c>=161&&c<=255))?s.charAt(i):'?';
    }
    return out;
  }
  function wrap(text,width){
    text=clean(text).replace(/\s+/g,' ').trim();
    if(!text)return [''];
    var out=[],line='';
    text.split(' ').forEach(function(word){
      while(word.length>width){                       // a word longer than the page: cut it
        if(line){out.push(line);line='';}
        out.push(word.slice(0,width));word=word.slice(width);
      }
      if(!line)line=word;
      else if((line+' '+word).length<=width)line+=' '+word;
      else{out.push(line);line=word;}
    });
    if(line)out.push(line);
    return out;
  }
  function padRight(left,right,width){
    left=clean(left);right=clean(right);
    var room=width-right.length-1;
    if(left.length>room)left=left.slice(0,Math.max(0,room));
    var gap=Math.max(1,width-left.length-right.length);
    return left+new Array(gap+1).join(' ')+right;
  }
  function rule(width,ch){return new Array(width+1).join(ch||'-');}

  // Receipt data (window.__rtLastReceiptData, built by pos.js) -> list of lines {t,b,s,a,gap}
  function layoutReceipt(d){
    d=d||{};
    var L=[],C=cols(FS);
    function push(t,o){o=o||{};L.push({t:clean(t),b:!!o.b,s:o.s||FS,a:o.a||'l',gap:o.gap||0});}
    function pushWrapped(text,o){o=o||{};wrap(text,o.width||C).forEach(function(x){push(x,o);});}

    var big=11,bigCols=cols(big);
    wrap(d.shopName||'REV TORQ WORKSHOP',bigCols).forEach(function(x){push(x,{b:true,s:big,a:'c'});});
    String(d.address||'').split(/\r?\n/).forEach(function(a){if(a.trim())pushWrapped(a,{a:'c'});});
    if(d.phone)pushWrapped('Tel: '+d.phone,{a:'c'});
    if(d.regNo)pushWrapped('SSM / No. Pendaftaran: '+d.regNo,{a:'c'});
    push(rule(C),{gap:2});

    // "Label    : value", long values wrap under the value
    function kv(label,value){
      var head=(label+'          ').slice(0,10)+': ';
      wrap(value,C-head.length).forEach(function(x,k){push((k?new Array(head.length+1).join(' '):head)+x);});
    }
    kv('No',d.invNo||'-');
    if(d.dateText)kv('Tarikh',d.dateText);
    if(d.cashier)kv('Juruwang',d.cashier);
    if(d.customerName)kv('Pelanggan',d.customerName);
    if(d.customerPhone)kv('Telefon',d.customerPhone);
    push(rule(C));
    push(padRight('ITEM','JUMLAH (RM)',C),{b:true});
    push(rule(C));

    (d.items||[]).forEach(function(i,n){
      pushWrapped(i.name||'-',{b:true});
      var gross=i.gross!=null?num(i.gross):num(i.qty)*num(i.price);
      var net=i.total!=null?num(i.total):Math.max(0,gross-num(i.discount));
      push(padRight('  '+num(i.qty)+' x '+fmt(i.price),fmt(net),C));
      if(num(i.discount)>0)wrap('Diskaun item: -'+fmt(i.discount)+' (asal '+fmt(gross)+')',C-2).forEach(function(x){push('  '+x);});
      if(n<(d.items||[]).length-1)push('',{s:3});
    });
    push(rule(C),{gap:2});

    (d.rows||[]).forEach(function(r){
      var value=(num(r[1])<0?'-':'')+fmt(Math.abs(num(r[1])));
      var label=wrap(r[0],Math.max(8,C-value.length-1));
      label.forEach(function(x,k){push(k===label.length-1?padRight(x,value,C):x);});
    });
    var tc=cols(10);
    push(padRight('JUMLAH',money(d.total),tc),{b:true,s:10,gap:3});
    push(padRight('Kaedah',clean(d.method||'CASH'),C));
    push(padRight('Dibayar',money(d.received),C));
    push(padRight('Baki',money(d.balance),C));

    var p=d.points;
    if(p&&p.balance!=null){
      push(rule(C),{gap:2});
      push('POINT REV TORQ',{b:true});
      if(num(p.earned)>0)push(padRight('Point baru','+'+Math.round(num(p.earned)),C));
      push(padRight('Jumlah point',String(Math.round(num(p.balance))),C),{b:true});
    }
    push('',{s:6});
    pushWrapped('Terima kasih kerana berurusan dengan kami.',{a:'c'});
    return L;
  }

  // ------------------------------------------------------------------ PDF writer (latin-1 text only, so 1 char = 1 byte)
  function pdfEscape(s){return String(s).replace(/\\/g,'\\\\').replace(/\(/g,'\\(').replace(/\)/g,'\\)');}
  function lineHeight(l){return l.s*1.28+(l.gap||0);}
  function buildPdfText(lines,meta){
    meta=meta||{};
    var pages=[];
    for(var i=0;i<lines.length;i+=LINES_PER_PAGE)pages.push(lines.slice(i,i+LINES_PER_PAGE));
    if(!pages.length)pages.push([{t:'',b:false,s:FS,a:'l',gap:0}]);
    var out='',offsets=[];
    function obj(n,body){offsets[n]=out.length;out+=n+' 0 obj\n'+body+'\nendobj\n';}
    out+='%PDF-1.4\n%âãÏÓ\n';
    var firstPage=6;
    var kids=pages.map(function(_,k){return (firstPage+k*2)+' 0 R';}).join(' ');
    obj(1,'<< /Type /Catalog /Pages 2 0 R >>');
    obj(2,'<< /Type /Pages /Count '+pages.length+' /Kids ['+kids+'] >>');
    obj(3,'<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>');
    obj(4,'<< /Type /Font /Subtype /Type1 /BaseFont /Courier-Bold /Encoding /WinAnsiEncoding >>');
    var stamp=meta.date instanceof Date&&!isNaN(meta.date)?meta.date:new Date();
    function two(n){return (n<10?'0':'')+n;}
    var cd='D:'+stamp.getFullYear()+two(stamp.getMonth()+1)+two(stamp.getDate())+two(stamp.getHours())+two(stamp.getMinutes())+two(stamp.getSeconds());
    obj(5,'<< /Title ('+pdfEscape(clean(meta.title||'Resit'))+') /Producer (REV TORQ POS) /CreationDate ('+cd+') >>');
    pages.forEach(function(pl,k){
      var height=2*MARGIN;
      pl.forEach(function(l){height+=lineHeight(l);});
      height=Math.max(height,60);
      var content='',cum=0;
      pl.forEach(function(l){
        if(l.t){
          var textW=l.t.length*CW*l.s;
          var x=MARGIN;
          if(l.a==='c')x=Math.max(MARGIN,(PAGE_W-textW)/2);
          else if(l.a==='r')x=Math.max(MARGIN,PAGE_W-MARGIN-textW);
          var y=height-MARGIN-cum-l.s*0.98;
          content+='BT /'+(l.b?'F2':'F1')+' '+l.s.toFixed(2)+' Tf '+x.toFixed(2)+' '+y.toFixed(2)+' Td ('+pdfEscape(l.t)+') Tj ET\n';
        }
        cum+=lineHeight(l);
      });
      var pn=firstPage+k*2,cn=pn+1;
      obj(pn,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+PAGE_W.toFixed(2)+' '+height.toFixed(2)+'] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents '+cn+' 0 R >>');
      obj(cn,'<< /Length '+content.length+' >>\nstream\n'+content+'endstream');
    });
    var count=firstPage+pages.length*2;
    var xref=out.length;
    out+='xref\n0 '+count+'\n0000000000 65535 f \n';
    for(var n=1;n<count;n++){out+=('0000000000'+offsets[n]).slice(-10)+' 00000 n \n';}
    out+='trailer\n<< /Size '+count+' /Root 1 0 R /Info 5 0 R >>\nstartxref\n'+xref+'\n%%EOF\n';
    return out;
  }
  function toBytes(str){
    var b=new Uint8Array(str.length);
    for(var i=0;i<str.length;i++)b[i]=str.charCodeAt(i)&255;
    return b;
  }
  function buildReceiptPdfBytes(data,date){
    var d=data||{};
    return toBytes(buildPdfText(layoutReceipt(d),{title:'Resit '+(d.invNo||''),date:date}));
  }

  var api={layoutReceipt:layoutReceipt,buildPdfText:buildPdfText,buildReceiptPdfBytes:buildReceiptPdfBytes,clean:clean,wrap:wrap,cols:cols};
  if(typeof module==='object'&&module&&module.exports){module.exports=api;}
  if(!root||!root.document)return;

  // ------------------------------------------------------------------ browser part
  var w=root,doc=root.document;
  var $=function(id){return doc.getElementById(id);};
  function toast(m,t){try{if(w.showToast)w.showToast(m,t||'success');}catch(_){}}
  function safeName(s){return String(s||'resit').replace(/[^A-Za-z0-9_-]+/g,'_').replace(/^_+|_+$/g,'')||'resit';}
  function pretty(d){d=String(d||'');return d.indexOf('60')===0?'0'+d.slice(2):'+'+d;}
  w.RTReceiptPdf=api;

  function download(blob,name){
    var url=URL.createObjectURL(blob),a=doc.createElement('a');
    a.href=url;a.download=name;doc.body.appendChild(a);a.click();a.remove();
    setTimeout(function(){URL.revokeObjectURL(url);},30000);
  }

  // PDF button on the receipt: share the file (iPad / phone / Windows share sheet -> WhatsApp), or save it and open the customer's chat.
  w.rtReceiptPdf=function(){
    var d=w.__rtLastReceiptData;
    if(!d||!d.invNo){toast('Resit belum tersedia untuk dijadikan PDF.','error');return;}
    var blob;
    try{blob=new Blob([buildReceiptPdfBytes(d)],{type:'application/pdf'});}
    catch(e){console.warn('receipt pdf',e);toast('PDF tidak dapat dibuat: '+(e&&e.message||e),'error');return;}
    var name='Resit-'+safeName(d.invNo)+'.pdf';
    var phone=typeof w.rtReceiptPhone==='function'?w.rtReceiptPhone():'';
    var file=null;
    try{file=new File([blob],name,{type:'application/pdf'});}catch(_){}
    var title='Resit '+d.invNo;
    var text=title+' - '+(d.shopName||'')+' - '+money(d.total)+(phone?'\nUntuk: '+(d.customerName?d.customerName+' ':'')+pretty(phone):'');
    if(file&&typeof navigator.share==='function'&&typeof navigator.canShare==='function'){
      var ok=false;try{ok=navigator.canShare({files:[file]});}catch(_){}
      if(ok){
        // no await before this call: the share sheet needs the tap that started it
        navigator.share({files:[file],title:title,text:text}).catch(function(e){
          if(e&&e.name==='AbortError')return;                    // the cashier closed the sheet
          console.warn('share pdf',e);saveAndOpenChat(blob,name,phone,d);
        });
        return;
      }
    }
    saveAndOpenChat(blob,name,phone,d);
  };
  function saveAndOpenChat(blob,name,phone,d){
    download(blob,name);
    if(phone){
      toast('PDF disimpan ('+name+'). WhatsApp dibuka: lampirkan fail itu.','success');
      var msg='Resit '+d.invNo+' ('+money(d.total)+') - PDF dilampirkan. Terima kasih.';
      var url='https://wa.me/'+phone+'?text='+encodeURIComponent(msg);
      setTimeout(function(){var p=w.open(url,'_blank','noopener,noreferrer');if(!p)w.location.href=url;},350);
    }else{
      toast('PDF disimpan ('+name+'). Lampirkan dalam WhatsApp.','success');
    }
  }

  // ------------------------------------------------------------------ customer points on the receipt
  // Last balance seen for the member in the cart (so the sale can show "+N" afterwards).
  var seen={id:'',pts:null,at:0};
  function readSeen(){
    var el=$('rtPosMemberPoints'),sel=$('rtPosCustomerSelect');
    var t=String((el&&el.textContent)||'').replace(/[^0-9]/g,''),id=sel&&sel.value?String(sel.value):'';
    if(t===''||!id)return;                           // cleared after a sale: keep what we had
    seen={id:id,pts:parseInt(t,10),at:Date.now()};
  }
  function watchSeen(){
    var el=$('rtPosMemberPoints');
    if(!el||el.dataset.rtSeen==='1')return;
    el.dataset.rtSeen='1';
    try{new MutationObserver(readSeen).observe(el,{childList:true,characterData:true,subtree:true});}catch(_){}
    readSeen();
  }
  var loadSeq=0;
  function withPointsLine(text,p){
    var base=String(text||'').replace(/\n+Point REV TORQ:[^\n]*/,'');
    var line='Point REV TORQ: '+Math.round(num(p.balance))+(num(p.earned)>0?' (+'+Math.round(num(p.earned))+' point baru)':'');
    var at=base.lastIndexOf('\n\nTerima kasih');
    return at>=0?base.slice(0,at)+'\n\n'+line+base.slice(at):base+'\n\n'+line;
  }
  function showPoints(p){
    var d=w.__rtLastReceiptData;
    if(d)d.points=p;
    if(w.__rtLastReceiptText)w.__rtLastReceiptText=withPointsLine(w.__rtLastReceiptText,p);
    var head=$('rtReceiptHead');
    if(!head)return;
    var el=$('rtReceiptPts');
    if(!el){el=doc.createElement('div');el.id='rtReceiptPts';el.className='rt-receipt-pts';head.appendChild(el);}
    el.textContent='';
    var b=doc.createElement('b');b.textContent=Math.round(num(p.balance)).toLocaleString()+' POINT';
    el.appendChild(b);
    if(num(p.earned)>0){var s=doc.createElement('span');s.textContent='+'+Math.round(num(p.earned))+' baru';el.appendChild(s);}
    head.hidden=false;
  }
  // called by js/rt-polish.js after every receipt render
  w.rtReceiptAfterRender=function(inv){
    var old=$('rtReceiptPts');if(old)old.remove();
    var seq=++loadSeq;
    if(!inv||inv.__rtReprint||!inv.customerId||typeof w.supabaseRpc!=='function')return;
    var id=String(inv.customerId);
    var before=(seen.id===id&&Date.now()-seen.at<30*60*1000)?seen.pts:null;
    Promise.resolve(w.supabaseRpc('rt_pos_customer_member_summary',{p_customer_id:id})).then(function(sum){
      if(seq!==loadSeq||!sum)return;
      var bal=Number(sum.points);
      if(!isFinite(bal))return;
      showPoints({balance:bal,earned:(before!=null&&bal>before)?bal-before:0});
    }).catch(function(){});
  };
  w.rtReceiptPointsSeen=function(){return seen;};

  function boot(){watchSeen();}
  if(doc.readyState==='loading')doc.addEventListener('DOMContentLoaded',boot);else boot();
})(typeof window!=='undefined'?window:(typeof globalThis!=='undefined'?globalThis:this));
