        // --- 1. SUPABASE CONFIGURATION ---
const sb = window.supabaseClient;
let app = null;
let db = window.db;
let staffAuthApp = null;
let staffAuth = null;
function getStaffAuth(){ return sb.auth; }
document.getElementById('dbgFirebase').innerText = 'SUPABASE';
document.getElementById('dbgFirestore').innerText = 'POSTGRESQL';

// --- 2. GLOBAL ERROR HANDLING (MOBILE FRIENDLY) ---
        function showErrorPanel(msg) {
            const panel = document.getElementById('globalErrorPanel');
            panel.innerText = msg;
            panel.classList.remove('hidden');
            setTimeout(() => { panel.classList.add('hidden'); }, 5000);
        }
        window.addEventListener("error", (e) => showErrorPanel("JS Error: " + e.message));
        window.addEventListener("unhandledrejection", (e) => {
            let msg = "Promise Error: " + (e.reason ? (e.reason.message || e.reason) : "Unknown");
            if(msg.includes('permission-denied')) msg = "SUPABASE RLS DENIED";
            showErrorPanel(msg);
        });

        // --- 3. SESSION & STATE VARIABLES ---
        let currentUser = null; // Basic user object
        let currentProfile = null; // Complete staff profile from DB
        // Expose read-only state to the additive POS UI layer.
        function syncPublicState(){
            window.currentProfile = currentProfile;
            window.currentUser = currentUser;
        }
        // Supabase Auth bridge: lets the replacement auth module update the
        // lexical state used by this legacy core module before initAppLayout().
        window.rtApplySupabaseProfile = function(profile, user){
            currentProfile = profile || null;
            currentUser = user || null;
            syncPublicState();
        };
        window.rtClearAuthUI = function(){
            try { posCart = []; } catch (_) {}
            const nav=document.getElementById('mainNav');
            if(nav)nav.innerHTML='';
            for(const id of ['navUserName','navUserRole','dbgStaffId','dbgRole','dbgSession']){
                const el=document.getElementById(id);if(el)el.innerText='NONE';
            }
        };
        const SESSION_KEY = "revtorq_session";
        
        // REV TORQ POS V2 CLEAN: operational POS/workshop app only.
        // Accounting, P&L and financial reporting are intentionally maintained in
        // the separate REV TORQ Accounting system and are not shipped here.
        const menuDefinitions = {
            // REV TORQ POS APK: operational navigation only.
            // POS is listed first so every selling role lands directly on the cashier screen.
            // Backend / Override / Audit are opened from Tetapan Sistem.
            owner: ['pos','jobcard','inventory','customers','sales','quotes','staff','settings','dashboard','booking','suppliers','purchase','reminders','tutorial'],
            super_admin: ['pos','jobcard','inventory','customers','sales','quotes','staff','settings','dashboard','booking','suppliers','purchase','reminders','tutorial'],
            admin: ['pos','jobcard','inventory','customers','sales','quotes','staff','settings','dashboard','booking','suppliers','purchase','reminders','tutorial'],

            // STAFF: operational screens only. Sales lists receipts for reprint;
            // VOID stays admin-only inside the list and in the database RPC.
            pos: ['pos','sales','quotes'],
            staff: ['pos','sales','quotes'],
            cashier: ['pos','sales','quotes'],
            pomen: ['jobcard'],
            mechanic: ['jobcard'],
            stor: ['inventory']
        };
        // Primary vs secondary navigation. Secondary items stay reachable from the
        // collapsible "Lagi" group and from section tabs inside their parent page.
        // Order: POS + Dashboard on top, then sales (Jualan, Quotation), workshop (Job Card,
        // Pelanggan, Inventori) and admin (Staf, Tetapan); a thin line starts each group.
        const navPrimary = ['pos','dashboard','sales','quotes','jobcard','customers','inventory','staff','settings'];
        const navSecondary = ['booking','suppliers','purchase','reminders','tutorial'];
        const navGroupStart = ['sales','jobcard','staff'];
        // Sub-pages highlight their parent in the sidebar.
        const navParent = { booking:'jobcard', myjobs:'jobcard', suppliers:'inventory', purchase:'inventory', stockledger:'inventory', reminders:'customers', backend:'settings', override:'settings', audit:'settings' };

        // --- 4. CRYPTO HASHING ---
        async function hashPIN(pin) {
            const encoder = new TextEncoder();
            const data = encoder.encode(pin);
            const hashBuffer = await crypto.subtle.digest('SHA-256', data);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        }

        // --- 5. UI UTILITIES ---
        function formatMoney(amount) { const n = parseFloat(amount); return "RM " + (Number.isFinite(n) ? n : 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }

        // Resolve inventory documents by SKU while remaining compatible with legacy data
        // where the Firestore document ID may not equal the SKU. New records still use SKU as ID.
        async function resolveInventoryRefBySku(sku) {
            const key = String(sku || '').trim().toUpperCase();
            if (!key) throw new Error('SKU kosong.');
            const direct = db.collection('inventory').doc(key);
            const directSnap = await direct.get();
            if (directSnap.exists) return direct;
            const q = await db.collection('inventory').where('sku', '==', key).limit(1).get();
            if (!q.empty) return q.docs[0].ref;
            throw new Error(`SKU ${key} tidak wujud dalam pangkalan data.`);
        }

        async function resolveInventoryDocBySku(sku) {
            const ref = await resolveInventoryRefBySku(sku);
            const snap = await ref.get();
            return { ref, snap };
        }
        const FAST_SERVICE_CHECKS = [
            { key: 'engineOilLeak', label: '1. Minyak enjin & kebocoran' },
            { key: 'chainSprocket', label: '2. Rantai & sprocket' },
            { key: 'brake', label: '3. Brek depan/belakang & pad' },
            { key: 'tyre', label: '4. Tayar: bunga & tekanan angin' },
            { key: 'lightsSignal', label: '5. Lampu & signal' },
            { key: 'batteryCharging', label: '6. Bateri & sistem pengecasan' },
            { key: 'coolant', label: '7. Coolant / suhu enjin' },
            { key: 'brakeFluid', label: '8. Minyak brek' },
            { key: 'suspensionSteering', label: '9. Fork, absorber & steering' },
            { key: 'controlsHorn', label: '10. Throttle, clutch & hon' }
        ];

        function normalizeInspection(data) {
            if (!data) return {};
            if (Array.isArray(data)) {
                const out = {};
                data.forEach(x => { if (x && x.key) out[x.key] = { status: x.status || 'OK', note: x.note || '' }; });
                return out;
            }
            return data;
        }

        function renderInspectionChecklist(containerId, data = {}) {
            const el = document.getElementById(containerId);
            if (!el) return;
            const values = normalizeInspection(data);
            el.innerHTML = FAST_SERVICE_CHECKS.map(item => {
                const v = values[item.key] || {};
                const status = v.status || 'OK';
                const note = (v.note || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
                return `<div class="grid grid-cols-[1fr_130px] gap-2 items-center bg-gray-950/40 rounded-lg p-2 border border-gray-800">
                    <div class="text-xs text-gray-300 font-medium">${item.label}</div>
                    <select data-check-key="${item.key}" class="inspection-status w-full bg-gray-900 border border-gray-700 rounded px-2 py-1 text-[11px] text-white">
                        <option value="OK" ${status === 'OK' ? 'selected' : ''}>OK</option>
                        <option value="ATTENTION" ${status === 'ATTENTION' ? 'selected' : ''}>PERLU PERHATIAN</option>
                        <option value="NA" ${status === 'NA' ? 'selected' : ''}>N/A</option>
                    </select>
                    <input data-check-note="${item.key}" value="${note}" placeholder="Nota jika perlu..." class="col-span-2 w-full bg-gray-900 border border-gray-800 rounded px-2 py-1 text-[10px] text-gray-300 focus:border-amber-500 focus:outline-none">
                </div>`;
            }).join('');
        }

        function collectInspectionChecklist(containerId) {
            const el = document.getElementById(containerId);
            if (!el) return {};
            const result = {};
            FAST_SERVICE_CHECKS.forEach(item => {
                const statusEl = el.querySelector(`[data-check-key="${item.key}"]`);
                const noteEl = el.querySelector(`[data-check-note="${item.key}"]`);
                result[item.key] = { status: statusEl ? statusEl.value : 'OK', note: noteEl ? noteEl.value.trim() : '' };
            });
            return result;
        }
        
        // Compact status toast. A newer toast restarts the timer so an older
        // timer can never hide it early. Errors stay a little longer.
        let rtToastTimer = null;
        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            const content = document.getElementById('toastContent');
            const msgEl = document.getElementById('toastMessage');
            if (!toast || !content || !msgEl) return;
            const kind = type === 'error' ? 'error' : type === 'info' ? 'info' : 'success';
            msgEl.innerText = message;
            content.className = 'rt-toast-card rt-toast-' + kind;
            content.setAttribute('role', kind === 'error' ? 'alert' : 'status');
            toast.classList.remove('translate-x-full', 'opacity-0');
            toast.classList.add('rt-toast-show');
            clearTimeout(rtToastTimer);
            rtToastTimer = setTimeout(() => {
                toast.classList.add('translate-x-full', 'opacity-0');
                toast.classList.remove('rt-toast-show');
            }, kind === 'error' ? 4500 : 2600);
        }

        function toggleLoading(btnId, isLoading) {
            const btn = document.getElementById(btnId);
            if (!btn) return;
            if (isLoading) {
                btn.disabled = true;
                btn.innerHTML = `<div class="loader mr-2"></div> Sila Tunggu...`;
            } else {
                btn.disabled = false;
                btn.innerHTML = btn.getAttribute('data-original-text') || 'Simpan';
            }
        }
        function setOriginalText(btnId) {
            const btn = document.getElementById(btnId);
            if(btn && !btn.hasAttribute('data-original-text')) btn.setAttribute('data-original-text', btn.innerHTML);
        }

        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('-translate-x-full');
        }

        function openModal(id) {
            document.getElementById('modalOverlay').classList.remove('hidden');
            const modals = document.querySelectorAll('.modal-content');
            modals.forEach(m => m.classList.add('hidden'));
            const modal = document.getElementById(id);
            if(modal) {
                modal.classList.remove('hidden');
                // Auto focus first input if any
                const input = modal.querySelector('input');
                if(input) setTimeout(() => input.focus(), 100);
            }
        }

        function closeModal(id) {
            document.getElementById(id).classList.add('hidden');
            document.getElementById('modalOverlay').classList.add('hidden');
        }

        function filterTable(tableId, query) {
            const q = query.toLowerCase();
            const rows = document.querySelectorAll(`#${tableId} tbody tr`);
            rows.forEach(row => {
                const text = row.innerText.toLowerCase();
                row.style.display = text.includes(q) ? '' : 'none';
            });
        }

        // Live Clock
        setInterval(() => {
            const el = document.getElementById('clock');
            if(el) {
                const now = new Date();
                el.innerText = now.toLocaleString('ms-MY', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' });
            }
        }, 1000);

        // --- 6. AUTHENTICATION & LOGIN FLOW ---

        // HIDDEN DEBUG TRIGGER LOGIC
        let tapCount = 0;
        let tapTimer = null;
        function handleDebugTap() {
            tapCount++;
            if(tapCount === 1) {
                tapTimer = setTimeout(() => { tapCount = 0; }, 2000);
            }
            if(tapCount >= 5) {
                clearTimeout(tapTimer);
                tapCount = 0;
                showToast('Gunakan akaun admin yang sah melalui Tetapan Sistem.', 'info');
            }
        }

        function toggleDebugPanel() {
            const panel = document.getElementById('debugPanel');
            panel.classList.toggle('hidden');
        }

        // DEBUG FUNCTIONS
        async function testSupabase() { dbgLog("Supabase initialized: " + (app ? "YES" : "NO")); }
        async function testFirestore() {
            try {
                const user = window.currentUser;
                if (!user) {
                    // Rules intentionally protect Firestore before authentication.
                    dbgLog("Firestore SDK: READY");
                    dbgLog("Protected read skipped: LOGIN REQUIRED (this is expected).");
                    return;
                }
                const snap = await db.collection('staff').doc(user.uid).get();
                if (snap.exists) dbgLog("Firestore auth read: PASS");
                else dbgLog("Firestore auth read: CONNECTED, staff profile not found for current UID.");
            } catch(e) {
                dbgLog("Firestore Auth Read Error: " + e.message);
            }
        }
        function testSession() { dbgLog("Session exists: " + (sessionStorage.getItem(SESSION_KEY) ? "YES" : "NO")); }
        function clearDebugLog() { document.getElementById('debugLog').innerText = "=== DEBUG LOG CLEARED ==="; }
        function dbgLog(msg) {
            const l = document.getElementById('debugLog');
            l.innerText += "\n> " + msg;
            l.scrollTop = l.scrollHeight;
        }

        async function setupInitialAdmin() {
            if (window.setupInitialAdmin && window.setupInitialAdmin !== setupInitialAdmin) return window.setupInitialAdmin();
            showToast("Gunakan Setup Initial Admin selepas Supabase Auth siap.", "info");
        }

        async function debugFindStaff() {
            const user = window.currentUser;
            if (!user) {
                dbgLog("Find Staff: LOGIN REQUIRED. Firestore rules correctly block anonymous reads.");
                return;
            }
            const id = prompt("Masukkan Staff ID untuk dicari:");
            if(!id) return;
            try {
                const callerDoc = await db.collection("staff").doc(user.uid).get();
                if(!callerDoc.exists || !["owner","admin","administrator","super_admin","superadmin"].includes(String(callerDoc.data().role||"").toLowerCase())) {
                    dbgLog("Find Staff: ADMIN LOGIN REQUIRED.");
                    return;
                }
                const snap = await db.collection("staff").where("staffId", "==", id.trim().toUpperCase()).limit(1).get();
                if(snap.empty) { dbgLog(`STAFF NOT FOUND: ${id}`); return; }
                const data = snap.docs[0].data();
                dbgLog(`STAFF FOUND:\nUID: ${data.uid || snap.docs[0].id}\nID: ${data.staffId}\nName: ${data.name}\nRole: ${data.role}\nActive: ${data.active}`);
            } catch(e) { dbgLog("ERROR Find Staff: " + e.message); }
        }

        // Fail closed if the canonical auth script cannot load.
        // supabase-auth.js supplies the only login/restore/logout implementation.
        window.handleLogin = function(e){
            e.preventDefault();
            showToast('Modul login belum tersedia. Muat semula aplikasi.', 'error');
        };
        window.restoreSession = function(){ showLoginScreen(); };
        function handleLogout(){
            showLoginScreen();
            showToast('Modul logout belum tersedia. Muat semula aplikasi.', 'error');
        }

        function showLoginScreen() {
            document.getElementById('appContainer').classList.add('hidden');
            document.getElementById('loginScreen').classList.remove('hidden');
        }

        // V2: one trusted writer (js/rt-audit.js). The old body sent `details`/`role`/`timestamp`
        // that the bridge dropped or the table rejected, so the record was lost without a sound.
        // extra = { entityType, entityId, entityKey, before, after, meta }
        async function logAudit(action, details, extra) {
            if(!currentProfile) return;
            try {
                if (typeof window.rtAuditWrite === 'function') return await window.rtAuditWrite(action, details, extra);
                console.error('Audit writer missing; not recorded:', action);
            } catch (error) { console.error("Audit log error", error); }
        }

        // --- 7. APP INITIALIZATION & NAVIGATION ---
        // IMPORTANT: module scripts are loaded AFTER core.js.
        // Store function names here instead of referencing module functions
        // before those modules have been evaluated.
        const viewDefinitions = {
            dashboard: { icon: 'grid', title: 'Dashboard', nav: 'Dashboard', func: 'loadDashboard' },
            backend: { icon: 'shield', title: 'Backend / Admin Control', func: 'loadBackendCenter' },
            customers: { icon: 'users', title: 'Pelanggan & Kenderaan', nav: 'Pelanggan', func: 'loadCustomers' },
            booking: { icon: 'calendar', title: 'Booking', nav: 'Booking', func: 'loadBookings' },
            jobcard: { icon: 'clipboard', title: 'Job Cards', nav: 'Job Card', func: 'loadJobCards' },
            myjobs: { icon: 'tool', title: 'Tugasan Saya', func: 'loadMyJobs' },
            pos: { icon: 'shopping-cart', title: 'Jualan / POS', nav: 'POS', func: 'loadPOS' },
            sales: { icon: 'file-text', title: 'Sejarah Jualan', nav: 'Jualan', func: 'rtLoadSalesPage' },
            quotes: { icon: 'file-plus', title: 'Sebut Harga', nav: 'Quotation', func: 'rtLoadQuotes' },
            pay: { icon: 'credit-card', title: 'Bayar Job', func: 'rtOpenPayMenu' },
            inventory: { icon: 'box', title: 'Inventori', nav: 'Inventori', func: 'loadInventory' },
            pomenstock: { icon: 'package', title: 'Stok & Harga Jual', func: 'loadPomenStock' },
            stockledger: { icon: 'list', title: 'Lejar Stok', func: 'loadStockLedger' },
            suppliers: { icon: 'truck', title: 'Pembekal', nav: 'Pembekal', func: 'loadSuppliers' },
            purchase: { icon: 'package', title: 'Terimaan GRN', nav: 'GRN', func: 'loadGRN' },
            reminders: { icon: 'bell', title: 'Peringatan Servis', nav: 'Peringatan', func: 'loadReminders' },
            staff: { icon: 'user-check', title: 'Kakitangan', nav: 'Staf', func: 'loadStaff' },
            audit: { icon: 'shield', title: 'Log Sistem', func: 'loadAudit' },
            override: { icon: 'shield', title: 'Override / Audit', func: 'rtLoadOverride' },
            settings: { icon: 'settings', title: 'Tetapan Sistem', nav: 'Tetapan', func: 'loadSettings' },
            tutorial: { icon: 'book-open', title: 'Tutorial', nav: 'Tutorial', func: 'loadTutorial' }
        };

        function loadTutorial() {
            const box = document.getElementById('tutorialContent');
            if (!box) return;
            box.innerHTML = `
              <div class="max-w-5xl mx-auto space-y-5">
                <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                  <h2 class="text-xl font-black text-slate-900">REV TORQ — Tutorial Sistem</h2>
                  <p class="text-sm text-slate-500 mt-1">Panduan ringkas untuk Owner/Admin dan Staff.</p>
                </div>
                <div class="grid md:grid-cols-2 gap-4">
                  <div class="bg-white rounded-2xl border border-slate-200 p-5">
                    <h3 class="font-black text-slate-900 mb-3">ADMIN / OWNER</h3>
                    <ol class="text-sm text-slate-600 space-y-2 list-decimal pl-5">
                      <li>POS — skrin utama selepas login: scan / pilih barang, bayar, cetak resit.</li>
                      <li>Dashboard — ringkasan jualan, job dan stok hari ini (terus di bawah POS).</li>
                      <li>Jualan — sejarah resit, cetak semula, VOID (Admin).</li>
                      <li>Quotation — sebut harga UBAH SUAI dan SERVIS (PDF A4 + WhatsApp). Rekod sahaja, tidak masuk troli.</li>
                      <li>Job Card — buka dan urus kerja. Tab Booking untuk sahkan tempahan.</li>
                      <li>Pelanggan — pelanggan dan kenderaan. Tab Peringatan Servis.</li>
                      <li>Inventori — stok, harga, Stock In / Pelarasan. Tab Pembekal &amp; GRN.</li>
                      <li>Staf — akaun &amp; attendance.</li>
                      <li>Tetapan — printer, QR bayaran, profil bengkel, Backend, Override &amp; Audit.</li>
                      <li>Lagi — Jualan Tertinggal, Booking, Pembekal, GRN, Peringatan, Tutorial dan Override.</li>
                      <li>✦ REV TORQ AI — di bawah menu, atas Log Keluar: ringkasan stok, cadangan restok dan audit (baca sahaja).</li>
                    </ol>
                  </div>
                  <div class="bg-white rounded-2xl border border-slate-200 p-5">
                    <h3 class="font-black text-slate-900 mb-3">STAFF / POMEN</h3>
                    <ul class="text-sm text-slate-600 space-y-2 list-disc pl-5">
                      <li>POS — jualan &amp; bayaran</li>
                      <li>Jualan — cari &amp; cetak semula resit</li>
                      <li>Quotation — buat &amp; hantar sebut harga kepada pelanggan</li>
                      <li>Job Card (Pomen)</li>
                    </ul>
                    <div class="mt-5 rounded-xl bg-slate-50 p-4 text-xs text-slate-500">
                      Akses admin tidak dipaparkan kepada akaun staff.
                    </div>
                  </div>
                </div>
                <div class="bg-white rounded-2xl border border-slate-200 p-5">
                  <h3 class="font-black text-slate-900 mb-2">Override Mode</h3>
                  <p class="text-sm text-slate-600">Gunakan hanya untuk pembetulan rekod yang salah key-in, termasuk rekod ujian. Semua fungsi pemadaman patut dilindungi dengan pengesahan admin dan audit log.</p>
                </div>
              </div>`;
        }

        function initAppLayout() {
            const profile = currentProfile || window.currentProfile;
            if (!profile) throw new Error('Profil staff belum tersedia.');
            currentProfile = profile;
            if (window.currentUser) currentUser = window.currentUser;
            syncPublicState();
            document.getElementById('loginScreen').classList.add('hidden');
            document.getElementById('appContainer').classList.remove('hidden');

            const role = String(profile.role || '').toLowerCase();
            if(!menuDefinitions[role]){showLoginScreen();throw new Error('Peranan POS tidak sah.');}
            document.getElementById('dbgSession').innerText = "EXISTS";
            document.getElementById('dbgLogin').innerText = "LOGGED IN";
            document.getElementById('dbgStaffId').innerText = profile.staffId || profile.staff_code || profile.id || 'NONE';
            document.getElementById('dbgRole').innerText = role;
            document.getElementById('navUserName').innerText = profile.name || profile.staffId || 'Staff';
            document.getElementById('navUserRole').innerText = role;

            buildNavigation();
            const allowed = menuDefinitions[role] || [];
            if (allowed.length > 0) switchView(allowed[0]);
        }

        function navButtonHtml(menuId) {
            const def = viewDefinitions[menuId];
            if (!def) return '';
            return `<button type="button" data-view="${menuId}" onclick="window.switchView('${menuId}')" id="nav-${menuId}" class="rt-nav-item w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium" title="${def.title}">
                      <i data-feather="${def.icon}" class="w-4 h-4"></i><span class="rt-nav-label">${def.nav || def.title}</span>
                    </button>`;
        }

        function rtNavMoreOpen() {
            // iPad landscape rail: start with "Lagi" closed (open it pushes its items below the screen edge).
            try { if (window.matchMedia && window.matchMedia('(min-width:768px) and (max-width:1366px) and (max-height:860px)').matches) return false; } catch (_) {}
            try { return localStorage.getItem('rt_nav_more_open') === '1'; } catch (_) { return false; }
        }

        window.rtToggleNavMore = function(force) {
            const more = document.getElementById('rtNavMore');
            const btn = document.getElementById('rtNavMoreToggle');
            if (!more) return;
            const open = typeof force === 'boolean' ? force : more.classList.contains('hidden');
            more.classList.toggle('hidden', !open);
            if (btn) btn.setAttribute('aria-expanded', open ? 'true' : 'false');
            try { localStorage.setItem('rt_nav_more_open', open ? '1' : '0'); } catch (_) {}
            // Tapped open on a short screen (iPad rail): scroll the menu so the "Lagi" items come into view.
            const nav = document.getElementById('mainNav');
            if (open && typeof force !== 'boolean' && btn && nav && nav.scrollHeight > nav.clientHeight) {
                const top = Math.max(0, btn.offsetTop - nav.offsetTop - 6);
                try { nav.scrollTo({ top, behavior: 'smooth' }); } catch (_) { nav.scrollTop = top; }
            }
        };

        function buildNavigation() {
            const nav = document.getElementById('mainNav');
            if (!nav) return;
            const allowed = menuDefinitions[currentProfile.role] || [];
            const adminRole = ['owner','super_admin','admin'].includes(String(currentProfile.role || '').toLowerCase());
            let html = '';
            if (adminRole) {
              // Few equal-priority items; everything else is one tap away under "Lagi".
              html += navPrimary.filter(id => allowed.includes(id)).map(id => (navGroupStart.includes(id) ? '<div class="rt-nav-sep" aria-hidden="true"></div>' : '') + navButtonHtml(id)).join('');
              const secondary = navSecondary.filter(id => allowed.includes(id));
              if (secondary.length) {
                const open = rtNavMoreOpen();
                html += `<button type="button" id="rtNavMoreToggle" class="rt-nav-more-toggle" aria-expanded="${open ? 'true' : 'false'}" onclick="window.rtToggleNavMore()">
                          <i data-feather="more-horizontal" class="w-4 h-4"></i><span class="rt-nav-label">Lagi</span><i data-feather="chevron-down" class="rt-nav-chevron w-4 h-4"></i>
                        </button>
                        <div id="rtNavMore" class="rt-nav-more${open ? '' : ' hidden'}">
                          <button type="button" id="rtNavLateEntry" data-rt-late-launch hidden class="rt-nav-item w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium" title="Jualan Tertinggal (Admin)">
                            <i data-feather="clock" class="w-4 h-4"></i><span class="rt-nav-label">Jualan Tertinggal</span>
                          </button>${secondary.map(navButtonHtml).join('')}
                          <button type="button" id="rtAdminPosBtn" class="rt-nav-item w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium" onclick="window.rtOpenAdminOverride?.()" title="Override Mode">
                            <i data-feather="shield" class="w-4 h-4"></i><span class="rt-nav-label">Override</span>
                          </button>
                        </div>`;
              }
            } else {
              html += allowed.map(navButtonHtml).join('');
            }
            nav.innerHTML = html;
            if (typeof feather !== 'undefined') feather.replace();
            // Jualan Tertinggal (js/rt-late-entry.js) shows its menu item to Admin / Owner only.
            if (window.rtLateEntry && typeof window.rtLateEntry.sync === 'function') window.rtLateEntry.sync();
        }

        // Sidebar + section-tab active state. A sub-page (Booking, GRN, ...) also
        // highlights its parent so staff always know where they are.
        function rtMarkActiveNav(viewId) {
            const parent = navParent[viewId] || viewId;
            document.querySelectorAll('#mainNav [data-view]').forEach(el => {
                const v = el.getAttribute('data-view');
                const on = v === viewId || v === parent;
                el.classList.toggle('active', on);
                if (on) el.setAttribute('aria-current', 'page'); else el.removeAttribute('aria-current');
            });
            if (navSecondary.includes(viewId) && !navPrimary.includes(parent)) window.rtToggleNavMore(true);
            const role = String((currentProfile || window.currentProfile || {}).role || '').toLowerCase();
            const allowed = menuDefinitions[role] || [];
            document.querySelectorAll('.rt-section-tabs [data-view]').forEach(el => {
                const v = el.getAttribute('data-view');
                el.classList.toggle('active', v === viewId);
                el.classList.toggle('hidden', !allowed.includes(v));
            });
            document.querySelectorAll('.rt-section-tabs').forEach(bar => {
                bar.classList.toggle('hidden', bar.querySelectorAll('[data-view]:not(.hidden)').length < 2);
            });
        }
        window.rtMarkActiveNav = rtMarkActiveNav;

        
// V34.3: prevent accidental double-loading from rapid taps/navigation.
const __rtViewLoadGuard = new Map();
let __rtViewEnforcing = false;

function rtApplyActiveView(viewId) {
    const targetId = 'view-' + viewId;
    window.__rtActiveView = viewId;
    const sections = document.querySelectorAll('#viewsContainer > .view-section, #viewsContainer .view-section');
    __rtViewEnforcing = true;
    sections.forEach(el => {
        const active = el.id === targetId;
        if (active) {
            el.hidden = false;
            el.removeAttribute('hidden');
            el.classList.remove('hidden');
            el.setAttribute('aria-hidden', 'false');
            el.dataset.rtActiveView = '1';
            el.style.setProperty('display', viewId === 'pos' ? 'flex' : 'block', 'important');
            el.style.setProperty('visibility', 'visible', 'important');
        } else {
            el.hidden = true;
            el.setAttribute('hidden', '');
            el.classList.add('hidden');
            el.setAttribute('aria-hidden', 'true');
            delete el.dataset.rtActiveView;
            el.style.setProperty('display', 'none', 'important');
            el.style.setProperty('visibility', 'hidden', 'important');
        }
    });
    __rtViewEnforcing = false;
}
window.rtApplyActiveView = rtApplyActiveView;

function switchView(viewId) {
            // Hard UI gate: a staff/cashier account can only open the views
            // granted by menuDefinitions. Finance modules are not part of this POS build.
            const role = String((currentProfile || window.currentProfile || {}).role || '').toLowerCase();
            const allowedForRole = menuDefinitions[role] || [];
            const systemViews = ['backend','staff','override','audit'];
            const isAdminSystemView = ['owner','super_admin','admin'].includes(role) && systemViews.includes(viewId);
            if (!allowedForRole.includes(viewId) && !isAdminSystemView) {
                if (typeof window.showToast === 'function') window.showToast('Akses tidak dibenarkan untuk akaun ini.', 'error');
                return;
            }

            // Native + CSS + inline IMPORTANT. Only ONE page may exist visually.
            rtApplyActiveView(viewId);

            rtMarkActiveNav(viewId);

            if(viewDefinitions[viewId]) {
                const titleEl = document.getElementById('pageTitle');
                if (titleEl) titleEl.innerText = viewDefinitions[viewId].title;
                const fnName = viewDefinitions[viewId].func;
                const fn = typeof fnName === 'function'
                    ? fnName
                    : (typeof fnName === 'string' && typeof window[fnName] === 'function'
                        ? window[fnName]
                        : null);
                if (fn) {
                    const now = Date.now();
                    const last = __rtViewLoadGuard.get(viewId) || 0;
                    if (['customers','inventory','jobcard','audit'].includes(viewId) || now - last > (window.RT_TURBO_VIEW_GUARD_MS || 700)) {
                        __rtViewLoadGuard.set(viewId, now);
                        Promise.resolve(fn())
                          .catch(err => console.error("View load error:", viewId, err))
                          .finally(() => {
                              // Some legacy loaders still touch classes/styles. Re-assert route after load.
                              if (window.__rtActiveView === viewId) rtApplyActiveView(viewId);
                          });
                    }
                }
            }

            // Re-assert after legacy animation/event handlers have had a chance to run.
            requestAnimationFrame(() => {
                if (window.__rtActiveView === viewId) rtApplyActiveView(viewId);
            });
            setTimeout(() => {
                if (window.__rtActiveView === viewId) rtApplyActiveView(viewId);
            }, 60);
            setTimeout(() => {
                if (window.__rtActiveView === viewId) rtApplyActiveView(viewId);
            }, 300);

            // Close sidebar on mobile after click
            if(window.innerWidth < 768) {
                const sidebar = document.getElementById('sidebar');
                if (sidebar) sidebar.classList.add('-translate-x-full');
            }
        }

// Guard against legacy modules accidentally unhiding an old page.
(function installSingleViewGuard(){
    function boot(){
        const host=document.getElementById('viewsContainer');
        if(!host || host.__rtSingleViewGuard) return;
        host.__rtSingleViewGuard=true;
        const obs=new MutationObserver(() => {
            if(__rtViewEnforcing || !window.__rtActiveView) return;
            const expected='view-'+window.__rtActiveView;
            let bad=false;
            host.querySelectorAll('.view-section').forEach(el => {
                if(el.id===expected) return;
                const cs=getComputedStyle(el);
                if(cs.display!=='none' || !el.hidden || !el.classList.contains('hidden')) bad=true;
            });
            if(bad) rtApplyActiveView(window.__rtActiveView);
        });
        obs.observe(host,{subtree:true,attributes:true,attributeFilter:['class','style','hidden']});
    }
    if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true}); else boot();
})();

        // V36.4.9.11 — explicit public UI API.
        // Do not rely on classic-script implicit globals; tablet/mobile deployments
        // and later modules may wrap or replace functions.
        window.toggleSidebar = toggleSidebar;
        window.openModal = openModal;
        window.closeModal = closeModal;
        window.initAppLayout = initAppLayout;
        window.switchView = switchView;

        // --- 8. MODULES IMPLEMENTATION ---

        

// V34.3 SCALE: paginated audit retrieval. Never load a full year's audit log.
window.rtAuditPage = async function(startDate,endDate,pageSize=50,cursor=null){
  if(!window.db) throw new Error('Supabase belum tersedia');
  const lim=Math.min(Number(pageSize)||50,100);
  let q=db.collection('audit_logs')
    .where('createdAt','>=',startDate)
    .where('createdAt','<=',endDate)
    .orderBy('createdAt','desc')
    .limit(lim);
  if(cursor) q=q.startAfter(cursor);
  const snap=await q.get();
  return {
    items:snap.docs.map(d=>({id:d.id,...d.data()})),
    lastDoc:snap.docs.length?snap.docs[snap.docs.length-1]:null,
    hasMore:snap.size===lim
  };
};
