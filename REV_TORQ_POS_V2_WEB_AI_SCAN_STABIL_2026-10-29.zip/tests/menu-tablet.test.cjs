const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
const html=read('index.html');
const core=read('js/core.js');
const css=read('css/rt-polish.css');
const late=read('js/rt-late-entry.js');
const list=re=>re.exec(core)[1].split(',').map(x=>x.trim().replace(/'/g,''));

test('menu 2026-10-28: POS + Dashboard on top, then Jualan / Quotation, Job Card / Pelanggan / Inventori, Staf / Tetapan',()=>{
  const prim=list(/const navPrimary = \[([^\]]*)\]/);
  assert.deepEqual(prim,['pos','dashboard','sales','quotes','jobcard','customers','inventory','staff','settings']);
  const sec=list(/const navSecondary = \[([^\]]*)\]/);
  assert.deepEqual(sec,['booking','suppliers','purchase','reminders','tutorial']);
  assert.ok(!sec.includes('dashboard'),'Dashboard is no longer hidden under "Lagi"');
  assert.deepEqual(list(/const navGroupStart = \[([^\]]*)\]/),['sales','jobcard','staff']);
  assert.match(core,/navGroupStart\.includes\(id\) \? '<div class="rt-nav-sep" aria-hidden="true"><\/div>'/);
  for(const r of ['owner','super_admin','admin']){
    const m=new RegExp('\\n\\s+'+r+":\\s*\\[([^\\]]*)\\]").exec(core.slice(core.indexOf('const menuDefinitions')));
    const allowed=m[1].split(',').map(x=>x.trim().replace(/'/g,''));
    for(const id of prim.concat(sec))assert.ok(allowed.includes(id),r+' can open '+id);
    assert.equal(allowed[0],'pos',r+' still lands on POS');
  }
  assert.match(core,/cashier: \['pos','sales','quotes'\]/,'cashier menu unchanged');
});

test('menu: Jualan Tertinggal sits under "Lagi" and on the Jualan page, hidden until js/rt-late-entry.js confirms Admin / Owner',()=>{
  const more=core.slice(core.indexOf('<div id="rtNavMore"'),core.indexOf('rtAdminPosBtn'));
  assert.match(more,/id="rtNavLateEntry" data-rt-late-launch hidden/);
  assert.match(core,/if \(window\.rtLateEntry && typeof window\.rtLateEntry\.sync === 'function'\) window\.rtLateEntry\.sync\(\);/);
  const sales=html.slice(html.indexOf('id="view-sales"'),html.indexOf('id="tblSales"'));
  assert.match(sales,/data-rt-late-launch hidden/);
  assert.match(late,/const ok=admin\(\);const slots=document\.querySelectorAll\('\[data-rt-late-launch\]'\);/);
  assert.match(late,/slots\.forEach\(s=>\{s\.hidden=!ok\}\)/);
  assert.match(late,/closest\('\[data-rt-late-launch\]'\);if\(b\)\{e\.preventDefault\(\);open\(\)\}/);
  assert.match(late,/w\.rtLateEntry=\{open,close,sync\};/);
  assert.match(late,/const admin=\(\)=>w\.rtHasAdminAccess\?\.\(\)===true&&\['owner','admin','super_admin'\]/,'admin check unchanged');
  assert.match(late,/nav\.appendChild\(b\)/,'an older menu without the slot still gets a button');
  assert.match(css,/\[data-rt-late-launch\]\[hidden\]\{display:none!important\}/,'hidden wins over Tailwind "flex"');
});

test('menu: REV TORQ AI under the menu (above Log Keluar), compact "AI Hub" on the tablet rail; toast shows above it',()=>{
  const side=html.slice(html.indexOf('<aside id="sidebar"'),html.indexOf('</aside>'));
  const nav=side.indexOf('id="mainNav"'),ai=side.indexOf('id="rtAiHubLauncher"'),out=side.indexOf('handleLogout()');
  assert.ok(nav>0&&ai>nav&&out>ai,'menu, then AI Hub, then Log Keluar');
  assert.match(side,/<button type="button" id="rtAiHubLauncher" class="rtai-launch" hidden><span class="rtai-launch-mark">✦<\/span><span class="rtai-launch-name">REV TORQ AI<\/span><span class="rtai-launch-short">AI Hub<\/span><span class="rtai-launch-tag">ADMIN<\/span><\/button>/);
  const rail=css.slice(css.indexOf('/* REV TORQ menu + tablet / phone tidy (2026-10-28)'));
  assert.match(rail,/#appContainer\.rt-reference-ui #mainNav \.rt-nav-item\{gap:0!important\}/);
  assert.match(rail,/#appContainer\.rt-reference-ui #rtAiHubLauncher \.rtai-launch-short\{display:block;line-height:14px\}/);
  assert.match(rail,/body\.rtai-open #toast\{z-index:21001!important\}/);
});

test('scripts: AI Hub and Jualan Tertinggal load before rt-polish.js, which stays last; changed files have a new ?v=',()=>{
  const srcs=[...html.matchAll(/<script src="([^"?]+)/g)].map(m=>m[1]);
  assert.equal(srcs[srcs.length-1],'js/rt-polish.js');
  assert.ok(srcs.indexOf('js/rt-ai-hub.js')>0&&srcs.indexOf('js/rt-late-entry.js')>srcs.indexOf('js/rt-ai-hub.js'));
  assert.ok(srcs.indexOf('js/rt-service-plate-guard.js')<srcs.indexOf('js/v36-4-9-pos-cash-canonical.js'),'plate guard before the checkout');
  // versions in the user's LATE_ENTRY upload; each changed file must carry a newer one (later releases may raise it again)
  for(const [f,v] of [['js/core.js','38.7.0-quotes'],['js/pos.js','37.0.9-tabletfix'],['js/v36-4-9-pos-cash-canonical.js','37.0.6-audit'],['js/rt-late-entry.js','20261028-1'],['css/rt-polish.css','2.8.1-tabletfix'],['js/rt-offline.js','2.5.1-tabletfix']]){
    const m=new RegExp(f.replace(/[.\/]/g,'\\$&')+'\\?v=([^"]+)"').exec(html);
    assert.ok(m,f+' is loaded with a ?v=');assert.notEqual(m[1],v,f+' version raised');
  }
  const sw=/var BUILD='([^']+)'/.exec(read('sw-notify.js'))[1],app=/var BUILD='([^']+)'/.exec(read('js/rt-offline.js'))[1];
  assert.equal(sw,app);
  assert.notEqual(sw,'2026-10-27-tablet-fix');
});

test('tablet / phone: finger-sized controls on touch screens, phone header keeps the menu button, short iPad rail fits',()=>{
  const block=css.slice(css.indexOf('/* REV TORQ menu + tablet / phone tidy (2026-10-28)'));
  const coarse=block.slice(block.indexOf('@media (any-pointer:coarse){'));
  for(const sel of ['#tblInventory td:last-child button{min-height:40px','.rtai-tabs button,.rtai-tools button,.rtai-action{min-height:40px','.rtai-chat-form textarea{font-size:16px}','.rtle-line>button{width:40px;height:40px','#rtServicePlateHint button{min-height:40px}'])
    assert.ok(coarse.includes(sel),sel);
  assert.match(block,/@media \(max-width:639px\)\{[\s\S]*main>header>div:first-child>button\{flex:none;width:40px;min-width:40px\}/);
  assert.match(block,/@media \(min-width:768px\) and \(max-width:1366px\) and \(max-height:860px\)\{[\s\S]*#rtAiHubLauncher\{min-height:48px\}/);
  assert.match(block,/#rtServicePlateHint:not\(\[hidden\]\)\{display:flex!important/);
});

test('menu / UI changes never write data: no Supabase calls in the menu code, checkout guard untouched',()=>{
  const nav=core.slice(core.indexOf('function buildNavigation()'),core.indexOf('function rtMarkActiveNav'));
  assert.doesNotMatch(nav,/\.rpc\(|\.from\(|\.insert\(|\.update\(|\.delete\(/);
  const cash=read('js/v36-4-9-pos-cash-canonical.js');
  assert.match(cash,/verifiedServiceVehicle=await window\.rtRequirePlateForService\(\{items:c,activeJob,customerId:selectedCustomer\}\);/);
  assert.match(read('js/pos.js'),/category: source\?\.category \|\| null/);
});
