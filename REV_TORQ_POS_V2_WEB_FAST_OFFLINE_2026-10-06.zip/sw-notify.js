/* REV TORQ POS — service worker.
   1. Booking alerts: tapping a notification brings the POS tab forward and opens the booking.
   2. App-shell cache (V2 offline level 1): the app's own files (index.html, js, css, fonts,
      icons) are kept on the device, so the POS opens fast and also without internet.

   What it does NOT do: it never touches another origin (the database API, CDNs, payment APIs),
   never caches an API reply, and never answers a sale. Data is fetched by the app itself.

   Updates: index.html is network-first (3 s), so a new version arrives as soon as the network
   answers; if the network is slow or down the copy on the device is used. Script / css URLs
   carry ?v=..., so a cached file never goes stale. Change BUILD with every release.
   Reset: open the app once with ?rt_reset=1, or Tetapan > Diagnostik > Kosongkan cache app. */
var BUILD='2026-10-06-offline1';
var CACHE='rt-shell-'+BUILD;
var NAV_TIMEOUT=3000;
var SCOPE=self.registration.scope;
var INDEX=new URL('index.html',SCOPE).href;
var STATIC_EXT=/\.(?:js|css|png|jpe?g|svg|webp|ico|gif|woff2?|ttf|otf|eot|json|webmanifest)$/i;

function sameOrigin(u){try{return new URL(u).origin===self.location.origin;}catch(_){return false;}}
function isStatic(u){try{var x=new URL(u);return x.origin===self.location.origin&&STATIC_EXT.test(x.pathname);}catch(_){return false;}}
function isAppPage(url){
  var p=url.pathname,base=new URL(SCOPE).pathname;
  return p===base||p===base+'index.html';
}
function hasVersion(u){try{return new URL(u).search.length>1;}catch(_){return false;}}
function refsOf(html,base){
  var out={},re=/(?:src|href)\s*=\s*["']([^"'#]+)["']/gi,m;
  while((m=re.exec(html))){
    var raw=m[1].trim();
    if(/^(?:data|javascript|mailto|tel|blob):/i.test(raw))continue;
    try{var u=new URL(raw,base);if(isStatic(u.href))out[u.href]=1;}catch(_){}
  }
  return Object.keys(out);
}
function cssUrls(css,base){
  var out={},re=/url\(\s*["']?([^"')]+)["']?\s*\)/gi,m;
  while((m=re.exec(css))){
    var raw=m[1].trim();
    if(/^(?:data|blob):/i.test(raw))continue;
    try{var u=new URL(raw,base);if(isStatic(u.href))out[u.href]=1;}catch(_){}
  }
  return Object.keys(out);
}
function putIfMissing(cache,url){
  return cache.match(url).then(function(hit){
    if(hit)return null;
    return fetch(url).then(function(res){
      if(res&&res.status===200&&res.type==='basic')return cache.put(url,res.clone()).then(function(){return res;});
      return null;
    }).catch(function(){return null;});
  });
}
function inBatches(list,size,fn){
  var i=0;
  function next(){
    if(i>=list.length)return Promise.resolve();
    var part=list.slice(i,i+size);i+=size;
    return Promise.all(part.map(fn)).then(next);
  }
  return next();
}
// Cache every file the page lists, then the fonts / images its stylesheets point at.
function precache(html){
  return caches.open(CACHE).then(function(cache){
    var list=refsOf(html,INDEX).concat([new URL('manifest.webmanifest',SCOPE).href]);
    return inBatches(list,6,function(u){return putIfMissing(cache,u);}).then(function(){
      var css=list.filter(function(u){return /\.css(?:$|\?)/i.test(u);});
      return Promise.all(css.map(function(u){return cache.match(u).then(function(r){return r?r.text().then(function(t){return cssUrls(t,u);}):[];});}));
    }).then(function(groups){
      var extra={};groups.forEach(function(g){g.forEach(function(u){extra[u]=1;});});
      return inBatches(Object.keys(extra),6,function(u){return putIfMissing(cache,u);});
    }).then(function(){
      // the install icons named in the manifest
      var murl=new URL('manifest.webmanifest',SCOPE).href;
      return cache.match(murl).then(function(r){return r?r.json():null;}).then(function(m){
        if(!m||!Array.isArray(m.icons))return;
        var icons=m.icons.map(function(i){try{return new URL(i.src,murl).href;}catch(_){return '';}}).filter(isStatic);
        return inBatches(icons,4,function(u){return putIfMissing(cache,u);});
      }).catch(function(){});
    }).then(function(){return pruneOldVersions(cache,list);});
  });
}
// Same file, older ?v=: drop it so the cache does not grow with every release.
function pruneOldVersions(cache,keep){
  var keepSet={},paths={};
  keep.forEach(function(u){keepSet[u]=1;paths[new URL(u).pathname]=1;});
  return cache.keys().then(function(keys){
    return Promise.all(keys.map(function(r){
      var u=new URL(r.url);
      if(!keepSet[r.url]&&paths[u.pathname])return cache.delete(r);
      return null;
    }));
  });
}
function refreshFromIndex(html){return precache(html).catch(function(){});}

self.addEventListener('install',function(e){
  self.skipWaiting();
  e.waitUntil(fetch(INDEX,{cache:'reload'}).then(function(res){
    if(!res||!res.ok)return null;
    var copy=res.clone();
    return caches.open(CACHE).then(function(c){return c.put(INDEX,copy);}).then(function(){return res.text();}).then(precache);
  }).catch(function(){}));
});
self.addEventListener('activate',function(e){
  e.waitUntil(caches.keys().then(function(keys){
    return Promise.all(keys.filter(function(k){return /^rt-shell-/.test(k)&&k!==CACHE;}).map(function(k){return caches.delete(k);}));
  }).then(function(){return self.clients.claim();}));
});

function cachedIndex(){return caches.open(CACHE).then(function(c){return c.match(INDEX);});}
function handleNavigation(e){
  var req=e.request;
  var netP=fetch(req).then(function(res){
    if(!res)throw new Error('no response');
    if(res.status>=500)throw new Error('server '+res.status);
    if(res.ok&&res.type==='basic'){
      var a=res.clone(),b=res.clone();
      e.waitUntil(caches.open(CACHE).then(function(c){return c.put(INDEX,a);}).then(function(){return b.text();}).then(refreshFromIndex).catch(function(){}));
    }
    return res;
  });
  var timer=new Promise(function(resolve){setTimeout(function(){resolve(null);},NAV_TIMEOUT);});
  return Promise.race([netP.catch(function(){return null;}),timer]).then(function(res){
    if(res)return res;                                    // the network answered in time
    return cachedIndex().then(function(hit){
      if(hit){e.waitUntil(netP.catch(function(){}));return hit;}   // slow or offline: the copy on this device
      return netP;                                        // nothing saved yet: wait for the network
    });
  });
}
function revalidate(cache,req){
  return fetch(req).then(function(res){
    if(res&&res.status===200&&res.type==='basic')return cache.put(req,res.clone());
  }).catch(function(){});
}
function handleAsset(e){
  var req=e.request;
  return caches.open(CACHE).then(function(cache){
    return cache.match(req).then(function(hit){
      if(hit){
        if(!hasVersion(req.url))e.waitUntil(revalidate(cache,req));   // unversioned files: refresh quietly
        return hit;
      }
      return fetch(req).then(function(res){
        if(res&&res.status===200&&res.type==='basic')cache.put(req,res.clone());
        return res;
      });
    });
  });
}
self.addEventListener('fetch',function(e){
  var req=e.request;
  if(req.method!=='GET'||!sameOrigin(req.url))return;     // the database API, CDNs, anything else: untouched
  var url=new URL(req.url);
  if(/\/sw-notify\.js$/.test(url.pathname))return;        // the worker script itself
  if(req.mode==='navigate'){
    if(isAppPage(url))e.respondWith(handleNavigation(e));
    return;
  }
  if(isStatic(req.url))e.respondWith(handleAsset(e));
});

// Messages from the page: warm the cache with what the page already loaded, report status, reset.
self.addEventListener('message',function(e){
  var d=e.data||{};
  if(d.type==='warm'&&Array.isArray(d.urls)){
    var urls=d.urls.filter(isStatic).slice(0,300);
    e.waitUntil(caches.open(CACHE).then(function(c){
      return inBatches(urls,6,function(u){return putIfMissing(c,u);}).then(function(){
        return Promise.all(urls.filter(function(u){return /\.css(?:$|\?)/i.test(u);}).map(function(u){
          return c.match(u).then(function(r){return r?r.text().then(function(t){return inBatches(cssUrls(t,u),6,function(x){return putIfMissing(c,x);});}):null;});
        }));
      });
    }).catch(function(){}));
  }else if(d.type==='info'&&e.source){
    e.waitUntil(caches.open(CACHE).then(function(c){return c.keys();}).then(function(keys){
      e.source.postMessage({type:'rt-sw-info',build:BUILD,cache:CACHE,files:keys.length});
    }).catch(function(){}));
  }else if(d.type==='reset'){
    e.waitUntil(caches.keys().then(function(keys){
      return Promise.all(keys.filter(function(k){return /^rt-shell-/.test(k);}).map(function(k){return caches.delete(k);}));
    }).then(function(){
      if(e.source)e.source.postMessage({type:'rt-sw-reset'});
    }));
  }
});

self.addEventListener('notificationclick',function(e){
  e.notification.close();
  var data=e.notification.data||{};
  e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(function(list){
    for(var i=0;i<list.length;i++){
      var c=list[i];
      if('focus' in c){c.postMessage({type:'rt-open-booking',bookingId:data.bookingId||null});return c.focus();}
    }
    if(self.clients.openWindow)return self.clients.openWindow(self.registration.scope);
  }));
});
