/* Build css/tailwind.css (run from this folder after changing HTML/JS classes):
   npx tailwindcss@3.4.17 -c tailwind.config.cjs -i tailwind.input.css -o css/tailwind.css --minify */
module.exports={content:['./index.html','./backend/index.html','./js/*.js'],theme:{extend:{}},plugins:[]};
