REV TORQ POS V2 - WEB HARDWARE TEST (U4-B + Clabel CT221D)
Build: 2026-10-02 PDF handoff

U4-B BARCODE SCANNER
1. Pair scanner as Bluetooth HID / keyboard.
2. POS > Inventory > TEST HARDWARE.
3. Tap SCAN DI SINI and scan a barcode.
4. Expected: status LULUS, barcode value, ENTER/TAB suffix and scan timing.
5. In POS screen, when no text field is focused, a completed HID scan is sent to POS item lookup/cart.

CLABEL CT221D - IPHONE/WEB FLOW
CT221D is not an AirPrint printer. Do not use iOS system Print for this printer.
The Clabel Trade iPhone app exposes More > PDF Printing and does not provide a practical image-import path in the tested UI.

Recommended flow:
1. Inventory > PRINT STIKER.
2. Pick product, size (default 50 x 30 mm), quantity and options.
3. Tap SHARE / SAVE PDF or PDF UNTUK CLABEL.
4. On iPhone choose Save to Files.
5. Open Clabel Trade > More > PDF Printing.
6. Pick the saved REV-TORQ-...pdf file.
7. Confirm label size and print to the connected CT221D.

PDF details:
- Exact page dimensions match the selected sticker size.
- Each requested copy is one PDF page.
- Barcode, item name, price and SKU/rack are rendered into the PDF.
- No Supabase migration is required for this hardware flow.
