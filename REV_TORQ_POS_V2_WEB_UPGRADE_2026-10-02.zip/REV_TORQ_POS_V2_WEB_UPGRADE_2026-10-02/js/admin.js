// ================= STAFF & SETTINGS =================
        let staffListMode = 'active';

        function setStaffListMode(mode) {
            staffListMode = mode === 'all' ? 'all' : 'active';
            const activeBtn = document.getElementById('staffFilterActive');
            const allBtn = document.getElementById('staffFilterAll');
            if (activeBtn && allBtn) {
                activeBtn.className = staffListMode === 'active'
                    ? 'px-3 py-2 rounded-lg bg-indigo-600 text-white text-xs font-bold'
                    : 'px-3 py-2 rounded-lg bg-slate-100 text-slate-600 text-xs font-bold';
                allBtn.className = staffListMode === 'all'
                    ? 'px-3 py-2 rounded-lg bg-indigo-600 text-white text-xs font-bold'
                    : 'px-3 py-2 rounded-lg bg-slate-100 text-slate-600 text-xs font-bold';
            }
            loadStaff();
        }

        async function loadStaff() {
            const tbody = document.querySelector('#tblStaff tbody');
            if (!tbody) return;
            tbody.innerHTML = '<tr><td colspan="5" class="text-center p-4">Loading...</td></tr>';
            try {
                const snap = await db.collection("staff").orderBy("staffId").limit(200).get();
                let rows = '';
                let visibleCount = 0;
                snap.forEach(doc => {
                    const raw = doc.data() || {};
                    const entries = Object.entries(raw);
                    const normKey = k => String(k).replace(/^\uFEFF/, '').trim().toLowerCase();
                    const getField = wanted => {
                        if (raw[wanted] !== undefined) return raw[wanted];
                        const hit = entries.find(([k]) => normKey(k) === normKey(wanted));
                        return hit ? hit[1] : undefined;
                    };
                    const activeRaw = getField('active');
                    const active = activeRaw === true || activeRaw === 'true';
                    const directoryVisibleRaw = getField('directoryVisible');
                    // Legacy staff without this field remain visible. Once an admin
                    // uses BUANG, the profile stays in Firestore for history/audit
                    // but disappears from the staff-management list.
                    const directoryVisible = directoryVisibleRaw !== false && directoryVisibleRaw !== 'false';
                    if (!directoryVisible) return;
                    if (staffListMode === 'active' && !active) return;

                    const staffId = String(getField('staffId') || doc.id || '').trim().toUpperCase();
                    const name = String(getField('name') || staffId).trim();
                    const role = String(getField('role') || '').trim().toUpperCase();
                    const uid = String(getField('uid') || doc.id).trim();
                    const statusLabel = active ? 'AKTIF' : 'BERHENTI';
                    visibleCount++;
                    if (typeof dbgLog === 'function') dbgLog(`STAFF LIST: ${staffId} | active=${String(activeRaw)} (${typeof activeRaw}) | uid=${uid}`);
                    rows += `
                        <tr class="hover:bg-slate-50">
                            <td class="p-4 font-mono font-bold text-indigo-600">${staffId}</td>
                            <td class="p-4 font-bold text-slate-800">${name}</td>
                            <td class="p-4 text-xs uppercase text-slate-600">${role}</td>
                            <td class="p-4 text-xs font-bold ${active ? 'text-green-600' : 'text-red-500'}">${statusLabel}</td>
                            <td class="p-4 text-right">
                                <button onclick="editStaff('${uid}')" class="text-blue-600 hover:text-blue-800 text-xs font-bold mr-3"><i data-feather="edit" class="w-4 h-4 inline"></i> KEMASKINI</button>
                                ${active
                                    ? `<button onclick="deactivateStaff('${uid}','${staffId.replace(/'/g, "\\'")}')" class="text-red-600 hover:text-red-800 text-xs font-bold mr-3"><i data-feather="user-x" class="w-4 h-4 inline"></i> BERHENTI</button>`
                                    : `<button onclick="reactivateStaff('${uid}','${staffId.replace(/'/g, "\\'")}')" class="text-green-600 hover:text-green-800 text-xs font-bold mr-3"><i data-feather="user-check" class="w-4 h-4 inline"></i> AKTIFKAN</button>`
                                }
                                ${!active
                                    ? `<button onclick="removeStaffFromList('${uid}','${staffId.replace(/'/g, "\\'")}')" class="text-slate-600 hover:text-slate-900 text-xs font-bold mr-3"><i data-feather="eye-off" class="w-4 h-4 inline"></i> BUANG</button>`
                                    : ''
                                }
                                <button onclick="resetPIN('${uid}')" class="text-amber-600 hover:text-amber-800 text-xs font-bold"><i data-feather="key" class="w-4 h-4 inline"></i> RESET PIN</button>
                            </td>
                        </tr>
                    `;
                });
                if (!visibleCount) {
                    rows = `<tr><td colspan="5" class="text-center p-8 text-slate-400 text-sm">${staffListMode === 'active' ? 'Tiada staf aktif.' : 'Tiada rekod staf.'}</td></tr>`;
                }
                tbody.innerHTML = rows;
                feather.replace();
            } catch(e) {
                tbody.innerHTML = `<tr><td colspan="5" class="text-center p-4 text-red-500">Ralat: ${e.message}</td></tr>`;
            }
        }

        async function deactivateStaff(uid, staffId) {
            if (!confirm(`Tamatkan akses ${staffId}? Staf akan hilang daripada senarai aktif tetapi rekod lama kekal.`)) return;
            try {
                await db.collection('staff').doc(uid).update({
                    active: false,
                    employmentStatus: 'berhenti',
                    deactivatedAt: new Date().toISOString(),
                    deactivatedBy: (window.currentUser?.id || window.currentProfile?.uid),
                    updatedAt: new Date().toISOString(),
                    updatedBy: (window.currentUser?.id || window.currentProfile?.uid)
                });
                showToast(`${staffId} telah dinyahaktifkan.`, 'success');
                try { await logAudit('DEACTIVATE_STAFF', `Deactivated staff: ${staffId}`); } catch (_) {}
                await loadStaff();
            } catch(e) {
                showToast(e.message || 'Gagal nyahaktifkan staf.', 'error');
            }
        }

        async function removeStaffFromList(uid, staffId) {
            if (!confirm(`Buang ${staffId} daripada senarai staf?\n\nRekod staf, transaksi POS, job card dan sejarah TIDAK akan dipadam. Akaun kekal disekat kerana status masih tidak aktif.`)) return;
            try {
                const currentUser = window.currentUser;
                if (!currentUser) throw new Error('Sesi Admin telah tamat. Sila login semula.');
                await db.collection('staff').doc(uid).update({
                    active: false,
                    employmentStatus: 'berhenti',
                    directoryVisible: false,
                    archivedFromStaffList: true,
                    archivedAt: new Date().toISOString(),
                    archivedBy: currentUser.uid,
                    updatedAt: new Date().toISOString(),
                    updatedBy: currentUser.uid
                });
                showToast(`${staffId} dibuang daripada senarai. Rekod masih disimpan.`, 'success');
                try { await logAudit('ARCHIVE_STAFF_FROM_LIST', `Removed staff from list: ${staffId}; records retained.`); } catch (_) {}
                await loadStaff();
            } catch (e) {
                showToast(e.message || 'Gagal buang staf daripada senarai.', 'error');
            }
        }

        async function reactivateStaff(uid, staffId) {
            if (!confirm(`Aktifkan semula ${staffId}?`)) return;
            try {
                await db.collection('staff').doc(uid).update({
                    active: true,
                    employmentStatus: 'aktif',
                    reactivatedAt: new Date().toISOString(),
                    reactivatedBy: (window.currentUser?.id || window.currentProfile?.uid),
                    updatedAt: new Date().toISOString(),
                    updatedBy: (window.currentUser?.id || window.currentProfile?.uid)
                });
                showToast(`${staffId} telah diaktifkan semula.`, 'success');
                try { await logAudit('REACTIVATE_STAFF', `Reactivated staff: ${staffId}`); } catch (_) {}
                await loadStaff();
            } catch(e) {
                showToast(e.message || 'Gagal aktifkan semula staf.', 'error');
            }
        }

        function openNewStaff() {
            document.getElementById('staffIsEdit').value = "false";
            document.getElementById('staffUidField').value = "";
            document.getElementById('staffIdField').value = "";
            document.getElementById('staffIdField').disabled = false;
            document.getElementById('staffName').value = "";
            document.getElementById('staffPin').value = "";
            document.getElementById('staffModalTitle').innerText = "Daftar Staf Baru";
            
            // Show PIN field for new staff
            document.getElementById('staffPinWrap').style.display = 'block';
            document.getElementById('staffPin').required = true;

            openModal('staffModal');
        }

        async function editStaff(uid) {
            document.getElementById('staffIsEdit').value = "true";
            document.getElementById('staffUidField').value = uid;
            document.getElementById('staffIdField').disabled = true; // ID cannot be changed
            document.getElementById('staffPinWrap').style.display = 'none'; // Pin is handled via Reset PIN
            document.getElementById('staffPin').required = false;
            document.getElementById('staffModalTitle').innerText = "Kemaskini Staf";

            try {
                const doc = await db.collection("staff").doc(uid).get();
                if(doc.exists) {
                    const d = doc.data();
                    document.getElementById('staffIdField').value = d.staffId;
                    document.getElementById('staffName').value = d.name;
                    document.getElementById('staffRole').value = d.role;
                    document.getElementById('staffStatus').value = d.active ? 'true' : 'false';
                    openModal('staffModal');
                }
            } catch(e) { showToast(e.message, 'error'); }
        }

        async function saveStaff(e) {
            e.preventDefault();
            const btnId = 'btnSaveStaff';
            setOriginalText(btnId);
            toggleLoading(btnId, true);

            const isEdit = document.getElementById('staffIsEdit').value === "true";
            const staffId = document.getElementById('staffIdField').value.trim().toUpperCase();
            const name = document.getElementById('staffName').value.trim();
            const role = String(document.getElementById('staffRole').value || 'pos').trim().toLowerCase();
            const active = document.getElementById('staffStatus').value === "true";

            try {
                if (!staffId || !/^[A-Z0-9_-]{2,30}$/.test(staffId)) {
                    throw new Error("ID staf mesti 2-30 aksara: A-Z, 0-9, _ atau -.");
                }
                if (!name) throw new Error("Nama penuh wajib diisi.");

                // IMPORTANT:
                // Firebase primary Auth session belongs to the currently logged-in
                // admin. Staff creation uses a SECONDARY Auth app so creating a new
                // user never replaces AQIL's admin session.
                const primaryUser = window.currentUser;
                if (!primaryUser) throw new Error("Sesi Admin telah tamat. Sila login semula.");

                // Verify the current caller is actually an active admin before doing
                // any Auth creation. Prefer the already-resolved login profile because
                // it has already passed the application's staff resolver. Only fall
                // back to a direct Firestore read when that profile is unavailable.
                const ADMIN_ROLES = ["owner", "admin", "administrator", "super_admin", "superadmin"];
                let adminData = (window.currentProfile && typeof window.currentProfile === 'object')
                    ? { ...window.currentProfile }
                    : null;

                const normaliseAdmin = (data) => {
                    const raw = data || {};
                    const entries = Object.entries(raw);
                    const normKey = k => String(k).replace(/^\uFEFF/, '').trim().toLowerCase();
                    const getField = wanted => {
                        if (raw[wanted] !== undefined) return raw[wanted];
                        const hit = entries.find(([k]) => normKey(k) === normKey(wanted));
                        return hit ? hit[1] : undefined;
                    };
                    const roleRaw = getField('role');
                    const activeRaw = getField('active');
                    return {
                        role: String(roleRaw ?? '').trim().toLowerCase(),
                        active: activeRaw === true || activeRaw === 'true',
                        activeRaw,
                        staffId: String(getField('staffId') ?? '').trim().toUpperCase(),
                        uid: String(getField('uid') ?? '').trim(),
                        raw
                    };
                };

                let admin = normaliseAdmin(adminData);

                // If the in-memory profile is missing/incomplete, read the canonical
                // staff/{AUTH UID} document and normalise field names (including
                // accidental whitespace/BOM/case differences).
                if (!admin.active || !ADMIN_ROLES.includes(admin.role)) {
                    // Resolve the canonical admin profile from Supabase first.
                    // Do NOT call the legacy bridge with an undefined UID: in this
                    // app primaryUser may expose `id` instead of Firebase-style `uid`.
                    const supaForAdmin = window.supabaseClient;
                    let adminAuthUid = String(primaryUser?.uid || primaryUser?.id || '').trim();
                    if (supaForAdmin) {
                        try {
                            const au = await supaForAdmin.auth.getUser();
                            if (au?.data?.user?.id) adminAuthUid = String(au.data.user.id).trim();
                        } catch (_) {}
                    }
                    if (!adminAuthUid) {
                        throw new Error("UID admin tidak dijumpai dalam sesi. Sila logout/login semula.");
                    }

                    if (supaForAdmin) {
                        const ar = await supaForAdmin.from('staff')
                            .select('id,company_id,location_id,staff_code,name,email,role,active,auth_user_id')
                            .eq('auth_user_id', adminAuthUid)
                            .maybeSingle();
                        if (!ar.error && ar.data) {
                            admin = normaliseAdmin({
                                ...ar.data,
                                staffId: ar.data.staff_code,
                                uid: ar.data.auth_user_id
                            });
                        }
                    }

                    // Legacy fallback is allowed only with a real UID.
                    if (!admin.active || !ADMIN_ROLES.includes(admin.role)) {
                        const adminSnap = await db.collection("staff").doc(adminAuthUid).get();
                        if (!adminSnap.exists) {
                            throw new Error(`Profil admin tidak wujud untuk UID ${adminAuthUid}.`);
                        }
                        admin = normaliseAdmin(adminSnap.data());
                    }
                }

                if (!admin.active || !ADMIN_ROLES.includes(admin.role)) {
                    throw new Error(
                        `Akaun semasa bukan admin aktif. UID=${primaryUser.uid}; ` +
                        `staff=${admin.staffId || '(kosong)'}; role=${admin.role || '(kosong)'}; ` +
                        `active=${String(admin.activeRaw)}. Jika Console menunjukkan active=true, ` +
                        `pastikan website menggunakan build V34.3 dan refresh cache.`
                    );
                }

                if (isEdit) {
                    const uid = document.getElementById('staffUidField').value.trim();
                    if (!uid) throw new Error("UID staff tidak sah.");

                    const editUpdate = {
                        staffId,
                        name,
                        role,
                        active,
                        employmentStatus: active ? 'aktif' : 'berhenti',
                        updatedAt: new Date().toISOString(),
                        updatedBy: primaryUser.uid
                    };
                    if (!active) {
                        editUpdate.deactivatedAt = new Date().toISOString();
                        editUpdate.deactivatedBy = primaryUser.uid;
                    }
                    await db.collection("staff").doc(uid).update(editUpdate);

                    showToast(`Staff ${staffId} berjaya dikemaskini.`, 'success');
                    await logAudit('UPDATE_STAFF', `Updated staff: ${staffId}`);
                } else {
                    const pin = document.getElementById('staffPin').value.trim();
                    if (!/^\d{6}$/.test(pin)) throw new Error("PIN mesti tepat 6 digit.");

                    // Canonical staff creation is server-side. The Edge Function creates
                    // the Auth identity + public.staff row as one guarded admin operation
                    // and removes the Auth identity again if the staff insert fails.
                    const supa = window.supabaseClient;
                    if (!supa) throw new Error('Supabase belum tersedia.');
                    const { data, error } = await supa.functions.invoke('rev-torq-staff-admin', {
                        body: {
                            action: 'create_staff',
                            staff_id: staffId,
                            name,
                            role: role.toLowerCase(),
                            active,
                            pin
                        }
                    });
                    if (error) throw error;
                    if (!data?.ok) throw new Error(data?.error || 'Staff gagal didaftarkan.');

                    showToast(`Staff ${staffId} berjaya didaftarkan.`, 'success');
                    await loadStaff();
                }

                closeModal('staffModal');
                await loadStaff();
            } catch (error) {
                console.error("saveStaff:", error);
                showToast(error.message || "Operasi staff gagal.", 'error');
                if (typeof showErrorPanel === 'function') showErrorPanel(error.message || "Operasi staff gagal.");
            } finally {
                toggleLoading(btnId, false);
            }
        }

        async function resetPIN(uid) {
            const newPin = prompt("Sila masukkan 6 digit PIN baru:");
            if (!newPin) return;
            if (!/^\d{6}$/.test(newPin)) {
                showToast("Sila masukkan tepat 6 digit nombor.", 'error');
                return;
            }

            try {
                const snap = await db.collection("staff").doc(uid).get();
                if (!snap.exists) throw new Error("Profil staff tidak wujud.");
                const row = snap.data() || {};
                const targetAuthUid = String(row.uid || row.auth_user_id || uid || '').trim();
                const staffCode = String(row.staffId || row.staff_code || 'staff').trim().toUpperCase();
                if (!targetAuthUid) throw new Error("Auth UID staff tidak dijumpai.");

                const ok = confirm(`Tetapkan PIN baru untuk ${staffCode}?`);
                if (!ok) return;

                const supa = window.supabaseClient;
                if (!supa) throw new Error('Supabase belum tersedia.');
                const { data, error } = await supa.functions.invoke('rev-torq-staff-admin', {
                    body: {
                        action: 'reset_pin',
                        target_auth_user_id: targetAuthUid,
                        new_pin: newPin
                    }
                });
                if (error) throw error;
                if (!data?.ok) throw new Error(data?.error || 'Reset PIN gagal.');

                showToast(`PIN ${data.staff_code || staffCode} berjaya ditukar.`, 'success');
            } catch(e) {
                showToast(e.message || "Reset PIN gagal.", 'error');
            }
        }


        // Explicit globals for HTML onclick handlers.
        window.openNewStaff = openNewStaff;
        window.editStaff = editStaff;
        window.resetPIN = resetPIN;
        window.saveStaff = saveStaff;

        function formatAuditTimestamp(value, dateOnly = false) {
            if (value == null || value === '') return '-';
            try {
                const raw = typeof value?.toDate === 'function' ? value.toDate() : value;
                const date = typeof raw === 'number'
                    ? new Date(raw < 1e11 ? raw * 1000 : raw)
                    : typeof raw?.seconds === 'number'
                        ? new Date(raw.seconds * 1000)
                        : new Date(raw);
                return Number.isNaN(date.getTime()) ? '-' : (dateOnly ? date.toLocaleDateString('ms-MY') : date.toLocaleString('ms-MY'));
            } catch (_) { return '-'; }
        }
        window.rtSafeDate = formatAuditTimestamp;

        function auditText(value) {
            if (value == null || typeof value === 'object') return '';
            const text = String(value).trim();
            return text.toLowerCase() === 'undefined' ? '' : text;
        }
        function auditEscape(value) {
            return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
        }
        function auditDetails(d, staffById) {
            let m = d.metadata;
            if (typeof m === 'string') { try { m = JSON.parse(m); } catch (_) { m = {}; } }
            if (!m || typeof m !== 'object' || Array.isArray(m)) m = {};
            const parts = [];
            const add = (label, value) => { const text = auditText(value); if (text) parts.push(label + ': ' + text); };
            const action = String(d.action || '').toUpperCase();
            if (action === 'POS_CHECKOUT') {
                add('Invois', m.invoice_no); add('Bayaran', m.payment_method); add('Jumlah', m.total);
            } else if (action === 'VOID_INVOICE' || action.includes('VOID')) {
                add('Invois', m.invoice_no); add('Sebab', m.reason || m.void_reason);
                add('Jumlah', m.total); add('Stok dipulangkan', m.stock_restored);
            } else if (action === 'CREATE_INVENTORY') {
                add('Item', m.sku || m.product_name || m.name); add('Stok awal', m.opening_stock);
            } else if (action.includes('ATTENDANCE') || action.includes('CLOCK_')) {
                const target = auditText(m.target_staff_name || m.staff_name) || staffById.get(auditText(m.target_staff_id || m.staff_id)) || auditText(m.target_staff_code || m.staff_code);
                add('Staf', target); add('Tindakan', m.clock_action || m.action || action);
            } else {
                add('Invois', m.invoice_no); add('Item', m.sku); add('Job Card', m.job_no);
                add('GRN', m.grn_no); add('Sebab', m.reason);
            }
            return parts.join(' · ') || auditText(d.details) || '-';
        }

        async function loadAudit() {
            const tbody = document.querySelector('#tblAudit tbody');
            const request = loadAudit.request = (loadAudit.request || 0) + 1;
            if (!loadAudit.loaded) tbody.innerHTML = '<tr><td colspan="4" class="text-center p-4">Loading...</td></tr>';
            try {
                const snap = await db.collection("audit_logs").orderBy("timestamp", "desc").limit(100).get();
                const docs = snap.docs || [];
                const ids = [...new Set(docs.map(doc => doc.data().staffId).filter(Boolean))];
                const staffById = new Map();
                try {
                    for (let i = 0; i < ids.length; i += 100) {
                        const staffSnap = await db.collection('staff').where('id', 'in', ids.slice(i, i + 100)).get();
                        staffSnap.forEach(doc => {
                            const s = doc.data();
                            staffById.set(doc.id, auditText(s.name) || auditText(s.staffCode || s.staffId) || doc.id);
                        });
                    }
                } catch (e) { console.warn('Audit staff lookup failed', e); }
                let rows = '';
                docs.forEach(doc => {
                    const d = doc.data();
                    rows += `
                        <tr class="hover:bg-gray-800/50">
                            <td class="p-4 text-xs font-mono text-gray-400">${formatAuditTimestamp(d.timestamp)}</td>
                            <td class="p-4 font-mono font-bold text-amber-500">${auditEscape(staffById.get(d.staffId) || auditText(d.staffId) || '-')}</td>
                            <td class="p-4 text-xs font-bold uppercase">${auditEscape(auditText(d.action) || '-')}</td>
                            <td class="p-4 text-gray-300 text-sm">${auditEscape(auditDetails(d, staffById))}</td>
                        </tr>
                    `;
                });
                if (request !== loadAudit.request) return;
                tbody.innerHTML = rows || '<tr><td colspan="4" class="text-center p-4 text-gray-500">Tiada log</td></tr>';
                loadAudit.loaded = true;
            } catch(e) { if (request === loadAudit.request && !loadAudit.loaded) tbody.innerHTML = `<tr><td colspan="4" class="text-center p-4 text-red-500">Ralat: ${e.message}</td></tr>`; else console.error('Audit refresh failed',e); }
        }

        async function loadSettings() {
            window.rtPaymentQr?.loadSettings();
            try {
                const doc = await db.collection("settings").doc("workshop").get();
                if(doc.exists) {
                    const d = doc.data();
                    document.getElementById('setWName').value = d.workshopName || '';
                    document.getElementById('setWReg').value = d.regNo || '';
                    document.getElementById('setWPhone').value = d.phone || '';
                    document.getElementById('setWAddress').value = d.address || '';
                    window.rtWorkshopProfile = {...d};
                }
            } catch(e) { console.error(e); }
        }

        async function saveSettings(e) {
            e.preventDefault();
            const btnId = 'btnSaveSettings';
            setOriginalText(btnId);
            toggleLoading(btnId, true);
            try {
                await db.collection("settings").doc("workshop").set({
                    workshopName: document.getElementById('setWName').value,
                    regNo: document.getElementById('setWReg').value,
                    phone: document.getElementById('setWPhone').value,
                    address: document.getElementById('setWAddress').value,
                    updatedAt: new Date().toISOString(),
                    updatedBy: currentProfile.staffId
                });
                window.rtWorkshopProfile = {
                    workshopName: document.getElementById('setWName').value,
                    regNo: document.getElementById('setWReg').value,
                    phone: document.getElementById('setWPhone').value,
                    address: document.getElementById('setWAddress').value
                };
                showToast("Tetapan disimpan.");
                await logAudit('UPDATE_SETTINGS', `Updated workshop settings`);
            } catch(e) { showToast(e.message, 'error'); }
            finally { toggleLoading(btnId, false); }
        }

        
