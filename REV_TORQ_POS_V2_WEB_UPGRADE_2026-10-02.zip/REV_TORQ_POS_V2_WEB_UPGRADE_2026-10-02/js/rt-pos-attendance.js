/* REV TORQ v0.9.4 — shared attendance controls
   Normal header + POS topbar use the same narrow SECURITY DEFINER RPCs.
   POS mode hides the normal header, so it has its own visible CLOCK IN card.
*/
(function(){
'use strict';
const $=id=>document.getElementById(id);
const STORE_KEY='rtAttendanceStaffId';
const instances=[
  {wrap:'rtAttendanceWrap',btn:'rtAttendanceMenuBtn',pop:'rtAttendancePopover',sel:'rtAttendanceStaffSelect',status:'rtAttendanceStatus',action:'rtAttendanceAction'},
  {wrap:'rtPosAttendanceWrap',btn:'rtPosAttendanceMenuBtn',pop:'rtPosAttendancePopover',sel:'rtPosAttendanceStaffSelect',status:'rtPosAttendanceStatus',action:'rtPosAttendanceAction',label:'rtPosAttendanceButtonLabel'}
];
function sb(){return window.supabaseClient||window.supabase||window.sb||null;}
function toast(m,type){if(typeof window.showToast==='function')window.showToast(m,type||'success');else alert(m);}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function cid(){
  const p=window.currentProfile||{};
  const cached=p.company_id||p.companyId||null;
  if(cached)return cached;
  try{if(typeof window.companyId==='function'){const v=await window.companyId();return(typeof v==='string'&&v)?v:null;}}catch(_){ }
  return null;
}
async function getStaff(){
  const db=sb();if(!db)throw Error('Supabase belum tersedia.');
  const company=await cid();
  let q=db.from('staff').select('id,staff_code,name,company_id,active,removed_from_active_list').eq('active',true).order('staff_code');
  if(company)q=q.eq('company_id',company);
  const r=await q;if(r.error)throw r.error;
  return(r.data||[]).filter(x=>x.active!==false&&x.removed_from_active_list!==true);
}
async function openShift(id){
  const db=sb();if(!db)throw Error('Supabase belum tersedia.');
  const r=await db.rpc('rt_pos_attendance_status',{p_staff_id:id});if(r.error)throw r.error;
  const row=Array.isArray(r.data)?r.data[0]:r.data;if(!row)return null;
  return row.is_clocked_in?{id:row.attendance_id,clock_in:row.clock_in,clock_out:row.clock_out}:null;
}
function fmt(v){return v?new Intl.DateTimeFormat('ms-MY',{dateStyle:'medium',timeStyle:'short'}).format(new Date(v)):'—';}
function profileStaffId(){const p=window.currentProfile||{};return p.staff_id||p.staffId||p.id||null;}
function savedStaffId(){try{return localStorage.getItem(STORE_KEY)||'';}catch(_){return'';}}
function saveStaffId(id){try{if(id)localStorage.setItem(STORE_KEY,id);else localStorage.removeItem(STORE_KEY);}catch(_){ }}
function setTopState(cfg,row,hasSelection){
  const btn=$(cfg.btn),label=cfg.label?$(cfg.label):null;if(!btn)return;
  btn.classList.toggle('is-clocked-in',!!row);
  btn.setAttribute('aria-label',row?'Clock Out':'Clock In');
  if(label)label.textContent=row?'CLOCK OUT':(hasSelection?'CLOCK IN':'CLOCK IN');
}
async function refreshStatus(cfg){
  const sel=$(cfg.sel),st=$(cfg.status),act=$(cfg.action);if(!sel||!st||!act)return;
  const id=sel.value;
  if(!id){st.textContent='Pilih nama staff.';act.textContent='CLOCK IN';act.disabled=true;setTopState(cfg,null,false);return;}
  st.textContent='Semak status...';act.disabled=true;
  try{
    const row=await openShift(id);sel.dataset.openId=row?.id||'';
    if(row){st.innerHTML='🟢 <b>Sedang Clock In</b><br><span class="text-slate-500">Masuk: '+esc(fmt(row.clock_in))+'</span>';act.textContent='CLOCK OUT';}
    else{st.textContent='🔴 Belum Clock In';act.textContent='CLOCK IN';}
    setTopState(cfg,row,true);act.disabled=false;
  }catch(e){st.textContent=e.message||'Gagal semak attendance';act.disabled=true;setTopState(cfg,null,!!id);}
}
async function loadStaff(cfg){
  const sel=$(cfg.sel);if(!sel)return;
  sel.innerHTML='<option value="">Memuatkan staff...</option>';sel.disabled=true;
  try{
    const list=await getStaff();
    sel.innerHTML='<option value="">Pilih nama staff</option>'+list.map(s=>`<option value="${esc(s.id)}">${esc(s.staff_code||'')} — ${esc(s.name||'')}</option>`).join('');
    sel.disabled=false;
    const preferred=[savedStaffId(),profileStaffId()].find(id=>id&&list.some(s=>String(s.id)===String(id)));
    if(preferred){sel.value=preferred;await refreshStatus(cfg);}else setTopState(cfg,null,false);
  }catch(e){sel.innerHTML='<option value="">Gagal load staff</option>';sel.disabled=true;toast(e.message||'Gagal load staff','error');}
}
async function action(cfg){
  const sel=$(cfg.sel),act=$(cfg.action);const id=sel?.value;if(!id)return;
  act.disabled=true;saveStaffId(id);
  try{
    const db=sb();if(!db)throw Error('Supabase belum tersedia.');
    const r=await db.rpc('rt_pos_attendance_toggle',{p_staff_id:id});if(r.error)throw r.error;
    const row=Array.isArray(r.data)?r.data[0]:r.data;const a=String(row?.action||'').toUpperCase();
    toast(a==='CLOCK_OUT'?'Clock Out berjaya.':'Clock In berjaya.');
    await refreshStatus(cfg);
    for(const other of instances){if(other===cfg)continue;const os=$(other.sel);if(os&&os.value===id)await refreshStatus(other);}
  }catch(e){toast(e.message||'Attendance gagal.','error');}
  finally{if(act)act.disabled=false;}
}
function closeOthers(cfg){for(const other of instances){if(other!==cfg)$(other.pop)?.classList.add('hidden');}}
function mountOne(cfg){
  const btn=$(cfg.btn),pop=$(cfg.pop),wrap=$(cfg.wrap);if(!btn||!pop||!wrap)return;
  btn.addEventListener('click',async e=>{e.stopPropagation();const opening=pop.classList.contains('hidden');closeOthers(cfg);pop.classList.toggle('hidden');btn.setAttribute('aria-expanded',opening?'true':'false');if(opening)await loadStaff(cfg);});
  $(cfg.sel)?.addEventListener('change',async e=>{saveStaffId(e.target.value);await refreshStatus(cfg);});
  $(cfg.action)?.addEventListener('click',()=>action(cfg));
}
function mount(){
  instances.forEach(mountOne);
  document.addEventListener('click',e=>{for(const cfg of instances){const wrap=$(cfg.wrap),pop=$(cfg.pop),btn=$(cfg.btn);if(wrap&&pop&&!e.target.closest('#'+cfg.wrap)){pop.classList.add('hidden');btn?.setAttribute('aria-expanded','false');}}});
}
document.addEventListener('DOMContentLoaded',mount);
window.rtAttendanceToggle=()=>{const inPos=$('appContainer')?.classList.contains('rt-pos-mode');$(inPos?'rtPosAttendanceMenuBtn':'rtAttendanceMenuBtn')?.click();};
})();
