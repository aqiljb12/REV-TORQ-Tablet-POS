package com.revtorq.pos;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.Size;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.ComponentActivity;
import androidx.annotation.NonNull;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.MeteringPoint;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class NativeBarcodeScannerActivity extends ComponentActivity {
    public static final String EXTRA_MODE = "mode";
    public static final String MODE_POS_MULTI = "POS_MULTI";
    public static final String MODE_INVENTORY_LOOKUP = "INVENTORY_LOOKUP";
    public static final String MODE_INVENTORY_BARCODE_INPUT = "INVENTORY_BARCODE_INPUT";
    public static final String MODE_MULTI = "MULTI_SCAN";
    public static final String MODE_SINGLE = "SINGLE_SCAN";

    private static final int CAMERA_PERMISSION_REQUEST = 6201;
    private static final long SAME_CODE_COOLDOWN_MS = 850L;
    private static final long REARM_ABSENCE_MS = 550L;
    private static final long LOOKUP_TIMEOUT_MS = 3000L;
    private static WeakReference<NativeBarcodeScannerActivity> activeScanner = new WeakReference<>(null);

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean frameInFlight = new AtomicBoolean(false);
    private final Map<String, Long> lastSeenAt = new HashMap<>();
    private final Map<String, Long> lastAcceptedAt = new HashMap<>();
    private final Map<String, Long> pendingLookupAt = new HashMap<>();

    private PreviewView previewView;
    private TextView statusText;
    private TextView zoomText;
    private Button torchButton;
    private Button retryPermissionButton;
    private Button appSettingsButton;
    private Button searchButton;
    private Button addProductButton;
    private EditText manualInput;

    private ExecutorService analyzerExecutor;
    private ProcessCameraProvider cameraProvider;
    private Camera camera;
    private BarcodeScanner barcodeScanner;
    private ScaleGestureDetector scaleGestureDetector;
    private ToneGenerator toneGenerator;
    private Vibrator vibrator;
    private boolean torchOn = false;
    private boolean cameraStarted = false;
    private String mode = MODE_POS_MULTI;
    private String lastUnknownBarcode = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        String requestedMode = getIntent().getStringExtra(EXTRA_MODE);
        if (MODE_SINGLE.equalsIgnoreCase(requestedMode)) mode = MODE_SINGLE;
        else if (MODE_INVENTORY_LOOKUP.equalsIgnoreCase(requestedMode)) mode = MODE_INVENTORY_LOOKUP;
        else if (MODE_INVENTORY_BARCODE_INPUT.equalsIgnoreCase(requestedMode)) mode = MODE_INVENTORY_BARCODE_INPUT;

        analyzerExecutor = Executors.newSingleThreadExecutor();
        toneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 80);
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        barcodeScanner = BarcodeScanning.getClient(
                new com.google.mlkit.vision.barcode.BarcodeScannerOptions.Builder()
                        .setBarcodeFormats(
                                Barcode.FORMAT_EAN_13,
                                Barcode.FORMAT_EAN_8,
                                Barcode.FORMAT_UPC_A,
                                Barcode.FORMAT_UPC_E,
                                Barcode.FORMAT_CODE_128)
                        .build());

        buildUi();
        activeScanner = new WeakReference<>(this);
        ensureCameraPermissionAndStart();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        previewView = new PreviewView(this);
        previewView.setImplementationMode(PreviewView.ImplementationMode.PERFORMANCE);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(previewView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        root.addView(new ScannerOverlayView(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        Button close = button("✕");
        FrameLayout.LayoutParams closeLp = new FrameLayout.LayoutParams(dp(48), dp(48));
        closeLp.gravity = Gravity.TOP | Gravity.START;
        closeLp.setMargins(dp(18), dp(18), 0, 0);
        root.addView(close, closeLp);
        close.setOnClickListener(v -> finish());

        LinearLayout topRight = new LinearLayout(this);
        topRight.setOrientation(LinearLayout.HORIZONTAL);
        topRight.setGravity(Gravity.CENTER_VERTICAL);
        topRight.setPadding(dp(8), dp(6), dp(8), dp(6));
        topRight.setBackgroundColor(0xAA111827);
        zoomText = text("1.0×", 13, Color.WHITE);
        torchButton = button("Torch");
        topRight.addView(zoomText);
        topRight.addView(torchButton, new LinearLayout.LayoutParams(dp(92), dp(44)));
        FrameLayout.LayoutParams trLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        trLp.gravity = Gravity.TOP | Gravity.END;
        trLp.setMargins(0, dp(18), dp(18), 0);
        root.addView(topRight, trLp);
        torchButton.setOnClickListener(v -> toggleTorch());

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setGravity(Gravity.CENTER_HORIZONTAL);
        bottom.setPadding(dp(18), dp(14), dp(18), dp(16));
        bottom.setBackgroundColor(0xE6111827);

        TextView title = text("Halakan kamera pada barcode", 17, Color.WHITE);
        title.setGravity(Gravity.CENTER);
        bottom.addView(title, matchWrap());

        statusText = text("Scanner sedang disediakan…", 13, 0xFFE5E7EB);
        statusText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusLp = matchWrap();
        statusLp.topMargin = dp(5);
        bottom.addView(statusText, statusLp);

        LinearLayout manualRow = new LinearLayout(this);
        manualRow.setOrientation(LinearLayout.HORIZONTAL);
        manualRow.setGravity(Gravity.CENTER_VERTICAL);
        manualInput = new EditText(this);
        manualInput.setSingleLine(true);
        manualInput.setTextColor(Color.WHITE);
        manualInput.setHintTextColor(0xFF9CA3AF);
        manualInput.setHint("Masukkan barcode manual");
        manualInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        manualInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
        manualInput.setBackgroundColor(0xFF1F2937);
        manualInput.setPadding(dp(12), 0, dp(12), 0);
        Button useManual = button("Guna");
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        LinearLayout.LayoutParams useLp = new LinearLayout.LayoutParams(dp(86), dp(48));
        useLp.leftMargin = dp(8);
        manualRow.addView(manualInput, inputLp);
        manualRow.addView(useManual, useLp);
        LinearLayout.LayoutParams manualLp = matchWrap();
        manualLp.topMargin = dp(10);
        bottom.addView(manualRow, manualLp);
        useManual.setOnClickListener(v -> acceptManualBarcode());
        manualInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                acceptManualBarcode();
                return true;
            }
            return false;
        });

        LinearLayout unknownRow = new LinearLayout(this);
        unknownRow.setOrientation(LinearLayout.HORIZONTAL);
        unknownRow.setGravity(Gravity.CENTER);
        searchButton = button("Cari Barang");
        addProductButton = button("Tambah Barang");
        unknownRow.addView(searchButton, new LinearLayout.LayoutParams(0, dp(44), 1f));
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        addLp.leftMargin = dp(8);
        unknownRow.addView(addProductButton, addLp);
        unknownRow.setVisibility(View.GONE);
        unknownRow.setTag("unknownRow");
        LinearLayout.LayoutParams unknownLp = matchWrap();
        unknownLp.topMargin = dp(8);
        bottom.addView(unknownRow, unknownLp);
        searchButton.setOnClickListener(v -> {
            NativeScannerBus.emitAction("SEARCH", lastUnknownBarcode);
            finish();
        });
        addProductButton.setOnClickListener(v -> {
            NativeScannerBus.emitAction("ADD_PRODUCT", lastUnknownBarcode);
            finish();
        });

        LinearLayout permissionRow = new LinearLayout(this);
        permissionRow.setOrientation(LinearLayout.HORIZONTAL);
        permissionRow.setGravity(Gravity.CENTER);
        retryPermissionButton = button("Cuba Izin Kamera");
        appSettingsButton = button("Buka App Settings");
        permissionRow.addView(retryPermissionButton, new LinearLayout.LayoutParams(0, dp(44), 1f));
        LinearLayout.LayoutParams settingsLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        settingsLp.leftMargin = dp(8);
        permissionRow.addView(appSettingsButton, settingsLp);
        permissionRow.setVisibility(View.GONE);
        permissionRow.setTag("permissionRow");
        LinearLayout.LayoutParams permLp = matchWrap();
        permLp.topMargin = dp(8);
        bottom.addView(permissionRow, permLp);
        retryPermissionButton.setOnClickListener(v -> ActivityCompat.requestPermissions(
                this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST));
        appSettingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        });

        Button done = button(isSingleResultMode() ? "Batal" : "SELESAI");
        LinearLayout.LayoutParams doneLp = matchWrap();
        doneLp.topMargin = dp(10);
        doneLp.height = dp(48);
        bottom.addView(done, doneLp);
        done.setOnClickListener(v -> finish());

        FrameLayout.LayoutParams bottomLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bottomLp.gravity = Gravity.BOTTOM;
        root.addView(bottom, bottomLp);

        setContentView(root);

        scaleGestureDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                if (camera == null || camera.getCameraInfo().getZoomState().getValue() == null) return false;
                float current = camera.getCameraInfo().getZoomState().getValue().getZoomRatio();
                float min = camera.getCameraInfo().getZoomState().getValue().getMinZoomRatio();
                float max = camera.getCameraInfo().getZoomState().getValue().getMaxZoomRatio();
                float next = Math.max(min, Math.min(max, current * detector.getScaleFactor()));
                camera.getCameraControl().setZoomRatio(next);
                updateZoomText(next);
                return true;
            }
        });
        previewView.setOnTouchListener((v, event) -> {
            scaleGestureDetector.onTouchEvent(event);
            if (event.getAction() == MotionEvent.ACTION_UP && !scaleGestureDetector.isInProgress()) {
                focusAt(event.getX(), event.getY());
            }
            return true;
        });
    }

    private void ensureCameraPermissionAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            hidePermissionActions();
            startCamera();
        } else {
            statusText.setText("Benarkan Camera untuk scan barcode.");
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != CAMERA_PERMISSION_REQUEST) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            hidePermissionActions();
            startCamera();
            return;
        }
        statusText.setText("Izin kamera ditolak. Scanner manual masih boleh digunakan.");
        LinearLayout permissionRow = (LinearLayout) retryPermissionButton.getParent();
        permissionRow.setVisibility(View.VISIBLE);
        boolean permanentlyDenied = !ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA);
        appSettingsButton.setVisibility(permanentlyDenied ? View.VISIBLE : View.GONE);
    }

    private void hidePermissionActions() {
        if (retryPermissionButton != null && retryPermissionButton.getParent() instanceof View) {
            ((View) retryPermissionButton.getParent()).setVisibility(View.GONE);
        }
    }

    private void startCamera() {
        if (cameraStarted || isFinishing()) return;
        cameraStarted = true;
        statusText.setText("Membuka kamera…");
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                cameraProvider = future.get();
                bindCameraUseCases();
            } catch (Exception e) {
                cameraStarted = false;
                statusText.setText("Kamera gagal dibuka. Cuba tutup app lain yang menggunakan kamera.");
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void bindCameraUseCases() {
        if (cameraProvider == null || isFinishing()) return;
        cameraProvider.unbindAll();

        Preview preview = new Preview.Builder()
                .setTargetResolution(new Size(1280, 720))
                .build();
        preview.setSurfaceProvider(previewView.getSurfaceProvider());

        ImageAnalysis analysis = new ImageAnalysis.Builder()
                .setTargetResolution(new Size(1280, 720))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build();
        analysis.setAnalyzer(analyzerExecutor, this::analyzeFrame);

        try {
            camera = cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis);
            torchButton.setEnabled(camera.getCameraInfo().hasFlashUnit());
            statusText.setText("Scanner aktif — halakan kamera pada barcode.");
            previewView.postDelayed(() -> focusAt(previewView.getWidth() / 2f, previewView.getHeight() / 2f), 350);
            if (camera.getCameraInfo().getZoomState().getValue() != null) {
                updateZoomText(camera.getCameraInfo().getZoomState().getValue().getZoomRatio());
            }
        } catch (Exception e) {
            cameraStarted = false;
            statusText.setText("Rear camera tidak tersedia.");
        }
    }

    @androidx.annotation.OptIn(markerClass = androidx.camera.core.ExperimentalGetImage.class)
    private void analyzeFrame(@NonNull ImageProxy imageProxy) {
        if (!frameInFlight.compareAndSet(false, true)) {
            imageProxy.close();
            return;
        }
        if (imageProxy.getImage() == null) {
            frameInFlight.set(false);
            imageProxy.close();
            return;
        }

        InputImage image = InputImage.fromMediaImage(
                imageProxy.getImage(), imageProxy.getImageInfo().getRotationDegrees());
        barcodeScanner.process(image)
                .addOnSuccessListener(barcodes -> {
                    long now = SystemClock.elapsedRealtime();
                    for (Barcode barcode : barcodes) {
                        String code = normalizeBarcode(barcode.getRawValue());
                        if (code.isEmpty()) continue;
                        Long previousSeen = lastSeenAt.put(code, now);
                        if (shouldAcceptCameraBarcode(code, now, previousSeen)) {
                            emitBarcode(code, now);
                            break;
                        }
                    }
                    pruneOldState(now);
                })
                .addOnFailureListener(e -> { /* live stream continues */ })
                .addOnCompleteListener(task -> {
                    frameInFlight.set(false);
                    imageProxy.close();
                });
    }

    private boolean shouldAcceptCameraBarcode(String code, long now, Long previousSeen) {
        if (pendingLookupAt.containsKey(code)) return false;
        Long accepted = lastAcceptedAt.get(code);
        if (accepted == null) return true;
        if (now - accepted < SAME_CODE_COOLDOWN_MS) return false;
        // A barcode that never left the view stays disarmed. Intentional rescans
        // require a brief absence from the camera before the same code can fire again.
        return previousSeen == null || now - previousSeen >= REARM_ABSENCE_MS;
    }

    private void emitBarcode(String code, long now) {
        pendingLookupAt.put(code, now);
        statusText.setText("Dikesan " + code + " — menyemak barang…");
        hideUnknownActions();
        NativeScannerBus.emitBarcode(code, mode);
        mainHandler.postDelayed(() -> {
            Long started = pendingLookupAt.get(code);
            if (started != null && SystemClock.elapsedRealtime() - started >= LOOKUP_TIMEOUT_MS) {
                pendingLookupAt.remove(code);
                statusText.setText("Carian lambat. Gerakkan barcode keluar dan scan semula, atau guna manual.");
            }
        }, LOOKUP_TIMEOUT_MS + 100L);
    }

    private void acceptManualBarcode() {
        String code = normalizeBarcode(manualInput.getText() == null ? "" : manualInput.getText().toString());
        if (code.isEmpty()) {
            statusText.setText("Masukkan barcode dahulu.");
            return;
        }
        if (pendingLookupAt.containsKey(code)) return;
        long now = SystemClock.elapsedRealtime();
        Long accepted = lastAcceptedAt.get(code);
        if (accepted != null && now - accepted < SAME_CODE_COOLDOWN_MS) return;
        emitBarcode(code, now);
    }

    public static String normalizeBarcode(String value) {
        if (value == null) return "";
        return value.trim().replaceAll("[\\r\\n\\t ]+", "");
    }

    public static void deliverLookupResult(String barcode, boolean found, String message) {
        NativeBarcodeScannerActivity activity = activeScanner.get();
        if (activity == null || activity.isFinishing()) return;
        activity.runOnUiThread(() -> activity.handleLookupResult(barcode, found, message));
    }

    private void handleLookupResult(String rawBarcode, boolean found, String message) {
        String barcode = normalizeBarcode(rawBarcode);
        pendingLookupAt.remove(barcode);
        lastAcceptedAt.put(barcode, SystemClock.elapsedRealtime());
        if (found) {
            statusText.setText(message == null || message.trim().isEmpty()
                    ? "Ditambah ke troli: " + barcode : message);
            hideUnknownActions();
            beepAndVibrate();
            manualInput.setText("");
            if (isSingleResultMode()) mainHandler.postDelayed(this::finish, 220L);
        } else {
            lastUnknownBarcode = barcode;
            statusText.setText(message == null || message.trim().isEmpty()
                    ? "Barcode tidak dijumpai" : message);
            if (MODE_INVENTORY_LOOKUP.equals(mode) || MODE_INVENTORY_BARCODE_INPUT.equals(mode)) hideUnknownActions();
            else showUnknownActions();
        }
    }

    private boolean isSingleResultMode() {
        return MODE_SINGLE.equals(mode) || MODE_INVENTORY_LOOKUP.equals(mode)
                || MODE_INVENTORY_BARCODE_INPUT.equals(mode);
    }

    private void showUnknownActions() {
        if (searchButton != null && searchButton.getParent() instanceof View) {
            ((View) searchButton.getParent()).setVisibility(View.VISIBLE);
        }
    }

    private void hideUnknownActions() {
        if (searchButton != null && searchButton.getParent() instanceof View) {
            ((View) searchButton.getParent()).setVisibility(View.GONE);
        }
    }

    private void beepAndVibrate() {
        try { toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP, 80); } catch (Exception ignored) {}
        try {
            if (vibrator == null || !vibrator.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(45);
            }
        } catch (Exception ignored) {}
    }

    private void toggleTorch() {
        if (camera == null || !camera.getCameraInfo().hasFlashUnit()) return;
        torchOn = !torchOn;
        camera.getCameraControl().enableTorch(torchOn);
        torchButton.setText(torchOn ? "Torch ON" : "Torch");
    }

    private void focusAt(float x, float y) {
        if (camera == null || previewView.getWidth() <= 0 || previewView.getHeight() <= 0) return;
        MeteringPoint point = previewView.getMeteringPointFactory().createPoint(x, y);
        FocusMeteringAction action = new FocusMeteringAction.Builder(
                point, FocusMeteringAction.FLAG_AF | FocusMeteringAction.FLAG_AE)
                .setAutoCancelDuration(3, TimeUnit.SECONDS)
                .build();
        camera.getCameraControl().startFocusAndMetering(action);
    }

    private void updateZoomText(float ratio) {
        if (zoomText != null) zoomText.setText(String.format(java.util.Locale.US, "%.1f×", ratio));
    }

    private void pruneOldState(long now) {
        lastSeenAt.entrySet().removeIf(entry -> now - entry.getValue() > 10000L);
        lastAcceptedAt.entrySet().removeIf(entry -> now - entry.getValue() > 30000L);
        pendingLookupAt.entrySet().removeIf(entry -> now - entry.getValue() > LOOKUP_TIMEOUT_MS + 2000L);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!cameraStarted && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        }
    }

    @Override
    protected void onDestroy() {
        if (activeScanner.get() == this) activeScanner.clear();
        try { if (cameraProvider != null) cameraProvider.unbindAll(); } catch (Exception ignored) {}
        try { if (barcodeScanner != null) barcodeScanner.close(); } catch (Exception ignored) {}
        try { if (toneGenerator != null) toneGenerator.release(); } catch (Exception ignored) {}
        if (analyzerExecutor != null) analyzerExecutor.shutdownNow();
        mainHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private Button button(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(13);
        button.setAllCaps(false);
        button.setBackgroundColor(0xFF374151);
        button.setPadding(dp(10), 0, dp(10), 0);
        return button;
    }

    private TextView text(String value, float size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class ScannerOverlayView extends View {
        private final Paint shade = new Paint();
        private final Paint border = new Paint();

        ScannerOverlayView(android.content.Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            shade.setColor(0x66000000);
            border.setColor(Color.WHITE);
            border.setStyle(Paint.Style.STROKE);
            border.setStrokeWidth(context.getResources().getDisplayMetrics().density * 2f);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float width = getWidth();
            float height = getHeight();
            float boxWidth = width * 0.64f;
            float boxHeight = Math.min(height * 0.30f, boxWidth * 0.45f);
            float left = (width - boxWidth) / 2f;
            float top = (height - boxHeight) / 2f - height * 0.04f;
            RectF box = new RectF(left, top, left + boxWidth, top + boxHeight);

            canvas.drawRect(0, 0, width, box.top, shade);
            canvas.drawRect(0, box.bottom, width, height, shade);
            canvas.drawRect(0, box.top, box.left, box.bottom, shade);
            canvas.drawRect(box.right, box.top, width, box.bottom, shade);
            canvas.drawRoundRect(box, dpStatic(14), dpStatic(14), border);
        }

        private float dpStatic(int value) {
            return value * getResources().getDisplayMetrics().density;
        }
    }
}
