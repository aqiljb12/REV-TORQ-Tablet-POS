package com.revtorq.pos;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.content.Intent;
import android.webkit.JavascriptInterface;
import android.view.View;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private final NativeScannerBus.Listener nativeScannerListener = new NativeScannerBus.Listener() {
        @Override public void onBarcode(String barcode, String mode) {
            runOnUiThread(() -> {
                if (webView == null) return;
                String js = "window.RevTorqNativeScanner&&window.RevTorqNativeScanner.onBarcode("
                        + org.json.JSONObject.quote(barcode) + "," + org.json.JSONObject.quote(mode) + ");";
                webView.evaluateJavascript(js, null);
            });
        }
        @Override public void onAction(String action, String barcode) {
            runOnUiThread(() -> {
                if (webView == null) return;
                String js = "window.RevTorqNativeScanner&&window.RevTorqNativeScanner.onAction("
                        + org.json.JSONObject.quote(action) + "," + org.json.JSONObject.quote(barcode) + ");";
                webView.evaluateJavascript(js, null);
            });
        }
    };
    private static final int CAMERA_REQUEST = 4101;
    private WebView webView;
    private PermissionRequest pendingPermissionRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11, 14, 20));
        getWindow().setNavigationBarColor(Color.rgb(11, 14, 20));
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        NativeScannerBus.setListener(nativeScannerListener);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11, 14, 20));
        webView.addJavascriptInterface(new RevTorqAndroidBridge(), "RevTorqAndroid");

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if ((request.getOrigin() != null) && request.getOrigin().toString().startsWith("https://appassets.androidplatform.net")) {
                        pendingPermissionRequest = request;
                        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                                checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(MainActivity.this,
                                    new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
                        } else {
                            grantCamera(request);
                        }
                    } else {
                        request.deny();
                    }
                });
            }
        });

        android.webkit.WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setTextZoom(100);

        setContentView(webView);
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html?native=1");
    }

    private void grantCamera(PermissionRequest request) {
        if (request == null) return;
        request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
        pendingPermissionRequest = null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_REQUEST && pendingPermissionRequest != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                grantCamera(pendingPermissionRequest);
            } else {
                pendingPermissionRequest.deny();
                pendingPermissionRequest = null;
            }
        }
    }

    private final class RevTorqAndroidBridge {
        @JavascriptInterface
        public boolean isNativeScannerAvailable() { return true; }

        @JavascriptInterface
        public void scanBarcode(String mode) {
            runOnUiThread(() -> {
                Intent intent = new Intent(MainActivity.this, NativeBarcodeScannerActivity.class);
                String safeMode = NativeBarcodeScannerActivity.MODE_POS_MULTI;
                if (NativeBarcodeScannerActivity.MODE_INVENTORY_LOOKUP.equalsIgnoreCase(mode))
                    safeMode = NativeBarcodeScannerActivity.MODE_INVENTORY_LOOKUP;
                else if (NativeBarcodeScannerActivity.MODE_INVENTORY_BARCODE_INPUT.equalsIgnoreCase(mode))
                    safeMode = NativeBarcodeScannerActivity.MODE_INVENTORY_BARCODE_INPUT;
                else if (NativeBarcodeScannerActivity.MODE_SINGLE.equalsIgnoreCase(mode))
                    safeMode = NativeBarcodeScannerActivity.MODE_SINGLE;
                intent.putExtra(NativeBarcodeScannerActivity.EXTRA_MODE, safeMode);
                startActivity(intent);
            });
        }

        @JavascriptInterface
        public void scannerLookupResult(String barcode, boolean found, String message) {
            NativeBarcodeScannerActivity.deliverLookupResult(barcode, found, message);
        }
    }

    @Override
    protected void onDestroy() {
        NativeScannerBus.clearListener(nativeScannerListener);
        if (webView != null) {
            try { webView.removeJavascriptInterface("RevTorqAndroid"); } catch (Exception ignored) {}
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
