package com.revtorq.pos;

final class NativeScannerBus {
    interface Listener {
        void onBarcode(String barcode, String mode);
        void onAction(String action, String barcode);
    }

    private static volatile Listener listener;

    private NativeScannerBus() {}

    static void setListener(Listener value) {
        listener = value;
    }

    static void clearListener(Listener value) {
        if (listener == value) listener = null;
    }

    static void emitBarcode(String barcode, String mode) {
        Listener value = listener;
        if (value != null) value.onBarcode(barcode, mode);
    }

    static void emitAction(String action, String barcode) {
        Listener value = listener;
        if (value != null) value.onAction(action, barcode);
    }
}
