-- REV TORQ Unified Promo System — 2026-09-18
-- Single source of truth for Customer PWA + POS promotion eligibility/redemption.

-- ---------------------------------------------------------------------------
-- 1) Legacy normalization + invariants
-- ---------------------------------------------------------------------------

update public.promotions
set publication_status = case when active then 'PUBLISHED' else 'DRAFT' end
where publication_status is null;

update public.promotions
set priority = 100
where priority is null;

update public.promotions
set cta_payload = '{}'::jsonb
where cta_payload is null;

create unique index if not exists uq_promotions_company_code_ci
on public.promotions(company_id, upper(promo_code))
where promo_code is not null and btrim(promo_code) <> '';

create unique index if not exists uq_promo_redemptions_promo_invoice
on public.promo_redemptions(promotion_id, invoice_id)
where invoice_id is not null;

drop policy if exists promo_redemptions_insert_own_company on public.promo_redemptions;
revoke insert on public.promo_redemptions from authenticated;

-- ---------------------------------------------------------------------------
-- 2) Admin save RPC — blank promo code auto-generates unique company code
-- ---------------------------------------------------------------------------

create or replace function public.rt_admin_save_promotion_v2(p_payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  v_staff record;
  v_id uuid := nullif(p_payload->>'id','')::uuid;
  v_row public.promotions;
  v_cta_type text := nullif(upper(btrim(coalesce(p_payload->>'cta_type',''))),'');
  v_payload jsonb := coalesce(p_payload->'cta_payload','{}'::jsonb);
  v_status text := coalesce(nullif(upper(btrim(p_payload->>'publication_status')),''),'DRAFT');
  v_code text := nullif(upper(btrim(coalesce(p_payload->>'promo_code',''))),'');
begin
  select * into v_staff from public.rt_staff_context() limit 1;
  if v_staff.staff_id is null
     or lower(coalesce(v_staff.role,'')) not in ('owner','admin','super_admin','manager') then
    raise exception 'STAFF_ADMIN_NOT_AUTHORIZED';
  end if;

  if nullif(btrim(p_payload->>'name'),'') is null then raise exception 'PROMOTION_NAME_REQUIRED'; end if;
  if nullif(btrim(p_payload->>'promo_type'),'') is null then raise exception 'PROMOTION_TYPE_REQUIRED'; end if;
  if nullif(p_payload->>'discount_value','') is null then raise exception 'PROMOTION_DISCOUNT_VALUE_REQUIRED'; end if;
  if nullif(p_payload->>'minimum_spend','') is null then raise exception 'PROMOTION_MINIMUM_SPEND_REQUIRED'; end if;
  if jsonb_typeof(v_payload) <> 'object' then raise exception 'CTA_PAYLOAD_MUST_BE_OBJECT'; end if;

  if v_cta_type is not null
     and v_cta_type not in ('BOOKING_SERVICE','REWARDS','ESHOP','INFO','WHATSAPP') then
    raise exception 'CTA_TYPE_NOT_ALLOWED';
  end if;

  if v_status not in ('DRAFT','PUBLISHED','ARCHIVED') then
    raise exception 'PUBLICATION_STATUS_NOT_ALLOWED';
  end if;

  if v_status='PUBLISHED' and v_cta_type='ESHOP' then
    raise exception 'ESHOP_ROUTE_NOT_CONFIGURED';
  end if;

  if (v_cta_type='BOOKING_SERVICE' and v_payload <> '{}'::jsonb)
     or (v_cta_type='REWARDS' and exists(select 1 from jsonb_object_keys(v_payload) k where k <> 'reward_id'))
     or (v_cta_type='INFO' and exists(select 1 from jsonb_object_keys(v_payload) k where k <> 'content_id'))
     or (v_cta_type='WHATSAPP' and exists(select 1 from jsonb_object_keys(v_payload) k where k <> 'message'))
     or (v_cta_type='ESHOP' and exists(select 1 from jsonb_object_keys(v_payload) k where k <> 'path')) then
    raise exception 'CTA_PAYLOAD_NOT_ALLOWED';
  end if;

  if v_cta_type='ESHOP'
     and v_payload ? 'path'
     and (v_payload->>'path' !~ '^/[^/].*') then
    raise exception 'ESHOP_PATH_NOT_SAME_ORIGIN';
  end if;

  if nullif(p_payload->>'usage_limit','') is not null
     and (p_payload->>'usage_limit')::integer < 1 then
    raise exception 'PROMOTION_USAGE_LIMIT_INVALID';
  end if;

  if nullif(p_payload->>'usage_per_customer','') is not null
     and (p_payload->>'usage_per_customer')::integer < 1 then
    raise exception 'PROMOTION_USAGE_PER_CUSTOMER_INVALID';
  end if;

  if v_code is null then
    loop
      v_code := 'RTQ-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,5));
      exit when not exists(
        select 1
        from public.promotions p
        where p.company_id=v_staff.company_id
          and upper(p.promo_code)=v_code
          and (v_id is null or p.id<>v_id)
      );
    end loop;
  end if;

  if v_id is null then
    insert into public.promotions(
      company_id,promo_code,name,description,promo_type,discount_value,
      max_discount,minimum_spend,usage_limit,usage_per_customer,
      customer_type,birthday_only,first_visit_only,active,starts_at,ends_at,
      metadata,created_by,updated_by,image_path,publication_status,priority,
      cta_type,cta_payload,published_at,archived_at
    ) values(
      v_staff.company_id,v_code,nullif(p_payload->>'name',''),
      nullif(p_payload->>'description',''),upper(nullif(p_payload->>'promo_type','')),
      nullif(p_payload->>'discount_value','')::numeric,
      nullif(p_payload->>'max_discount','')::numeric,
      nullif(p_payload->>'minimum_spend','')::numeric,
      nullif(p_payload->>'usage_limit','')::integer,
      nullif(p_payload->>'usage_per_customer','')::integer,
      coalesce(nullif(p_payload->>'customer_type',''),'ALL'),
      coalesce((p_payload->>'birthday_only')::boolean,false),
      coalesce((p_payload->>'first_visit_only')::boolean,false),
      coalesce((p_payload->>'active')::boolean,v_status='PUBLISHED'),
      nullif(p_payload->>'starts_at','')::timestamptz,
      nullif(p_payload->>'ends_at','')::timestamptz,
      coalesce(p_payload->'metadata','{}'::jsonb),
      v_staff.staff_id,v_staff.staff_id,
      nullif(p_payload->>'image_path',''),
      v_status,
      coalesce(nullif(p_payload->>'priority','')::integer,100),
      v_cta_type,v_payload,
      case when v_status='PUBLISHED' then now() else null end,
      case when v_status='ARCHIVED' then now() else null end
    )
    returning * into v_row;
  else
    update public.promotions p set
      promo_code=v_code,
      name=nullif(p_payload->>'name',''),
      description=nullif(p_payload->>'description',''),
      promo_type=upper(nullif(p_payload->>'promo_type','')),
      discount_value=nullif(p_payload->>'discount_value','')::numeric,
      max_discount=nullif(p_payload->>'max_discount','')::numeric,
      minimum_spend=nullif(p_payload->>'minimum_spend','')::numeric,
      usage_limit=nullif(p_payload->>'usage_limit','')::integer,
      usage_per_customer=nullif(p_payload->>'usage_per_customer','')::integer,
      customer_type=coalesce(nullif(p_payload->>'customer_type',''),'ALL'),
      birthday_only=coalesce((p_payload->>'birthday_only')::boolean,false),
      first_visit_only=coalesce((p_payload->>'first_visit_only')::boolean,false),
      active=coalesce((p_payload->>'active')::boolean,v_status='PUBLISHED'),
      starts_at=nullif(p_payload->>'starts_at','')::timestamptz,
      ends_at=nullif(p_payload->>'ends_at','')::timestamptz,
      metadata=coalesce(p_payload->'metadata','{}'::jsonb),
      updated_by=v_staff.staff_id,
      updated_at=now(),
      image_path=nullif(p_payload->>'image_path',''),
      publication_status=v_status,
      priority=coalesce(nullif(p_payload->>'priority','')::integer,100),
      cta_type=v_cta_type,
      cta_payload=v_payload,
      published_at=case when v_status='PUBLISHED' then coalesce(p.published_at,now()) else p.published_at end,
      archived_at=case when v_status='ARCHIVED' then now() else null end
    where p.id=v_id and p.company_id=v_staff.company_id
    returning * into v_row;

    if v_row.id is null then raise exception 'PROMOTION_NOT_FOUND'; end if;
  end if;

  return to_jsonb(v_row);
exception
  when unique_violation then
    raise exception 'PROMO_CODE_ALREADY_EXISTS';
end;
$function$;

-- ---------------------------------------------------------------------------
-- 3) Pure helpers
-- ---------------------------------------------------------------------------

create or replace function public.rt_promo_discount_amount(
  p_type text,
  p_value numeric,
  p_max numeric,
  p_base numeric
)
returns numeric
language sql
immutable
as $$
  select round(
    greatest(
      0,
      least(
        greatest(0,coalesce(p_base,0)),
        case
          when upper(coalesce(p_type,''))='PERCENT'
            then least(
              greatest(0,coalesce(p_base,0)) * greatest(0,coalesce(p_value,0)) / 100,
              coalesce(p_max,greatest(0,coalesce(p_base,0)))
            )
          else greatest(0,coalesce(p_value,0))
        end
      )
    ),2
  );
$$;

create or replace function public.rt_promo_validate_for_company(
  p_company_id uuid,
  p_promotion_id uuid default null,
  p_code text default null,
  p_customer_id uuid default null,
  p_subtotal numeric default 0,
  p_enforce_minimum boolean default true
)
returns jsonb
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  v public.promotions%rowtype;
  v_used integer := 0;
  v_customer_used integer := 0;
  v_discount numeric := 0;
  v_remaining integer := null;
  v_customer public.customers%rowtype;
  v_today date := (now() at time zone 'Asia/Kuala_Lumpur')::date;
  v_has_prior boolean := false;
  v_reason text := null;
begin
  if p_company_id is null then
    return jsonb_build_object('eligible',false,'reason','PROMO_NOT_FOUND');
  end if;

  select * into v
  from public.promotions
  where company_id=p_company_id
    and (
      (p_promotion_id is not null and id=p_promotion_id)
      or (
        p_promotion_id is null
        and nullif(btrim(coalesce(p_code,'')),'') is not null
        and upper(promo_code)=upper(btrim(p_code))
      )
    )
  order by case when p_promotion_id is not null and id=p_promotion_id then 0 else 1 end
  limit 1;

  if v.id is null then
    return jsonb_build_object('eligible',false,'reason','PROMO_NOT_FOUND');
  end if;

  select count(*)::int into v_used
  from public.promo_redemptions r
  where r.company_id=p_company_id and r.promotion_id=v.id;

  if p_customer_id is not null then
    select count(*)::int into v_customer_used
    from public.promo_redemptions r
    where r.company_id=p_company_id
      and r.promotion_id=v.id
      and r.customer_id=p_customer_id;
  end if;

  if v.usage_limit is not null then
    v_remaining := greatest(v.usage_limit-v_used,0);
  end if;

  if upper(coalesce(v.publication_status,'')) <> 'PUBLISHED' then
    v_reason := 'PROMO_NOT_PUBLISHED';
  elsif not coalesce(v.active,false) then
    v_reason := 'PROMO_NOT_ACTIVE';
  elsif v.starts_at is not null and now() < v.starts_at then
    v_reason := 'PROMO_NOT_STARTED';
  elsif v.ends_at is not null and now() > v.ends_at then
    v_reason := 'PROMO_EXPIRED';
  elsif v.usage_limit is not null and v_used >= v.usage_limit then
    v_reason := 'PROMO_USAGE_LIMIT_REACHED';
  elsif coalesce(upper(v.customer_type),'ALL') <> 'ALL' and p_customer_id is null then
    v_reason := 'PROMO_CUSTOMER_REQUIRED';
  elsif v.usage_per_customer is not null and p_customer_id is null then
    v_reason := 'PROMO_CUSTOMER_REQUIRED';
  elsif v.usage_per_customer is not null and v_customer_used >= v.usage_per_customer then
    v_reason := 'PROMO_CUSTOMER_LIMIT_REACHED';
  elsif p_enforce_minimum and greatest(0,coalesce(p_subtotal,0)) < greatest(0,coalesce(v.minimum_spend,0)) then
    v_reason := 'PROMO_MINIMUM_SPEND_NOT_MET';
  end if;

  if v_reason is null
     and (coalesce(v.birthday_only,false) or coalesce(v.first_visit_only,false)
          or coalesce(upper(v.customer_type),'ALL') <> 'ALL') then
    if p_customer_id is null then
      v_reason := 'PROMO_CUSTOMER_REQUIRED';
    else
      select * into v_customer
      from public.customers c
      where c.id=p_customer_id and c.company_id=p_company_id and c.active=true;

      if v_customer.id is null then
        v_reason := 'PROMO_CUSTOMER_REQUIRED';
      elsif coalesce(upper(v.customer_type),'ALL') <> 'ALL' then
        -- Current customer schema has no customer_type column. Do not silently
        -- grant segmented promotions until an explicit mapping exists.
        v_reason := 'PROMO_CUSTOMER_REQUIRED';
      elsif coalesce(v.birthday_only,false)
            and (
              v_customer.date_of_birth is null
              or extract(month from v_customer.date_of_birth) <> extract(month from v_today)
              or extract(day from v_customer.date_of_birth) <> extract(day from v_today)
            ) then
        v_reason := 'PROMO_BIRTHDAY_ONLY';
      elsif coalesce(v.first_visit_only,false) then
        select exists(
          select 1
          from public.invoices i
          where i.company_id=p_company_id
            and i.customer_id=p_customer_id
            and i.status <> 'VOID'
            and i.payment_status='PAID'
        ) into v_has_prior;
        if v_has_prior then
          v_reason := 'PROMO_FIRST_VISIT_ONLY';
        end if;
      end if;
    end if;
  end if;

  v_discount := public.rt_promo_discount_amount(
    v.promo_type,v.discount_value,v.max_discount,greatest(0,coalesce(p_subtotal,0))
  );

  return jsonb_build_object(
    'eligible',v_reason is null,
    'reason',v_reason,
    'promotion_id',v.id,
    'promo_code',v.promo_code,
    'name',v.name,
    'description',v.description,
    'promo_type',v.promo_type,
    'discount_value',v.discount_value,
    'discount_amount',v_discount,
    'minimum_spend',v.minimum_spend,
    'used_count',v_used,
    'usage_limit',v.usage_limit,
    'remaining',v_remaining,
    'usage_per_customer',v.usage_per_customer,
    'customer_used_count',v_customer_used,
    'starts_at',v.starts_at,
    'ends_at',v.ends_at,
    'image_path',v.image_path,
    'priority',v.priority,
    'cta_type',v.cta_type,
    'cta_payload',coalesce(v.cta_payload,'{}'::jsonb),
    'metadata',coalesce(v.metadata,'{}'::jsonb)
  );
end;
$function$;

-- ---------------------------------------------------------------------------
-- 4) Customer / POS read RPCs
-- ---------------------------------------------------------------------------

create or replace function public.rt_customer_available_promotions()
returns table(
  id uuid,
  company_id uuid,
  promo_code text,
  name text,
  description text,
  promo_type text,
  discount_value numeric,
  max_discount numeric,
  minimum_spend numeric,
  usage_limit integer,
  usage_per_customer integer,
  customer_type text,
  birthday_only boolean,
  first_visit_only boolean,
  active boolean,
  starts_at timestamptz,
  ends_at timestamptz,
  metadata jsonb,
  image_path text,
  publication_status text,
  priority integer,
  cta_type text,
  cta_payload jsonb,
  used_count integer,
  remaining integer
)
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  v_customer_id uuid := public.rt_current_customer_id();
  v_company_id uuid;
  r public.promotions%rowtype;
  v jsonb;
begin
  if v_customer_id is null then raise exception 'CUSTOMER_NOT_FOUND'; end if;

  select c.company_id into v_company_id
  from public.customers c
  where c.id=v_customer_id and c.active=true;

  if v_company_id is null then raise exception 'CUSTOMER_NOT_FOUND'; end if;

  for r in
    select p.*
    from public.promotions p
    where p.company_id=v_company_id
    order by coalesce(p.priority,100),p.created_at desc
  loop
    v := public.rt_promo_validate_for_company(
      v_company_id,r.id,null,v_customer_id,0,false
    );
    if coalesce((v->>'eligible')::boolean,false) then
      id:=r.id;
      company_id:=r.company_id;
      promo_code:=r.promo_code;
      name:=r.name;
      description:=r.description;
      promo_type:=r.promo_type;
      discount_value:=r.discount_value;
      max_discount:=r.max_discount;
      minimum_spend:=r.minimum_spend;
      usage_limit:=r.usage_limit;
      usage_per_customer:=r.usage_per_customer;
      customer_type:=r.customer_type;
      birthday_only:=r.birthday_only;
      first_visit_only:=r.first_visit_only;
      active:=r.active;
      starts_at:=r.starts_at;
      ends_at:=r.ends_at;
      metadata:=r.metadata;
      image_path:=r.image_path;
      publication_status:=r.publication_status;
      priority:=r.priority;
      cta_type:=r.cta_type;
      cta_payload:=coalesce(r.cta_payload,'{}'::jsonb);
      used_count:=coalesce((v->>'used_count')::int,0);
      remaining:=case when v->>'remaining' is null then null else (v->>'remaining')::int end;
      return next;
    end if;
  end loop;
end;
$function$;

create or replace function public.rt_validate_promo(
  p_promotion_id uuid default null,
  p_code text default null,
  p_customer_id uuid default null,
  p_subtotal numeric default 0
)
returns jsonb
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  s record;
begin
  select * into s from public.rt_staff_context() limit 1;
  if s.staff_id is null then raise exception 'STAFF_CONTEXT_NOT_FOUND'; end if;

  if p_customer_id is not null
     and not exists(
       select 1 from public.customers c
       where c.id=p_customer_id and c.company_id=s.company_id and c.active=true
     ) then
    return jsonb_build_object('eligible',false,'reason','PROMO_CUSTOMER_REQUIRED');
  end if;

  return public.rt_promo_validate_for_company(
    s.company_id,p_promotion_id,p_code,p_customer_id,p_subtotal,true
  );
end;
$function$;

create or replace function public.rt_pos_available_promotions(
  p_customer_id uuid default null,
  p_subtotal numeric default 0
)
returns table(promotion jsonb)
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  s record;
  r public.promotions%rowtype;
  v jsonb;
begin
  select * into s from public.rt_staff_context() limit 1;
  if s.staff_id is null then raise exception 'STAFF_CONTEXT_NOT_FOUND'; end if;

  for r in
    select p.*
    from public.promotions p
    where p.company_id=s.company_id
    order by coalesce(p.priority,100),p.created_at desc
  loop
    v:=public.rt_promo_validate_for_company(
      s.company_id,r.id,null,p_customer_id,p_subtotal,true
    );
    if coalesce((v->>'eligible')::boolean,false) then
      promotion:=v;
      return next;
    end if;
  end loop;
end;
$function$;

-- ---------------------------------------------------------------------------
-- 5) Helpers to compute server-authoritative net cart base
-- ---------------------------------------------------------------------------

create or replace function public.rt_pos_items_net_subtotal(
  p_company_id uuid,
  p_items jsonb
)
returns numeric
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  item jsonb;
  prod public.products%rowtype;
  qty numeric;
  price numeric;
  gross_line numeric;
  line_discount numeric;
  total numeric:=0;
begin
  if jsonb_typeof(coalesce(p_items,'[]'::jsonb)) <> 'array' then return 0; end if;

  for item in select * from jsonb_array_elements(coalesce(p_items,'[]'::jsonb))
  loop
    qty:=greatest(0,coalesce(nullif(item->>'quantity','')::numeric,0));

    if upper(coalesce(item->>'item_type','PART')) in ('SERVICE','LABOUR','OTHER')
       and nullif(item->>'product_id','') is null then
      price:=greatest(0,coalesce(nullif(item->>'unit_price','')::numeric,0));
    else
      select * into prod
      from public.products p
      where p.id=nullif(item->>'product_id','')::uuid
        and p.company_id=p_company_id
        and p.active=true;
      if prod.id is null then raise exception 'PRODUCT_NOT_FOUND'; end if;
      price:=greatest(0,coalesce(prod.sell_price,0));
    end if;

    gross_line:=round(qty*price,2);
    line_discount:=least(
      gross_line,
      greatest(0,coalesce(nullif(item->>'discount','')::numeric,0))
    );
    total:=total+round(greatest(0,gross_line-line_discount),2);
  end loop;

  return round(total,2);
end;
$function$;

create or replace function public.rt_job_items_net_subtotal(
  p_company_id uuid,
  p_job_card_id uuid,
  p_items jsonb
)
returns numeric
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  item jsonb;
  ji public.job_card_items%rowtype;
  prod public.products%rowtype;
  qty numeric;
  price numeric;
  gross_line numeric;
  line_discount numeric;
  total numeric:=0;
  is_service boolean;
  from_job boolean;
  job_item_id uuid;
  v_product_id uuid;
begin
  if jsonb_typeof(coalesce(p_items,'[]'::jsonb)) <> 'array' then return 0; end if;

  for item in select * from jsonb_array_elements(coalesce(p_items,'[]'::jsonb))
  loop
    qty:=greatest(0,coalesce(nullif(item->>'quantity','')::numeric,0));
    is_service:=upper(coalesce(item->>'item_type',''))='SERVICE';
    from_job:=coalesce((item->>'from_job_card')::boolean,false);
    job_item_id:=nullif(item->>'job_card_item_id','')::uuid;
    v_product_id:=nullif(item->>'product_id','')::uuid;

    if from_job then
      select * into ji
      from public.job_card_items j
      where j.id=job_item_id
        and j.company_id=p_company_id
        and j.job_card_id=p_job_card_id;
      if ji.id is null then raise exception 'JOB_ITEM_NOT_FOUND'; end if;
      price:=greatest(0,coalesce(ji.unit_price,0));
    elsif is_service then
      price:=greatest(0,coalesce(nullif(item->>'service_price','')::numeric,0));
    else
      select * into prod
      from public.products p
      where p.id=v_product_id and p.company_id=p_company_id and p.active=true;
      if prod.id is null then raise exception 'PRODUCT_NOT_FOUND'; end if;
      price:=greatest(0,coalesce(prod.sell_price,0));
    end if;

    gross_line:=round(qty*price,2);
    line_discount:=least(
      gross_line,
      greatest(0,coalesce(nullif(item->>'discount','')::numeric,0))
    );
    total:=total+round(greatest(0,gross_line-line_discount),2);
  end loop;

  return round(total,2);
end;
$function$;

-- ---------------------------------------------------------------------------
-- 6) Atomic sale wrappers
-- ---------------------------------------------------------------------------

create or replace function public.rt_post_pos_sale_with_promo(
  p_customer_id uuid default null,
  p_vehicle_id uuid default null,
  p_location_id uuid default null,
  p_payment_method text default 'CASH',
  p_amount_received numeric default 0,
  p_reference_no text default null,
  p_transaction_id uuid default null,
  p_items jsonb default '[]'::jsonb,
  p_manual_discount numeric default 0,
  p_promotion_id uuid default null,
  p_promo_code text default null
)
returns table(
  invoice_id uuid,
  invoice_no text,
  total numeric,
  change_amount numeric,
  promotion_id uuid,
  promo_code text,
  promo_name text,
  promo_discount numeric
)
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  s record;
  v_promo public.promotions%rowtype;
  v_validation jsonb;
  v_base numeric:=0;
  v_discount numeric:=0;
  v_sale record;
  v_existing_invoice uuid;
  v_existing_redemption public.promo_redemptions%rowtype;
begin
  select * into s from public.rt_staff_context() limit 1;
  if s.staff_id is null then raise exception 'STAFF_CONTEXT_NOT_FOUND'; end if;

  if p_transaction_id is not null then
    select i.id into v_existing_invoice
    from public.invoices i
    where i.company_id=s.company_id and i.transaction_id=p_transaction_id
    limit 1;

    if v_existing_invoice is not null then
      select * into v_existing_redemption
      from public.promo_redemptions r
      where r.company_id=s.company_id and r.invoice_id=v_existing_invoice
      order by r.created_at desc
      limit 1;

      select i.id,i.invoice_no,i.total,
             case when p_payment_method='CASH'
                  then greatest(0,coalesce(p_amount_received,0)-i.total)
                  else 0 end
      into invoice_id,invoice_no,total,change_amount
      from public.invoices i
      where i.id=v_existing_invoice;

      if v_existing_redemption.id is not null then
        select p.id,p.promo_code,p.name
        into promotion_id,promo_code,promo_name
        from public.promotions p
        where p.id=v_existing_redemption.promotion_id;
        promo_discount:=v_existing_redemption.discount_amount;
      else
        promotion_id:=null; promo_code:=null; promo_name:=null; promo_discount:=0;
      end if;
      return next;
      return;
    end if;
  end if;

  if p_promotion_id is null and nullif(btrim(coalesce(p_promo_code,'')),'') is null then
    for v_sale in
      select *
      from public.rt_post_pos_sale(
        p_customer_id,p_vehicle_id,p_location_id,p_payment_method,
        p_amount_received,p_manual_discount,p_reference_no,p_transaction_id,p_items
      )
    loop
      invoice_id:=v_sale.invoice_id;
      invoice_no:=v_sale.invoice_no;
      total:=v_sale.total;
      change_amount:=v_sale.change_amount;
      promotion_id:=null;
      promo_code:=null;
      promo_name:=null;
      promo_discount:=0;
      return next;
    end loop;
    return;
  end if;

  if greatest(0,coalesce(p_manual_discount,0)) > 0 then
    raise exception 'PROMO_AND_MANUAL_ORDER_DISCOUNT_NOT_ALLOWED';
  end if;

  select * into v_promo
  from public.promotions p
  where p.company_id=s.company_id
    and (
      (p_promotion_id is not null and p.id=p_promotion_id)
      or (
        p_promotion_id is null
        and nullif(btrim(coalesce(p_promo_code,'')),'') is not null
        and upper(p.promo_code)=upper(btrim(p_promo_code))
      )
    )
  order by case when p_promotion_id is not null and p.id=p_promotion_id then 0 else 1 end
  limit 1
  for update;

  if v_promo.id is null then raise exception 'PROMO_NOT_FOUND'; end if;

  v_base:=public.rt_pos_items_net_subtotal(s.company_id,p_items);
  v_validation:=public.rt_promo_validate_for_company(
    s.company_id,v_promo.id,null,p_customer_id,v_base,true
  );

  if not coalesce((v_validation->>'eligible')::boolean,false) then
    raise exception '%',coalesce(v_validation->>'reason','PROMO_NOT_ELIGIBLE');
  end if;

  v_discount:=coalesce((v_validation->>'discount_amount')::numeric,0);

  for v_sale in
    select *
    from public.rt_post_pos_sale(
      p_customer_id,p_vehicle_id,p_location_id,p_payment_method,
      p_amount_received,v_discount,p_reference_no,p_transaction_id,p_items
    )
  loop
    insert into public.promo_redemptions(
      company_id,promotion_id,customer_id,invoice_id,discount_amount,staff_id
    ) values(
      s.company_id,v_promo.id,p_customer_id,v_sale.invoice_id,v_discount,s.staff_id
    );

    invoice_id:=v_sale.invoice_id;
    invoice_no:=v_sale.invoice_no;
    total:=v_sale.total;
    change_amount:=v_sale.change_amount;
    promotion_id:=v_promo.id;
    promo_code:=v_promo.promo_code;
    promo_name:=v_promo.name;
    promo_discount:=v_discount;
    return next;
  end loop;
end;
$function$;

create or replace function public.rt_post_job_pos_sale_with_promo(
  p_job_card_id uuid,
  p_customer_id uuid default null,
  p_payment_method text default 'CASH',
  p_amount_received numeric default 0,
  p_items jsonb default '[]'::jsonb,
  p_manual_discount numeric default 0,
  p_promotion_id uuid default null,
  p_promo_code text default null
)
returns table(
  invoice_id uuid,
  invoice_no text,
  total numeric,
  change_amount numeric,
  promotion_id uuid,
  promo_code text,
  promo_name text,
  promo_discount numeric
)
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  s record;
  j public.job_cards%rowtype;
  v_customer_id uuid;
  v_promo public.promotions%rowtype;
  v_validation jsonb;
  v_base numeric:=0;
  v_discount numeric:=0;
  v_sale record;
begin
  select * into s from public.rt_staff_context() limit 1;
  if s.staff_id is null then raise exception 'STAFF_CONTEXT_NOT_FOUND'; end if;

  select * into j
  from public.job_cards
  where id=p_job_card_id and company_id=s.company_id;

  if j.id is null then raise exception 'JOB_CARD_NOT_FOUND'; end if;

  v_customer_id:=coalesce(p_customer_id,j.customer_id);

  if p_promotion_id is null and nullif(btrim(coalesce(p_promo_code,'')),'') is null then
    for v_sale in
      select *
      from public.rt_post_job_pos_sale(
        p_job_card_id,p_customer_id,p_payment_method,p_amount_received,p_manual_discount,p_items
      )
    loop
      invoice_id:=v_sale.invoice_id;
      invoice_no:=v_sale.invoice_no;
      total:=v_sale.total;
      change_amount:=v_sale.change_amount;
      promotion_id:=null;
      promo_code:=null;
      promo_name:=null;
      promo_discount:=0;
      return next;
    end loop;
    return;
  end if;

  if greatest(0,coalesce(p_manual_discount,0)) > 0 then
    raise exception 'PROMO_AND_MANUAL_ORDER_DISCOUNT_NOT_ALLOWED';
  end if;

  select * into v_promo
  from public.promotions p
  where p.company_id=s.company_id
    and (
      (p_promotion_id is not null and p.id=p_promotion_id)
      or (
        p_promotion_id is null
        and nullif(btrim(coalesce(p_promo_code,'')),'') is not null
        and upper(p.promo_code)=upper(btrim(p_promo_code))
      )
    )
  order by case when p_promotion_id is not null and p.id=p_promotion_id then 0 else 1 end
  limit 1
  for update;

  if v_promo.id is null then raise exception 'PROMO_NOT_FOUND'; end if;

  v_base:=public.rt_job_items_net_subtotal(s.company_id,p_job_card_id,p_items);
  v_validation:=public.rt_promo_validate_for_company(
    s.company_id,v_promo.id,null,v_customer_id,v_base,true
  );

  if not coalesce((v_validation->>'eligible')::boolean,false) then
    raise exception '%',coalesce(v_validation->>'reason','PROMO_NOT_ELIGIBLE');
  end if;

  v_discount:=coalesce((v_validation->>'discount_amount')::numeric,0);

  for v_sale in
    select *
    from public.rt_post_job_pos_sale(
      p_job_card_id,p_customer_id,p_payment_method,p_amount_received,v_discount,p_items
    )
  loop
    insert into public.promo_redemptions(
      company_id,promotion_id,customer_id,invoice_id,discount_amount,staff_id
    ) values(
      s.company_id,v_promo.id,v_customer_id,v_sale.invoice_id,v_discount,s.staff_id
    );

    invoice_id:=v_sale.invoice_id;
    invoice_no:=v_sale.invoice_no;
    total:=v_sale.total;
    change_amount:=v_sale.change_amount;
    promotion_id:=v_promo.id;
    promo_code:=v_promo.promo_code;
    promo_name:=v_promo.name;
    promo_discount:=v_discount;
    return next;
  end loop;
end;
$function$;

-- ---------------------------------------------------------------------------
-- 7) Receipt detail enrichment
-- ---------------------------------------------------------------------------

create or replace function public.rt_staff_receipt_detail(p_invoice_id uuid)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  ctx record;
  out_json jsonb;
begin
  select * into ctx from public.rt_staff_context() limit 1;
  if ctx.staff_id is null or lower(coalesce(ctx.role,'')) not in
    ('owner','admin','administrator','super_admin','superadmin','manager','staff','pos','cashier') then
    raise exception 'REPRINT_ROLE_NOT_ALLOWED';
  end if;

  select jsonb_build_object(
    'id',i.id,
    'invoiceNo',i.invoice_no,
    'customerId',i.customer_id,
    'vehicleId',i.vehicle_id,
    'subtotal',coalesce(i.subtotal,0),
    'grossSubtotal',coalesce(items.gross_subtotal,i.subtotal,0),
    'itemDiscount',coalesce(items.item_discount,0),
    'discount',coalesce(i.discount,0),
    'orderDiscount',coalesce(i.discount,0),
    'totalDiscount',coalesce(items.item_discount,0)+coalesce(i.discount,0),
    'tax',coalesce(i.tax,0),
    'total',coalesce(i.total,0),
    'status',i.status,
    'paymentStatus',i.payment_status,
    'createdAt',i.created_at,
    'customerName',coalesce(c.name,'Walk-in'),
    'customerPhone',coalesce(c.phone,''),
    'plateNo',coalesce(v.plate_no,''),
    'vehicleModel',trim(concat_ws(' ',v.brand,v.model,v.variant)),
    'createdBy',coalesce(s.staff_code,s.name,'-'),
    'staffName',coalesce(s.name,s.staff_code,'-'),
    'paymentMethod',coalesce(pay.payment_method,checkout.metadata->>'payment_method','CASH'),
    'amountPaid',coalesce(
      case when nullif(checkout.metadata->>'amount_received','') is not null
           then (checkout.metadata->>'amount_received')::numeric end,
      pay.amount_paid,i.total,0
    ),
    'change',coalesce(
      case when nullif(checkout.metadata->>'change','') is not null
           then (checkout.metadata->>'change')::numeric end,0
    ),
    'items',coalesce(items.data,'[]'::jsonb),
    'promotion',promo.data
  ) into out_json
  from public.invoices i
  left join public.customers c on c.id=i.customer_id and c.company_id=i.company_id
  left join public.vehicles v on v.id=i.vehicle_id and v.company_id=i.company_id
  left join public.staff s on s.id=i.staff_id and s.company_id=i.company_id
  left join lateral (
    select string_agg(distinct p.payment_method,' + ' order by p.payment_method) as payment_method,
           sum(p.amount) as amount_paid
    from public.payments p
    where p.invoice_id=i.id and p.company_id=i.company_id
  ) pay on true
  left join lateral (
    select al.metadata
    from public.audit_logs al
    where al.company_id=i.company_id
      and al.entity_id=i.id
      and al.action='POS_CHECKOUT'
    order by al.created_at desc
    limit 1
  ) checkout on true
  left join lateral (
    select
      jsonb_agg(jsonb_build_object(
        'name',coalesce(nullif(ii.description,''),prod.name,prod.sku,'Item'),
        'sku',coalesce(prod.sku,''),
        'qty',coalesce(ii.quantity,0),
        'quantity',coalesce(ii.quantity,0),
        'price',coalesce(ii.unit_price,0),
        'unitPrice',coalesce(ii.unit_price,0),
        'discount',coalesce(ii.discount,0),
        'lineTotal',coalesce(ii.line_total,0),
        'itemType',coalesce(ii.job_item_type,'PART')
      ) order by ii.id) as data,
      coalesce(sum(ii.quantity*ii.unit_price),0) as gross_subtotal,
      coalesce(sum(ii.discount),0) as item_discount
    from public.invoice_items ii
    left join public.products prod on prod.id=ii.product_id
    where ii.invoice_id=i.id
  ) items on true
  left join lateral (
    select jsonb_build_object(
      'id',p.id,
      'code',p.promo_code,
      'name',p.name,
      'discount',r.discount_amount
    ) as data
    from public.promo_redemptions r
    join public.promotions p on p.id=r.promotion_id
    where r.invoice_id=i.id and r.company_id=i.company_id
    order by r.created_at desc
    limit 1
  ) promo on true
  where i.id=p_invoice_id and i.company_id=ctx.company_id
  limit 1;

  if out_json is null then raise exception 'INVOICE_NOT_FOUND'; end if;
  return out_json;
end;
$function$;

-- ---------------------------------------------------------------------------
-- 8) Permissions
-- ---------------------------------------------------------------------------

revoke all on function public.rt_admin_save_promotion_v2(jsonb) from public,anon;
grant execute on function public.rt_admin_save_promotion_v2(jsonb) to authenticated,service_role;

revoke all on function public.rt_promo_validate_for_company(uuid,uuid,text,uuid,numeric,boolean) from public,anon,authenticated;
grant execute on function public.rt_promo_validate_for_company(uuid,uuid,text,uuid,numeric,boolean) to service_role;

revoke all on function public.rt_pos_items_net_subtotal(uuid,jsonb) from public,anon,authenticated;
grant execute on function public.rt_pos_items_net_subtotal(uuid,jsonb) to service_role;

revoke all on function public.rt_job_items_net_subtotal(uuid,uuid,jsonb) from public,anon,authenticated;
grant execute on function public.rt_job_items_net_subtotal(uuid,uuid,jsonb) to service_role;

revoke all on function public.rt_customer_available_promotions() from public,anon;
grant execute on function public.rt_customer_available_promotions() to authenticated,service_role;

revoke all on function public.rt_validate_promo(uuid,text,uuid,numeric) from public,anon;
grant execute on function public.rt_validate_promo(uuid,text,uuid,numeric) to authenticated,service_role;

revoke all on function public.rt_pos_available_promotions(uuid,numeric) from public,anon;
grant execute on function public.rt_pos_available_promotions(uuid,numeric) to authenticated,service_role;

revoke all on function public.rt_post_pos_sale_with_promo(uuid,uuid,uuid,text,numeric,text,uuid,jsonb,numeric,uuid,text) from public,anon;
grant execute on function public.rt_post_pos_sale_with_promo(uuid,uuid,uuid,text,numeric,text,uuid,jsonb,numeric,uuid,text) to authenticated,service_role;

revoke all on function public.rt_post_job_pos_sale_with_promo(uuid,uuid,text,numeric,jsonb,numeric,uuid,text) from public,anon;
grant execute on function public.rt_post_job_pos_sale_with_promo(uuid,uuid,text,numeric,jsonb,numeric,uuid,text) to authenticated,service_role;
