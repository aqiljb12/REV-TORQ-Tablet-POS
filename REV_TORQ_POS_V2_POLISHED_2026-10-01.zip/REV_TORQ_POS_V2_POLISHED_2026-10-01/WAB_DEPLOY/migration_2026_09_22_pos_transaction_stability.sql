-- Apply this single additive migration before relying on uncertain-response checkout recovery.
-- The production invoices table already has unique transaction_id and invoice_no indexes.
-- An unanswered HTTP request may have committed. The browser uses this read-only,
-- company-scoped lookup before sending a pending sale again.
create or replace function public.rt_pos_transaction_lookup(p_transaction_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_staff record;
  v_invoice_id uuid;
begin
  if p_transaction_id is null then raise exception 'TRANSACTION_ID_REQUIRED'; end if;
  select * into v_staff from public.rt_staff_context() limit 1;
  if v_staff.staff_id is null or lower(coalesce(v_staff.role,'')) not in
     ('owner','admin','super_admin','manager','cashier','pos') then
    raise exception 'POS_ROLE_NOT_ALLOWED';
  end if;
  select i.id into v_invoice_id
  from public.invoices i
  where i.company_id=v_staff.company_id and i.transaction_id=p_transaction_id
  limit 1;
  if v_invoice_id is null then return null; end if;
  return public.rt_staff_receipt_detail(v_invoice_id);
end;
$function$;

revoke all on function public.rt_pos_transaction_lookup(uuid) from public, anon;
grant execute on function public.rt_pos_transaction_lookup(uuid) to authenticated;
