-- REV TORQ — phone-linked membership, spend-based loyalty, reward claiming and POS member lookup.
-- Additive/idempotent. Existing loyalty history and issued vouchers are preserved.

create or replace function public.rt_normalize_phone(p_phone text)
returns text
language sql
immutable
set search_path = public, pg_temp
as $$
  with x as (
    select regexp_replace(coalesce(p_phone,''), '[^0-9]', '', 'g') as d
  )
  select case
    when d = '' then null
    when d like '60%' then d
    when d like '0%' then '60' || substr(d, 2)
    when d like '1%' then '60' || d
    else d
  end
  from x;
$$;

alter table public.customers
  add column if not exists phone_normalized text;

update public.customers
set phone_normalized = public.rt_normalize_phone(phone)
where phone_normalized is distinct from public.rt_normalize_phone(phone);

create index if not exists idx_customers_company_phone_normalized
  on public.customers(company_id, phone_normalized)
  where phone_normalized is not null;

create or replace function public.rt_customer_phone_normalize_trigger()
returns trigger
language plpgsql
set search_path = public, pg_temp
as $$
begin
  new.phone_normalized := public.rt_normalize_phone(new.phone);
  return new;
end;
$$;

drop trigger if exists trg_customers_normalize_phone on public.customers;
create trigger trg_customers_normalize_phone
before insert or update of phone on public.customers
for each row execute function public.rt_customer_phone_normalize_trigger();

-- Customer PWA: bind an authenticated web account to an existing POS-created
-- customer row by phone, or create a fresh row if no member exists yet.
create or replace function public.rt_customer_claim_or_create_profile(
  p_company_id uuid,
  p_name text,
  p_phone text,
  p_email text default null,
  p_date_of_birth date default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_uid uuid := auth.uid();
  v_phone text := public.rt_normalize_phone(p_phone);
  v_row public.customers%rowtype;
  v_count integer := 0;
  v_other_linked integer := 0;
begin
  if v_uid is null then raise exception 'AUTH_REQUIRED'; end if;
  if p_company_id is null or not exists(select 1 from public.companies where id=p_company_id and active=true) then
    raise exception 'INVALID_COMPANY';
  end if;
  if v_phone is null or length(v_phone) < 9 or length(v_phone) > 15 then
    raise exception 'VALID_PHONE_REQUIRED';
  end if;

  perform pg_advisory_xact_lock(hashtextextended('customer-phone:'||p_company_id::text||':'||v_phone, 0));

  -- Existing web profile for this auth user: update safely and return it.
  select * into v_row
  from public.customers
  where company_id=p_company_id and auth_user_id=v_uid and active=true
  order by created_at asc
  limit 1
  for update;

  if v_row.id is not null then
    select count(*) into v_other_linked
    from public.customers
    where company_id=p_company_id
      and phone_normalized=v_phone
      and active=true
      and auth_user_id is not null
      and auth_user_id<>v_uid;
    if v_other_linked>0 then raise exception 'PHONE_ALREADY_REGISTERED'; end if;

    update public.customers
    set name=coalesce(nullif(btrim(p_name),''),name),
        phone=btrim(p_phone),
        email=coalesce(nullif(btrim(coalesce(p_email,'')),''),email),
        date_of_birth=coalesce(p_date_of_birth,date_of_birth),
        updated_at=now()
    where id=v_row.id
    returning * into v_row;

    insert into public.loyalty_accounts(company_id,customer_id,balance)
    values(v_row.company_id,v_row.id,0)
    on conflict(customer_id) do nothing;

    return to_jsonb(v_row);
  end if;

  -- Never let a new web account take over a phone already linked to someone else.
  if exists(
    select 1 from public.customers
    where company_id=p_company_id and phone_normalized=v_phone and active=true and auth_user_id is not null
  ) then
    raise exception 'PHONE_ALREADY_REGISTERED';
  end if;

  select count(*) into v_count
  from public.customers
  where company_id=p_company_id and phone_normalized=v_phone and active=true and auth_user_id is null;

  if v_count>1 then raise exception 'PHONE_DUPLICATE_NEEDS_ADMIN'; end if;

  if v_count=1 then
    select * into v_row
    from public.customers
    where company_id=p_company_id and phone_normalized=v_phone and active=true and auth_user_id is null
    limit 1
    for update;

    update public.customers
    set auth_user_id=v_uid,
        name=coalesce(nullif(btrim(p_name),''),name),
        phone=btrim(p_phone),
        email=coalesce(nullif(btrim(coalesce(p_email,'')),''),email),
        date_of_birth=coalesce(p_date_of_birth,date_of_birth),
        updated_at=now()
    where id=v_row.id
    returning * into v_row;
  else
    insert into public.customers(
      company_id,customer_code,name,phone,email,date_of_birth,auth_user_id,active
    ) values(
      p_company_id,
      'RTQ-'||upper(substr(encode(gen_random_bytes(5),'hex'),1,10)),
      coalesce(nullif(btrim(p_name),''),'Member '||right(v_phone,4)),
      btrim(p_phone),
      nullif(btrim(coalesce(p_email,'')),''),
      p_date_of_birth,
      v_uid,
      true
    ) returning * into v_row;
  end if;

  insert into public.loyalty_accounts(company_id,customer_id,balance)
  values(v_row.company_id,v_row.id,0)
  on conflict(customer_id) do nothing;

  return to_jsonb(v_row);
end;
$$;

-- POS: exact phone lookup. If no record exists, create a lightweight member row
-- immediately so the current sale can earn points even before the customer uses PWA.
create or replace function public.rt_pos_find_or_create_customer(
  p_phone text,
  p_name text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  s record;
  v_phone text := public.rt_normalize_phone(p_phone);
  v_row public.customers%rowtype;
  v_count integer := 0;
  v_balance integer := 0;
begin
  select * into s from public.rt_staff_context() limit 1;
  if s.staff_id is null then raise exception 'STAFF_CONTEXT_NOT_FOUND'; end if;
  if lower(coalesce(s.role,'')) not in ('owner','admin','super_admin','manager','cashier','pos') then
    raise exception 'POS_ROLE_NOT_ALLOWED';
  end if;
  if v_phone is null or length(v_phone) < 9 or length(v_phone) > 15 then
    raise exception 'VALID_PHONE_REQUIRED';
  end if;

  perform pg_advisory_xact_lock(hashtextextended('customer-phone:'||s.company_id::text||':'||v_phone, 0));

  select count(*) into v_count
  from public.customers
  where company_id=s.company_id and phone_normalized=v_phone and active=true;

  if v_count>1 then raise exception 'DUPLICATE_PHONE_NEEDS_ADMIN'; end if;

  if v_count=1 then
    select * into v_row
    from public.customers
    where company_id=s.company_id and phone_normalized=v_phone and active=true
    limit 1
    for update;
    if nullif(btrim(coalesce(p_name,'')),'') is not null and (v_row.name is null or v_row.name like 'Member %') then
      update public.customers set name=btrim(p_name),updated_at=now() where id=v_row.id returning * into v_row;
    end if;
  else
    insert into public.customers(company_id,customer_code,name,phone,active)
    values(
      s.company_id,
      'RTQ-'||upper(substr(encode(gen_random_bytes(5),'hex'),1,10)),
      coalesce(nullif(btrim(p_name),''),'Member '||right(v_phone,4)),
      btrim(p_phone),
      true
    ) returning * into v_row;
  end if;

  insert into public.loyalty_accounts(company_id,customer_id,balance)
  values(v_row.company_id,v_row.id,0)
  on conflict(customer_id) do nothing;

  select coalesce(balance,0) into v_balance
  from public.loyalty_accounts where customer_id=v_row.id limit 1;

  return jsonb_build_object(
    'customer_id',v_row.id,
    'name',v_row.name,
    'phone',v_row.phone,
    'phone_normalized',v_row.phone_normalized,
    'points',coalesce(v_balance,0),
    'web_registered',v_row.auth_user_id is not null,
    'created_now',v_count=0
  );
end;
$$;

-- POS summary is read-only: points plus vouchers the customer has already claimed in PWA.
create or replace function public.rt_pos_customer_member_summary(p_customer_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  s record;
  c public.customers%rowtype;
  v_balance integer := 0;
  v_vouchers jsonb := '[]'::jsonb;
begin
  select * into s from public.rt_staff_context() limit 1;
  if s.staff_id is null then raise exception 'STAFF_CONTEXT_NOT_FOUND'; end if;
  if lower(coalesce(s.role,'')) not in ('owner','admin','super_admin','manager','cashier','pos') then
    raise exception 'POS_ROLE_NOT_ALLOWED';
  end if;

  select * into c from public.customers
  where id=p_customer_id and company_id=s.company_id and active=true
  limit 1;
  if c.id is null then raise exception 'CUSTOMER_NOT_FOUND'; end if;

  select coalesce(balance,0) into v_balance
  from public.loyalty_accounts where customer_id=c.id limit 1;

  select coalesce(jsonb_agg(jsonb_build_object(
    'id',lv.id,
    'code',lv.code,
    'reward_name',lv.reward_name,
    'reward_type',lv.reward_type,
    'discount_value',lv.discount_value,
    'max_discount',lv.max_discount,
    'minimum_spend',lv.minimum_spend,
    'service_code',lv.service_code,
    'expires_at',lv.expires_at,
    'status',lv.status
  ) order by lv.issued_at desc),'[]'::jsonb)
  into v_vouchers
  from public.loyalty_vouchers lv
  where lv.company_id=s.company_id
    and lv.customer_id=c.id
    and lv.status='UNUSED'
    and lv.expires_at>=now();

  return jsonb_build_object(
    'customer_id',c.id,
    'name',c.name,
    'phone',c.phone,
    'phone_normalized',c.phone_normalized,
    'points',coalesce(v_balance,0),
    'web_registered',c.auth_user_id is not null,
    'claimed_vouchers',v_vouchers
  );
end;
$$;

-- Canonical spend-based loyalty. RM1 of eligible final spend = 1 point.
-- Dyno lines are excluded. Item discounts are already reflected in line_total;
-- order/promo/voucher discount is allocated proportionally before flooring points.
create or replace function public.rt_award_spend_loyalty_on_paid_invoice()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_phone text;
  v_eligible_before_order_discount numeric := 0;
  v_eligible_after_order_discount numeric := 0;
  v_order_discount numeric := greatest(0,coalesce(new.discount,0));
  v_subtotal numeric := greatest(0,coalesce(new.subtotal,0));
  v_points integer := 0;
begin
  if upper(coalesce(new.status,'')) <> 'PAID'
     or upper(coalesce(new.payment_status,'')) <> 'PAID' then
    return new;
  end if;

  if tg_op='UPDATE'
     and upper(coalesce(old.status,''))='PAID'
     and upper(coalesce(old.payment_status,''))='PAID' then
    return new;
  end if;

  if new.customer_id is null then return new; end if;

  select phone_normalized into v_phone
  from public.customers
  where id=new.customer_id and company_id=new.company_id and active=true
  limit 1;

  -- Business rule: customer must have a registered phone number to earn points.
  if v_phone is null then return new; end if;

  select coalesce(sum(ii.line_total),0)
  into v_eligible_before_order_discount
  from public.invoice_items ii
  left join public.products p on p.id=ii.product_id
  where ii.invoice_id=new.id
    and upper(coalesce(p.category,'')||' '||coalesce(p.name,'')||' '||coalesce(ii.description,'')) not like '%DYNO%';

  if v_eligible_before_order_discount<=0 then
    insert into public.notifications(company_id,customer_id,title,body,notification_type,dedupe_key,created_at)
    values(new.company_id,new.customer_id,'Bayaran diterima',
      'Invoice '||coalesce(new.invoice_no,'')||' telah dibayar. Item transaksi ini tidak mengumpul point.',
      'PAYMENT_UPDATE','invoice-paid-notification:'||new.id::text,now())
    on conflict do nothing;
    return new;
  end if;

  if v_subtotal>0 and v_order_discount>0 then
    v_eligible_after_order_discount := greatest(
      0,
      v_eligible_before_order_discount - (v_order_discount * (v_eligible_before_order_discount / v_subtotal))
    );
  else
    v_eligible_after_order_discount := v_eligible_before_order_discount;
  end if;

  v_points := floor(round(v_eligible_after_order_discount,2))::integer;

  if v_points>0 then
    perform public.rt_add_loyalty_points(
      new.customer_id,
      v_points,
      'POS_SPEND',
      format('Belanja layak invoice %s · +%s point',coalesce(new.invoice_no,new.id::text),v_points),
      'INVOICE',
      new.id,
      'invoice-spend-loyalty:'||new.id::text
    );

    insert into public.notifications(company_id,customer_id,title,body,notification_type,dedupe_key,created_at)
    values(
      new.company_id,new.customer_id,'Point REV TORQ masuk',
      format('+%s point untuk invoice %s.',v_points,coalesce(new.invoice_no,new.id::text)),
      'LOYALTY','invoice-spend-loyalty-notification:'||new.id::text,now()
    ) on conflict do nothing;
  else
    insert into public.notifications(company_id,customer_id,title,body,notification_type,dedupe_key,created_at)
    values(new.company_id,new.customer_id,'Bayaran diterima',
      'Invoice '||coalesce(new.invoice_no,'')||' telah dibayar.',
      'PAYMENT_UPDATE','invoice-paid-notification:'||new.id::text,now())
    on conflict do nothing;
  end if;

  return new;
end;
$$;

-- Remove old fixed-service loyalty triggers to prevent double earning.
drop trigger if exists trg_award_loyalty_on_paid_invoice on public.invoices;
drop trigger if exists trg_customer_invoice_paid_loyalty on public.invoices;
drop trigger if exists trg_booking_loyalty on public.bookings;
drop trigger if exists trg_rt_award_booking_loyalty on public.bookings;

drop trigger if exists trg_rt_award_spend_loyalty on public.invoices;
create trigger trg_rt_award_spend_loyalty
after insert or update of status, payment_status on public.invoices
for each row execute function public.rt_award_spend_loyalty_on_paid_invoice();

-- New deliberate claim catalog. Old reward rows and issued vouchers are preserved.
-- Only rows tagged catalog_claim=true are shown by the new PWA catalog.
with seed(code,name,value,cost) as (
  values
    ('RM5','RM5 OFF',5::numeric,500::integer),
    ('RM10','RM10 OFF',10::numeric,1000::integer),
    ('RM20','RM20 OFF',20::numeric,2000::integer)
)
insert into public.loyalty_rewards(
  company_id,name,reward_type,discount_value,max_discount,minimum_spend,
  points_cost,probability,active,description,expires_days,metadata
)
select
  c.id,seed.name,'FIXED_DISCOUNT',seed.value,null,0,
  seed.cost,0,true,
  seed.cost::text||' point → '||seed.name,
  30,
  jsonb_build_object('catalog_claim',true,'source','spend_rewards_v1','code',seed.code)
from public.companies c
cross join seed
where c.active=true
  and not exists(
    select 1 from public.loyalty_rewards lr
    where lr.company_id=c.id
      and lr.metadata->>'source'='spend_rewards_v1'
      and lr.metadata->>'code'=seed.code
  );

revoke all on function public.rt_customer_claim_or_create_profile(uuid,text,text,text,date) from public, anon, authenticated;
revoke all on function public.rt_pos_find_or_create_customer(text,text) from public, anon, authenticated;
revoke all on function public.rt_pos_customer_member_summary(uuid) from public, anon, authenticated;

grant execute on function public.rt_customer_claim_or_create_profile(uuid,text,text,text,date) to authenticated;
grant execute on function public.rt_pos_find_or_create_customer(text,text) to authenticated;
grant execute on function public.rt_pos_customer_member_summary(uuid) to authenticated;

-- Atomic loyalty-voucher checkout wrappers. The POS sends only the claimed
-- voucher code; the database revalidates ownership/value, posts the sale and
-- marks the voucher REDEEMED in the same transaction.
create or replace function public.rt_loyalty_voucher_discount_locked(
  p_company_id uuid,
  p_customer_id uuid,
  p_code text,
  p_subtotal numeric
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v public.loyalty_vouchers%rowtype;
  v_base numeric := greatest(0,coalesce(p_subtotal,0));
  v_discount numeric := 0;
begin
  if p_customer_id is null then raise exception 'VOUCHER_CUSTOMER_REQUIRED'; end if;
  if nullif(btrim(coalesce(p_code,'')),'') is null then raise exception 'VOUCHER_CODE_REQUIRED'; end if;

  select * into v
  from public.loyalty_vouchers
  where company_id=p_company_id
    and customer_id=p_customer_id
    and upper(code)=upper(btrim(p_code))
  limit 1
  for update;

  if v.id is null then raise exception 'VOUCHER_NOT_FOUND'; end if;
  if v.status<>'UNUSED' then raise exception 'VOUCHER_ALREADY_USED'; end if;
  if v.expires_at<now() then
    update public.loyalty_vouchers set status='EXPIRED',updated_at=now() where id=v.id;
    raise exception 'VOUCHER_EXPIRED';
  end if;
  if v_base < greatest(0,coalesce(v.minimum_spend,0)) then raise exception 'VOUCHER_MINIMUM_SPEND_NOT_MET'; end if;

  if upper(coalesce(v.reward_type,''))='PERCENT_DISCOUNT' then
    v_discount := v_base * greatest(0,coalesce(v.discount_value,0)) / 100;
    if v.max_discount is not null then v_discount:=least(v_discount,greatest(0,v.max_discount)); end if;
  elsif upper(coalesce(v.reward_type,''))='FIXED_DISCOUNT' then
    v_discount := least(v_base,greatest(0,coalesce(v.discount_value,0)));
  else
    raise exception 'VOUCHER_TYPE_NOT_SUPPORTED_AT_POS';
  end if;

  v_discount:=round(least(v_base,greatest(0,v_discount)),2);
  if v_discount<=0 then raise exception 'VOUCHER_ZERO_DISCOUNT'; end if;

  return jsonb_build_object(
    'voucher_id',v.id,
    'code',v.code,
    'reward_name',v.reward_name,
    'reward_type',v.reward_type,
    'discount_amount',v_discount,
    'expires_at',v.expires_at
  );
end;
$$;

create or replace function public.rt_post_pos_sale_with_loyalty_voucher(
  p_customer_id uuid,
  p_vehicle_id uuid default null,
  p_location_id uuid default null,
  p_payment_method text default 'CASH',
  p_amount_received numeric default 0,
  p_reference_no text default null,
  p_transaction_id uuid default null,
  p_items jsonb default '[]'::jsonb,
  p_voucher_code text default null
)
returns table(
  invoice_id uuid,
  invoice_no text,
  total numeric,
  change_amount numeric,
  voucher_code text,
  reward_name text,
  voucher_discount numeric
)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  s record;
  v_base numeric:=0;
  v_info jsonb;
  v_sale record;
  v_voucher_id uuid;
begin
  select * into s from public.rt_staff_context() limit 1;
  if s.staff_id is null then raise exception 'STAFF_CONTEXT_NOT_FOUND'; end if;
  if lower(coalesce(s.role,'')) not in ('owner','admin','super_admin','manager','cashier','pos') then raise exception 'POS_ROLE_NOT_ALLOWED'; end if;
  if p_customer_id is null then raise exception 'VOUCHER_CUSTOMER_REQUIRED'; end if;

  v_base:=public.rt_pos_items_net_subtotal(s.company_id,p_items);
  v_info:=public.rt_loyalty_voucher_discount_locked(s.company_id,p_customer_id,p_voucher_code,v_base);
  v_voucher_id:=(v_info->>'voucher_id')::uuid;

  for v_sale in
    select * from public.rt_post_pos_sale(
      p_customer_id,p_vehicle_id,p_location_id,p_payment_method,
      p_amount_received,(v_info->>'discount_amount')::numeric,
      p_reference_no,p_transaction_id,p_items
    )
  loop
    update public.loyalty_vouchers
    set status='REDEEMED',redeemed_at=now(),redeemed_by=s.staff_id,
        redeemed_invoice_id=v_sale.invoice_id,updated_at=now()
    where id=v_voucher_id and status='UNUSED';
    if not found then raise exception 'VOUCHER_ALREADY_USED'; end if;

    invoice_id:=v_sale.invoice_id;
    invoice_no:=v_sale.invoice_no;
    total:=v_sale.total;
    change_amount:=v_sale.change_amount;
    voucher_code:=v_info->>'code';
    reward_name:=v_info->>'reward_name';
    voucher_discount:=(v_info->>'discount_amount')::numeric;
    return next;
  end loop;
end;
$$;

create or replace function public.rt_post_job_pos_sale_with_loyalty_voucher(
  p_job_card_id uuid,
  p_customer_id uuid,
  p_payment_method text default 'CASH',
  p_amount_received numeric default 0,
  p_items jsonb default '[]'::jsonb,
  p_voucher_code text default null
)
returns table(
  invoice_id uuid,
  invoice_no text,
  total numeric,
  change_amount numeric,
  voucher_code text,
  reward_name text,
  voucher_discount numeric
)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  s record;
  v_base numeric:=0;
  v_info jsonb;
  v_sale record;
  v_voucher_id uuid;
begin
  select * into s from public.rt_staff_context() limit 1;
  if s.staff_id is null then raise exception 'STAFF_CONTEXT_NOT_FOUND'; end if;
  if lower(coalesce(s.role,'')) not in ('owner','admin','super_admin','manager','cashier','pos') then raise exception 'POS_ROLE_NOT_ALLOWED'; end if;
  if p_customer_id is null then raise exception 'VOUCHER_CUSTOMER_REQUIRED'; end if;

  v_base:=public.rt_job_items_net_subtotal(s.company_id,p_job_card_id,p_items);
  v_info:=public.rt_loyalty_voucher_discount_locked(s.company_id,p_customer_id,p_voucher_code,v_base);
  v_voucher_id:=(v_info->>'voucher_id')::uuid;

  for v_sale in
    select * from public.rt_post_job_pos_sale(
      p_job_card_id,p_customer_id,p_payment_method,p_amount_received,
      (v_info->>'discount_amount')::numeric,p_items
    )
  loop
    update public.loyalty_vouchers
    set status='REDEEMED',redeemed_at=now(),redeemed_by=s.staff_id,
        redeemed_invoice_id=v_sale.invoice_id,updated_at=now()
    where id=v_voucher_id and status='UNUSED';
    if not found then raise exception 'VOUCHER_ALREADY_USED'; end if;

    invoice_id:=v_sale.invoice_id;
    invoice_no:=v_sale.invoice_no;
    total:=v_sale.total;
    change_amount:=v_sale.change_amount;
    voucher_code:=v_info->>'code';
    reward_name:=v_info->>'reward_name';
    voucher_discount:=(v_info->>'discount_amount')::numeric;
    return next;
  end loop;
end;
$$;

revoke all on function public.rt_loyalty_voucher_discount_locked(uuid,uuid,text,numeric) from public,anon,authenticated;
revoke all on function public.rt_post_pos_sale_with_loyalty_voucher(uuid,uuid,uuid,text,numeric,text,uuid,jsonb,text) from public,anon,authenticated;
revoke all on function public.rt_post_job_pos_sale_with_loyalty_voucher(uuid,uuid,text,numeric,jsonb,text) from public,anon,authenticated;
grant execute on function public.rt_post_pos_sale_with_loyalty_voucher(uuid,uuid,uuid,text,numeric,text,uuid,jsonb,text) to authenticated;
grant execute on function public.rt_post_job_pos_sale_with_loyalty_voucher(uuid,uuid,text,numeric,jsonb,text) to authenticated;

revoke all on function public.rt_award_spend_loyalty_on_paid_invoice() from public,anon,authenticated;
