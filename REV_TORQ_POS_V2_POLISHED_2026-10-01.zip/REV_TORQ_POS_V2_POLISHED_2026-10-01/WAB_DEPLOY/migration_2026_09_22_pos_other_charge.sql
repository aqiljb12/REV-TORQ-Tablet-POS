-- CAJ LAIN is already persisted as an invoice_items row of type OTHER.
-- Exclude only its marked, productless line from promo/voucher eligibility;
-- rt_post_pos_sale still includes the line in subtotal and total.
create or replace function public.rt_pos_items_net_subtotal(
  p_company_id uuid,
  p_items jsonb
)
returns numeric
language plpgsql
security definer
set search_path to 'public','pg_temp'
as $function$
declare
  item jsonb;
  prod public.products%rowtype;
  qty numeric;
  price numeric;
  gross_line numeric;
  line_discount numeric;
  total numeric:=0;
begin
  if jsonb_typeof(coalesce(p_items,'[]'::jsonb)) <> 'array' then return 0; end if;

  for item in select * from jsonb_array_elements(coalesce(p_items,'[]'::jsonb))
  loop
    if upper(coalesce(item->>'item_type','PART'))='OTHER'
       and nullif(item->>'product_id','') is null
       and coalesce(item->>'other_charge','false')='true' then
      continue;
    end if;

    qty:=greatest(0,coalesce(nullif(item->>'quantity','')::numeric,0));
    if upper(coalesce(item->>'item_type','PART')) in ('SERVICE','LABOUR','OTHER')
       and nullif(item->>'product_id','') is null then
      price:=greatest(0,coalesce(nullif(item->>'unit_price','')::numeric,0));
    else
      select * into prod
      from public.products p
      where p.id=nullif(item->>'product_id','')::uuid
        and p.company_id=p_company_id
        and p.active=true;
      if prod.id is null then raise exception 'PRODUCT_NOT_FOUND'; end if;
      price:=greatest(0,coalesce(prod.sell_price,0));
    end if;

    gross_line:=round(qty*price,2);
    line_discount:=least(gross_line,greatest(0,coalesce(nullif(item->>'discount','')::numeric,0)));
    total:=total+round(greatest(0,gross_line-line_discount),2);
  end loop;

  return round(total,2);
end;
$function$;
