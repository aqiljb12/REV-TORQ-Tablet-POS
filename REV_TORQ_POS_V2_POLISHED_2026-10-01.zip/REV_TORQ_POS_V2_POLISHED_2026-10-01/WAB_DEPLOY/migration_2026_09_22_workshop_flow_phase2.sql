-- Apply after the existing Job sale, promotion, voucher, and Phase 1 POS migrations.
-- One additive RPC: caller transaction ID and Job Card PART stock deduction in one SQL transaction.
create or replace function public.rt_post_job_pos_sale_idempotent(
  p_transaction_id uuid,
  p_job_card_id uuid,
  p_kind text default 'STANDARD',
  p_customer_id uuid default null,
  p_payment_method text default 'CASH',
  p_amount_received numeric default 0,
  p_discount numeric default 0,
  p_items jsonb default '[]'::jsonb,
  p_promotion_id uuid default null,
  p_promo_code text default null,
  p_voucher_code text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  v_staff record;
  v_job public.job_cards%rowtype;
  v_invoice public.invoices%rowtype;
  v_sale jsonb;
  v_old_tx uuid;
  v_item jsonb;
  v_job_item public.job_card_items%rowtype;
  v_product public.products%rowtype;
  v_location uuid;
  v_qty numeric;
  v_stock numeric;
  v_part_ids uuid[] := array[]::uuid[];
begin
  if p_transaction_id is null or p_job_card_id is null then raise exception 'TRANSACTION_OR_JOB_REQUIRED'; end if;
  if upper(coalesce(p_kind,'')) not in ('STANDARD','PROMO','VOUCHER') then raise exception 'JOB_SALE_KIND_INVALID'; end if;
  select * into v_staff from public.rt_staff_context() limit 1;
  if v_staff.staff_id is null or lower(coalesce(v_staff.role,'')) not in
    ('owner','admin','super_admin','manager','cashier','pos') then
    raise exception 'POS_ROLE_NOT_ALLOWED';
  end if;

  -- The job lock serializes both same-ID retries and different-ID checkout attempts.
  select * into v_job from public.job_cards
  where id=p_job_card_id and company_id=v_staff.company_id for update;
  if v_job.id is null then raise exception 'JOB_CARD_NOT_FOUND'; end if;
  if p_customer_id is not null and v_job.customer_id is not null
    and p_customer_id is distinct from v_job.customer_id then
    raise exception 'JOB_CUSTOMER_MISMATCH';
  end if;

  select * into v_invoice from public.invoices
  where transaction_id=p_transaction_id limit 1;
  if v_invoice.id is not null then
    if v_invoice.company_id is distinct from v_staff.company_id
      or v_invoice.job_card_id is distinct from v_job.id
      or v_invoice.status <> 'PAID' or v_invoice.payment_status <> 'PAID' then
      raise exception 'TRANSACTION_ID_CONFLICT';
    end if;
    return jsonb_build_object('invoice_id',v_invoice.id,'invoice_no',v_invoice.invoice_no,
      'total',v_invoice.total,'transaction_id',p_transaction_id);
  end if;

  if upper(p_kind)='VOUCHER' then
    select to_jsonb(s) into v_sale from public.rt_post_job_pos_sale_with_loyalty_voucher(
      p_job_card_id,coalesce(v_job.customer_id,p_customer_id),p_payment_method,p_amount_received,p_items,p_voucher_code) s;
  elsif upper(p_kind)='PROMO' then
    select to_jsonb(s) into v_sale from public.rt_post_job_pos_sale_with_promo(
      p_job_card_id,coalesce(v_job.customer_id,p_customer_id),p_payment_method,p_amount_received,p_items,0,
      p_promotion_id,p_promo_code) s;
  else
    select to_jsonb(s) into v_sale from public.rt_post_job_pos_sale(
      p_job_card_id,coalesce(v_job.customer_id,p_customer_id),p_payment_method,p_amount_received,p_discount,p_items) s;
  end if;
  if v_sale is null or nullif(v_sale->>'invoice_id','') is null then
    raise exception 'JOB_SALE_NO_INVOICE';
  end if;

  select * into v_invoice from public.invoices
  where id=(v_sale->>'invoice_id')::uuid and company_id=v_staff.company_id and job_card_id=v_job.id for update;
  if v_invoice.id is null then raise exception 'JOB_SALE_INVOICE_MISMATCH'; end if;
  v_old_tx:=v_invoice.transaction_id;
  v_location:=v_invoice.location_id;

  -- Legacy Job RPCs mint their own UUID. Replace it throughout the committed sale
  -- before returning, so lookup after a lost HTTP response finds this invoice.
  update public.invoices set transaction_id=p_transaction_id where id=v_invoice.id;
  update public.payments set transaction_id=p_transaction_id
    where company_id=v_staff.company_id and invoice_id=v_invoice.id and transaction_id=v_old_tx;
  update public.stock_movements set transaction_id=p_transaction_id
    where company_id=v_staff.company_id and reference_type='INVOICE'
      and reference_id=v_invoice.id and transaction_id=v_old_tx;
  update public.cash_movements set transaction_id=p_transaction_id
    where company_id=v_staff.company_id and reference_type='INVOICE'
      and reference_id=v_invoice.id and transaction_id=v_old_tx;
  update public.audit_logs set transaction_id=p_transaction_id
    where company_id=v_staff.company_id and entity_type='INVOICE'
      and entity_id=v_invoice.id and transaction_id=v_old_tx;
  update public.sync_events set transaction_id=p_transaction_id
    where company_id=v_staff.company_id and entity_id=v_invoice.id and transaction_id=v_old_tx;

  -- The legacy Job RPC invoices Job Card PART items but does not deduct their stock.
  -- A failure here rolls back the invoice, payment, voucher/promo, and Job status too.
  for v_item in select * from jsonb_array_elements(p_items) loop
    if upper(coalesce(v_item->>'item_type',''))='PART'
      and coalesce((v_item->>'from_job_card')::boolean,false) then
      select * into v_job_item from public.job_card_items
      where id=nullif(v_item->>'job_card_item_id','')::uuid
        and job_card_id=v_job.id and company_id=v_staff.company_id;
      if v_job_item.id is null or v_job_item.product_id is null
        or upper(coalesce(v_job_item.item_type,''))<>'PART'
        or v_job_item.product_id is distinct from nullif(v_item->>'product_id','')::uuid then
        raise exception 'JOB_PART_INVALID';
      end if;
      if v_job_item.id=any(v_part_ids) then raise exception 'JOB_PART_DUPLICATE'; end if;
      v_part_ids:=array_append(v_part_ids,v_job_item.id);
      v_qty:=(v_item->>'quantity')::numeric;
      if v_qty is null or v_qty<=0 or v_qty is distinct from v_job_item.quantity then
        raise exception 'JOB_PART_QUANTITY_MISMATCH';
      end if;
      select * into v_product from public.products
      where id=v_job_item.product_id and company_id=v_staff.company_id and active=true;
      if v_product.id is null then raise exception 'JOB_PART_PRODUCT_NOT_FOUND'; end if;
      select quantity into v_stock from public.stock_balances
      where product_id=v_job_item.product_id and location_id=v_location for update;
      if coalesce(v_stock,0)<v_qty then raise exception 'JOB_PART_STOCK_INSUFFICIENT: %',v_product.name; end if;
      update public.stock_balances set quantity=quantity-v_qty,updated_at=now()
      where product_id=v_job_item.product_id and location_id=v_location;
      insert into public.stock_movements(
        company_id,location_id,product_id,transaction_id,movement_type,quantity,
        unit_cost,reference_type,reference_id,staff_id
      ) values (
        v_staff.company_id,v_location,v_job_item.product_id,p_transaction_id,'SALE',-v_qty,
        v_product.cost_price,'INVOICE',v_invoice.id,v_staff.staff_id
      );
    end if;
  end loop;
  return v_sale||jsonb_build_object('transaction_id',p_transaction_id);
end;
$function$;

revoke all on function public.rt_post_job_pos_sale_idempotent(uuid,uuid,text,uuid,text,numeric,numeric,jsonb,uuid,text,text) from public,anon,authenticated;
grant execute on function public.rt_post_job_pos_sale_idempotent(uuid,uuid,text,uuid,text,numeric,numeric,jsonb,uuid,text,text) to authenticated;
