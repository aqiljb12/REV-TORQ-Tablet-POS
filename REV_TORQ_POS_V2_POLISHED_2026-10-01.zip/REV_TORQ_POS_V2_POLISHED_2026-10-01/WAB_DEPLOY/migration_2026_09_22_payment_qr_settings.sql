-- Phase 3: reuse app_settings for one payment QR per company/location.
-- QR images are bounded data URLs, so no public Storage bucket or RLS change is needed.
create or replace function public.rt_payment_qr_get()
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  s record;
  loc uuid;
  saved jsonb;
begin
  select * into s from public.rt_staff_context() limit 1;
  if s.staff_id is null or lower(coalesce(s.role,'')) not in
    ('owner','admin','super_admin','manager','staff','cashier','pos') then
    raise exception 'POS_ROLE_NOT_ALLOWED';
  end if;
  loc:=s.location_id;
  if loc is null then
    select id into loc from public.locations
      where company_id=s.company_id and active=true order by code limit 1;
  end if;
  if loc is null then raise exception 'QR_LOCATION_NOT_FOUND'; end if;
  select setting_value into saved from public.app_settings
    where company_id=s.company_id and location_id=loc and setting_key='payment_qr_v1'
    order by updated_at desc limit 1;
  return coalesce(saved,jsonb_build_object('active',false,'label','QR / DuitNow'));
end;
$function$;

create or replace function public.rt_payment_qr_save(p_settings jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  s record;
  loc uuid;
  image_data text;
  merchant text;
  provider text;
  label_text text;
  note_text text;
  enabled boolean;
  saved jsonb;
begin
  select * into s from public.rt_staff_context() limit 1;
  if s.staff_id is null or lower(coalesce(s.role,'')) not in
    ('owner','admin','super_admin') then
    raise exception 'QR_SETTINGS_ADMIN_ONLY';
  end if;
  if p_settings is null or jsonb_typeof(p_settings)<>'object' then
    raise exception 'QR_SETTINGS_INVALID';
  end if;
  loc:=s.location_id;
  if loc is null then
    select id into loc from public.locations
      where company_id=s.company_id and active=true order by code limit 1;
  end if;
  if loc is null then raise exception 'QR_LOCATION_NOT_FOUND'; end if;

  image_data:=nullif(p_settings->>'image_data','');
  merchant:=left(btrim(coalesce(p_settings->>'merchant_name','')),120);
  provider:=left(btrim(coalesce(p_settings->>'provider_name','')),120);
  label_text:=left(btrim(coalesce(p_settings->>'label','')),80);
  note_text:=left(btrim(coalesce(p_settings->>'note','')),300);
  enabled:=coalesce((p_settings->>'active')::boolean,false);
  if image_data is not null and
    (length(image_data)>1400000 or image_data !~ '^data:image/(png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$') then
    raise exception 'QR_IMAGE_INVALID';
  end if;
  if enabled and (image_data is null or merchant='' or provider='') then
    raise exception 'QR_ACTIVE_REQUIRES_IMAGE_MERCHANT_PROVIDER';
  end if;
  saved:=jsonb_build_object(
    'active',enabled,'image_data',image_data,'merchant_name',merchant,
    'provider_name',provider,'label',coalesce(nullif(label_text,''),'QR / DuitNow'),
    'note',note_text
  );
  insert into public.app_settings(company_id,location_id,setting_key,setting_value,updated_by)
  values(s.company_id,loc,'payment_qr_v1',saved,s.staff_id)
  on conflict (company_id,location_id,setting_key)
  do update set setting_value=excluded.setting_value,updated_by=excluded.updated_by,updated_at=now();
  return saved;
end;
$function$;

revoke all on function public.rt_payment_qr_get() from public,anon,authenticated;
revoke all on function public.rt_payment_qr_save(jsonb) from public,anon,authenticated;
grant execute on function public.rt_payment_qr_get() to authenticated;
grant execute on function public.rt_payment_qr_save(jsonb) to authenticated;
