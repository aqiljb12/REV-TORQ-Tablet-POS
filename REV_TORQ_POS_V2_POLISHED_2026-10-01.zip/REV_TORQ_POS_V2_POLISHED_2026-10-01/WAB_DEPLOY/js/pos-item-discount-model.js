(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.RTPosDiscountModel=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  const round2=v=>Math.round((Number(v||0)+Number.EPSILON)*100)/100;
  function lineGross(item){return round2(Math.max(0,Number(item?.qty??item?.quantity??0))*Math.max(0,Number(item?.price??item?.unitPrice??0)));}
  function normalizeLineDiscount(value,qty,price){
    const gross=round2(Math.max(0,Number(qty||0))*Math.max(0,Number(price||0)));
    const n=Math.max(0,Number(value||0));
    return round2(Math.min(n,gross));
  }
  function itemDiscount(item){return normalizeLineDiscount(item?.discount,item?.qty??item?.quantity,item?.price??item?.unitPrice);}
  function cartTotals(cart,orderDiscount){
    const list=Array.isArray(cart)?cart:[];
    const grossSubtotal=round2(list.reduce((s,i)=>s+lineGross(i),0));
    const itemDiscountTotal=round2(list.reduce((s,i)=>s+itemDiscount(i),0));
    const netBeforeOrderDiscount=round2(Math.max(0,grossSubtotal-itemDiscountTotal));
    const order=round2(Math.min(Math.max(0,Number(orderDiscount||0)),netBeforeOrderDiscount));
    return {grossSubtotal,itemDiscount:itemDiscountTotal,netBeforeOrderDiscount,orderDiscount:order,total:round2(Math.max(0,netBeforeOrderDiscount-order))};
  }
  function buildCheckoutItems(cart){
    return (Array.isArray(cart)?cart:[]).map(i=>({
      ...i,
      quantity:Number(i?.qty??i?.quantity??0),
      discount:itemDiscount(i)
    }));
  }
  function receiptDiscountSummary(inv){
    const items=Array.isArray(inv?.items)?inv.items:[];
    const grossSubtotal=round2(items.reduce((s,i)=>s+lineGross(i),0));
    const itemDiscountTotal=round2(items.reduce((s,i)=>s+itemDiscount(i),0));
    const orderDiscount=round2(Math.max(0,Number(inv?.orderDiscount??inv?.discount??0)));
    const totalDiscount=round2(itemDiscountTotal+orderDiscount);
    const total=Number.isFinite(Number(inv?.total))?round2(inv.total):round2(Math.max(0,grossSubtotal-totalDiscount));
    return {grossSubtotal,itemDiscount:itemDiscountTotal,orderDiscount,totalDiscount,total};
  }
  return {round2,lineGross,normalizeLineDiscount,itemDiscount,cartTotals,buildCheckoutItems,receiptDiscountSummary};
});
