/* Payment QR display/settings only. Sale/payment posting remains with canonical POS. */
(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  const qrMethod=method=>['QR','DUITNOW','QR / DUITNOW'].includes(String(method||'').toUpperCase());
  const validImage=value=>/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(String(value||''));
  const toast=(message,type='error')=>window.showToast?.(message,type);
  let current=null, imageData=null, confirmed=false, saveBusy=false, loading=null;

  async function fetchQr(){
    if(loading)return loading;
    loading=(async()=>{
      const sb=window.supabaseClient;
      if(!sb)throw new Error('Supabase belum tersedia.');
      const response=await sb.rpc('rt_payment_qr_get');
      if(response.error)throw response.error;
      current=response.data||{active:false};
      imageData=validImage(current.image_data)?current.image_data:null;
      return current;
    })();
    try{return await loading}finally{loading=null}
  }

  function setPreview(id,value){
    const img=$(id);if(!img)return;
    if(validImage(value)){img.src=value;img.classList.remove('hidden')}
    else {img.removeAttribute('src');img.classList.add('hidden')}
  }
  function renderCheckout(error=''){
    const panel=$('rtPaymentQrPanel');if(!panel)return;
    const selected=qrMethod(window.posPayMethod);
    panel.classList.toggle('hidden',!selected);
    if(!selected)return;
    const ready=!error&&current?.active===true&&validImage(current.image_data);
    $('rtPaymentQrCheckoutLabel').textContent=current?.label||'QR / DuitNow';
    $('rtPaymentQrCheckoutMerchant').textContent=current?.merchant_name||'';
    $('rtPaymentQrCheckoutProvider').textContent=current?.provider_name||'';
    $('rtPaymentQrCheckoutNote').textContent=current?.note||'';
    $('rtPaymentQrCheckoutStatus').textContent=error||(!ready?'QR tidak aktif / belum dikonfigurasi. Pilih kaedah bayaran lain.':'Sahkan bayaran dalam aplikasi bank sebelum checkout.');
    setPreview('rtPaymentQrCheckoutImage',ready?current.image_data:null);
    const checkbox=$('rtPaymentQrConfirm');
    if(checkbox){checkbox.checked=ready&&confirmed;checkbox.disabled=!ready}
  }
  async function showForMethod(method){
    confirmed=false;
    if(!qrMethod(method)){renderCheckout();return}
    current=null;renderCheckout('Memuatkan QR bayaran...');
    try{await fetchQr();renderCheckout()}catch(e){renderCheckout('QR tidak dapat dimuat: '+(e.message||e))}
  }
  function fillSettings(){
    const admin=window.rtHasAdminAccess?.()===true;
    for(const [id,key] of [['rtPaymentQrLabel','label'],['rtPaymentQrMerchant','merchant_name'],['rtPaymentQrProvider','provider_name'],['rtPaymentQrNote','note']]){
      const input=$(id);if(input){input.value=current?.[key]||'';input.disabled=!admin}
    }
    const active=$('rtPaymentQrActive');if(active){active.checked=current?.active===true;active.disabled=!admin}
    for(const id of ['rtPaymentQrFile','rtPaymentQrRemove','rtPaymentQrSave'])if($(id))$(id).disabled=!admin;
    setPreview('rtPaymentQrPreview',imageData);
    $('rtPaymentQrSettingsStatus').textContent=admin?'Admin boleh tukar QR. Staff mengesahkan bayaran secara manual.':'Tetapan QR boleh dilihat; admin sahaja boleh mengubahnya.';
  }
  async function loadSettings(){
    const status=$('rtPaymentQrSettingsStatus');if(status)status.textContent='Memuatkan QR...';
    try{await fetchQr();fillSettings()}catch(e){if(status)status.textContent='Gagal memuatkan QR: '+(e.message||e)}
  }
  function readImage(file){
    return new Promise((resolve,reject)=>{
      if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>1000000){reject(new Error('Pilih imej PNG/JPEG/WebP sehingga 1 MB.'));return}
      const reader=new FileReader();
      reader.onerror=()=>reject(new Error('Imej QR tidak dapat dibaca.'));
      reader.onload=()=>validImage(reader.result)?resolve(reader.result):reject(new Error('Format imej QR tidak sah.'));
      reader.readAsDataURL(file);
    });
  }
  async function save(){
    if(saveBusy)return;
    if(window.rtHasAdminAccess?.()!==true){toast('Admin sahaja boleh ubah QR.');return}
    const payload={label:$('rtPaymentQrLabel')?.value.trim()||'QR / DuitNow',
      merchant_name:$('rtPaymentQrMerchant')?.value.trim()||'',provider_name:$('rtPaymentQrProvider')?.value.trim()||'',
      note:$('rtPaymentQrNote')?.value.trim()||'',active:!!$('rtPaymentQrActive')?.checked,image_data:imageData};
    if(payload.active&&(!payload.image_data||!payload.merchant_name||!payload.provider_name)){
      toast('QR aktif perlukan imej, nama merchant dan provider.');return;
    }
    saveBusy=true;const button=$('rtPaymentQrSave');if(button)button.disabled=true;
    try{
      const response=await window.supabaseClient.rpc('rt_payment_qr_save',{p_settings:payload});
      if(response.error)throw response.error;
      current=response.data;imageData=validImage(current?.image_data)?current.image_data:null;
      confirmed=false;fillSettings();renderCheckout();toast('Tetapan QR disimpan.','success');
    }catch(e){toast('Gagal simpan QR: '+(e.message||e))}
    finally{saveBusy=false;if(button)button.disabled=false}
  }

  function readyForCheckout(){return !qrMethod(window.posPayMethod)||
    (current?.active===true&&validImage(current.image_data)&&confirmed&&$('rtPaymentQrConfirm')?.checked===true)}

  const originalMethod=window.posSetPaymentMethod;
  window.posSetPaymentMethod=function(method){
    const result=originalMethod?.apply(this,arguments);
    showForMethod(method);
    return result;
  };
  const originalCheckout=window.posCheckout;
  window.posCheckout=function(){
    if(!readyForCheckout()){
      toast('QR belum disahkan. Semak bayaran diterima atau pilih kaedah lain.');
      return;
    }
    return originalCheckout?.apply(this,arguments);
  };
  window.rtPaymentQr={loadSettings,showForMethod,readyForCheckout};
  window.addEventListener('load',()=>{
    $('rtPaymentQrConfirm')?.addEventListener('change',event=>{confirmed=event.target.checked===true});
    $('rtPaymentQrFile')?.addEventListener('change',async event=>{
      const file=event.target.files?.[0];if(!file)return;
      try{imageData=await readImage(file);setPreview('rtPaymentQrPreview',imageData)}
      catch(e){toast(e.message||e);event.target.value=''}
    });
    $('rtPaymentQrRemove')?.addEventListener('click',()=>{imageData=null;setPreview('rtPaymentQrPreview',null);$('rtPaymentQrActive').checked=false;$('rtPaymentQrFile').value=''});
    $('rtPaymentQrSave')?.addEventListener('click',save);
    renderCheckout();
  });
})();
