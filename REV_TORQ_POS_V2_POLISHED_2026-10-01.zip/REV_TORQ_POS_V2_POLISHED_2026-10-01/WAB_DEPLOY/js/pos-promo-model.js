(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.RTPosPromoModel=api;})(typeof window!=='undefined'?window:globalThis,function(){
  function num(v){const n=Number(v);return Number.isFinite(n)?n:0}
  function normalizePromo(p={}){return {
    promotion_id:p.promotion_id||p.id||null,
    promo_code:String(p.promo_code||p.code||'').trim().toUpperCase(),
    name:String(p.name||p.promo_name||'Promo REV TORQ'),
    promo_type:String(p.promo_type||'').toUpperCase(),
    discount_value:num(p.discount_value),
    discount_amount:Math.max(0,num(p.discount_amount??p.promo_discount)),
    minimum_spend:Math.max(0,num(p.minimum_spend)),
    used_count:Math.max(0,num(p.used_count)),
    usage_limit:p.usage_limit==null?null:Math.max(0,num(p.usage_limit)),
    remaining:p.remaining==null?null:Math.max(0,num(p.remaining))
  }}
  function applyPromo(p,state={}){const promo=normalizePromo(p);return {...state,promo,voucher:null,promoDiscount:promo.discount_amount,orderDiscountLocked:true}}
  function removePromo(state={}){return {...state,promo:null,promoDiscount:0,orderDiscountLocked:false}}
  function usageText(p={}){const used=Math.max(0,num(p.used_count));return p.usage_limit==null?`${used} digunakan · Tiada had`:`${used} / ${Math.max(0,num(p.usage_limit))} digunakan`}
  function discountLabel(p={}){const x=normalizePromo(p);return x.promo_type==='PERCENT'?`${x.discount_value}% OFF`:`RM ${x.discount_value.toFixed(2)}`}
  return {normalizePromo,applyPromo,removePromo,usageText,discountLabel};
});
