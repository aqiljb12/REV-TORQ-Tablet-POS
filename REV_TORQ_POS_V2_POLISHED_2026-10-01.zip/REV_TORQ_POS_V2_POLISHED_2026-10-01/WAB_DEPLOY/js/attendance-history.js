/* REV TORQ v0.9.3 — ADMIN ATTENDANCE HISTORY
   Owner/Admin view inside Kakitangan. Read-only history from staff_attendance.
   Does not change Clock In/Out, stock, POS, invoice, or payment data.
*/
(function(){
'use strict';
const state={rows:[],staff:[],staffMap:new Map(),loading:false,lastLoadedAt:0};
const $=id=>document.getElementById(id);
function db(){return window.supabaseClient||window.sb||null;}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function role(){return String((window.currentProfile||{}).role||'').trim().toLowerCase();}
function isAdmin(){return ['owner','admin','super_admin'].includes(role());}
function toast(m,t){if(typeof window.showToast==='function')window.showToast(m,t||'success');else if(t==='error')alert(m);}
async function companyId(){
  const p=window.currentProfile||{};
  const cached=p.company_id||p.companyId||null;
  if(cached)return cached;
  try{
    if(typeof window.companyId==='function'){
      const v=await window.companyId();
      if(typeof v==='string'&&v)return v;
    }
    const client=db();
    if(client){
      const r=await client.rpc('get_my_company_id');
      if(!r.error&&r.data)return r.data;
    }
  }catch(_){ }
  return null;
}
function startOfDay(d){const x=new Date(d);x.setHours(0,0,0,0);return x;}
function addDays(d,n){const x=new Date(d);x.setDate(x.getDate()+n);return x;}
function periodRange(key){
  const now=new Date();
  if(key==='today'){const a=startOfDay(now);return [a,addDays(a,1)];}
  if(key==='week'){const b=addDays(startOfDay(now),1);return [addDays(b,-7),b];}
  if(key==='last_month'){
    const end=new Date(now.getFullYear(),now.getMonth(),1,0,0,0,0);
    const start=new Date(now.getFullYear(),now.getMonth()-1,1,0,0,0,0);
    return [start,end];
  }
  if(key==='90days'){const b=addDays(startOfDay(now),1);return [addDays(b,-90),b];}
  const start=new Date(now.getFullYear(),now.getMonth(),1,0,0,0,0);
  const end=new Date(now.getFullYear(),now.getMonth()+1,1,0,0,0,0);
  return [start,end];
}
const dtfDate=new Intl.DateTimeFormat('ms-MY',{timeZone:'Asia/Kuala_Lumpur',day:'2-digit',month:'short',year:'numeric'});
const dtfTime=new Intl.DateTimeFormat('ms-MY',{timeZone:'Asia/Kuala_Lumpur',hour:'2-digit',minute:'2-digit',hour12:false});
function fmtDate(v){try{return dtfDate.format(new Date(v));}catch(_){return '—';}}
function fmtTime(v){try{return v?dtfTime.format(new Date(v)):'—';}catch(_){return '—';}}
function durationMs(row){
  const a=new Date(row.clock_in).getTime();
  const b=row.clock_out?new Date(row.clock_out).getTime():Date.now();
  return Number.isFinite(a)&&Number.isFinite(b)?Math.max(0,b-a):0;
}
function fmtDuration(ms){
  const mins=Math.floor(Math.max(0,ms)/60000);
  const h=Math.floor(mins/60),m=mins%60;
  return `${h}j ${String(m).padStart(2,'0')}m`;
}
function setTab(which){
  if(!isAdmin()){toast('Attendance history untuk Owner/Admin sahaja.','error');return;}
  const dir=$('rtStaffDirectoryPanel'),att=$('rtStaffAttendancePanel');
  const bDir=$('rtStaffTabDirectory'),bAtt=$('rtStaffTabAttendance');
  const showAtt=which==='attendance';
  dir?.classList.toggle('hidden',showAtt);
  att?.classList.toggle('hidden',!showAtt);
  if(bDir)bDir.className=showAtt?'px-4 py-2.5 rounded-xl bg-slate-100 text-slate-600 text-xs font-black border border-slate-200':'px-4 py-2.5 rounded-xl bg-slate-900 text-white text-xs font-black shadow-sm';
  if(bAtt)bAtt.className=showAtt?'px-4 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-black shadow-sm':'px-4 py-2.5 rounded-xl bg-slate-100 text-slate-600 text-xs font-black border border-slate-200';
  if(showAtt)load();
}
async function fetchStaff(client,company){
  let q=client.from('staff').select('id,staff_code,name,role,active,removed_from_active_list').order('staff_code',{ascending:true});
  if(company)q=q.eq('company_id',company);
  const r=await q;
  if(r.error)throw r.error;
  state.staff=r.data||[];
  state.staffMap=new Map(state.staff.map(s=>[String(s.id),s]));
  const sel=$('rtAttStaff');
  if(sel){
    const keep=sel.value;
    sel.innerHTML='<option value="">Semua staff</option>'+state.staff.map(s=>`<option value="${esc(s.id)}">${esc(s.staff_code||'')} — ${esc(s.name||'')}</option>`).join('');
    if([...sel.options].some(o=>o.value===keep))sel.value=keep;
  }
}
async function load(){
  if(state.loading)return;
  if(!isAdmin()){toast('Attendance history untuk Owner/Admin sahaja.','error');return;}
  const client=db();if(!client){toast('Supabase belum tersedia.','error');return;}
  state.loading=true;
  const btn=$('rtAttRefresh');if(btn){btn.disabled=true;btn.textContent='LOADING...';}
  const tbody=$('rtAttendanceHistoryTable')?.querySelector('tbody');
  if(tbody)tbody.innerHTML='<tr><td colspan="6" class="p-8 text-center text-slate-400">Memuatkan attendance...</td></tr>';
  try{
    const company=await companyId();
    await fetchStaff(client,company);
    const period=$('rtAttPeriod')?.value||'month';
    const [from,to]=periodRange(period);
    let q=client.from('staff_attendance')
      .select('id,company_id,staff_id,clock_in,clock_out,created_at')
      .gte('clock_in',from.toISOString())
      .lt('clock_in',to.toISOString())
      .order('clock_in',{ascending:false})
      .limit(1000);
    if(company)q=q.eq('company_id',company);
    const staffId=$('rtAttStaff')?.value||'';
    if(staffId)q=q.eq('staff_id',staffId);
    const r=await q;
    if(r.error)throw r.error;
    state.rows=r.data||[];
    state.lastLoadedAt=Date.now();
    render();
  }catch(e){
    console.error('ATTENDANCE HISTORY:',e);
    if(tbody)tbody.innerHTML=`<tr><td colspan="6" class="p-8 text-center text-rose-600">${esc(e.message||'Gagal load attendance.')}</td></tr>`;
    toast(e.message||'Gagal load attendance.','error');
  }finally{
    state.loading=false;
    if(btn){btn.disabled=false;btn.textContent='REFRESH';}
  }
}
function filteredRows(){
  const needle=String($('rtAttSearch')?.value||'').trim().toLowerCase();
  if(!needle)return state.rows;
  return state.rows.filter(r=>{
    const s=state.staffMap.get(String(r.staff_id))||{};
    return [s.staff_code,s.name,s.role].some(v=>String(v||'').toLowerCase().includes(needle));
  });
}
function render(){
  const rows=filteredRows();
  const tbody=$('rtAttendanceHistoryTable')?.querySelector('tbody');
  const open=rows.filter(r=>!r.clock_out).length;
  const unique=new Set(rows.map(r=>String(r.staff_id))).size;
  const total=rows.reduce((n,r)=>n+durationMs(r),0);
  if($('rtAttCount'))$('rtAttCount').textContent=String(rows.length);
  if($('rtAttStaffCount'))$('rtAttStaffCount').textContent=String(unique);
  if($('rtAttHours'))$('rtAttHours').textContent=fmtDuration(total);
  if($('rtAttOpen'))$('rtAttOpen').textContent=String(open);
  if(!tbody)return;
  if(!rows.length){tbody.innerHTML='<tr><td colspan="6" class="p-10 text-center text-slate-400">Tiada rekod attendance untuk filter ini.</td></tr>';return;}
  tbody.innerHTML=rows.map(r=>{
    const s=state.staffMap.get(String(r.staff_id))||{};
    const active=!r.clock_out;
    return `<tr class="hover:bg-slate-50">
      <td class="p-4 whitespace-nowrap font-semibold text-slate-700">${esc(fmtDate(r.clock_in))}</td>
      <td class="p-4"><div class="font-black text-slate-900">${esc(s.name||'Staff')}</div><div class="text-[10px] font-mono text-slate-400">${esc(s.staff_code||r.staff_id)}</div></td>
      <td class="p-4 whitespace-nowrap font-mono text-emerald-700 font-bold">${esc(fmtTime(r.clock_in))}</td>
      <td class="p-4 whitespace-nowrap font-mono ${active?'text-amber-600':'text-slate-700'} font-bold">${active?'—':esc(fmtTime(r.clock_out))}</td>
      <td class="p-4 whitespace-nowrap font-black text-slate-900">${esc(fmtDuration(durationMs(r)))}</td>
      <td class="p-4 whitespace-nowrap">${active?'<span class="inline-flex rounded-full bg-amber-50 border border-amber-200 px-2.5 py-1 text-[10px] font-black text-amber-700">BELUM CLOCK OUT</span>':'<span class="inline-flex rounded-full bg-emerald-50 border border-emerald-200 px-2.5 py-1 text-[10px] font-black text-emerald-700">HADIR</span>'}</td>
    </tr>`;
  }).join('');
}
function mount(){
  $('rtAttPeriod')?.addEventListener('change',load);
  $('rtAttStaff')?.addEventListener('change',load);
  let timer=null;
  $('rtAttSearch')?.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(render,180);});
  // Refresh live duration for staff who have not clocked out.
  setInterval(()=>{
    const panel=$('rtStaffAttendancePanel');
    if(panel&&!panel.classList.contains('hidden')&&state.rows.some(r=>!r.clock_out))render();
  },60000);
}
window.rtShowStaffTab=setTab;
window.rtLoadAttendanceHistory=load;
window.rtRenderAttendanceHistory=render;
document.addEventListener('DOMContentLoaded',mount);
})();
