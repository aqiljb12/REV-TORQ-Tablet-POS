(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports) module.exports=api;
  if(root) root.REVTORQ_POS_PAGER=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  function getPageSize(viewport){
    const width=Math.max(0,Number(viewport&&viewport.width)||0);
    const height=Math.max(0,Number(viewport&&viewport.height)||0);
    const shortSide=Math.min(width||0,height||0);
    const longSide=Math.max(width||0,height||0);
    if(shortSide>0 && shortSide<600 && longSide<1000) return 12;
    if(height>width) return 16;
    return 24;
  }

  function pageCount(total,pageSize){
    const count=Math.max(0,Number(total)||0);
    const size=Math.max(1,Number(pageSize)||1);
    return Math.max(1,Math.ceil(count/size));
  }

  function clampPage(page,totalPages){
    const total=Math.max(1,Number(totalPages)||1);
    return Math.min(total,Math.max(1,Math.trunc(Number(page)||1)));
  }

  function paginate(items,page,pageSize){
    const list=Array.isArray(items)?items:[];
    const size=Math.max(1,Number(pageSize)||1);
    const current=clampPage(page,pageCount(list.length,size));
    const start=(current-1)*size;
    return list.slice(start,start+size);
  }

  function buildPageTokens(page,totalPages){
    const total=Math.max(1,Number(totalPages)||1);
    const current=clampPage(page,total);
    if(total<=7) return Array.from({length:total},(_,i)=>i+1);
    if(current<=3) return [1,2,3,'…',total];
    if(current>=total-2) return [1,'…',total-2,total-1,total];
    return [1,'…',current-1,current,current+1,'…',total];
  }

  return {getPageSize,pageCount,clampPage,paginate,buildPageTokens};
});
