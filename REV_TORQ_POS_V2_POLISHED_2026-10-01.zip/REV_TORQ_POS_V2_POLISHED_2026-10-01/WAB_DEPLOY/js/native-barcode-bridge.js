(function(){
  'use strict';

  const nativeBridge=window.RevTorqAndroid;
  if(!nativeBridge || typeof nativeBridge.scanBarcode!=='function') return;

  function normalizeBarcode(value){
    return String(value==null?'':value).trim().replace(/[\r\n\t ]+/g,'').toUpperCase();
  }
  window.rtNormalizeBarcode=normalizeBarcode;

  function notifyNative(code,found,message){
    try{nativeBridge.scannerLookupResult(String(code||''),!!found,String(message||''));}catch(_){ }
  }

  async function findProductExact(code){
    const normalized=normalizeBarcode(code);
    if(!normalized)return null;
    const upper=normalized.toUpperCase();

    // Fast path: use the products already loaded by the existing POS.
    let item=(window.posProducts||[]).find(p=>{
      const barcode=normalizeBarcode(p?.barcode||'');
      const sku=String(p?.sku||'').trim().toUpperCase();
      return barcode===normalized || sku===upper;
    });
    if(item)return item;

    // Existing inventory bridge maps the live Supabase product/barcode data.
    try{
      if(window.db?.collection){
        let snap=await db.collection('inventory').where('barcode','==',normalized).limit(1).get();
        if(snap.empty) snap=await db.collection('inventory').where('sku','==',upper).limit(1).get();
        if(!snap.empty){
          const doc=snap.docs[0],d=doc.data()||{};
          return {sku:String(d.sku||doc.id),name:d.name||d.sku||doc.id,
            price:Number(d.sellPrice??d.sell_price??d.price??0),stock:Number(d.stock??d.quantity??0),
            barcode:normalizeBarcode(d.barcode||'')};
        }
      }
    }catch(e){console.warn('Native scanner inventory lookup failed',e);}

    // Direct exact Supabase fallback. Never convert barcode to Number.
    try{
      const sb=window.supabaseClient;
      if(sb?.from){
        let company=null;
        if(typeof window.companyId==='function') company=await window.companyId();
        company=company||window.currentProfile?.companyId||window.currentProfile?.company_id||null;
        if(company){
          let q=sb.from('products').select('id,sku,name,barcode,sell_price,active')
            .eq('company_id',company).eq('barcode',normalized).eq('active',true).limit(1).maybeSingle();
          let r=await q;
          if(!r.error && r.data){
            const p=r.data;
            let stock=0;
            try{
              let location=window.currentProfile?.locationId||window.currentProfile?.location_id||null;
              if(!location){
                const lr=await sb.from('locations').select('id').eq('company_id',company).eq('active',true).order('code').limit(1).maybeSingle();
                if(!lr.error)location=lr.data?.id||null;
              }
              if(location){
                const sr=await sb.from('stock_balances').select('quantity').eq('product_id',p.id).eq('location_id',location).maybeSingle();
                if(!sr.error)stock=Number(sr.data?.quantity||0);
              }
            }catch(_){ }
            return {id:p.id,sku:String(p.sku||p.id),name:p.name||p.sku||p.id,
              price:Number(p.sell_price||0),barcode:normalizeBarcode(p.barcode||''),stock};
          }
        }
      }
    }catch(e){console.warn('Native scanner Supabase lookup failed',e);}
    return null;
  }

  async function lookupAndAdd(rawCode){
    const code=normalizeBarcode(rawCode);
    if(!code){notifyNative(code,false,'Barcode tidak sah');return;}
    try{
      const item=await findProductExact(code);
      if(!item){
        notifyNative(code,false,'Barcode tidak dijumpai');
        try{showToast('Barcode tidak dijumpai: '+code,'error');}catch(_){ }
        return;
      }
      if(Number(item.stock||0)<=0){
        notifyNative(code,false,'Barang dijumpai tetapi stok habis');
        try{showToast('Stok barang ini habis.','error');}catch(_){ }
        return;
      }
      if(typeof window.posAddToCart!=='function')throw new Error('POS cart belum sedia');
      window.posAddToCart(item.sku,item.name,item.price,item.stock);
      notifyNative(code,true,(item.name||item.sku)+' ditambah ke troli');
    }catch(e){
      console.warn('Native barcode lookup:',e);
      notifyNative(code,false,'Carian barcode gagal');
      try{showToast('Carian barcode gagal: '+(e.message||e),'error');}catch(_){ }
    }
  }

  async function lookupInventory(rawCode){
    const code=normalizeBarcode(rawCode);
    if(!code){notifyNative(code,false,'Barcode tidak sah');return;}
    try{
      if(typeof window.inventoryBarcodeLookup!=='function')throw new Error('Carian inventori belum sedia');
      const item=await window.inventoryBarcodeLookup(code);
      notifyNative(code,true,item?'Inventori: '+(item.name||item.sku||code):'Barcode belum ada: '+code);
    }catch(e){
      console.warn('Native inventory lookup:',e);
      notifyNative(code,false,'Carian inventori gagal');
    }
  }

  function fillInventoryBarcode(rawCode){
    const code=normalizeBarcode(rawCode);
    const input=document.getElementById('invBarcode');
    if(!code||!input){notifyNative(code,false,'Medan barcode inventori tidak tersedia');return;}
    window.rtPendingInventoryBarcode=code;
    if(window.rtSetNativeInputValue)window.rtSetNativeInputValue(input,code,{uppercase:true,rebuild:true});
    else{input.value=code;input.setAttribute?.('value',code);input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));}
    setTimeout(()=>{if(window.rtPendingInventoryBarcode===code)window.rtPendingInventoryBarcode='';},250);
    notifyNative(code,true,'Barcode diisi: '+code);
  }

  function openNativeScanner(mode){
    try{nativeBridge.scanBarcode(mode||'MULTI_SCAN');}
    catch(e){console.warn('Native scanner open failed',e);return false;}
    return true;
  }

  const oldOpenPOSScanner=window.rtOpenPOSScanner;
  window.rtOpenPOSScanner=function(){
    if(!openNativeScanner('POS_MULTI') && typeof oldOpenPOSScanner==='function') return oldOpenPOSScanner();
  };
  window.rtOpenNativeScanner=openNativeScanner;

  window.RevTorqNativeScanner={
    onBarcode:function(code,mode){
      if(mode==='INVENTORY_LOOKUP')lookupInventory(code);
      else if(mode==='INVENTORY_BARCODE_INPUT')fillInventoryBarcode(code);
      else lookupAndAdd(code);
    },
    onAction:function(action,rawCode){
      const code=normalizeBarcode(rawCode);
      if(action==='SEARCH'){
        const input=document.getElementById('posSearch');
        if(input){if(window.rtSetNativeInputValue)window.rtSetNativeInputValue(input,code,{uppercase:true,rebuild:true});else input.value=code;try{window.posFilterProducts?.(code);}catch(_){input.dispatchEvent(new Event('input',{bubbles:true}));}}
        return;
      }
      if(action==='ADD_PRODUCT'){
        window.rtPendingInventoryBarcode=code;
        try{
          if(typeof window.openNewInventory==='function')window.openNewInventory();
          else if(typeof window.openInventoryPage==='function')window.openInventoryPage('Tambah Inventori Baru','Daftarkan item, barcode, harga dan stok permulaan.');
          setTimeout(()=>{
            const el=document.getElementById('invBarcode');
            if(el){if(window.rtSetNativeInputValue)window.rtSetNativeInputValue(el,code,{uppercase:true,rebuild:true});else{el.value=code;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}}
          },120);
        }catch(e){console.warn('Open add product from scanner failed',e);}
      }
    }
  };

  // Capture the existing scanner buttons in APK mode. Web/browser builds keep
  // their existing ZXing/BarcodeDetector fallbacks because this file exits when
  // the native JavascriptInterface is absent.
  document.addEventListener('click',function(e){
    const button=e.target?.closest?.('#rtScanBtn,#rtScanBtnTop,#rtInventoryCameraBtn,#rtInvScanBtn');
    if(!button)return;
    e.preventDefault();
    e.stopImmediatePropagation();
    const mode=button.id==='rtInventoryCameraBtn'?'INVENTORY_LOOKUP'
      :button.id==='rtInvScanBtn'?'INVENTORY_BARCODE_INPUT':'POS_MULTI';
    openNativeScanner(mode);
  },true);

  // A keyboard/HID scanner uses the existing POS barcode field and Enter.
  document.addEventListener('keydown',function(e){
    if(e.target?.id!=='posSearch'||e.key!=='Enter'||e.isComposing||e.ctrlKey||e.altKey||e.metaKey)return;
    e.preventDefault();
    e.stopImmediatePropagation();
    const code=normalizeBarcode(e.target.value);
    if(!code)return;
    e.target.value='';
    lookupAndAdd(code);
  },true);
})();
