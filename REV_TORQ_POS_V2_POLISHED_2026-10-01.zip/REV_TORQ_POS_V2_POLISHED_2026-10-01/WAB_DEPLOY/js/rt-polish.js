/* REV TORQ POS V2 POLISH — UI behaviour layer (loaded last).
   UI/UX only: confirmations, compact cart panels, receipt success state, drawer
   popover, customer quick pick, loading/empty states. It never posts sales,
   stock or payments; checkout, promo/voucher validation and receipts keep using
   the existing canonical modules. Plain ES2017-compatible code for Android 9 WebView. */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
  function num(v){var n=Number(v);return isFinite(n)?n:0;}
  function money(v){return 'RM '+num(v).toFixed(2);}
  function toast(m,t){try{if(window.showToast)window.showToast(m,t||'success');}catch(_){}}
  function feather(){try{if(window.feather)window.feather.replace();}catch(_){}}
  function posActive(){return window.__rtActiveView==='pos';}
  function coarse(){try{return window.matchMedia&&window.matchMedia('(pointer:coarse)').matches;}catch(_){return false;}}
  function cart(){try{return (window.rtGetPosCart&&window.rtGetPosCart())||[];}catch(_){return [];}}
  function method(){return String(window.posPayMethod||'CASH').toUpperCase();}
  function parseRm(text){var m=String(text||'').replace(/,/g,'').match(/-?\d+(?:\.\d+)?/);return m?Number(m[0]):0;}

  // ---------------------------------------------------------------- confirm
  // Small standard confirm dialog (used for destructive actions only).
  function rtConfirm(opts){
    opts=opts||{};
    return new Promise(function(resolve){
      var old=$('rtConfirmModal');if(old)old.remove();
      var m=document.createElement('div');
      m.id='rtConfirmModal';m.className='rt-confirm-backdrop';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');
      m.innerHTML='<div class="rt-confirm-box"><h3>'+esc(opts.title||'Sahkan?')+'</h3>'+(opts.message?'<p>'+esc(opts.message)+'</p>':'')+
        '<div class="rt-confirm-actions"><button type="button" class="rt-btn rt-btn-secondary" data-act="no">'+esc(opts.cancelText||'BATAL')+'</button>'+
        '<button type="button" class="rt-btn '+(opts.danger?'rt-btn-danger':'rt-btn-primary')+'" data-act="yes">'+esc(opts.confirmText||'YA')+'</button></div></div>';
      document.body.appendChild(m);
      var done=function(v){document.removeEventListener('keydown',onKey,true);m.remove();resolve(v);};
      var onKey=function(e){if(e.key==='Escape'){e.preventDefault();done(false);}};
      document.addEventListener('keydown',onKey,true);
      m.addEventListener('click',function(e){
        var b=e.target.closest?e.target.closest('[data-act]'):null;
        if(b)done(b.getAttribute('data-act')==='yes');else if(e.target===m)done(false);
      });
      setTimeout(function(){var y=m.querySelector('[data-act="yes"]');if(y&&!coarse())y.focus();},30);
    });
  }
  window.rtConfirm=rtConfirm;

  // ---------------------------------------------------------------- cart: clear
  window.rtConfirmClearCart=function(){
    var c=cart();
    if(!c.length){toast('Troli sudah kosong.','info');return;}
    var qty=c.reduce(function(n,i){return n+num(i.qty);},0);
    rtConfirm({title:'Kosongkan troli?',message:qty+' item akan dibuang daripada order ini.',confirmText:'KOSONGKAN',danger:true}).then(function(ok){
      if(!ok)return;
      if(typeof window.posClearCart==='function')window.posClearCart();
      toast('Troli dikosongkan.','info');
    });
  };

  // ---------------------------------------------------------------- search box
  function syncSearchClear(){
    var q=$('posSearch'),b=$('rtPosSearchClear');
    if(q&&b)b.hidden=!String(q.value||'').length;
  }
  window.rtSyncPosSearchClear=syncSearchClear;
  function bindSearch(){
    var q=$('posSearch'),b=$('rtPosSearchClear');
    if(!q||q.dataset.rtPolish==='1')return;
    q.dataset.rtPolish='1';
    q.addEventListener('input',syncSearchClear);
    q.addEventListener('keyup',syncSearchClear);
    if(b)b.addEventListener('click',function(){
      if(window.rtSetNativeInputValue)window.rtSetNativeInputValue(q,'',{dispatch:false,rebuild:false});else q.value='';
      if(typeof window.posFilterProducts==='function')window.posFilterProducts('');
      syncSearchClear();
      try{q.focus();}catch(_){}
    });
  }

  // ---------------------------------------------------------------- product tap feedback
  function bindGrid(){
    var g=$('posProductGrid');
    if(!g||g.dataset.rtPolish==='1')return;
    g.dataset.rtPolish='1';
    g.addEventListener('click',function(e){
      var card=e.target.closest?e.target.closest('.rt-pos-card'):null;
      if(!card)return;
      card.classList.remove('rt-tapped');void card.offsetWidth;card.classList.add('rt-tapped');
      setTimeout(function(){card.classList.remove('rt-tapped');},260);
    });
  }

  // Lightweight skeleton while POS products load (never shown once items exist).
  function wrapLoadPOS(){
    var orig=window.loadPOS;
    if(typeof orig!=='function'||orig.__rtPolish)return;
    var wrapped=function(){
      var g=$('posProductGrid');
      if(g&&!g.querySelector('.rt-pos-card')){
        var sk='';for(var i=0;i<12;i++)sk+='<div class="rt-pos-card rt-skel-card"><span class="rt-skel"></span><span class="rt-skel rt-skel-short"></span></div>';
        g.innerHTML=sk;
      }
      var res=orig.apply(this,arguments);
      Promise.resolve(res).then(function(){
        var grid=$('posProductGrid');
        if(grid&&grid.querySelector('.rt-skel-card')){
          grid.innerHTML='<div class="rt-grid-empty"><i data-feather="wifi-off"></i><b>Barang tidak dapat dimuat</b><span>Semak sambungan internet.</span><button type="button" class="rt-btn rt-btn-secondary" onclick="window.loadPOS&&window.loadPOS()">CUBA LAGI</button></div>';
          feather();
        }
      });
      return res;
    };
    wrapped.__rtPolish=true;
    window.loadPOS=wrapped;
  }

  // ---------------------------------------------------------------- customer bar
  var vehicleCache={}, selectedVehicle=null, lastCustomerId=null, custSig='';
  function selectedOption(){
    var sel=$('rtPosCustomerSelect');
    if(!sel||!sel.value)return null;
    var opt=sel.options[sel.selectedIndex];
    return opt?{id:sel.value,name:opt.getAttribute('data-name')||opt.textContent||'Pelanggan',phone:opt.getAttribute('data-phone')||''}:{id:sel.value,name:'Pelanggan',phone:''};
  }
  window.rtToggleCustPanel=function(force){
    var p=$('rtCustPanel'),t=$('rtCustToggle');if(!p)return;
    var open=typeof force==='boolean'?force:p.classList.contains('hidden');
    p.classList.toggle('hidden',!open);
    if(t)t.setAttribute('aria-expanded',open?'true':'false');
    if(open){window.rtToggleAdjust(null);renderCustResults(($('rtPosCustSearch')||{}).value||'');}
  };
  function renderCustResults(q){
    var box=$('rtPosCustResults'),sel=$('rtPosCustomerSelect');if(!box||!sel)return;
    q=String(q||'').trim().toLowerCase();
    if(!q){box.innerHTML='';return;}
    var digits=q.replace(/\D/g,'');
    var list=[].slice.call(sel.options).filter(function(o){
      if(!o.value)return false;
      var name=String(o.getAttribute('data-name')||o.textContent||'').toLowerCase();
      var phone=String(o.getAttribute('data-phone')||'').replace(/\D/g,'');
      return name.indexOf(q)>=0||(digits.length>=3&&phone.indexOf(digits)>=0);
    }).slice(0,8);
    if(!list.length){
      box.innerHTML='<div class="rt-muted-note">Tiada dalam senarai. '+(digits.length>=9?'Tekan <b>CARI / DAFTAR</b> di bawah untuk cari / daftar ikut telefon.':'Cuba nama lain atau no. telefon.')+'</div>';
      if(digits.length>=9){var ph=$('rtPosMemberPhone');if(ph&&!ph.value)ph.value=digits;}
      return;
    }
    box.innerHTML=list.map(function(o){
      return '<button type="button" class="rt-cust-result" data-id="'+esc(o.value)+'"><b>'+esc(o.getAttribute('data-name')||o.textContent)+'</b><small>'+esc(o.getAttribute('data-phone')||'')+'</small></button>';
    }).join('');
  }
  window.rtPosCustSearch=renderCustResults;
  function chooseCustomer(id){
    var sel=$('rtPosCustomerSelect');if(!sel)return;
    sel.value=String(id);
    // Same event the existing member flow fires: loads points/vouchers and re-checks promo.
    try{sel.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){}
    var s=$('rtPosCustSearch');if(s)s.value='';
    renderCustResults('');
    syncCustomer(true);
  }
  function loadVehicles(customerId){
    var box=$('rtPosVehicleList');if(!box)return;
    if(!customerId){box.innerHTML='<div class="rt-muted-note">Pilih pelanggan untuk lihat motosikal.</div>';return;}
    var render=function(rows){
      if(!rows.length){box.innerHTML='<div class="rt-muted-note">Tiada motosikal berdaftar untuk pelanggan ini.</div>';return;}
      if(rows.length===1&&!selectedVehicle)selectedVehicle=rows[0];
      box.innerHTML=rows.map(function(v){
        var on=selectedVehicle&&selectedVehicle.id===v.id;
        return '<button type="button" class="rt-vehicle-chip'+(on?' active':'')+'" data-vid="'+esc(v.id)+'"><b>'+esc(v.plate||'-')+'</b><small>'+esc(v.name||'')+'</small></button>';
      }).join('');
      syncCustomer(true);
    };
    if(vehicleCache[customerId]){render(vehicleCache[customerId]);return;}
    box.innerHTML='<div class="rt-muted-note">Memuatkan motosikal...</div>';
    var sb=window.supabaseClient;
    if(!sb||!sb.from){box.innerHTML='<div class="rt-muted-note">Motosikal tidak dapat dimuat.</div>';return;}
    var q=sb.from('vehicles').select('id,plate_no,brand,model').eq('customer_id',customerId);
    var company=(window.currentProfile||{}).companyId;
    if(company)q=q.eq('company_id',company);
    Promise.resolve(q.limit(20)).then(function(r){
      if(r&&r.error)throw r.error;
      var rows=((r&&r.data)||[]).map(function(v){return {id:v.id,plate:v.plate_no||'',name:[v.brand,v.model].filter(Boolean).join(' ')};});
      vehicleCache[customerId]=rows;
      if(lastCustomerId===customerId)render(rows);
    }).catch(function(e){console.warn('POS vehicles',e);box.innerHTML='<div class="rt-muted-note">Motosikal tidak dapat dimuat.</div>';});
  }
  function syncCustomer(force){
    var c=selectedOption();
    var job=window.rtActiveJob||null;
    var id=c?c.id:null;
    if(id!==lastCustomerId){lastCustomerId=id;selectedVehicle=null;if(!job)loadVehicles(id);else{var vb=$('rtPosVehicleList');if(vb)vb.innerHTML='<div class="rt-muted-note">Motosikal ikut Job Card.</div>';}}
    var jv=job&&window.rtActiveJobVehicle?window.rtActiveJobVehicle:null;
    var veh=jv?{plate:jv.plate,name:jv.name}:selectedVehicle;
    var pts=(($('rtPosMemberPoints')||{}).textContent||'').trim();
    var sig=[id,c&&c.name,c&&c.phone,veh&&veh.plate,pts,!!job].join('|');
    if(!force&&sig===custSig)return;
    custSig=sig;
    var sum=$('rtCustSummary'),cta=$('rtCustCta'),bar=$('rtCustBar');
    if(!sum)return;
    if(!c){
      sum.innerHTML='<b>Walk-in</b><small>Pelanggan pilihan · tekan untuk cari / daftar</small>';
      if(cta)cta.textContent='PILIH';
      if(bar)bar.classList.remove('has-customer');
    }else{
      var line2=[c.phone,pts].filter(Boolean).join(' · ');
      var moto=veh?'<span class="rt-cust-moto">'+esc(veh.name||'Motosikal')+' · <b>'+esc(veh.plate||'-')+'</b></span>':'';
      sum.innerHTML='<b>'+esc(c.name)+'</b><small>'+esc(line2||'Pelanggan dipilih')+'</small>'+moto;
      if(cta)cta.textContent=job?'JOB':'TUKAR';
      if(bar)bar.classList.add('has-customer');
    }
    var clr=$('rtCustClear');
    if(clr)clr.hidden=!c||!!job;
    var cartEl=document.querySelector('#view-pos .rt-pos-cart');
    if(cartEl)cartEl.classList.toggle('rt-has-job',!!job);
  }
  function bindCustomer(){
    var bar=$('rtCustBar');
    if(!bar||bar.dataset.rtPolish==='1')return;
    bar.dataset.rtPolish='1';
    var clr=document.createElement('button');
    clr.type='button';clr.id='rtCustClear';clr.className='rt-icon-btn rt-cust-clear';clr.hidden=true;
    clr.setAttribute('aria-label','Buang pelanggan (walk-in)');clr.title='Buang pelanggan';clr.innerHTML='&times;';
    clr.onclick=function(){if(typeof window.rtPosClearMember==='function')window.rtPosClearMember();selectedVehicle=null;syncCustomer(true);};
    var t=$('rtCustToggle');if(t&&t.parentNode)t.parentNode.insertBefore(clr,t.nextSibling);
    bar.addEventListener('click',function(e){
      var r=e.target.closest?e.target.closest('.rt-cust-result'):null;
      if(r){chooseCustomer(r.getAttribute('data-id'));return;}
      var v=e.target.closest?e.target.closest('.rt-vehicle-chip'):null;
      if(v){
        var rows=vehicleCache[lastCustomerId]||[];
        var id=v.getAttribute('data-vid');
        selectedVehicle=(selectedVehicle&&selectedVehicle.id===id)?null:(rows.filter(function(x){return x.id===id;})[0]||null);
        [].forEach.call(bar.querySelectorAll('.rt-vehicle-chip'),function(x){x.classList.toggle('active',!!selectedVehicle&&x.getAttribute('data-vid')===selectedVehicle.id);});
        syncCustomer(true);
      }
    });
    document.addEventListener('change',function(e){
      if(e.target&&e.target.id==='rtPosCustomerSelect')setTimeout(function(){syncCustomer(true);},0);
      if(e.target&&e.target.id==='rtPaymentQrConfirm')setTimeout(syncCheckout,0);
    });
    document.addEventListener('click',function(e){
      var p=$('rtCustPanel');
      if(!p||p.classList.contains('hidden'))return;
      // A tapped result/chip may already be re-rendered (detached); that is not an outside tap.
      if(!document.body.contains(e.target)||bar.contains(e.target))return;
      if(e.target.closest&&e.target.closest('#rtConfirmModal'))return;
      window.rtToggleCustPanel(false);
    });
  }

  // ---------------------------------------------------------------- adjustments + summary
  window.rtToggleAdjust=function(key){
    var panels=document.querySelectorAll('[data-adjust-panel]');
    var current=null;
    [].forEach.call(panels,function(p){if(!p.classList.contains('hidden'))current=p.getAttribute('data-adjust-panel');});
    var next=(key&&key!==current)?key:null;
    [].forEach.call(panels,function(p){p.classList.toggle('hidden',p.getAttribute('data-adjust-panel')!==next);});
    [].forEach.call(document.querySelectorAll('.rt-adjust-bar [data-adjust]'),function(b){
      var on=b.getAttribute('data-adjust')===next;
      b.classList.toggle('open',on);b.setAttribute('aria-expanded',on?'true':'false');
    });
    if(next)window.rtToggleCustPanel&&window.rtToggleCustPanel(false);
  };
  function setRow(key,amount,label){
    var row=document.querySelector('.rt-sum [data-sum="'+key+'"]');
    if(row)row.classList.toggle('is-zero',!(amount>0.004));
    if(label!=null){var l=row&&row.querySelector('span');if(l)l.textContent=label;}
  }
  function setBadge(key,text){
    var b=document.querySelector('[data-adjust-badge="'+key+'"]');
    if(b){b.textContent=text||'';b.parentNode.classList.toggle('has-value',!!text);}
  }
  function syncSummary(){
    var promo=null,voucher=null;
    try{promo=window.rtGetActivePromo?window.rtGetActivePromo():null;}catch(_){}
    try{voucher=window.rtPosGetActiveVoucher?window.rtPosGetActiveVoucher():null;}catch(_){}
    var itemDisc=parseRm(($('rtItemDiscountDisplay')||{}).textContent);
    var orderDisc=parseRm(($('rtDiscountDisplay')||{}).textContent);
    var charge=parseRm(($('rtOtherChargeDisplay')||{}).textContent);
    var promoDisc=0;
    if(promo){
      var net=0;
      try{net=window.RTPosDiscountModel?num(window.RTPosDiscountModel.cartTotals(cart(),0).netBeforeOrderDiscount):0;}catch(_){}
      promoDisc=Math.min(Math.max(0,num(promo.discount_amount)),Math.max(0,net));
    }
    var pd=$('rtPromoDiscountDisplay');if(pd)pd.textContent=promoDisc>0?'-'+money(promoDisc):money(0);
    var id=$('rtItemDiscountDisplay');if(id&&itemDisc>0&&id.textContent.charAt(0)!=='-')id.textContent='-'+id.textContent;
    var od=$('rtDiscountDisplay');if(od&&orderDisc>0&&od.textContent.charAt(0)!=='-')od.textContent='-'+od.textContent;
    setRow('item',itemDisc);
    setRow('order',orderDisc,voucher?('Voucher '+(voucher.code||'')).trim():'Diskaun order');
    setRow('promo',promoDisc,promo?('Promo '+(promo.promo_code||promo.name||'')).trim():'Promo');
    setRow('charge',charge);
    setBadge('discount',(!voucher&&orderDisc>0)?'-'+orderDisc.toFixed(2):'');
    setBadge('promo',promo?'-'+promoDisc.toFixed(2):'');
    setBadge('voucher',voucher?'-'+num(voucher.discount_applied).toFixed(2):'');
    setBadge('charge',charge>0?'+'+charge.toFixed(2):'');
    syncCheckout();
  }
  // Cash "Diterima" defaults to the exact total (existing cash-tender behaviour). It used to
  // freeze at the first item's total; now it keeps following the total until the cashier
  // types an amount or taps a quick-cash button.
  var autoReceived=null;
  function followTotal(total){
    var inp=$('posAmountReceived');
    if(!inp||method()!=='CASH')return false;
    var cur=String(inp.value||'').trim(),t=total.toFixed(2);
    if(autoReceived!==null&&cur===autoReceived&&cur!==t){
      if(window.rtSetNativeInputValue)window.rtSetNativeInputValue(inp,t,{dispatch:false,rebuild:true});else inp.value=t;
      autoReceived=t;return true;
    }
    if(cur===t)autoReceived=t;
    return false;
  }
  function syncCheckout(){
    var btn=$('btnCheckout'),amt=$('rtCheckoutAmount');
    var total=parseRm(($('posTotal')||{}).textContent);
    if(amt)amt.textContent=total>0?money(total):'';
    var qrPending=method()==='QR'&&!(($('rtPaymentQrConfirm')||{}).checked);
    if(btn)btn.classList.toggle('is-ready',!btn.disabled&&total>0&&!qrPending);
    // Cash: show what is still owed instead of a red RM 0.00.
    var m=method(),lab=$('rtCashChangeLabel'),ch=$('posChange'),box=$('rtCashTenderBox');
    if(m==='CASH'&&ch&&lab){
      var rec=num(String(($('posAmountReceived')||{}).value||'').replace(/,/g,''));
      var short=Math.round((total-rec)*100)/100;
      if(total>0&&short>0.004){lab.textContent='KURANG';ch.textContent=money(short);if(box)box.classList.add('is-short');}
      else{lab.textContent='BAKI / KEMBALI';if(box)box.classList.remove('is-short');}
    }
    var qr=$('rtPaymentQrPanel'),cb=$('rtPaymentQrConfirm');
    if(qr&&cb)qr.classList.toggle('is-confirmed',!!cb.checked);
  }
  function wrapTotals(){
    var calc=window.posCalculateTotal;
    if(typeof calc==='function'&&!calc.__rtPolish){
      var w=function(){
        var r=calc.apply(this,arguments);
        try{
          syncSummary();
          if(followTotal(parseRm(($('posTotal')||{}).textContent))&&typeof window.rtSyncCashTender==='function')window.rtSyncCashTender();
        }catch(e){console.warn('polish summary',e);}
        return r;
      };
      w.__rtPolish=true;window.posCalculateTotal=w;
    }
    var tender=window.rtSyncCashTender;
    if(typeof tender==='function'&&!tender.__rtPolish){
      var t=function(){var r=tender.apply(this,arguments);try{syncCheckout();}catch(_){}return r;};
      t.__rtPolish=true;window.rtSyncCashTender=t;
    }
    var setM=window.posSetPaymentMethod;
    if(typeof setM==='function'&&!setM.__rtPolish){
      var s=function(){var r=setM.apply(this,arguments);try{syncCheckout();}catch(_){}return r;};
      s.__rtPolish=true;window.posSetPaymentMethod=s;
    }
  }

  // ---------------------------------------------------------------- cash drawer popover
  function drawerOpen(){var st=$('rtCashDrawerStatus');return st&&/OPEN/i.test(st.textContent||'');}
  window.rtToggleDrawerPopover=function(force){
    var p=$('rtDrawerPopover'),chip=$('rtPosDrawerChip');if(!p)return;
    var open=typeof force==='boolean'?force:p.classList.contains('hidden');
    p.classList.toggle('hidden',!open);
    if(chip)chip.setAttribute('aria-expanded',open?'true':'false');
    if(open&&typeof window.rtRefreshCashDrawer==='function')window.rtRefreshCashDrawer();
  };
  function syncDrawerChip(){
    var chip=$('rtPosDrawerChip'),txt=$('rtPosDrawerChipText');if(!chip||!txt)return;
    var st=(($('rtCashDrawerStatus')||{}).textContent||'').trim().toUpperCase();
    var ex=(($('rtCashDrawerExpected')||{}).textContent||'').trim();
    var open=st==='OPEN',closed=st==='CLOSED';
    var t=open?('BUKA · '+ex):closed?'DITUTUP':st==='RALAT'?'RALAT':'Semak...';
    if(txt.textContent!==t)txt.textContent=t;
    chip.classList.toggle('is-open',open);chip.classList.toggle('is-closed',closed||st==='RALAT');
  }
  function bindDrawer(){
    var p=$('rtDrawerPopover');
    if(!p||p.dataset.rtPolish==='1')return;
    p.dataset.rtPolish='1';
    if(p.parentElement!==document.body)document.body.appendChild(p);
    var head=document.createElement('div');head.className='rt-drawer-popover-head';
    head.innerHTML='<b>Peti Tunai</b><button type="button" class="rt-icon-btn" aria-label="Tutup">&times;</button>';
    head.querySelector('button').onclick=function(){window.rtToggleDrawerPopover(false);};
    p.insertBefore(head,p.firstChild);
    p.addEventListener('click',function(e){
      // Actions open their own modal; close the popover so it does not sit on top.
      if(e.target.closest&&e.target.closest('.rt-cash-drawer-actions button,#rtDailyBookBtn'))setTimeout(function(){window.rtToggleDrawerPopover(false);},0);
    });
    document.addEventListener('click',function(e){
      if(p.classList.contains('hidden'))return;
      if(!document.body.contains(e.target)||p.contains(e.target))return;
      if(e.target.closest&&e.target.closest('#rtPosDrawerChip'))return;
      window.rtToggleDrawerPopover(false);
    });
    try{new MutationObserver(syncDrawerChip).observe(p,{subtree:true,childList:true,characterData:true});}catch(_){}
    syncDrawerChip();
  }
  function wrapCheckout(){
    var co=window.posCheckout;
    if(typeof co!=='function'||co.__rtPolish)return;
    var w=function(){
      var res=co.apply(this,arguments);
      Promise.resolve(res).then(function(){
        // CASH needs an OPEN drawer (enforced by the canonical checkout). Point the cashier to it.
        setTimeout(function(){if(method()==='CASH'&&cart().length&&$('rtCashDrawerStatus')&&!drawerOpen()&&/CLOSED/i.test($('rtCashDrawerStatus').textContent||''))window.rtToggleDrawerPopover(true);},150);
      });
      return res;
    };
    w.__rtPolish=true;window.posCheckout=w;
  }

  // ---------------------------------------------------------------- QR enlarge
  window.rtEnlargeQr=function(){
    var img=$('rtPaymentQrCheckoutImage');
    if(!img||!img.getAttribute('src')||img.classList.contains('hidden')){toast('QR belum tersedia.','error');return;}
    var m=document.createElement('div');m.className='rt-qr-zoom';m.setAttribute('role','dialog');
    m.innerHTML='<div class="rt-qr-zoom-box"><div class="rt-qr-zoom-amount">'+esc(($('posTotal')||{}).textContent||'')+'</div><img alt="QR bayaran" src="'+esc(img.getAttribute('src'))+'"><div class="rt-qr-zoom-merchant">'+esc(($('rtPaymentQrCheckoutMerchant')||{}).textContent||'')+'</div><button type="button" class="rt-btn rt-btn-primary rt-btn-block">TUTUP</button></div>';
    m.addEventListener('click',function(){m.remove();});
    document.body.appendChild(m);
  };

  // ---------------------------------------------------------------- receipt success state
  var receiptMode='sale';
  function wrapReceipt(){
    var gen=window.generateReceiptFromInvoice;
    if(typeof gen!=='function'||gen.__rtPolish)return;
    var w=function(inv){
      var result=gen.apply(this,arguments);
      return Promise.resolve(result).then(function(r){try{showReceiptHead(inv||{});}catch(e){console.warn('receipt head',e);}return r;});
    };
    w.__rtPolish=true;window.generateReceiptFromInvoice=w;
  }
  function showReceiptHead(inv){
    var head=$('rtReceiptHead'),label=$('rtReceiptDoneLabel');if(!head)return;
    receiptMode=inv.__rtReprint?'reprint':'sale';
    var no=inv.invoiceNo||inv.invNo||inv.id||'-';
    var total=num(inv.total);
    var m=String(inv.paymentMethod||inv.method||'CASH').toUpperCase();
    var paid=m==='CASH'?num(inv.amountPaid!=null?inv.amountPaid:(inv.amountReceived!=null?inv.amountReceived:total)):total;
    var change=m==='CASH'?Math.max(0,num(inv.change!=null?inv.change:(inv.balance!=null?inv.balance:paid-total))):0;
    var mLabel=m==='CASH'?'TUNAI':m==='CARD'?'KAD':m;
    head.setAttribute('data-invoice',String(no));
    if(receiptMode==='sale'){
      head.className='rt-receipt-head no-print is-sale';
      head.innerHTML='<div class="rt-receipt-ok"><span class="rt-receipt-tick">✓</span><div><b>BAYARAN BERJAYA</b><small>'+esc(no)+' · '+esc(mLabel)+'</small></div></div>'+
        '<div class="rt-receipt-figs"><div><span>JUMLAH</span><b>'+money(total)+'</b></div>'+(m==='CASH'?'<div class="rt-receipt-change"><span>BAKI / KEMBALI</span><b>'+money(change)+'</b></div>':'<div><span>DIBAYAR</span><b>'+money(paid)+'</b></div>')+'</div>';
      if(label)label.textContent='JUALAN BARU';
    }else{
      head.className='rt-receipt-head no-print is-reprint';
      head.innerHTML='<div class="rt-receipt-ok"><span class="rt-receipt-tick rt-receipt-copy">⎘</span><div><b>SALINAN RESIT</b><small>'+esc(no)+' · cetakan semula direkod bila dicetak</small></div></div>';
      if(label)label.textContent='TUTUP';
    }
    head.hidden=false;
  }
  window.rtReceiptDone=function(){
    if(typeof window.closeModal==='function')window.closeModal('receiptModal');
    if(receiptMode==='sale'){
      if(window.__rtActiveView!=='pos'&&typeof window.switchView==='function')window.switchView('pos');
      if(!coarse()){var q=$('posSearch');if(q)setTimeout(function(){try{q.focus();}catch(_){}},80);}
    }
  };
  window.rtPrintReceiptUi=function(btn){
    if(typeof window.rtPrintReceipt!=='function')return;
    if(btn&&btn.disabled)return;
    var old=btn?btn.innerHTML:'';
    if(btn){btn.disabled=true;btn.innerHTML='<span>MENCETAK...</span>';}
    return Promise.resolve(window.rtPrintReceipt()).catch(function(e){toast('Cetak gagal: '+(e&&e.message||e),'error');})
      .then(function(r){if(btn){btn.disabled=false;btn.innerHTML=old;feather();}return r;});
  };

  // ---------------------------------------------------------------- inventory stock filter
  var invFilter='all';
  window.rtApplyInventoryFilter=function(cache){
    var rows=document.querySelectorAll('#tblInventory tbody tr[data-stock-status]');
    var low=0,out=0;
    [].forEach.call(rows,function(r){
      var s=r.getAttribute('data-stock-status');
      if(s==='low')low++;if(s==='out')out++;
      var show=invFilter==='all'||(invFilter==='low'&&(s==='low'||s==='out'))||(invFilter==='out'&&s==='out');
      r.classList.toggle('rt-inv-hide',!show);
    });
    var lc=$('rtInvLowCount'),oc=$('rtInvOutCount');
    if(lc)lc.textContent=String(low+out);if(oc)oc.textContent=String(out);
  };
  window.rtSetInventoryFilter=function(key){
    invFilter=key||'all';
    [].forEach.call(document.querySelectorAll('#rtInvFilter [data-inv-filter]'),function(b){b.classList.toggle('active',b.getAttribute('data-inv-filter')===invFilter);});
    window.rtApplyInventoryFilter();
  };

  // ---------------------------------------------------------------- keyboard safety (Android tablets)
  document.addEventListener('focusin',function(e){
    var t=e.target;
    if(!t||!/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)||!coarse())return;
    if(!(t.closest&&t.closest('.modal-content,[id$="Modal"],.rt-cust-panel,.rt-adjust-panel,.rt-cart-footer,.rt-drawer-popover,.rt-confirm-box')))return;
    setTimeout(function(){try{t.scrollIntoView({block:'center'});}catch(_){}},320);
  });
  document.addEventListener('keydown',function(e){
    if(e.key!=='Escape')return;
    var p=$('rtDrawerPopover');if(p&&!p.classList.contains('hidden'))window.rtToggleDrawerPopover(false);
    var c=$('rtCustPanel');if(c&&!c.classList.contains('hidden'))window.rtToggleCustPanel(false);
  });

  // ---------------------------------------------------------------- toast de-duplication
  // The success header already shows the invoice; skip the identical "berjaya" toast behind it.
  function wrapToast(){
    var orig=window.showToast;
    if(typeof orig!=='function'||orig.__rtPolish)return;
    var w=function(message,type){
      try{
        var rm=$('receiptModal'),head=$('rtReceiptHead');
        if((type||'success')==='success'&&rm&&!rm.classList.contains('hidden')&&head&&!head.hidden&&head.classList.contains('is-sale')){
          var no=head.getAttribute('data-invoice')||'';
          if(no&&String(message||'').indexOf(no)>=0)return;
        }
      }catch(_){}
      return orig.apply(this,arguments);
    };
    w.__rtPolish=true;window.showToast=w;
  }

  // ---------------------------------------------------------------- portrait: jump to cart
  function bindCartJump(){
    var view=$('view-pos'),cartEl=document.querySelector('#view-pos .rt-pos-cart');
    if(!view||!cartEl||$('rtCartJump'))return;
    var b=document.createElement('button');
    b.type='button';b.id='rtCartJump';b.className='rt-cart-jump';b.hidden=true;
    b.onclick=function(){try{cartEl.scrollIntoView({block:'start',behavior:'smooth'});}catch(_){cartEl.scrollIntoView();}};
    view.appendChild(b);
    var cartVisible=false;
    if('IntersectionObserver' in window){
      try{new IntersectionObserver(function(es){cartVisible=es[0]&&es[0].isIntersecting;syncCartJump();},{threshold:0.15}).observe(cartEl);}catch(_){}
    }
    function syncCartJump(){
      var n=cart().reduce(function(a,i){return a+num(i.qty);},0);
      var narrow=(window.innerWidth||0)<=900;
      b.hidden=!(narrow&&n>0&&!cartVisible);
      if(!b.hidden)b.innerHTML='<span>TROLI '+n+'</span><b>'+esc(($('posTotal')||{}).textContent||'')+'</b><i>&#8250;</i>';
    }
    window.rtSyncCartJump=syncCartJump;
  }

  // ---------------------------------------------------------------- boot
  var cartRendered=false;
  function boot(){
    wrapTotals();wrapCheckout();wrapReceipt();wrapLoadPOS();wrapToast();
    bindSearch();bindGrid();bindCustomer();bindDrawer();bindCartJump();
    syncSearchClear();syncDrawerChip();
    // Show the "Troli kosong" state on first open (cart was only drawn after the first change).
    if(!cartRendered&&typeof window.rtRenderPosCart==='function'){cartRendered=true;try{window.rtRenderPosCart();}catch(_){}}
    try{window.posCalculateTotal&&window.posCalculateTotal();}catch(_){}
    syncCustomer(true);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
  // Later modules finish wiring around load (+900..1500ms); re-wrap once they are in place.
  window.addEventListener('load',function(){setTimeout(boot,1100);setTimeout(boot,2000);});
  setInterval(function(){
    if(!posActive())return;
    syncCustomer(false);syncDrawerChip();
    if(window.rtSyncCartJump)window.rtSyncCartJump();
  },700);
})();
