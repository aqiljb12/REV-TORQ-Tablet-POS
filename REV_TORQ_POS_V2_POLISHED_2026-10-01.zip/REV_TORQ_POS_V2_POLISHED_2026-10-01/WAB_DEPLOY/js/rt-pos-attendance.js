/* REV TORQ v0.9.2 — POS attendance popover
   Shared POS terminal: staff selects their own name.
   Uses narrow SECURITY DEFINER RPCs so RLS stays intact.
*/
(function(){
'use strict';
const $=id=>document.getElementById(id);
function sb(){return window.supabaseClient||window.supabase||window.sb||null;}
function toast(m,type){if(typeof window.showToast==='function')window.showToast(m,type||'success');else alert(m);}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function cid(){
  const p=window.currentProfile||{};
  const cached=p.company_id||p.companyId||null;
  if(cached)return cached;
  try{
    if(typeof window.companyId==='function'){
      const v=await window.companyId();
      return (typeof v==='string'&&v)?v:null;
    }
  }catch(_){ }
  return null;
}
async function getStaff(){
  const db=sb(); if(!db)throw Error('Supabase belum tersedia.');
  const company=await cid();
  let q=db.from('staff').select('id,staff_code,name,company_id,active,removed_from_active_list').eq('active',true).order('staff_code');
  if(company)q=q.eq('company_id',company);
  const r=await q; if(r.error)throw r.error;
  return (r.data||[]).filter(x=>x.active!==false&&x.removed_from_active_list!==true);
}
async function openShift(id){
  const db=sb(); if(!db)throw Error('Supabase belum tersedia.');
  const r=await db.rpc('rt_pos_attendance_status',{p_staff_id:id});
  if(r.error)throw r.error;
  const row=Array.isArray(r.data)?r.data[0]:r.data;
  if(!row)return null;
  return row.is_clocked_in?{id:row.attendance_id,clock_in:row.clock_in,clock_out:row.clock_out}:null;
}
function fmt(v){return v?new Intl.DateTimeFormat('ms-MY',{dateStyle:'medium',timeStyle:'short'}).format(new Date(v)):'—';}
async function refreshStatus(){
  const sel=$('rtAttendanceStaffSelect'), st=$('rtAttendanceStatus'), act=$('rtAttendanceAction');
  if(!sel||!st||!act)return;
  const id=sel.value;
  if(!id){st.textContent='Pilih nama staff.';act.textContent='CLOCK IN';act.disabled=true;return;}
  st.textContent='Semak status...';act.disabled=true;
  try{
    const row=await openShift(id);
    sel.dataset.openId=row?.id||'';
    if(row){st.innerHTML='🟢 <b>Clocked In</b><br><span class="text-slate-500">Masuk: '+esc(fmt(row.clock_in))+'</span>';act.textContent='CLOCK OUT';}
    else{st.textContent='🔴 Belum Clock In';act.textContent='CLOCK IN';}
    act.disabled=false;
  }catch(e){st.textContent=e.message||'Gagal semak attendance';act.disabled=true;}
}
async function loadStaff(){
  const sel=$('rtAttendanceStaffSelect');if(!sel)return;
  sel.innerHTML='<option value="">Memuatkan staff...</option>';sel.disabled=true;
  try{
    const list=await getStaff();
    sel.innerHTML='<option value="">Pilih nama staff</option>'+list.map(s=>`<option value="${esc(s.id)}">${esc(s.staff_code||'')} — ${esc(s.name||'')}</option>`).join('');
    sel.disabled=false;
  }catch(e){sel.innerHTML='<option value="">Gagal load staff</option>';sel.disabled=true;toast(e.message||'Gagal load staff','error');}
}
async function action(){
  const sel=$('rtAttendanceStaffSelect'),act=$('rtAttendanceAction');const id=sel?.value;if(!id)return;
  act.disabled=true;
  try{
    const db=sb(); if(!db)throw Error('Supabase belum tersedia.');
    const r=await db.rpc('rt_pos_attendance_toggle',{p_staff_id:id});
    if(r.error)throw r.error;
    const row=Array.isArray(r.data)?r.data[0]:r.data;
    const a=String(row?.action||'').toUpperCase();
    toast(a==='CLOCK_OUT'?'Clock Out berjaya.':'Clock In berjaya.');
    await refreshStatus();
  }catch(e){toast(e.message||'Attendance gagal.','error');}
  finally{if(act)act.disabled=false;}
}
function mount(){
  const btn=$('rtAttendanceMenuBtn'),pop=$('rtAttendancePopover');if(!btn||!pop)return;
  btn.addEventListener('click',e=>{e.stopPropagation();pop.classList.toggle('hidden');if(!pop.classList.contains('hidden'))loadStaff();});
  document.addEventListener('click',e=>{if(!e.target.closest('#rtAttendanceWrap'))pop.classList.add('hidden');});
  $('rtAttendanceStaffSelect')?.addEventListener('change',refreshStatus);
  $('rtAttendanceAction')?.addEventListener('click',action);
}
document.addEventListener('DOMContentLoaded',mount);
window.rtAttendanceToggle=()=>{$('rtAttendanceMenuBtn')?.click();};
})();
