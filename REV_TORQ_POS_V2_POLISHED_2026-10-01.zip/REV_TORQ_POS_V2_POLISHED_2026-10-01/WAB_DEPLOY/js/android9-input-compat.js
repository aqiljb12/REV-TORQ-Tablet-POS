/* REV TORQ Android 9 WebView input compatibility
   Keeps text controls visible on old Chromium WebView and keeps programmatic
   values synchronized with Blink's inner editor. No external dependency. */
(function(){
  'use strict';

  function descriptorSetter(el){
    try{
      if(window.HTMLInputElement && el instanceof HTMLInputElement){
        var d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');
        return d&&d.set?d.set:null;
      }
      if(window.HTMLTextAreaElement && el instanceof HTMLTextAreaElement){
        var d=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value');
        return d&&d.set?d.set:null;
      }
    }catch(_){ }
    return null;
  }

  function nativeSet(el,value){
    if(!el)return false;
    const next=String(value==null?'':value);
    const setter=descriptorSetter(el);
    try{
      if(setter)setter.call(el,next);
      else el.value=next;
      return true;
    }catch(_){
      try{el.value=next;return true;}catch(__){return false;}
    }
  }

  function emit(el,type){
    try{el.dispatchEvent(new Event(type,{bubbles:true}));}catch(_){ }
  }

  function schedulePaintRefresh(el,expected){
    const run=function(){
      if(!el || (typeof el.isConnected==='boolean' && !el.isConnected))return;
      if(String(el.value==null?'':el.value)!==expected)return; // user changed it already
      // Old Android WebView can leave the inner editor stale even while .value
      // is correct. Rebuilding through the native setter forces a fresh paint.
      nativeSet(el,'');
      nativeSet(el,expected);
      try{
        const n=expected.length;
        if(document.activeElement===el && typeof el.setSelectionRange==='function')el.setSelectionRange(n,n);
      }catch(_){ }
    };
    try{(window.requestAnimationFrame||function(cb){setTimeout(cb,16);})(run);}catch(_){setTimeout(run,16);}
  }

  window.rtSetNativeInputValue=function(target,value,opts){
    opts=opts||{};
    const el=typeof target==='string'?document.getElementById(target):target;
    if(!el)return false;
    let next=String(value==null?'':value);
    if(opts.uppercase)next=next.toUpperCase();
    if(!nativeSet(el,next))return false;
    try{if(el.tagName==='INPUT')el.setAttribute('value',next);}catch(_){ }
    if(opts.dispatch!==false){emit(el,'input');emit(el,'change');}
    if(opts.rebuild!==false && next)schedulePaintRefresh(el,next);
    return true;
  };

  window.rtUppercaseControl=function(target){
    const el=typeof target==='string'?document.getElementById(target):target;
    if(!el)return '';
    const current=String(el.value==null?'':el.value);
    const upper=current.toUpperCase();
    if(current!==upper){
      let start=null,end=null;
      try{start=el.selectionStart;end=el.selectionEnd;}catch(_){ }
      nativeSet(el,upper);
      try{if(start!=null&&end!=null&&typeof el.setSelectionRange==='function')el.setSelectionRange(start,end);}catch(_){ }
    }
    return upper;
  };

  // UUID v4 helper for Android 9-era WebView where crypto.randomUUID may not exist.
  function uuidV4(){
    try{if(window.crypto && typeof window.crypto.randomUUID==='function')return window.crypto.randomUUID();}catch(_){ }
    const bytes=new Uint8Array(16);
    if(window.crypto && typeof window.crypto.getRandomValues==='function')window.crypto.getRandomValues(bytes);
    else for(let i=0;i<16;i++)bytes[i]=Math.floor(Math.random()*256);
    bytes[6]=(bytes[6]&0x0f)|0x40;
    bytes[8]=(bytes[8]&0x3f)|0x80;
    const h=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
    return h.slice(0,8)+'-'+h.slice(8,12)+'-'+h.slice(12,16)+'-'+h.slice(16,20)+'-'+h.slice(20);
  }
  window.rtUuidV4=uuidV4;
  try{
    if(window.crypto && typeof window.crypto.randomUUID!=='function'){
      Object.defineProperty(window.crypto,'randomUUID',{value:uuidV4,configurable:true});
    }
  }catch(_){ }

  const uppercaseIds=new Set([
    'loginId','custInitPlat','vehPlate','staffIdField','invSku','invBarcode','invRackCode','grnRef','remPlate'
  ]);
  function needsUppercase(el){
    if(!el || !el.id && typeof el.matches!=='function')return false;
    if(uppercaseIds.has(el.id))return true;
    try{return !!el.matches('.rt-pos-voucher-row input,.rt-pos-promo input');}catch(_){return false;}
  }
  function applyUppercaseEvent(e){
    if(e && e.isComposing)return;
    const el=e?e.target:null;
    if(needsUppercase(el))window.rtUppercaseControl(el);
  }
  document.addEventListener('input',applyUppercaseEvent,true);
  document.addEventListener('change',applyUppercaseEvent,true);
  document.addEventListener('blur',applyUppercaseEvent,true);
  document.addEventListener('compositionend',applyUppercaseEvent,true);
})();
