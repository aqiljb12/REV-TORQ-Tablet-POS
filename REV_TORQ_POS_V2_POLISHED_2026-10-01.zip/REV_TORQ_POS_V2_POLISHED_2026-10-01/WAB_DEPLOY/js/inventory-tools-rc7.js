/* REV TORQ RC7 - Inventory scanner gun, internal barcode and price/barcode sticker printing */
(function(){
'use strict';
const $=id=>document.getElementById(id);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
const money=v=>'RM '+Number(v||0).toFixed(2);
async function companyId(){
  if(typeof window.companyId==='function')return await window.companyId();
  const p=window.currentProfile||{};return p.companyId||p.company_id||null;
}
function cachedBySku(sku){return (window.rtInventoryCache||[]).find(x=>String(x.sku||'').toUpperCase()===String(sku||'').toUpperCase())||null;}
async function productBySku(sku){
  const hit=cachedBySku(sku);if(hit)return hit;
  const cid=await companyId();
  const r=await sb.from('products').select('id,sku,name,category,barcode,rack_location,cost_price,sell_price,min_stock,active').eq('company_id',cid).eq('sku',String(sku||'').trim().toUpperCase()).maybeSingle();
  if(r.error)throw r.error;return r.data||null;
}

// ---------------- Internal barcode ----------------
window.rtGenerateInventoryBarcode=async function(){
  const input=$('invBarcode');
  if(!input)return;
  if(String(input.value||'').trim()){
    if(typeof showToast==='function')showToast('Barcode sudah diisi. Kosongkan dahulu jika mahu kod REV TORQ.','info');
    return input.value;
  }
  try{
    const r=await sb.rpc('rt_generate_internal_barcode');
    if(r.error)throw r.error;
    const generated=String(r.data||'').trim().toUpperCase();
    if(window.rtSetNativeInputValue)window.rtSetNativeInputValue(input,generated,{uppercase:true,rebuild:true});
    else{input.value=generated;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));}
    if(typeof showToast==='function')showToast('Kod dalaman dijana: '+input.value,'success');
    return input.value;
  }catch(e){console.error('rtGenerateInventoryBarcode',e);if(typeof showToast==='function')showToast('Gagal jana barcode: '+(e.message||e),'error');}
};

async function ensureExistingProductBarcode(product){
  if(product?.barcode)return product;
  if(String(product?.category||'').toUpperCase()==='SERVIS')throw new Error('Item SERVIS tidak memerlukan sticker barcode.');
  const g=await sb.rpc('rt_generate_internal_barcode');if(g.error)throw g.error;
  const code=String(g.data||'').trim();
  const p=window.currentProfile||{};
  const s=await sb.rpc('rt_inventory_save_fast',{
    p_sku:product.sku,p_name:product.name,p_category:product.category||null,p_barcode:code,
    p_rack_location:product.rack_location||null,p_cost_price:Number(product.cost_price||0),p_sell_price:Number(product.sell_price||0),
    p_min_stock:Number(product.min_stock||0),p_active:product.active!==false,p_opening_stock:0,p_is_edit:true,
    p_location_id:p.locationId||p.location_id||null
  });
  if(s.error)throw s.error;
  const updated={...product,...(s.data||{}),barcode:code};
  if(window.rtInventoryCache){const i=window.rtInventoryCache.findIndex(x=>x.id===updated.id||x.sku===updated.sku);if(i>=0)window.rtInventoryCache[i]={...window.rtInventoryCache[i],...updated};}
  setTimeout(()=>window.loadInventory?.({silent:true}),80);
  return updated;
}

// ---------------- Scanner gun / HID ----------------
let gunBuffer='',gunLast=0;
function inventoryVisible(){const v=$('view-inventory');return !!v && !v.classList.contains('hidden');}
function isTypingTarget(t){return !!t && ['INPUT','TEXTAREA','SELECT'].includes(t.tagName) && t.id!=='inventoryBarcodeSearch';}
document.addEventListener('keydown',function(e){
  if(e.ctrlKey||e.altKey||e.metaKey)return;
  if(e.target?.id==='invBarcode'&&e.key==='Enter'){
    e.preventDefault();
    const code=String(e.target.value??'').trim().replace(/[\r\n\t ]+/g,'').toUpperCase();
    if(window.rtSetNativeInputValue)window.rtSetNativeInputValue(e.target,code,{uppercase:true,rebuild:true});
    else{e.target.value=code;e.target.dispatchEvent(new Event('change',{bubbles:true}));}
    return;
  }
  if(!inventoryVisible())return;
  if(isTypingTarget(e.target))return;
  if(e.target?.id==='inventoryBarcodeSearch')return; // field has its own Enter flow
  const now=performance.now();
  if(e.key==='Enter'){
    const code=gunBuffer.trim();
    const fast=(now-gunLast)<180;
    gunBuffer='';
    if(code.length>=4&&fast){e.preventDefault();window.inventoryBarcodeLookup?.(code);}
    return;
  }
  if(e.key.length===1){
    if(now-gunLast>100)gunBuffer='';
    gunBuffer+=e.key;gunLast=now;
    if(gunBuffer.length>80)gunBuffer=gunBuffer.slice(-80);
  }
},true);

function enhanceScannerUI(){
  const field=$('inventoryBarcodeSearch');
  if(field&&!field.dataset.rc7){
    field.dataset.rc7='1';field.inputMode='text';field.placeholder='Scanner gun / taip barcode atau SKU...';
    const wrap=field.parentElement;
    if(wrap&&!$('rtScannerReady')){
      const hint=document.createElement('div');hint.id='rtScannerReady';hint.className='w-full text-[10px] text-emerald-700 font-bold mt-1';
      hint.textContent='● SCANNER GUN READY — scan terus, tak perlu tekan kotak';
      wrap.parentElement?.appendChild(hint);
    }
  }
  const cam=$('rtInventoryCameraBtn');if(cam&&!cam.dataset.bound){cam.dataset.bound='1';cam.onclick=()=>window.openInventoryCameraScanner?.();}
}

// ---------------- Sticker modal ----------------
function createStickerModal(){
  let m=$('rtStickerModal');if(m)return m;
  m=document.createElement('div');m.id='rtStickerModal';m.className='fixed inset-0 z-[260] bg-slate-950/70 backdrop-blur-sm hidden items-center justify-center p-4';
  m.innerHTML=`<div class="bg-white rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden">
    <div class="p-5 border-b border-slate-100 flex items-center justify-between"><div><b class="text-lg text-slate-900">Print Sticker Harga + Barcode</b><p class="text-xs text-slate-500 mt-1">Pilih item, saiz sticker dan kuantiti.</p></div><button id="rtStickerClose" class="w-9 h-9 rounded-xl bg-slate-100 font-bold text-slate-600">✕</button></div>
    <div class="p-5 space-y-4 max-h-[80dvh] overflow-y-auto">
      <div><label class="text-[11px] font-black text-slate-500 uppercase">Cari Item</label><input id="rtStickerSearch" autocomplete="off" class="mt-1 w-full border border-slate-200 rounded-xl px-4 py-3 text-sm" placeholder="Nama / SKU / barcode"><div id="rtStickerResults" class="mt-2 max-h-44 overflow-y-auto border border-slate-100 rounded-xl hidden"></div></div>
      <div id="rtStickerSelected" class="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-500">Belum pilih item.</div>
      <div class="grid grid-cols-2 gap-3"><div><label class="text-[11px] font-black text-slate-500 uppercase">Kuantiti Sticker</label><input id="rtStickerQty" type="number" min="1" max="100" value="1" class="mt-1 w-full border border-slate-200 rounded-xl px-4 py-3 font-mono"></div><div><label class="text-[11px] font-black text-slate-500 uppercase">Saiz</label><select id="rtStickerSize" class="mt-1 w-full border border-slate-200 rounded-xl px-4 py-3 bg-white"><option value="50x30">50 × 30 mm</option><option value="40x30">40 × 30 mm</option><option value="60x40">60 × 40 mm</option></select></div></div>
      <div class="flex gap-4 text-xs font-bold text-slate-600"><label class="flex gap-2 items-center"><input id="rtStickerShowPrice" type="checkbox" checked> Harga jual</label><label class="flex gap-2 items-center"><input id="rtStickerShowSku" type="checkbox" checked> SKU</label></div>
      <div id="rtStickerNoBarcode" class="hidden p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs"><b>Item ini belum ada barcode.</b> Tekan Jana Barcode untuk simpan kod REV TORQ sebelum print. <button id="rtStickerGen" class="mt-2 w-full py-2 rounded-lg bg-amber-500 text-white font-black">JANA & SIMPAN BARCODE</button></div>
      <button id="rtStickerPrint" class="w-full py-3.5 rounded-xl bg-violet-600 text-white font-black shadow-md disabled:opacity-40" disabled>PRINT STICKER</button>
    </div></div>`;
  document.body.appendChild(m);
  m.querySelector('#rtStickerClose').onclick=()=>m.classList.add('hidden');
  m.addEventListener('click',e=>{if(e.target===m)m.classList.add('hidden');});
  let timer=null;
  m.querySelector('#rtStickerSearch').addEventListener('input',e=>{clearTimeout(timer);timer=setTimeout(()=>searchStickerItems(e.target.value),180);});
  m.querySelector('#rtStickerGen').onclick=async()=>{
    try{if(!window.rtStickerProduct)return;const b=m.querySelector('#rtStickerGen');b.disabled=true;b.textContent='MENJANA...';window.rtStickerProduct=await ensureExistingProductBarcode(window.rtStickerProduct);renderSelectedSticker();if(typeof showToast==='function')showToast('Barcode '+window.rtStickerProduct.barcode+' disimpan.','success');}catch(e){window.showToast?.(e.message||e,'error');}finally{const b=m.querySelector('#rtStickerGen');b.disabled=false;b.textContent='JANA & SIMPAN BARCODE';}
  };
  m.querySelector('#rtStickerPrint').onclick=printSticker;
  return m;
}
async function searchStickerItems(q){
  const out=$('rtStickerResults');if(!out)return;
  const term=String(q||'').trim().toLowerCase();
  if(!term){out.classList.add('hidden');out.innerHTML='';return;}
  let list=(window.rtInventoryCache||[]).filter(x=>[x.sku,x.name,x.barcode].some(v=>String(v||'').toLowerCase().includes(term))).slice(0,12);
  if(!list.length&&term.length>=2){
    try{const cid=await companyId();const r=await sb.from('products').select('id,sku,name,category,barcode,rack_location,cost_price,sell_price,min_stock,active').eq('company_id',cid).ilike('name','%'+term.replace(/[%_]/g,'')+'%').limit(12);if(!r.error)list=r.data||[];}catch(_){ }
  }
  out.innerHTML=list.map(x=>`<button type="button" data-sku="${esc(x.sku)}" class="w-full text-left px-3 py-2.5 border-b border-slate-100 hover:bg-slate-50"><b class="text-slate-800">${esc(x.name)}</b><div class="text-[10px] text-slate-500 font-mono">${esc(x.sku)} • ${esc(x.barcode||'TIADA BARCODE')} • ${money(x.sell_price)}</div></button>`).join('')||'<div class="p-3 text-xs text-slate-400">Item tak jumpa.</div>';
  out.classList.remove('hidden');
  out.querySelectorAll('button[data-sku]').forEach(b=>b.onclick=()=>window.rtOpenStickerForSku(b.dataset.sku));
}
function renderSelectedSticker(){
  const p=window.rtStickerProduct,m=createStickerModal(),box=m.querySelector('#rtStickerSelected'),no=m.querySelector('#rtStickerNoBarcode'),print=m.querySelector('#rtStickerPrint');
  if(!p){box.textContent='Belum pilih item.';print.disabled=true;return;}
  box.innerHTML=`<div class="font-black text-slate-900 text-base">${esc(p.name)}</div><div class="mt-1 font-mono text-xs text-slate-500">SKU ${esc(p.sku)} • Barcode ${esc(p.barcode||'TIADA')}</div><div class="mt-2 text-xl font-black text-emerald-700">${money(p.sell_price)}</div>`;
  no.classList.toggle('hidden',!!p.barcode||String(p.category||'').toUpperCase()==='SERVIS');
  print.disabled=!p.barcode;
  m.querySelector('#rtStickerSearch').value='';m.querySelector('#rtStickerResults').classList.add('hidden');
}
window.rtOpenStickerManager=function(){window.rtStickerProduct=null;const m=createStickerModal();renderSelectedSticker();m.classList.remove('hidden');m.classList.add('flex');setTimeout(()=>m.querySelector('#rtStickerSearch')?.focus(),60);};
window.rtOpenStickerForSku=async function(sku){
  try{const p=await productBySku(sku);if(!p)throw new Error('Item tidak ditemui.');window.rtStickerProduct=p;const m=createStickerModal();renderSelectedSticker();m.classList.remove('hidden');m.classList.add('flex');}catch(e){window.showToast?.('Sticker gagal: '+(e.message||e),'error');}
};
function printSticker(){
  const p=window.rtStickerProduct;if(!p?.barcode){window.showToast?.('Item belum ada barcode.','error');return;}
  const qty=Math.min(100,Math.max(1,Number($('rtStickerQty')?.value||1)));
  const size=String($('rtStickerSize')?.value||'50x30');const [wmm,hmm]=size.split('x').map(Number);
  const showPrice=$('rtStickerShowPrice')?.checked!==false,showSku=$('rtStickerShowSku')?.checked!==false;
  const popup=window.open('','_blank');if(!popup){window.showToast?.('Browser block popup print. Benarkan pop-up untuk website ini.','error');return;}
  const labels=Array.from({length:qty},(_,i)=>`<section class="label"><div class="name">${esc(p.name)}</div>${showPrice?`<div class="price">${money(p.sell_price)}</div>`:''}<svg class="barcode" data-code="${esc(p.barcode)}"></svg>${showSku?`<div class="sku">${esc(p.sku)}${p.rack_location?' • '+esc(p.rack_location):''}</div>`:''}</section>`).join('');
  popup.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Sticker ${esc(p.sku)}</title><script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"><\/script><style>@page{size:${wmm}mm ${hmm}mm;margin:0}*{box-sizing:border-box}html,body{margin:0;padding:0;font-family:Arial,sans-serif}.label{width:${wmm}mm;height:${hmm}mm;padding:1.5mm 2mm;display:flex;flex-direction:column;align-items:center;justify-content:center;overflow:hidden;page-break-after:always}.name{font-weight:800;font-size:${wmm<=40?'8.5':'10'}pt;line-height:1.05;text-align:center;max-height:8mm;overflow:hidden}.price{font-size:${wmm<=40?'15':'18'}pt;font-weight:900;line-height:1;margin:.5mm 0}.barcode{width:95%;max-height:${hmm<=30?'10':'14'}mm}.sku{font-size:7pt;font-weight:700;margin-top:.5mm;text-align:center}.label:last-child{page-break-after:auto}@media screen{body{background:#ddd}.label{background:white;margin:8px auto;box-shadow:0 2px 12px #999}}</style></head><body>${labels}<script>window.addEventListener('load',function(){document.querySelectorAll('.barcode').forEach(function(el){JsBarcode(el,el.dataset.code,{format:'CODE128',displayValue:true,fontSize:10,height:${hmm<=30?28:38},margin:0,width:1.35});});setTimeout(function(){window.print();},350);});<\/script></body></html>`);
  popup.document.close();
}

function setupAutoBarcodeHint(){
  const hint=$('rtNoBarcodeHint');if(hint&&!hint.dataset.rc7){
    hint.dataset.rc7='1';
    hint.innerHTML='<span class="text-[10px] text-slate-500">Tiada barcode supplier? Kosongkan — masa Simpan sistem auto jana barcode REV TORQ.</span><button type="button" id="rtGenerateBarcodeNow" class="text-[10px] font-black text-violet-700 bg-violet-50 border border-violet-100 px-2 py-1 rounded-lg">JANA SEKARANG</button>';
    const b=$('rtGenerateBarcodeNow');if(b)b.onclick=window.rtGenerateInventoryBarcode;
  }
  const input=$('invBarcode');if(input)input.placeholder='Barcode supplier / kosong = AUTO REV TORQ';
}

window.addEventListener('load',()=>{enhanceScannerUI();setTimeout(setupAutoBarcodeHint,250);});
const observer=new MutationObserver(()=>{enhanceScannerUI();setupAutoBarcodeHint();});
observer.observe(document.documentElement,{childList:true,subtree:true});
})();
