-- REV TORQ POS v1.0.1 - Workshop Booking Confirmation
-- Customer Workshop bookings stay NEW with no Job Card until staff confirmation.

begin;

-- New customer Workshop bookings notify only. Job Card creation now belongs to
-- rt_staff_confirm_workshop_booking() so acceptance is explicit and atomic.
create or replace function public.rt_route_customer_workshop_booking()
returns trigger
language plpgsql
security definer
set search_path = public
as $function$
begin
  if new.booking_department = 'WORKSHOP'
     and coalesce(new.source,'') in ('website','customer_portal','customer_web','pwa') then
    insert into public.notifications(
      company_id, customer_id, title, body, url, notification_type, dedupe_key
    ) values (
      new.company_id, new.customer_id,
      'Booking diterima 🔧',
      'Booking '||new.booking_no||' sudah diterima dan menunggu pengesahan Workshop.',
      '/?tab=booking', 'BOOKING', 'booking-received:'||new.id::text
    ) on conflict do nothing;
  end if;
  return new;
end;
$function$;

-- Historical protection: never permit two Job Cards to point at one booking.
do $guard$
begin
  if exists (
    select 1
    from public.job_cards
    where booking_id is not null
    group by booking_id
    having count(*) > 1
  ) then
    raise exception 'DUPLICATE_JOB_CARD_BOOKING_LINKS_EXIST';
  end if;
end;
$guard$;

create unique index if not exists ux_job_cards_booking_id_one
on public.job_cards(booking_id)
where booking_id is not null;

create or replace function public.rt_staff_confirm_workshop_booking(p_booking_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $function$
declare
  v_staff_id uuid;
  v_company_id uuid;
  v_staff_location_id uuid;
  v_role text;
  v_booking public.bookings%rowtype;
  v_job_id uuid;
  v_job_no text;
  v_job_status text;
  v_job_card_created boolean := false;
begin
  if auth.uid() is null then
    raise exception 'AUTH_REQUIRED';
  end if;

  select s.id, s.company_id, s.location_id, lower(s.role)
  into v_staff_id, v_company_id, v_staff_location_id, v_role
  from public.staff s
  where s.auth_user_id = auth.uid()
    and s.active = true
    and coalesce(s.removed_from_active_list,false) = false
  limit 1;

  if v_staff_id is null then
    raise exception 'STAFF_NOT_FOUND';
  end if;
  if v_role not in ('owner','super_admin','admin') then
    raise exception 'BOOKING_ADMIN_REQUIRED';
  end if;

  select * into v_booking
  from public.bookings b
  where b.id = p_booking_id
  for update;

  if v_booking.id is null then raise exception 'BOOKING_NOT_FOUND'; end if;
  if v_booking.company_id is distinct from v_company_id then raise exception 'COMPANY_MISMATCH'; end if;
  if v_booking.booking_department <> 'WORKSHOP' then raise exception 'WORKSHOP_BOOKING_REQUIRED'; end if;
  if v_booking.status = 'CANCELLED' then raise exception 'BOOKING_CANCELLED'; end if;
  if v_booking.status = 'COMPLETED' then raise exception 'BOOKING_COMPLETED'; end if;
  if v_booking.status not in ('NEW','CONFIRMED') then raise exception 'BOOKING_NOT_PENDING'; end if;
  if v_booking.customer_id is null or v_booking.vehicle_id is null then raise exception 'BOOKING_CUSTOMER_VEHICLE_REQUIRED'; end if;

  select jc.id, jc.job_no, jc.status
  into v_job_id, v_job_no, v_job_status
  from public.job_cards jc
  where jc.booking_id = v_booking.id
  limit 1;

  if v_job_id is null then
    insert into public.job_cards(
      company_id, location_id, job_no, booking_id, customer_id, vehicle_id,
      status, complaint, estimated_total, actual_total, opened_at,
      source, created_by, updated_by
    ) values (
      v_booking.company_id,
      coalesce(v_booking.location_id, v_staff_location_id),
      'JC-' || upper(replace(v_booking.booking_no,'BK-','')),
      v_booking.id, v_booking.customer_id, v_booking.vehicle_id,
      'OPEN',
      concat_ws(E'\n', nullif(v_booking.notes,''),
        case when v_booking.requested_service is not null then 'Servis: '||v_booking.requested_service end),
      0, 0, now(), 'BOOKING', v_staff_id, v_staff_id
    )
    returning id, job_no, status into v_job_id, v_job_no, v_job_status;
    v_job_card_created := true;
  else
    v_job_card_created := false;
  end if;

  if v_booking.status = 'NEW' then
    update public.bookings
    set status='CONFIRMED', updated_at=now()
    where id=v_booking.id;
  end if;

  insert into public.notifications(
    company_id,customer_id,title,body,url,notification_type,dedupe_key
  ) values (
    v_booking.company_id, v_booking.customer_id,
    'Booking disahkan ✅',
    'Booking '||v_booking.booking_no||' telah disahkan oleh REV TORQ.',
    '/?tab=booking', 'BOOKING', 'booking-confirmed:'||v_booking.id::text
  ) on conflict do nothing;

  return jsonb_build_object(
    'booking_id', v_booking.id,
    'booking_no', v_booking.booking_no,
    'booking_status', 'CONFIRMED',
    'job_card_id', v_job_id,
    'job_no', v_job_no,
    'job_status', v_job_status,
    'job_card_created', v_job_card_created
  );
end;
$function$;

create or replace function public.rt_staff_reject_workshop_booking(
  p_booking_id uuid,
  p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $function$
declare
  v_staff_id uuid;
  v_company_id uuid;
  v_staff_location_id uuid;
  v_role text;
  v_booking public.bookings%rowtype;
  v_cancelled_jobs integer := 0;
  v_reason text;
begin
  if auth.uid() is null then
    raise exception 'AUTH_REQUIRED';
  end if;

  select s.id, s.company_id, s.location_id, lower(s.role)
  into v_staff_id, v_company_id, v_staff_location_id, v_role
  from public.staff s
  where s.auth_user_id = auth.uid()
    and s.active = true
    and coalesce(s.removed_from_active_list,false) = false
  limit 1;

  if v_staff_id is null then
    raise exception 'STAFF_NOT_FOUND';
  end if;
  if v_role not in ('owner','super_admin','admin') then
    raise exception 'BOOKING_ADMIN_REQUIRED';
  end if;

  v_reason := nullif(trim(coalesce(p_reason,'')),'');
  if v_reason is null then
    raise exception 'REJECTION_REASON_REQUIRED';
  end if;

  select * into v_booking
  from public.bookings b
  where b.id = p_booking_id
  for update;

  if v_booking.id is null then raise exception 'BOOKING_NOT_FOUND'; end if;
  if v_booking.company_id is distinct from v_company_id then raise exception 'COMPANY_MISMATCH'; end if;
  if v_booking.booking_department <> 'WORKSHOP' then raise exception 'WORKSHOP_BOOKING_REQUIRED'; end if;
  if v_booking.status = 'CANCELLED' then raise exception 'BOOKING_CANCELLED'; end if;
  if v_booking.status = 'COMPLETED' then raise exception 'BOOKING_COMPLETED'; end if;

  update public.bookings
  set status='CANCELLED',
      notes=concat_ws(E'\n', nullif(notes,''), '[STAFF REJECT] '||v_reason),
      updated_at=now()
  where id=v_booking.id;

  update public.job_cards
  set status='CANCELLED', updated_by=v_staff_id, updated_at=now()
  where booking_id=v_booking.id and status='OPEN';
  get diagnostics v_cancelled_jobs = row_count;

  insert into public.notifications(
    company_id,customer_id,title,body,url,notification_type,dedupe_key
  ) values (
    v_booking.company_id, v_booking.customer_id,
    'Booking tidak dapat disahkan',
    'Booking '||v_booking.booking_no||' dibatalkan: '||v_reason,
    '/?tab=booking', 'BOOKING', 'booking-rejected:'||v_booking.id::text
  ) on conflict do nothing;

  insert into public.audit_logs(
    company_id, location_id, staff_id, action, entity_type, entity_id,
    before_data, after_data, metadata
  ) values (
    v_booking.company_id,
    coalesce(v_booking.location_id, v_staff_location_id),
    v_staff_id,
    'BOOKING_REJECT',
    'BOOKING',
    v_booking.id,
    to_jsonb(v_booking),
    jsonb_build_object('status','CANCELLED'),
    jsonb_build_object('reason',v_reason,'cancelled_open_jobs',v_cancelled_jobs)
  );

  return jsonb_build_object(
    'booking_id', v_booking.id,
    'booking_no', v_booking.booking_no,
    'booking_status', 'CANCELLED',
    'cancelled_open_job_cards', v_cancelled_jobs,
    'reason', v_reason
  );
end;
$function$;

create or replace function public.rt_staff_reschedule_workshop_booking(
  p_booking_id uuid,
  p_preferred_date date,
  p_preferred_time time without time zone,
  p_staff_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $function$
declare
  v_staff_id uuid;
  v_company_id uuid;
  v_staff_location_id uuid;
  v_role text;
  v_booking public.bookings%rowtype;
  v_active integer;
  v_now_local timestamp;
  v_note text;
  v_dedupe text;
begin
  if auth.uid() is null then
    raise exception 'AUTH_REQUIRED';
  end if;

  select s.id, s.company_id, s.location_id, lower(s.role)
  into v_staff_id, v_company_id, v_staff_location_id, v_role
  from public.staff s
  where s.auth_user_id = auth.uid()
    and s.active = true
    and coalesce(s.removed_from_active_list,false) = false
  limit 1;

  if v_staff_id is null then
    raise exception 'STAFF_NOT_FOUND';
  end if;
  if v_role not in ('owner','super_admin','admin') then
    raise exception 'BOOKING_ADMIN_REQUIRED';
  end if;

  select * into v_booking
  from public.bookings b
  where b.id = p_booking_id
  for update;

  if v_booking.id is null then raise exception 'BOOKING_NOT_FOUND'; end if;
  if v_booking.company_id is distinct from v_company_id then raise exception 'COMPANY_MISMATCH'; end if;
  if v_booking.booking_department <> 'WORKSHOP' then raise exception 'WORKSHOP_BOOKING_REQUIRED'; end if;
  if v_booking.status <> 'NEW' then raise exception 'BOOKING_NOT_PENDING'; end if;
  if p_preferred_date is null or p_preferred_time is null then raise exception 'BOOKING_SLOT_REQUIRED'; end if;

  v_now_local := now() at time zone 'Asia/Kuala_Lumpur';
  if p_preferred_date < v_now_local::date
     or (p_preferred_date = v_now_local::date and p_preferred_time < v_now_local::time) then
    raise exception 'BOOKING_TIME_PAST';
  end if;

  perform pg_advisory_xact_lock(
    hashtextextended(v_booking.company_id::text||':'||p_preferred_date::text||':SERVICE',230826)
  );

  select count(*)::integer into v_active
  from public.bookings b
  where b.company_id=v_booking.company_id
    and b.id<>v_booking.id
    and b.preferred_date=p_preferred_date
    and b.status in ('NEW','CONFIRMED','ARRIVED')
    and upper(coalesce(b.requested_service,'')) not like '%DYNO%';
  if v_active >= 50 then raise exception 'BOOKING_FULL'; end if;

  if exists (
    select 1 from public.bookings b
    where b.company_id=v_booking.company_id
      and b.id<>v_booking.id
      and b.customer_id=v_booking.customer_id
      and b.vehicle_id=v_booking.vehicle_id
      and b.preferred_date=p_preferred_date
      and b.preferred_time=p_preferred_time
      and b.status in ('NEW','CONFIRMED','ARRIVED')
  ) then
    raise exception 'BOOKING_DUPLICATE';
  end if;

  v_note := nullif(trim(coalesce(p_staff_note,'')),'');
  update public.bookings
  set preferred_date=p_preferred_date,
      preferred_time=p_preferred_time,
      notes=case when v_note is null then notes
        else concat_ws(E'\n', nullif(notes,''), '[SLOT UPDATE] '||v_note) end,
      updated_at=now()
  where id=v_booking.id;

  v_dedupe := 'booking-slot:'||v_booking.id::text||':'||p_preferred_date::text||':'||replace(p_preferred_time::text,':','');
  insert into public.notifications(
    company_id,customer_id,title,body,url,notification_type,dedupe_key
  ) values (
    v_booking.company_id, v_booking.customer_id,
    'Slot booking dikemas kini',
    'Booking '||v_booking.booking_no||' dicadangkan ke '||p_preferred_date::text||' '||to_char(p_preferred_time,'HH24:MI')||'.',
    '/?tab=booking', 'BOOKING', v_dedupe
  ) on conflict do nothing;

  return jsonb_build_object(
    'booking_id', v_booking.id,
    'booking_no', v_booking.booking_no,
    'booking_status', 'NEW',
    'preferred_date', p_preferred_date,
    'preferred_time', to_char(p_preferred_time,'HH24:MI')
  );
end;
$function$;

revoke all on function public.rt_staff_confirm_workshop_booking(uuid) from public, anon;
grant execute on function public.rt_staff_confirm_workshop_booking(uuid) to authenticated, service_role;

revoke all on function public.rt_staff_reject_workshop_booking(uuid,text) from public, anon;
grant execute on function public.rt_staff_reject_workshop_booking(uuid,text) to authenticated, service_role;

revoke all on function public.rt_staff_reschedule_workshop_booking(uuid,date,time without time zone,text) from public, anon;
grant execute on function public.rt_staff_reschedule_workshop_booking(uuid,date,time without time zone,text) to authenticated, service_role;

commit;
