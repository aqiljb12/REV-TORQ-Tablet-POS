-- REV TORQ POS v1.0.3 — RM discount per cart item + overall discount.
-- Keeps existing RPC signatures. invoice_items.discount stores the RM discount for the whole line.
-- invoice_items.line_total stores the line net after item discount.
-- invoices.subtotal remains the sum of net line totals; invoices.discount remains the overall/cart discount.

create or replace function public.rt_post_pos_sale(
  p_customer_id uuid default null::uuid,
  p_vehicle_id uuid default null::uuid,
  p_location_id uuid default null::uuid,
  p_payment_method text default 'CASH'::text,
  p_amount_received numeric default 0,
  p_discount numeric default 0,
  p_reference_no text default null::text,
  p_transaction_id uuid default null::uuid,
  p_items jsonb default '[]'::jsonb
)
returns table(invoice_id uuid, invoice_no text, total numeric, change_amount numeric)
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  s record; loc uuid; tx uuid := coalesce(p_transaction_id,gen_random_uuid());
  inv uuid; v_invoice_no text; item jsonb; prod public.products;
  qty numeric; price numeric; gross_line numeric; line_discount numeric; net_line numeric;
  v_gross_subtotal numeric := 0; v_item_discount numeric := 0; v_subtotal numeric := 0;
  v_discount numeric := greatest(0,coalesce(p_discount,0)); v_total numeric := 0;
  received numeric := greatest(0,coalesce(p_amount_received,0)); payment_id uuid; drawer public.cash_drawers;
begin
  select * into s from public.rt_staff_context() limit 1;
  if s.staff_id is null then raise exception 'STAFF_CONTEXT_NOT_FOUND'; end if;
  if lower(coalesce(s.role,'')) not in ('owner','admin','super_admin','manager','cashier','pos') then raise exception 'POS_ROLE_NOT_ALLOWED'; end if;
  if p_payment_method not in ('CASH','QR','DUITNOW','CARD','TRANSFER','OTHER') then raise exception 'INVALID_PAYMENT_METHOD'; end if;
  if jsonb_typeof(coalesce(p_items,'[]'::jsonb)) <> 'array' or jsonb_array_length(coalesce(p_items,'[]'::jsonb))=0 then raise exception 'CART_EMPTY'; end if;

  if p_transaction_id is not null then
    select i.id,i.invoice_no,i.total into inv,v_invoice_no,v_total
    from public.invoices as i where i.company_id=s.company_id and i.transaction_id=p_transaction_id limit 1;
    if inv is not null then
      return query select inv,v_invoice_no,v_total,case when p_payment_method='CASH' then greatest(0,received-v_total) else 0::numeric end;
      return;
    end if;
  end if;

  loc := coalesce(p_location_id,s.location_id);
  if loc is null or not exists (select 1 from public.locations l where l.id=loc and l.company_id=s.company_id and l.active=true) then raise exception 'INVALID_LOCATION'; end if;
  if p_customer_id is not null and not exists (select 1 from public.customers c where c.id=p_customer_id and c.company_id=s.company_id and c.active=true) then raise exception 'INVALID_CUSTOMER'; end if;
  if p_vehicle_id is not null and not exists (select 1 from public.vehicles v where v.id=p_vehicle_id and v.company_id=s.company_id and v.active=true and (p_customer_id is null or v.customer_id=p_customer_id)) then raise exception 'INVALID_VEHICLE'; end if;

  for item in select * from jsonb_array_elements(p_items) loop
    qty := greatest(0,coalesce((item->>'quantity')::numeric,0)); if qty<=0 then raise exception 'INVALID_QUANTITY'; end if;
    if upper(coalesce(item->>'item_type','PART')) in ('SERVICE','LABOUR','OTHER') and nullif(item->>'product_id','') is null then
      price := greatest(0,coalesce((item->>'unit_price')::numeric,0));
    else
      if nullif(item->>'product_id','') is null then raise exception 'PRODUCT_ID_REQUIRED'; end if;
      select * into prod from public.products p where p.id=(item->>'product_id')::uuid and p.company_id=s.company_id and p.active=true;
      if prod.id is null then raise exception 'PRODUCT_NOT_FOUND'; end if;
      price := greatest(0,coalesce(prod.sell_price,0));
    end if;
    gross_line := round(qty*price,2);
    line_discount := least(gross_line,greatest(0,coalesce(nullif(item->>'discount','')::numeric,0)));
    net_line := round(greatest(0,gross_line-line_discount),2);
    v_gross_subtotal := v_gross_subtotal + gross_line;
    v_item_discount := v_item_discount + line_discount;
    v_subtotal := v_subtotal + net_line;
  end loop;

  v_discount := least(v_discount,v_subtotal);
  v_total := greatest(0,round(v_subtotal-v_discount,2));
  if v_total<=0 then raise exception 'INVALID_TOTAL'; end if;
  if p_payment_method='CASH' and received<v_total then raise exception 'CASH_RECEIVED_NOT_ENOUGH'; end if;
  if p_payment_method='CASH' then
    select * into drawer from public.cash_drawers where company_id=s.company_id and drawer_code='MAIN' and status='OPEN' for update;
    if drawer.id is null then raise exception 'CASH_DRAWER_NOT_OPEN'; end if;
  end if;

  insert into public.invoices(company_id,location_id,transaction_id,invoice_no,customer_id,vehicle_id,staff_id,subtotal,discount,tax,total,status,payment_status)
  values(s.company_id,loc,tx,null,p_customer_id,p_vehicle_id,s.staff_id,v_subtotal,v_discount,0,v_total,'UNPAID','UNPAID')
  returning id, public.invoices.invoice_no into inv,v_invoice_no;

  for item in select * from jsonb_array_elements(p_items) loop
    prod := null; qty := greatest(0,coalesce((item->>'quantity')::numeric,0));
    if upper(coalesce(item->>'item_type','PART')) in ('SERVICE','LABOUR','OTHER') and nullif(item->>'product_id','') is null then
      price := greatest(0,coalesce((item->>'unit_price')::numeric,0));
    else
      select * into prod from public.products p where p.id=(item->>'product_id')::uuid and p.company_id=s.company_id and p.active=true;
      price := greatest(0,coalesce(prod.sell_price,0));
    end if;
    gross_line := round(qty*price,2);
    line_discount := least(gross_line,greatest(0,coalesce(nullif(item->>'discount','')::numeric,0)));
    net_line := round(greatest(0,gross_line-line_discount),2);
    insert into public.invoice_items(invoice_id,product_id,job_item_type,description,quantity,unit_price,discount,line_total)
    values(
      inv,
      nullif(item->>'product_id','')::uuid,
      case when upper(coalesce(item->>'item_type','PART'))='LABOUR' then 'LABOUR' when upper(coalesce(item->>'item_type','PART'))='SERVICE' then 'SERVICE' when upper(coalesce(item->>'item_type','PART'))='OTHER' then 'OTHER' else 'PART' end,
      coalesce(nullif(item->>'description',''),prod.name,prod.sku,'POS Item'),
      qty,price,line_discount,net_line
    );
    if nullif(item->>'product_id','') is not null and upper(coalesce(item->>'item_type','PART')) not in ('SERVICE','LABOUR','OTHER') then
      perform public.post_stock_movement(s.company_id,loc,(item->>'product_id')::uuid,'SALE',qty,prod.cost_price,'INVOICE',inv,s.staff_id,null,tx);
    end if;
  end loop;

  perform public.recalculate_invoice(inv);
  if p_payment_method='CASH' then
    payment_id := public.post_payment(inv,'CASH',v_total,p_reference_no,drawer.id);
    update public.cash_drawers set expected_amount=coalesce(expected_amount,0)+v_total,updated_at=now() where id=drawer.id;
  else payment_id := public.post_payment(inv,p_payment_method,v_total,p_reference_no,null); end if;
  insert into public.audit_logs(company_id,location_id,transaction_id,staff_id,action,entity_type,entity_id,metadata)
  values(s.company_id,loc,tx,s.staff_id,'POS_CHECKOUT','INVOICE',inv,jsonb_build_object(
    'invoice_no',v_invoice_no,'payment_method',p_payment_method,'gross_subtotal',v_gross_subtotal,
    'item_discount',v_item_discount,'order_discount',v_discount,'total_discount',v_item_discount+v_discount,
    'total',v_total,'amount_received',received,'change',case when p_payment_method='CASH' then received-v_total else 0 end,'payment_id',payment_id
  ));
  return query select inv,v_invoice_no,v_total,case when p_payment_method='CASH' then received-v_total else 0::numeric end;
end;
$function$;

create or replace function public.rt_post_job_pos_sale(
  p_job_card_id uuid,
  p_customer_id uuid default null::uuid,
  p_payment_method text default 'CASH'::text,
  p_amount_received numeric default 0,
  p_discount numeric default 0,
  p_items jsonb default '[]'::jsonb
)
returns table(invoice_id uuid, invoice_no text, total numeric, change_amount numeric)
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  s record;
  j public.job_cards;
  loc uuid;
  tx uuid := gen_random_uuid();
  inv uuid;
  inv_no text;
  drawer public.cash_drawers;
  existing_paid uuid;
  item jsonb;
  ji public.job_card_items;
  prod public.products;
  subtotal numeric := 0;
  gross_subtotal numeric := 0;
  item_discount_total numeric := 0;
  discount numeric := greatest(0,coalesce(p_discount,0));
  total numeric := 0;
  received numeric := greatest(0,coalesce(p_amount_received,0));
  qty numeric;
  price numeric;
  gross_line numeric;
  line_discount numeric;
  line numeric;
  is_service boolean;
  from_job boolean;
  job_item_id uuid;
  v_product_id uuid;
  desc_text text;
  existing_qty numeric;
begin
  if p_payment_method not in ('CASH','QR','DUITNOW','CARD','TRANSFER','OTHER') then
    raise exception 'Kaedah bayaran tidak sah: %',p_payment_method;
  end if;

  select * into s from public.rt_staff_context() limit 1;
  if s.staff_id is null then raise exception 'Staf aktif tidak dijumpai'; end if;

  select * into j from public.job_cards where id=p_job_card_id and company_id=s.company_id for update;
  if j.id is null then raise exception 'Job Card tidak dijumpai'; end if;

  select i.id into existing_paid
  from public.invoices i
  where i.company_id=s.company_id and i.job_card_id=j.id and i.status='PAID' and i.payment_status='PAID'
  order by i.created_at desc limit 1;
  if existing_paid is not null then raise exception 'Job Card % sudah dibayar. Invoice sedia ada tidak boleh dibayar sekali lagi.',j.job_no; end if;

  if upper(coalesce(j.status,'')) in ('PAID','CLOSED') then raise exception 'Job Card % sudah dibayar',j.job_no; end if;
  if upper(coalesce(j.status,'')) not in ('COMPLETED','READY','DONE') then raise exception 'Job Card % belum siap dibayar (status: %)',j.job_no,j.status; end if;

  loc:=coalesce(j.location_id,s.location_id);
  if loc is null then select id into loc from public.locations where company_id=s.company_id and active=true order by code limit 1; end if;
  if loc is null then raise exception 'Lokasi aktif tidak dijumpai'; end if;

  if jsonb_typeof(coalesce(p_items,'[]'::jsonb)) <> 'array' or jsonb_array_length(coalesce(p_items,'[]'::jsonb))=0 then raise exception 'Troli kosong'; end if;

  for item in select * from jsonb_array_elements(p_items) loop
    qty:=greatest(0,coalesce((item->>'quantity')::numeric,0));
    if qty<=0 then raise exception 'Kuantiti tidak sah'; end if;
    is_service:=upper(coalesce(item->>'item_type',''))='SERVICE';
    from_job:=coalesce((item->>'from_job_card')::boolean,false);
    job_item_id:=nullif(item->>'job_card_item_id','')::uuid;
    v_product_id:=nullif(item->>'product_id','')::uuid;
    if from_job and job_item_id is null then raise exception 'Item Job Card tidak mempunyai job_card_item_id'; end if;
    if from_job then
      select * into ji from public.job_card_items where id=job_item_id and company_id=s.company_id and job_card_id=j.id;
      if ji.id is null then raise exception 'Item Job Card tidak sah'; end if;
      if is_service <> (upper(coalesce(ji.item_type,'PART'))<>'PART') then raise exception 'Jenis item Job Card tidak sepadan'; end if;
      price:=greatest(0,coalesce(ji.unit_price,0)); desc_text:=coalesce(item->>'description','Job Card Item');
    elsif is_service then
      price:=greatest(0,coalesce((item->>'service_price')::numeric,0)); desc_text:=coalesce(item->>'description','Service');
    else
      if v_product_id is null then raise exception 'Part tanpa product_id'; end if;
      select * into prod from public.products where id=v_product_id and company_id=s.company_id and active=true;
      if prod.id is null then raise exception 'Produk tidak dijumpai'; end if;
      price:=greatest(0,coalesce(prod.sell_price,0)); desc_text:=coalesce(item->>'description',prod.name,prod.sku,'Part');
    end if;
    gross_line:=round(qty*price,2);
    line_discount:=least(gross_line,greatest(0,coalesce(nullif(item->>'discount','')::numeric,0)));
    line:=round(greatest(0,gross_line-line_discount),2);
    gross_subtotal:=gross_subtotal+gross_line;
    item_discount_total:=item_discount_total+line_discount;
    subtotal:=subtotal+line;
  end loop;

  discount:=least(discount,subtotal);
  total:=greatest(0,round(subtotal-discount,2));
  if p_payment_method='CASH' and received<total then raise exception 'Tunai diterima tidak mencukupi'; end if;

  if p_payment_method='CASH' then
    select * into drawer from public.cash_drawers where company_id=s.company_id and drawer_code='MAIN' and status='OPEN' for update;
    if drawer.id is null then raise exception 'Peti tunai belum OPEN'; end if;
  end if;

  inv_no:='INV-JOB-'||to_char(clock_timestamp(),'YYYYMMDDHH24MISS')||'-'||substr(replace(gen_random_uuid()::text,'-',''),1,5);
  insert into public.invoices(company_id,location_id,transaction_id,invoice_no,customer_id,vehicle_id,job_card_id,staff_id,subtotal,discount,tax,total,status,payment_status)
  values(s.company_id,loc,tx,inv_no,coalesce(p_customer_id,j.customer_id),j.vehicle_id,j.id,s.staff_id,subtotal,discount,0,total,'PAID','PAID')
  returning id into inv;

  for item in select * from jsonb_array_elements(p_items) loop
    qty:=greatest(0,coalesce((item->>'quantity')::numeric,0));
    is_service:=upper(coalesce(item->>'item_type',''))='SERVICE';
    from_job:=coalesce((item->>'from_job_card')::boolean,false);
    job_item_id:=nullif(item->>'job_card_item_id','')::uuid;
    v_product_id:=nullif(item->>'product_id','')::uuid;
    if from_job then
      select * into ji from public.job_card_items where id=job_item_id and company_id=s.company_id and job_card_id=j.id;
      price:=greatest(0,coalesce(ji.unit_price,0)); desc_text:=coalesce(item->>'description','Job Card Item'); v_product_id:=ji.product_id;
    elsif is_service then
      price:=greatest(0,coalesce((item->>'service_price')::numeric,0)); desc_text:=coalesce(item->>'description','Service');
    else
      select * into prod from public.products where id=v_product_id and company_id=s.company_id and active=true;
      price:=greatest(0,coalesce(prod.sell_price,0)); desc_text:=coalesce(item->>'description',prod.name,prod.sku,'Part');
    end if;
    gross_line:=round(qty*price,2);
    line_discount:=least(gross_line,greatest(0,coalesce(nullif(item->>'discount','')::numeric,0)));
    line:=round(greatest(0,gross_line-line_discount),2);
    insert into public.invoice_items(invoice_id,product_id,job_item_type,description,quantity,unit_price,discount,line_total)
    values(inv,v_product_id,case when is_service then 'SERVICE' else 'PART' end,desc_text,qty,price,line_discount,line);
    if not is_service and not from_job then
      select quantity into existing_qty from public.stock_balances where stock_balances.product_id=v_product_id and stock_balances.location_id=loc for update;
      existing_qty:=coalesce(existing_qty,0);
      if existing_qty<qty then
        select name into desc_text from public.products where id=v_product_id;
        raise exception 'Stok % tidak mencukupi. Baki: %, perlu: %',desc_text,existing_qty,qty;
      end if;
      update public.stock_balances set quantity=quantity-qty,updated_at=now() where stock_balances.product_id=v_product_id and stock_balances.location_id=loc;
      insert into public.stock_movements(company_id,location_id,product_id,transaction_id,movement_type,quantity,unit_cost,reference_type,reference_id,staff_id)
      select s.company_id,loc,v_product_id,tx,'SALE',-qty,p.cost_price,'INVOICE',inv,s.staff_id from public.products p where p.id=v_product_id;
    end if;
  end loop;

  insert into public.payments(company_id,invoice_id,transaction_id,payment_method,amount,staff_id)
  values(s.company_id,inv,tx,p_payment_method,total,s.staff_id);

  if p_payment_method='CASH' then
    update public.cash_drawers set expected_amount=coalesce(expected_amount,0)+total where id=drawer.id;
    insert into public.cash_movements(company_id,cash_drawer_id,transaction_id,movement_type,amount,reference_type,reference_id,reason,staff_id)
    values(s.company_id,drawer.id,tx,'SALE',total,'INVOICE',inv,
      concat('Jualan ',inv_no,'; diterima ',to_char(received,'FM999999990.00'),'; baki ',to_char(received-total,'FM999999990.00')),s.staff_id);
  end if;

  update public.job_cards set status='COMPLETED', actual_total=total, completed_at=coalesce(completed_at, now()), updated_at=now()
  where id=j.id and company_id=s.company_id;

  insert into public.audit_logs(company_id,location_id,transaction_id,staff_id,action,entity_type,entity_id,metadata)
  values(s.company_id,loc,tx,s.staff_id,'POS_CHECKOUT','INVOICE',inv,jsonb_build_object(
    'invoice_no',inv_no,'payment_method',p_payment_method,'gross_subtotal',gross_subtotal,
    'item_discount',item_discount_total,'order_discount',discount,'total_discount',item_discount_total+discount,
    'total',total,'job_card_id',j.id
  ));

  return query select inv,inv_no,total,case when p_payment_method='CASH' then received-total else 0 end;
end;
$function$;

create or replace function public.rt_staff_receipt_detail(p_invoice_id uuid)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  ctx record;
  out_json jsonb;
begin
  select * into ctx from public.rt_staff_context() limit 1;
  if ctx.staff_id is null or lower(coalesce(ctx.role,'')) not in
    ('owner','admin','administrator','super_admin','superadmin','manager','staff','pos','cashier') then
    raise exception 'REPRINT_ROLE_NOT_ALLOWED';
  end if;

  select jsonb_build_object(
    'id', i.id,
    'invoiceNo', i.invoice_no,
    'customerId', i.customer_id,
    'vehicleId', i.vehicle_id,
    'subtotal', coalesce(i.subtotal,0),
    'grossSubtotal', coalesce(items.gross_subtotal,i.subtotal,0),
    'itemDiscount', coalesce(items.item_discount,0),
    'discount', coalesce(i.discount,0),
    'orderDiscount', coalesce(i.discount,0),
    'totalDiscount', coalesce(items.item_discount,0)+coalesce(i.discount,0),
    'tax', coalesce(i.tax,0),
    'total', coalesce(i.total,0),
    'status', i.status,
    'paymentStatus', i.payment_status,
    'createdAt', i.created_at,
    'customerName', coalesce(c.name,'Walk-in'),
    'customerPhone', coalesce(c.phone,''),
    'plateNo', coalesce(v.plate_no,''),
    'vehicleModel', trim(concat_ws(' ',v.brand,v.model,v.variant)),
    'createdBy', coalesce(s.staff_code,s.name,'-'),
    'staffName', coalesce(s.name,s.staff_code,'-'),
    'paymentMethod', coalesce(pay.payment_method, checkout.metadata->>'payment_method', 'CASH'),
    'amountPaid', coalesce(
      case when nullif(checkout.metadata->>'amount_received','') is not null then (checkout.metadata->>'amount_received')::numeric end,
      pay.amount_paid,i.total,0
    ),
    'change', coalesce(
      case when nullif(checkout.metadata->>'change','') is not null then (checkout.metadata->>'change')::numeric end,0
    ),
    'items', coalesce(items.data,'[]'::jsonb)
  ) into out_json
  from public.invoices i
  left join public.customers c on c.id=i.customer_id and c.company_id=i.company_id
  left join public.vehicles v on v.id=i.vehicle_id and v.company_id=i.company_id
  left join public.staff s on s.id=i.staff_id and s.company_id=i.company_id
  left join lateral (
    select string_agg(distinct p.payment_method, ' + ' order by p.payment_method) as payment_method, sum(p.amount) as amount_paid
    from public.payments p where p.invoice_id=i.id and p.company_id=i.company_id
  ) pay on true
  left join lateral (
    select al.metadata from public.audit_logs al
    where al.company_id=i.company_id and al.entity_id=i.id and al.action='POS_CHECKOUT'
    order by al.created_at desc limit 1
  ) checkout on true
  left join lateral (
    select
      jsonb_agg(jsonb_build_object(
        'name', coalesce(nullif(ii.description,''), prod.name, prod.sku, 'Item'),
        'sku', coalesce(prod.sku,''),
        'qty', coalesce(ii.quantity,0),
        'quantity', coalesce(ii.quantity,0),
        'price', coalesce(ii.unit_price,0),
        'unitPrice', coalesce(ii.unit_price,0),
        'discount', coalesce(ii.discount,0),
        'lineTotal', coalesce(ii.line_total,0),
        'itemType', coalesce(ii.job_item_type,'PART')
      ) order by ii.id) as data,
      coalesce(sum(ii.quantity*ii.unit_price),0) as gross_subtotal,
      coalesce(sum(ii.discount),0) as item_discount
    from public.invoice_items ii
    left join public.products prod on prod.id=ii.product_id
    where ii.invoice_id=i.id
  ) items on true
  where i.id=p_invoice_id and i.company_id=ctx.company_id
  limit 1;

  if out_json is null then raise exception 'INVOICE_NOT_FOUND'; end if;
  return out_json;
end;
$function$;
