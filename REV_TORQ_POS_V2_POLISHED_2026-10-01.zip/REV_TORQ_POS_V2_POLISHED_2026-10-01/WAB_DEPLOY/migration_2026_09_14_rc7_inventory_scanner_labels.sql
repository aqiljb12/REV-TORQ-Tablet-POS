-- REV TORQ RC7: internal barcode generator + fast inventory save auto-barcode
-- Applied to production wabtoq.

create sequence if not exists public.rt_internal_barcode_seq
  as bigint
  start with 1
  increment by 1
  minvalue 1
  cache 20;

create or replace function public.rt_generate_internal_barcode()
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_company_id uuid;
  v_role text;
  v_code text;
begin
  if auth.uid() is null then raise exception 'Login diperlukan'; end if;
  select s.company_id, lower(trim(coalesce(s.role,'')))
    into v_company_id, v_role
  from public.staff s
  where s.auth_user_id = auth.uid()
    and s.active = true
    and coalesce(s.removed_from_active_list,false) = false
    and s.blocked_at is null
  limit 1;
  if v_company_id is null then raise exception 'Staff login tidak sah'; end if;
  if v_role not in ('owner','admin','super_admin','manager','storekeeper','stor') then
    raise exception 'Role % tidak dibenarkan jana barcode inventori', coalesce(v_role,'-');
  end if;
  loop
    v_code := 'RT' || lpad(nextval('public.rt_internal_barcode_seq'::regclass)::text,10,'0');
    exit when not exists (
      select 1 from public.products p where p.company_id=v_company_id and p.barcode=v_code
    );
  end loop;
  return v_code;
end;
$$;

revoke all on function public.rt_generate_internal_barcode() from public;
revoke all on function public.rt_generate_internal_barcode() from anon;
grant execute on function public.rt_generate_internal_barcode() to authenticated;

create or replace function public.rt_inventory_save_fast(
  p_sku text,
  p_name text,
  p_category text default null::text,
  p_barcode text default null::text,
  p_rack_location text default null::text,
  p_cost_price numeric default 0,
  p_sell_price numeric default 0,
  p_min_stock numeric default 0,
  p_active boolean default true,
  p_opening_stock numeric default 0,
  p_is_edit boolean default false,
  p_location_id uuid default null::uuid
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_staff_id uuid;
  v_company_id uuid;
  v_staff_location_id uuid;
  v_role text;
  v_location_id uuid;
  v_product public.products%rowtype;
  v_before public.products%rowtype;
  v_sku text;
  v_name text;
  v_category text;
  v_barcode text;
  v_rack text;
  v_stock numeric := 0;
  v_tx uuid := gen_random_uuid();
begin
  if auth.uid() is null then raise exception 'Login diperlukan'; end if;

  select s.id, s.company_id, s.location_id, lower(trim(coalesce(s.role,'')))
    into v_staff_id, v_company_id, v_staff_location_id, v_role
  from public.staff s
  where s.auth_user_id = auth.uid()
    and s.active = true
    and coalesce(s.removed_from_active_list,false) = false
    and s.blocked_at is null
  limit 1;

  if v_company_id is null then raise exception 'Staff login tidak sah atau belum dipetakan kepada company'; end if;
  if v_role not in ('owner','admin','super_admin','manager','storekeeper','stor') then
    raise exception 'Role % tidak dibenarkan mengubah inventori', coalesce(v_role,'-');
  end if;

  v_sku := upper(trim(coalesce(p_sku,'')));
  v_name := trim(coalesce(p_name,''));
  v_category := nullif(upper(trim(coalesce(p_category,''))), '');
  v_barcode := nullif(trim(coalesce(p_barcode,'')), '');
  v_rack := nullif(upper(trim(coalesce(p_rack_location,''))), '');
  if v_sku = '' or v_name = '' then raise exception 'SKU dan nama item diperlukan'; end if;
  if coalesce(p_cost_price,0) < 0 or coalesce(p_sell_price,0) < 0 or coalesce(p_min_stock,0) < 0 or coalesce(p_opening_stock,0) < 0 then
    raise exception 'Nilai harga/stok tidak sah';
  end if;

  -- Physical stock items without a supplier barcode get a REV TORQ internal Code128 value.
  -- Service/labour items are intentionally left without a barcode.
  if v_barcode is null and coalesce(v_category,'') <> 'SERVIS' then
    loop
      v_barcode := 'RT' || lpad(nextval('public.rt_internal_barcode_seq'::regclass)::text,10,'0');
      exit when not exists (
        select 1 from public.products p where p.company_id=v_company_id and p.barcode=v_barcode
      );
    end loop;
  end if;

  v_location_id := coalesce(p_location_id, v_staff_location_id);
  if v_location_id is null then
    select l.id into v_location_id from public.locations l
    where l.company_id = v_company_id and l.active = true
    order by l.code nulls last, l.created_at limit 1;
  end if;
  if v_location_id is null or not exists (
    select 1 from public.locations l where l.id = v_location_id and l.company_id = v_company_id and l.active = true
  ) then raise exception 'Location aktif tidak dijumpai'; end if;

  if p_is_edit then
    select * into v_before from public.products p
    where p.company_id = v_company_id and p.sku = v_sku for update;
    if not found then raise exception 'Item % tidak ditemui', v_sku; end if;
    if v_barcode is not null and exists (
      select 1 from public.products p where p.company_id = v_company_id and p.barcode = v_barcode and p.id <> v_before.id
    ) then raise exception 'Barcode % sudah digunakan oleh item lain', v_barcode; end if;
    update public.products
    set name=v_name, category=v_category, barcode=v_barcode,
        rack_location=v_rack, cost_price=coalesce(p_cost_price,0), sell_price=coalesce(p_sell_price,0),
        min_stock=coalesce(p_min_stock,0), active=coalesce(p_active,true), updated_at=now()
    where id=v_before.id returning * into v_product;
  else
    if exists (select 1 from public.products p where p.company_id=v_company_id and p.sku=v_sku) then
      raise exception 'SKU % telah wujud', v_sku;
    end if;
    if v_barcode is not null and exists (select 1 from public.products p where p.company_id=v_company_id and p.barcode=v_barcode) then
      raise exception 'Barcode % sudah digunakan oleh item lain', v_barcode;
    end if;
    insert into public.products(company_id,sku,barcode,name,category,unit,cost_price,sell_price,min_stock,active,rack_location)
    values(v_company_id,v_sku,v_barcode,v_name,v_category,'pcs',coalesce(p_cost_price,0),coalesce(p_sell_price,0),coalesce(p_min_stock,0),coalesce(p_active,true),v_rack)
    returning * into v_product;

    if coalesce(p_opening_stock,0) > 0 then
      insert into public.stock_balances(product_id,location_id,quantity,reserved_quantity)
      values(v_product.id,v_location_id,p_opening_stock,0)
      on conflict(product_id,location_id) do update set quantity=excluded.quantity,updated_at=now();
      insert into public.stock_movements(company_id,location_id,product_id,transaction_id,movement_type,quantity,unit_cost,reference_type,reference_id,staff_id,device_id)
      values(v_company_id,v_location_id,v_product.id,v_tx,'OPENING',p_opening_stock,coalesce(p_cost_price,0),'PRODUCT_SETUP',null,v_staff_id,null);
    end if;
  end if;

  select coalesce(sb.quantity,0) into v_stock from public.stock_balances sb
  where sb.product_id=v_product.id and sb.location_id=v_location_id;
  v_stock:=coalesce(v_stock,0);

  insert into public.audit_logs(company_id,location_id,transaction_id,staff_id,action,entity_type,entity_id,before_data,after_data,metadata)
  values(v_company_id,v_location_id,v_tx,v_staff_id,
    case when p_is_edit then 'UPDATE_INVENTORY' else 'CREATE_INVENTORY' end,
    'PRODUCT',v_product.id,
    case when p_is_edit then to_jsonb(v_before) else null end,
    to_jsonb(v_product),jsonb_build_object('source','rt_inventory_save_fast','opening_stock',case when p_is_edit then 0 else coalesce(p_opening_stock,0) end,'internal_barcode',coalesce(p_barcode,'')=''));

  return jsonb_build_object('id',v_product.id,'company_id',v_product.company_id,'sku',v_product.sku,'name',v_product.name,
    'category',v_product.category,'barcode',v_product.barcode,'rack_location',v_product.rack_location,'cost_price',v_product.cost_price,
    'sell_price',v_product.sell_price,'min_stock',v_product.min_stock,'active',v_product.active,'stock',v_stock,
    'mode',case when p_is_edit then 'updated' else 'created' end,'saved_at',now());
end;
$$;

revoke all on function public.rt_inventory_save_fast(text,text,text,text,text,numeric,numeric,numeric,boolean,numeric,boolean,uuid) from public;
revoke all on function public.rt_inventory_save_fast(text,text,text,text,text,numeric,numeric,numeric,boolean,numeric,boolean,uuid) from anon;
grant execute on function public.rt_inventory_save_fast(text,text,text,text,text,numeric,numeric,numeric,boolean,numeric,boolean,uuid) to authenticated;
