# REV TORQ POS v1.0.0 RC5 — Pomen Inventory Access

- POMEN / MECHANIC no longer gets the full Inventory menu.
- Direct navigation to the Inventory view is blocked by the existing role gate.
- POMEN can still select parts inside Job Card workflow, so workshop operations continue normally.
- Owner/Admin/Storekeeper Inventory access is unchanged.
- No Supabase schema, RLS, stock, invoice or payment logic changed.
