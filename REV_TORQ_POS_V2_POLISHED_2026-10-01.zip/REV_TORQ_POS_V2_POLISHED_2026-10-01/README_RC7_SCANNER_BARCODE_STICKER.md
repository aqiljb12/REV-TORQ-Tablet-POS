# REV TORQ WAB v1.0.0 RC7

## Inventory Scanner + Internal Barcode + Sticker

### RC7 changes
- Inventory outside scanner field now supports barcode/SKU exact lookup without opening stock adjustment automatically.
- USB/Bluetooth HID barcode scanner can scan directly while Inventory is open; no need to focus the input box.
- Camera scanner remains available as a backup via **KAMERA**.
- Products without supplier barcode automatically receive a REV TORQ internal Code128 value (`RT##########`) in the same fast Supabase save transaction.
- Existing older products without barcode can generate and save an internal barcode from the sticker dialog.
- New **PRINT STIKER** action in Inventory.
- Per-item **STIKER** button.
- Sticker supports 40×30 mm, 50×30 mm and 60×40 mm; quantity 1–100; optional price and SKU.
- Sticker uses Code128 and opens the browser/system print dialog for a label printer.
- RC6 one-RPC fast inventory save remains enabled.
- POMEN inventory restrictions from RC5 remain enabled.

### Supabase
Production migration applied to `wabtoq`:
- `public.rt_internal_barcode_seq`
- `public.rt_generate_internal_barcode()`
- updated `public.rt_inventory_save_fast(...)` to auto-generate barcode for non-SERVIS items when barcode is blank.
- RPC execution is granted to `authenticated`, revoked from `anon`.

### Scanner recommendation
Use a USB/Bluetooth scanner in HID/keyboard mode and configure suffix **ENTER**. Scan directly while the Inventory screen is open.

### Sticker printing
For real adhesive labels use a thermal label printer and select the matching paper size in the system print dialog. Browser print is used in WAB RC7; no APK/native printer bridge is required for this test build.
