# REV TORQ POS V2 CLEAN — Scope

This repository is the **POS/workshop operations app only**.

## Keep in this app
- POS sale/cart/checkout
- Native barcode scanner
- Customer + vehicle lookup
- Job Card / booking operational flow
- Inventory / stock / GRN / suppliers
- Promotions, vouchers, discounts and other charges used at checkout
- Cash drawer / operational Money Out
- Receipt / reprint / void with admin controls
- Staff login, attendance, permissions, audit and settings
- Operational dashboard (sales today, active jobs, customers, low stock)

## Do NOT add back
- Accounting dashboard
- P&L
- Balance Sheet
- Accounting Cash Flow
- Chart of Accounts
- Journal / General Ledger
- Full Expenses accounting
- Tax / financial statements

Those belong to the separate **REV TORQ Accounting** system. The POS remains the source of truth for sale/invoice/payment/stock operational records, which Accounting may read separately.

## UX direction
Simple, fast and tablet-first. Do not redesign the existing UI without an explicit request. Reduce taps and keep checkout reliable.

## Safety
Do not drop/reset Supabase tables. Preserve existing production data and current transaction/RPC contracts.
