# REV TORQ POS v1.0.0 RC6 — Fast Inventory Save

- Inventory Save now uses one atomic Supabase RPC: `rt_inventory_save_fast`.
- Product save, duplicate validation, opening stock, stock movement and audit log are committed in one PostgreSQL transaction.
- The UI no longer waits for full Inventory + POS reload after Save.
- Inventory refresh is silent/background after a successful save.
- Existing canonical tables remain: products, stock_balances, stock_movements, audit_logs.
- No database reset and no production data deletion.
