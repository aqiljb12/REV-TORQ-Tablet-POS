# Verification — REV TORQ POS V2 POLISH (2026-10-01)

## Automated (in this package)

`node --test tests/*.test.cjs` → **84 / 84 passed** (71 existing V2 CLEAN tests + 13 new in `tests/pos-v2-polish.test.cjs`).

New tests cover: every POS/receipt/void ID and inline handler kept; POS landing for all selling roles and no accounting menus; the UI layer (`js/rt-polish.js`) has no sale/stock/payment writes or RPC calls; two-tap line removal; HTML-escaped cart rows; confirmed clear-cart; Job → POS via canonical checkout only (legacy direct payment disabled); receipt success header outside `#printArea`; Sales page uses role-checked RPCs with admin-only VOID; inventory stock status; unchanged fetch/retry behaviour; daily-close button; root / `app/src/main/assets` / `WAB_DEPLOY` runtime files identical.

## Browser run with simulated backend (not shipped)

Headless Chromium against each runtime copy (root, `WAB_DEPLOY`, `app/src/main/assets`) with an in-memory Supabase stand-in. Tailwind / Feather were served from local npm copies because the CDNs were unreachable from the build machine.

- 54 / 54 scripted flows passed on each copy, 0 page errors: landing on POS, navigation and tabs, product tap and badges, out-of-stock block, two-tap remove, item / order discount, other charge, promo apply/remove, customer search + motorcycle, QR gating then QR checkout, receipt success and NEW SALE, clear-cart confirm, scanner-gun Enter, cash shortfall and quick cash, drawer popover, cash checkout (invoice + stock deduction in the mock), inventory filter, Sales page VOID and reprint, cashier role restrictions, Job Card → POS on a 1024×600 tablet.
- Layout: no horizontal scroll; BAYAR button inside the viewport at 1280×800, 1180×820 and 1024×600 (baseline: ~700 px below the fold at 1280×800).
- Simulated APK bridge (`window.RevTorqAndroid`): top-bar SCAN opens native `POS_MULTI`, native barcode adds to cart with feedback, HID Enter adds once and clears, inventory camera opens `INVENTORY_LOOKUP`.

## Not verified

- Real Supabase login, RLS/RPC behaviour, real sales / stock / cash drawer data.
- Physical Android 9 tablet, real WebView version, CameraX / ML Kit camera, RawBT / thermal printing, cash-drawer kick.
- APK build / signing (no Java or Gradle changes in this release).
- Cloudflare deployment.

Recommended device check before rollout: login → POS → scan → cash sale → print → reprint from Jualan → Job Card BAWA KE POS → QR sale → Stock In / Pelarasan → GRN → VOID (admin).
