const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

// IDs the existing POS modules, checkout engine and tests rely on (V2 CLEAN baseline).
const POS_IDS=['view-pos','rtPosMobileMenu','posSearch','rtScanBtnTop','rtPosAdminName','rtPosClock','rtCatBar','posProductGrid',
  'rtPosPagination','rtCartCount','rtCurrentJob','rtPickJobBtn','posCartList','posSubtotal','rtItemDiscountDisplay','posDiscount',
  'rtDiscountDisplay','rtPosMemberPoints','rtPosMemberPhone','rtPosMemberFind','rtPosMemberClear','rtPosMemberInfo',
  'rtPosClaimedVoucherList','rtPosPromoBadge','rtPosPromoChoose','rtPosPromoRemove','rtPosPromoList','rtPosPromoCode',
  'rtPosPromoApply','rtPosPromoMessage','rtPosVoucherBadge','rtPosVoucherCode','rtPosVoucherApply','rtPosVoucherRemove',
  'rtPosVoucherMessage','rtOtherCharge','rtOtherChargeDisplay','posTotal','btnPayCASH','btnPayQR','btnPayCARD','btnPayTRANSFER',
  'rtPosPaymentDetail','rtPosCustomerSelect','rtPaymentQrPanel','rtPaymentQrCheckoutLabel','rtPaymentQrCheckoutImage',
  'rtPaymentQrCheckoutMerchant','rtPaymentQrCheckoutProvider','rtPaymentQrCheckoutNote','rtPaymentQrCheckoutStatus',
  'rtPaymentQrConfirm','rtCashTenderBox','rtCashDue','posAmountReceived','rtQuickCash','rtCashTotal','rtCashReceived','posChange',
  'rtCashDrawerPanel','rtCashDrawerStatus','rtCashDrawerExpected','rtOpenCashDrawerBtn','rtCashOutBtn','rtCloseCashDrawerBtn',
  'btnCheckout','receiptModal','printArea','rtPosHistoryModal','rtHistoryList','rtVoidModal','rtConfirmVoidBtn'];

test('polished POS keeps every functional ID and inline handler used by checkout',()=>{
  const html=read('index.html');
  for(const id of POS_IDS){
    const n=(html.match(new RegExp(`id="${id}"`,'g'))||[]).length;
    assert.equal(n,1,`${id} must exist exactly once`);
  }
  assert.match(html,/id="btnCheckout"[^>]*onclick="posCheckout\(\)"/);
  for(const m of ['CASH','QR','CARD','TRANSFER'])assert.match(html,new RegExp(`onclick="posSetPaymentMethod\\('${m}'\\)" id="btnPay${m}"`));
  assert.match(html,/id="posSearch"[^>]*onkeyup="posFilterProducts\(this\.value\)"/);
  assert.match(html,/id="posAmountReceived"[^>]*oninput="posCalculateTotal\(\)"/);
  assert.match(html,/id="posDiscount"[^>]*onchange="posCalculateTotal\(\)"/);
  assert.match(html,/<script src="js\/rt-polish\.js[^"]*"><\/script>\s*<\/body>/,'UI polish layer loads last');
  assert.match(html,/js\/v36-4-9-pos-cash-canonical\.js/,'canonical checkout still loaded');
});

test('POS is the landing screen and navigation stays operational (no accounting)',()=>{
  const core=read('js/core.js');
  for(const role of ['owner','super_admin','admin','pos','staff','cashier'])
    assert.match(core,new RegExp(`\\b${role}: \\['pos'`),`${role} lands on POS`);
  assert.match(core,/const navPrimary = \['pos','jobcard','inventory','customers','sales','staff','settings'\]/);
  assert.match(core,/const navSecondary = \['dashboard','booking','suppliers','purchase','reminders','tutorial'\]/);
  assert.match(core,/pomen: \['jobcard'\]/);
  assert.match(core,/stor: \['inventory'\]/);
  const menus=core.slice(core.indexOf('const menuDefinitions'),core.indexOf('// --- 4. CRYPTO HASHING'));
  assert.doesNotMatch(menus,/'(accounting|reports|pnl|finance|ledger|journal|expenses)'/i);
  assert.match(core,/function switchView\(viewId\)[\s\S]*allowedForRole\.includes\(viewId\)/,'role gate kept');
});

test('UI polish layer never writes sales, stock, payments or calls checkout RPCs',()=>{
  const js=read('js/rt-polish.js');
  assert.doesNotMatch(js,/\.(insert|update|upsert|delete)\(/);
  assert.doesNotMatch(js,/\.rpc\(|supabaseRpc\(/);
  assert.doesNotMatch(js,/rt_post_|rt_cash_|rt_admin_void|rt_redeem/);
  // the only Supabase read is the customer's motorcycles for display
  assert.equal((js.match(/sb\.from\(/g)||[]).length,1);
  assert.match(js,/sb\.from\('vehicles'\)\.select\('id,plate_no,brand,model'\)/);
});

function cartHarness(){
  const list={innerHTML:'',contains:()=>false,querySelector:()=>null};
  const els=new Map([['posCartList',list]]);
  for(const id of ['rtCartCount','posSubtotal','rtItemDiscountDisplay','rtDiscountDisplay','posTotal','rtOtherChargeDisplay','posChange'])
    els.set(id,{innerText:'',textContent:'',className:'',value:''});
  els.set('posDiscount',{value:'0'});els.set('rtOtherCharge',{value:'0'});els.set('posAmountReceived',{value:'0'});
  const armed=[];
  const document={addEventListener(){},getElementById:id=>els.get(id)||null,querySelectorAll:()=>armed,activeElement:null};
  const win={RTPosDiscountModel:require('../js/pos-item-discount-model.js'),addEventListener(){}};
  const ctx={window:win,document,formatMoney:v=>'RM '+Number(v).toFixed(2),showToast(){},setTimeout:()=>0,console};
  vm.runInNewContext(read('js/pos.js'),ctx);
  return {win,list,ctx};
}
function fakeButton(){
  const classes=new Set();
  return {innerHTML:'×',dataset:{},classList:{add:c=>classes.add(c),remove:c=>classes.delete(c),contains:c=>classes.has(c)}};
}

test('removing a cart line needs two taps; qty minus at 1 does not drop the item',()=>{
  const {win,list}=cartHarness();
  win.rtSetPosCart([{sku:'A',name:'Oil',price:10,qty:1,maxStock:5,discount:0},{sku:"B'1",name:'Plug',price:5,qty:2,maxStock:5,discount:0}]);
  assert.match(list.innerHTML,/rtCartArmRemove\(this,'A'\)/,'minus at qty 1 arms removal');
  assert.match(list.innerHTML,/posUpdateQty\('B\\&#39;1',-1\)/,'minus at qty >1 decrements; quotes escaped');
  const btn=fakeButton();
  win.rtCartArmRemove(btn,'A');
  assert.equal(win.rtGetPosCart().length,2,'first tap only arms');
  assert.equal(btn.innerHTML,'BUANG?');
  win.rtCartArmRemove(btn,'A');
  assert.deepEqual(win.rtGetPosCart().map(i=>i.sku),["B'1"],'second tap removes');
});

test('cart rows escape product names and show item discount + kind tags',()=>{
  const {win,list}=cartHarness();
  win.rtSetPosCart([{sku:'X',name:'<b>Oil</b>',price:10,qty:2,maxStock:5,discount:3},{sku:'JOBLABOUR-1',name:'Labour',price:40,qty:1,maxStock:999999,service:true,itemType:'SERVICE'}]);
  assert.doesNotMatch(list.innerHTML,/<b>Oil<\/b>/);
  assert.match(list.innerHTML,/&lt;b&gt;Oil&lt;\/b&gt;/);
  assert.match(list.innerHTML,/class="rt-row-disc has-value"/);
  assert.match(list.innerHTML,/rt-kind-labour/);
  assert.match(list.innerHTML,/onchange="posSetItemDiscount\('X',this\.value\)"/);
});

test('clear cart is confirmed; checkout/job flows still clear programmatically',()=>{
  const html=read('index.html');
  const polish=read('js/rt-polish.js');
  assert.match(html,/id="rtClearCartBtn"[^>]*onclick="window\.rtConfirmClearCart\?\.\(\)"/);
  assert.doesNotMatch(html,/onclick="posClearCart\(\)"/,'no unconfirmed clear button');
  assert.match(polish,/rtConfirmClearCart=function[\s\S]*rtConfirm\([\s\S]*posClearCart\(\)/);
  assert.match(read('js/v36-4-9-pos-cash-canonical.js'),/window\.posClearCart\?\.\(\)/);
});

test('Job Card goes to POS only through the canonical checkout',()=>{
  const html=read('index.html');
  const flow=read('js/job-pos-flow.js');
  assert.match(html,/const RT_LEGACY_JOB_PAY_BUTTONS=false;[\s\S]*if\(!RT_LEGACY_JOB_PAY_BUTTONS\)return;/,'legacy direct BAYAR buttons disabled');
  assert.match(flow,/b\.textContent='BAWA KE POS'/);
  assert.match(flow,/getElementById\('rtJobContextSlot'\)/,'job banner lives inside the cart');
  assert.match(html,/id="rtJobContextSlot"/);
  assert.match(flow,/window\.rtActiveJob=\{jobCardId:data\.j\.id/);
});

test('receipt success state stays outside the printed receipt',()=>{
  const html=read('index.html');
  const modal=html.slice(html.indexOf('<div id="receiptModal"'),html.indexOf('<!-- MAIN APP JAVASCRIPT -->'));
  const head=modal.indexOf('id="rtReceiptHead"'),area=modal.indexOf('id="printArea"');
  assert.ok(head>0&&area>head);
  assert.match(modal,/id="rtReceiptHead" class="rt-receipt-head no-print"/);
  assert.match(modal,/window\.rtPrintReceipt\(\)/);
  assert.match(modal,/window\.rtShareReceiptWhatsApp\(\)/);
  assert.match(modal,/JUALAN BARU/);
  const printArea=modal.slice(area,modal.indexOf('</div>',area));
  assert.doesNotMatch(printArea,/rtReceiptHead|BAYARAN BERJAYA/);
});

test('Sales page uses the role-checked receipt RPCs and keeps VOID admin-only',()=>{
  const js=read('js/receipt-reprint.js');
  const html=read('index.html');
  assert.match(html,/id="view-sales"/);
  assert.match(js,/rtLoadSalesPage=function/);
  assert.match(js,/supabaseRpc\('rt_staff_receipt_history',\{p_search:sales\.search\|\|null/);
  assert.match(js,/isAdmin\(\)&&!isVoid\?`<button type="button" onclick="window\.rtAskVoidInvoice/);
  assert.match(html,/supabaseRpc\('rt_admin_void_invoice'/);
  assert.match(html,/function rtConfirmVoidInvoice\(\)\{\s*if\(!rtIsAdmin\(\)\)/);
});

test('inventory rows expose IN STOCK / LOW / OUT status for badges and filter',async()=>{
  const body={innerHTML:''};
  const rows=[{id:'1',sku:'A',name:'Oil',active:true,min_stock:5},{id:'2',sku:'B',name:'Plug',active:true,min_stock:5},{id:'3',sku:'C',name:'Tyre',active:true,min_stock:5}];
  const qty={1:20,2:3,3:0};
  const q=t=>({select(){return this},eq(){return this},order(){return this},in(){return this},then(res){return Promise.resolve(t==='products'?{data:rows}:{data:rows.map(r=>({product_id:r.id,quantity:qty[r.id]}))}).then(res)}});
  const win={currentProfile:{companyId:'c',locationId:'l'},feather:null};
  vm.runInNewContext(read('js/inventory-canonical-list.js'),{window:win,sb:{from:q},document:{querySelector:()=>body,getElementById:()=>null},formatMoney:v=>'RM '+v,console,setTimeout});
  await win.loadInventory();
  assert.match(body.innerHTML,/data-sku="A"[^>]*data-stock-status="ok"/);
  assert.match(body.innerHTML,/data-sku="B"[^>]*data-stock-status="low"/);
  assert.match(body.innerHTML,/data-sku="C"[^>]*data-stock-status="out"/);
  assert.match(body.innerHTML,/STOK RENDAH/);
  assert.match(body.innerHTML,/HABIS/);
});

test('connection status is honest and request behaviour is unchanged',()=>{
  const bridge=read('js/supabase-bridge.js');
  const html=read('index.html');
  assert.match(bridge,/for\(let attempt=0;attempt<3;attempt\+\+\)/);
  assert.match(bridge,/setTimeout\(\(\)=>controller\.abort\(\),15000\)/);
  assert.match(bridge,/rtNetSignal\('fail'\);\s*throw last;/);
  assert.match(html,/Jualan, stok dan resit memerlukan sambungan ke server/);
  assert.doesNotMatch(html,/jualan offline berjaya|offline sale saved/i);
});

test('daily close button survives the canonical drawer panel rebuild',()=>{
  const js=read('js/v36-4-9-pos-canonical-daily.js');
  assert.match(js,/if\(!panel\|\|panel\.dataset\.v49!=='1'\|\|\$\('rtDailyBookBtn'\)\)return;/);
});

test('root, Android assets and WAB_DEPLOY runtime files are identical',()=>{
  const files=['index.html','backend/index.html',...fs.readdirSync(path.join(root,'css')).map(f=>'css/'+f),...fs.readdirSync(path.join(root,'js')).map(f=>'js/'+f)];
  for(const dir of ['app/src/main/assets','WAB_DEPLOY']){
    for(const f of files)assert.equal(fs.readFileSync(path.join(root,dir,f),'utf8'),read(f),`${dir}/${f} out of sync`);
    for(const sub of ['css','js'])for(const f of fs.readdirSync(path.join(root,dir,sub)))
      assert.ok(fs.existsSync(path.join(root,sub,f)),`${dir}/${sub}/${f} has no root source`);
  }
});
