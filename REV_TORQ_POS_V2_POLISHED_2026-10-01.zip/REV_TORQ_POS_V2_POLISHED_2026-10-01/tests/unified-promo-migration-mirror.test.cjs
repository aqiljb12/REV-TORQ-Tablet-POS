const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const sql = fs.readFileSync(path.join(root, 'migration_2026_09_18_unified_promo_system.sql'), 'utf8');

test('POS ships the same unified promo migration contract', () => {
  assert.match(sql, /rt_post_pos_sale_with_promo/);
  assert.match(sql, /rt_post_job_pos_sale_with_promo/);
  assert.match(sql, /PROMO_USAGE_LIMIT_REACHED/);
  assert.match(sql, /revoke insert on public\.promo_redemptions from authenticated/i);
});
