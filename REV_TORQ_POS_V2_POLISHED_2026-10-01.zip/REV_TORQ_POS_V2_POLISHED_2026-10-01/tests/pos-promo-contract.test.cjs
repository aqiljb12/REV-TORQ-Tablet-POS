const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const pos=fs.readFileSync(path.join(root,'js/pos.js'),'utf8');
const canonical=fs.readFileSync(path.join(root,'js/v36-4-9-pos-cash-canonical.js'),'utf8');

test('POS exposes promo selector and manual promo code UI',()=>{
  assert.match(html,/id="rtPosPromoCode"/);
  assert.match(html,/id="rtPosPromoApply"/);
  assert.match(html,/id="rtPosPromoChoose"/);
  assert.match(html,/js\/pos-promo-model\.js/);
});

test('POS loads and validates promos from authoritative RPCs',()=>{
  assert.match(pos,/rt_pos_available_promotions/);
  assert.match(pos,/rt_validate_promo/);
  assert.match(pos,/rtPosRemovePromo/);
});

test('canonical checkout routes Job STANDARD and PROMO through the idempotent wrapper',()=>{
  const sql=fs.readFileSync(path.join(root,'migration_2026_09_22_workshop_flow_phase2.sql'),'utf8');
  assert.match(canonical,/rt_post_pos_sale_with_promo/);
  assert.match(canonical,/postProductSale\('rt_post_job_pos_sale_idempotent',args,c\)/);
  assert.match(canonical,/p_kind:voucher\?'VOUCHER':promo\?'PROMO':'STANDARD'/);
  assert.match(canonical,/p_promotion_id:promo\?\.promotion_id\|\|null/);
  assert.match(canonical,/p_promo_code:promo\?\.promo_code\|\|null/);
  assert.doesNotMatch(canonical,/rt_post_job_pos_sale_with_promo/);
  assert.match(sql,/upper\(p_kind\)='PROMO'[\s\S]*?rt_post_job_pos_sale_with_promo/);
  assert.match(sql,/else[\s\S]*?rt_post_job_pos_sale\(/);
  assert.match(canonical,/p_promotion_id/);
  assert.match(canonical,/p_manual_discount/);
  assert.doesNotMatch(canonical,/p_promo_discount/);
});
