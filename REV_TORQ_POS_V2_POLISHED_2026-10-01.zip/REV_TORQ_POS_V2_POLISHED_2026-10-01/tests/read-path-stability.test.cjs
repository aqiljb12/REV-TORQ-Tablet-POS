const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.join(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const between=(s,a,b)=>s.slice(s.indexOf(a),s.indexOf(b,s.indexOf(a)));
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};};

test('inventory first load may show loading, return keeps rows during fresh query',async()=>{
  const body={innerHTML:''};const first=deferred(),second=deferred();let calls=0;
  const query={select(){return this},eq(){return this},order(){return this},then(resolve){return (++calls===1?first:second).promise.then(resolve)}};
  const win={currentProfile:{companyId:'company-1'},feather:null};
  const context={window:win,sb:{from:()=>query},document:{querySelector:()=>body,getElementById:()=>null},formatMoney:n=>`RM ${Number(n).toFixed(2)}`,console,setTimeout};
  vm.runInNewContext(read('js/inventory-canonical-list.js'),context);
  const a=win.loadInventory();assert.match(body.innerHTML,/Memuatkan inventori/);
  first.resolve({data:[{id:'A',sku:'A',name:'Old',active:true}]});await a;
  const b=win.loadInventory();assert.match(body.innerHTML,/Old/);assert.doesNotMatch(body.innerHTML,/Memuatkan inventori/);
  second.resolve({data:[{id:'A',sku:'A',name:'Fresh',active:true}]});await b;
  assert.match(body.innerHTML,/Fresh/);assert.equal(calls,2);
});

test('customer loader batches vehicles and groups by customer',async()=>{
  const code=between(read('js/customers.js'),'async function loadCustomers()','async function saveCustomer(');
  const body={innerHTML:''};let vehicleQueries=0;let whereArgs=[];
  const docs=[{data:()=>({customerId:'C1',name:'One'})},{data:()=>({customerId:'C2',name:'Two'})}];
  const db={collection:name=>({orderBy(){return this},where(...args){whereArgs.push(args);return this},async get(){if(name==='customers')return {docs};vehicleQueries++;return {forEach:cb=>{cb({data:()=>({customerId:'C1',plateNo:'AAA',model:'M1'})});cb({data:()=>({customerId:'C2',plateNo:'BBB',model:'M2'})});}}}})};
  const context={db,document:{querySelector:()=>body},feather:{replace(){}}};vm.runInNewContext(`${code}\nthis.load=loadCustomers`,context);await context.load();
  assert.equal(vehicleQueries,1);assert.deepEqual(whereArgs[0].slice(0,2),['customerId','in']);
  assert.match(body.innerHTML,/One[\s\S]*AAA[\s\S]*Two[\s\S]*BBB/);
  assert.doesNotMatch(body.innerHTML,/One[\s\S]*BBB[\s\S]*Two/);
});

test('currently used date renderers call safe formatter',()=>{
  const html=read('index.html');
  const grn=read('js/grn-reminders.js');
  const admin=read('js/admin.js');
  assert.match(html,/rtSafeDate\(d\.timestamp\)/);
  assert.match(grn,/rtSafeDate\(d\.createdAt,\s*true\)/);
  assert.match(admin,/window\.rtSafeDate\s*=\s*formatAuditTimestamp/);
});

test('navigation invokes all four background list loaders on return',()=>{
  const core=read('js/core.js');
  assert.match(core,/\['customers','inventory','jobcard','audit'\]\.includes\(viewId\)/);
  for(const [file,pattern] of [
    ['js/customers.js',/if \(!loadCustomers\.loaded\) tbody\.innerHTML/],
    ['js/jobcards.js',/if\(!loadJobCards\.loaded\)tbody\.innerHTML/],
    ['js/admin.js',/if \(!loadAudit\.loaded\) tbody\.innerHTML/]
  ]) assert.match(read(file),pattern);
});

