const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const pos=fs.readFileSync(path.join(root,'js/pos.js'),'utf8');
const reprint=fs.readFileSync(path.join(root,'js/receipt-reprint.js'),'utf8');

test('receipt renders promo name/code and promo discount when present',()=>{
  assert.match(pos,/promotion/);
  assert.match(pos,/promoDiscount/);
  assert.match(pos,/promoCode/);
  assert.match(pos,/Jumlah diskaun/);
});

test('reprint keeps promotion field from receipt detail payload',()=>{
  assert.match(reprint,/generateReceiptFromInvoice/);
  assert.doesNotMatch(reprint,/delete\s+inv\.promotion/);
});
