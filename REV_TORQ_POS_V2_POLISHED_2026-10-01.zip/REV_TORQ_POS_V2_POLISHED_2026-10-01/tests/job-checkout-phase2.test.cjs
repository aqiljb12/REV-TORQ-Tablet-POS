const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');

const source=fs.readFileSync(path.join(__dirname,'../js/v36-4-9-pos-cash-canonical.js'),'utf8');
const sql=fs.readFileSync(path.join(__dirname,'../migration_2026_09_22_workshop_flow_phase2.sql'),'utf8');
const id='11111111-1111-4111-8111-111111111111';
const jobId='22222222-2222-4222-8222-222222222222';
const partId='33333333-3333-4333-8333-333333333333';
const saved={id,invoiceNo:'INV-JOB-1',status:'PAID',paymentStatus:'PAID',total:42,
  items:[{name:'Saved service',qty:1,price:42,itemType:'SERVICE'}]};
function harness({method='CASH',mixed=false,storage=new Map(),rpc}={}){
  const cart=mixed?[
    {name:'Part',sku:'P',productId:partId,jobCardItemId:partId,fromJobCard:true,itemType:'PART',qty:1,price:20},
    {name:'Labour',sku:'L',itemType:'SERVICE',service:true,qty:1,price:10}
  ]:[{name:'Labour',sku:'L',itemType:'SERVICE',service:true,qty:1,price:10}];
  const els=new Map(Object.entries({btnCheckout:'',posDiscount:'0',posAmountReceived:'100',rtPosCustomerSelect:'',rtOtherCharge:'0'})
    .map(([k,v])=>[k,{value:v,innerHTML:'BAYAR / CHECKOUT',disabled:false}]));
  const calls=[],receipts=[];
  const query=table=>{const q={select(){return q},eq(){return q},limit(){return q},
    async maybeSingle(){return {data:table==='staff'?{id,company_id:id,location_id:id,role:'cashier'}:{id,status:'OPEN'},error:null}}};return q};
  const win={supabaseClient:{from:query,async rpc(name,args){calls.push({name,args});
    if(rpc)return rpc(name,args,calls);
    if(name==='rt_staff_receipt_detail')return {data:saved,error:null};
    if(name==='rt_pos_transaction_lookup')return {data:null,error:null};
    return {data:{invoice_id:id,invoice_no:'INV-JOB-1',total:42},error:null};}},
    currentProfile:{uid:id},posPayMethod:method,rtActiveJob:{jobCardId:jobId},
    rtGetPosCart:()=>cart,rtSetPosCart:()=>{cart.length=0},posClearCart:()=>{cart.length=0},
    showToast(){},generateReceiptFromInvoice:async x=>receipts.push(x),
    addEventListener(){},loadPOS(){},loadJobCards(){},rtSyncCashTender(){}};
  vm.runInNewContext(source,{window:win,document:{getElementById:x=>els.get(x)||null},
    sessionStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},
    crypto:{randomUUID:()=>id},setTimeout(){},setInterval(){},console:{error(){},warn(){}},alert(){}});
  return {win,cart,calls,receipts,storage};
}

test('labour-only CASH and parts plus labour QR use the same saved receipt',async()=>{
  for(const [method,mixed] of [['CASH',false],['QR / DUITNOW',true]]){
    const h=harness({method,mixed});await h.win.posCheckout();
    const sale=h.calls.find(x=>x.name==='rt_post_job_pos_sale_idempotent');
    assert.ok(sale);assert.equal(sale.args.p_transaction_id,id);
    assert.equal(sale.args.p_payment_method,method==='CASH'?'CASH':'QR');
    assert.equal(sale.args.p_items.filter(x=>x.item_type==='PART').length,mixed?1:0);
    assert.equal(sale.args.p_items.find(x=>x.item_type==='SERVICE').service_price,10);
    assert.equal(h.receipts.length,1);assert.equal(h.receipts[0].total,42);
    assert.equal(h.receipts[0].items[0].name,'Saved service');
    assert.equal(h.cart.length,0);
  }
});

test('rapid taps post one Job sale',async()=>{
  let release;const gate=new Promise(r=>release=r);
  const h=harness({rpc:async name=>{
    if(name==='rt_post_job_pos_sale_idempotent'){await gate;return {data:{invoice_id:id,invoice_no:'INV-JOB-1'},error:null}}
    return {data:saved,error:null};
  }});
  const first=h.win.posCheckout(),second=h.win.posCheckout();release();await Promise.all([first,second]);
  assert.equal(h.calls.filter(x=>x.name==='rt_post_job_pos_sale_idempotent').length,1);
  assert.equal(h.receipts.length,1);
});

test('failed request preserves cart and retries with the original ID',async()=>{
  let offline=true;
  const h=harness({rpc:async name=>{
    if(name==='rt_pos_transaction_lookup')return {data:null,error:null};
    if(name==='rt_post_job_pos_sale_idempotent'&&offline)return {error:{message:'offline'},data:null};
    if(name==='rt_staff_receipt_detail')return {data:saved,error:null};
    return {data:{invoice_id:id,invoice_no:'INV-JOB-1'},error:null};
  }});
  await h.win.posCheckout();assert.equal(h.cart.length,1);assert.equal(h.receipts.length,0);
  offline=false;await h.win.posCheckout();
  const sales=h.calls.filter(x=>x.name==='rt_post_job_pos_sale_idempotent');
  assert.equal(sales.length,2);assert.equal(sales[0].args.p_transaction_id,sales[1].args.p_transaction_id);
  assert.equal(h.receipts.length,1);assert.equal(h.cart.length,0);
});

test('committed sale with lost response recovers, including after refresh',async()=>{
  const storage=new Map();
  const before=harness({storage,rpc:async name=>name==='rt_pos_transaction_lookup'
    ?{data:null,error:null}:{data:null,error:{message:'offline'}}});
  await before.win.posCheckout();assert.equal(before.cart.length,1);
  const after=harness({storage,rpc:async name=>name==='rt_pos_transaction_lookup'
    ?{data:{id},error:null}:{data:saved,error:null}});
  after.cart.length=0;await after.win.posCheckout();
  assert.equal(after.calls.filter(x=>x.name==='rt_post_job_pos_sale_idempotent').length,0);
  assert.equal(after.receipts.length,1);assert.equal(after.storage.size,0);
});

test('insufficient stock keeps Job and cart, and SQL excludes service from stock loop',async()=>{
  const h=harness({mixed:true,rpc:async name=>name==='rt_pos_transaction_lookup'
    ?{data:null,error:null}:{data:null,error:{message:'JOB_PART_STOCK_INSUFFICIENT',code:'P0001'}}});
  await h.win.posCheckout();
  assert.equal(h.cart.length,2);assert.equal(h.win.rtActiveJob.jobCardId,jobId);
  assert.equal(h.receipts.length,0);assert.equal(h.storage.size,0);
  assert.match(sql,/if upper\(coalesce\(v_item->>'item_type',''\)\)='PART'[\s\S]*?insert into public\.stock_movements/);
});

test('Job receipt reprint and share retain the saved-invoice path; void uses the existing RPC',()=>{
  const reprint=fs.readFileSync(path.join(__dirname,'../js/receipt-reprint.js'),'utf8');
  const receipt=fs.readFileSync(path.join(__dirname,'../js/pos.js'),'utf8');
  const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
  assert.match(reprint,/rt_staff_receipt_detail/);
  assert.match(reprint,/generateReceiptFromInvoice/);
  assert.match(receipt,/__rtLastReceiptText/);
  assert.match(receipt,/rtShareReceiptWhatsApp/);
  assert.match(html,/supabaseRpc\('rt_admin_void_invoice'/);
  assert.match(sql,/reference_type,reference_id,staff_id[\s\S]*?'INVOICE',v_invoice\.id/);
});
