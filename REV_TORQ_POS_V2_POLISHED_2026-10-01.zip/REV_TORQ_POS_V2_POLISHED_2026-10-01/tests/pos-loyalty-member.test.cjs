const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('POS exposes phone-first member lookup without redesigning hidden customer binding',()=>{
  const html=read('index.html');
  for(const id of ['rtPosMemberPhone','rtPosMemberFind','rtPosMemberInfo','rtPosMemberPoints','rtPosClaimedVoucherList','rtPosCustomerSelect']) assert.match(html,new RegExp(`id="${id}"`));
  assert.match(html,/CARI \/ DAFTAR/);
});

test('POS member bridge calls server RPCs and renders claimed vouchers',()=>{
  const js=read('js/pos.js');
  assert.match(js,/rt_pos_find_or_create_customer/);
  assert.match(js,/rt_pos_customer_member_summary/);
  assert.match(js,/claimed_vouchers/);
  assert.match(js,/rtPosUseClaimedVoucher/);
  assert.match(js,/rtPosGetActiveVoucher/);
});

test('canonical checkout routes Job vouchers through the idempotent wrapper',()=>{
  const js=read('js/v36-4-9-pos-cash-canonical.js');
  const sql=read('migration_2026_09_22_workshop_flow_phase2.sql');
  assert.match(js,/rt_post_pos_sale_with_loyalty_voucher/);
  assert.match(js,/postProductSale\('rt_post_job_pos_sale_idempotent',args,c\)/);
  assert.match(js,/p_kind:voucher\?'VOUCHER':promo\?'PROMO':'STANDARD'/);
  assert.match(js,/p_voucher_code:voucher\?\.code\|\|null/);
  assert.doesNotMatch(js,/rt_post_job_pos_sale_with_loyalty_voucher/);
  assert.match(sql,/upper\(p_kind\)='VOUCHER'[\s\S]*?rt_post_job_pos_sale_with_loyalty_voucher/);
  assert.match(js,/rtPosApplyVoucher/);
});

test('POS migration mirror contains point and voucher primitives',()=>{
  const sql=read('migration_2026_09_18_loyalty_phone_member_claim.sql');
  assert.match(sql,/RM1 of eligible final spend = 1 point/);
  assert.match(sql,/rt_customer_claim_or_create_profile/);
  assert.match(sql,/rt_post_pos_sale_with_loyalty_voucher/);
});
