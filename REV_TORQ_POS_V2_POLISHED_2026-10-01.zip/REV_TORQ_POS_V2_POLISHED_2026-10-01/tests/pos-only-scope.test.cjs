const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ROOT=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(ROOT,p),'utf8');

test('admin navigation ships no accounting or P&L views',()=>{
  const core=read('js/core.js');
  assert.doesNotMatch(core,/['"]accounting['"]\s*,/i);
  assert.doesNotMatch(core,/['"]reports['"]\s*,/i);
  assert.doesNotMatch(core,/KEWANGAN/);
});

test('POS HTML does not load finance-only modules or screens',()=>{
  const html=read('index.html');
  assert.doesNotMatch(html,/accounting-live\.js|accounting-live\.css|monitacc-dashboard\.js|monitacc-mobile\.css/i);
  assert.doesNotMatch(html,/id="view-accounting"|id="view-reports"|id="expenseModal"/i);
});

test('finance-only files and Customer PWA are excluded from clean package',()=>{
  for(const p of ['js/accounting-live.js','css/accounting-live.css','js/monitacc-dashboard.js','css/monitacc-mobile.css','customer-pwa']){
    assert.equal(fs.existsSync(path.join(ROOT,p)),false,p+' should not ship');
  }
});

test('core POS operational modules remain present',()=>{
  for(const p of ['js/pos.js','js/jobcards.js','js/bookings.js','js/inventory.js','js/customers.js','js/native-barcode-bridge.js','js/receipt-reprint.js']){
    assert.equal(fs.existsSync(path.join(ROOT,p)),true,p+' missing');
  }
});
