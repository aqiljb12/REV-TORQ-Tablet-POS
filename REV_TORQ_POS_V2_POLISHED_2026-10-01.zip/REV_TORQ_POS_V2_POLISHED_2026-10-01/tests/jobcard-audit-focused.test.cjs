const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const root = path.join(__dirname, '..');
const between = (source, start, end) => source.slice(source.indexOf(start), source.indexOf(end, source.indexOf(start)));

test('active Job Card loader excludes CANCELLED without modifying source rows', async () => {
  const source = fs.readFileSync(path.join(root, 'js/jobcards.js'), 'utf8');
  const code = between(source, 'async function getJobRows()', 'async function getCustomers()');
  const jobs = [
    {id:'open', status:'OPEN'},
    {id:'cancelled', status:'CANCELLED'},
    {id:'paid', status:'COMPLETED'}
  ];
  const queries = [];
  const query = {
    select() { return this; }, eq() { return this; }, not() { return this; },
    then(resolve) { return Promise.resolve({data:[{job_card_id:'paid'}]}).then(resolve); }
  };
  const context = {
    queryRows: async (table) => { queries.push(table); return jobs; },
    companyJC: () => null,
    sb: {from: () => query},
    console
  };
  vm.runInNewContext(`${code}\nthis.result=getJobRows;`, context);
  const result = await context.result();
  assert.deepEqual(Array.from(result, x => x.id), ['open']);
  assert.deepEqual(jobs.map(x => x.status), ['OPEN','CANCELLED','COMPLETED']);
  assert.deepEqual(queries, ['job_cards']);
});

test('audit renders supported timestamps and all four existing columns', async () => {
  const source = fs.readFileSync(path.join(root, 'js/admin.js'), 'utf8');
  const code = between(source, 'function formatAuditTimestamp(', 'async function exportToExcel(');
  assert.ok(code.startsWith('function formatAuditTimestamp('), 'timestamp helper exists');
  const tbody = {innerHTML:''};
  const documents = [
    {timestamp:'2026-09-22T05:30:00.000Z', staffId:'S-ISO', action:'CREATE', details:'ISO row'},
    {timestamp:new Date('2026-09-22T05:30:00.000Z'), staffId:'S-DATE', action:'UPDATE', details:'Date row'},
    {timestamp:1790055000000, staffId:'S-NUM', action:'VOID', details:'Numeric row'},
    {timestamp:{toDate:()=>new Date('2026-09-22T05:30:00.000Z')}, staffId:'S-LEG', action:'REPRINT', details:'Legacy row'},
    {timestamp:{seconds:1790055000}, staffId:'S-SEC', action:'SHARE', details:'Seconds row'},
    {timestamp:'bad timestamp', staffId:'S-BAD', action:'CHECK', details:'Invalid row'}
  ];
  const context = {
    window:{},console,
    document:{querySelector:()=>tbody},
    db:{collection:name=>({orderBy(){return this},limit(){return this},where(){return this},async get(){return name==='staff' ? {forEach(){}} : {docs:documents.map(d=>({data:()=>d}))}}})}
  };
  vm.runInNewContext(`${code}\nthis.result=loadAudit;`, context);
  await context.result();
  const html = tbody.innerHTML;
  for (const d of documents) {
    assert.match(html, new RegExp(d.staffId));
    assert.match(html, new RegExp(d.action));
    assert.match(html, new RegExp(d.details));
  }
  assert.doesNotMatch(html, /Invalid Date|Ralat:/);
  assert.equal((html.match(/22\/(?:0)?9\/2026/g)||[]).length, 5);
  assert.match(html, />-<\/td>[\s\S]*S-BAD/);
});

test('audit batch resolves staff and shows selected metadata without private fields',async()=>{
  const source=fs.readFileSync(path.join(root,'js/admin.js'),'utf8');
  const code=between(source,'function formatAuditTimestamp(','async function exportToExcel(');
  const body={innerHTML:''};let staffQueries=0;
  const logs=[
    {timestamp:'2026-09-22T05:30:00Z',staffId:'uuid-1',action:'POS_CHECKOUT',metadata:{invoice_no:'INV-1',payment_method:'CASH',total:23,pin:'SECRET'}},
    {timestamp:'2026-09-22T05:30:00Z',staffId:'uuid-2',action:'VOID_INVOICE',metadata:{invoice_no:'INV-2',reason:'Duplicate',stock_restored:2}},
    {timestamp:'2026-09-22T05:30:00Z',staffId:'uuid-3',action:'CREATE_INVENTORY',metadata:{sku:'SKU-1',opening_stock:3}},
    {timestamp:'2026-09-22T05:30:00Z',staffId:'uuid-1',action:'CLOCK_IN',metadata:{target_staff_id:'uuid-2',clock_action:'CLOCK_IN'}}
  ];
  const context={window:{},console,document:{querySelector:()=>body},db:{collection:name=>({
    orderBy(){return this},limit(){return this},where(){return this},async get(){
      if(name==='audit_logs')return {docs:logs.map(d=>({data:()=>d}))};
      staffQueries++;return {forEach:cb=>{
        cb({id:'uuid-1',data:()=>({name:'Aqil',staffCode:'ST-1'})});
        cb({id:'uuid-2',data:()=>({name:'',staffCode:'ST-2'})});
      }};
    }
  })}};
  vm.runInNewContext(`${code}\nthis.load=loadAudit`,context);await context.load();
  assert.equal(staffQueries,1);
  for(const value of ['Aqil','ST-2','uuid-3','INV-1','CASH','23','INV-2','Duplicate','SKU-1','Stok awal: 3','CLOCK_IN'])assert.match(body.innerHTML,new RegExp(value));
  assert.doesNotMatch(body.innerHTML,/undefined|SECRET/);
});
