const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../js/v36-4-9-pos-cash-canonical.js'), 'utf8');
const uuid = '11111111-1111-4111-8111-111111111111';

function setup({method = 'CASH', rpcImpl, savedStorage} = {}) {
  const elements = new Map();
  for (const [id, value] of Object.entries({
    btnCheckout: '', posDiscount: '0', posAmountReceived: '20',
    rtPosCustomerSelect: '', rtOtherCharge: '0'
  })) elements.set(id, {value, innerHTML: 'BAYAR / CHECKOUT', disabled: false});
  const storage = savedStorage || new Map();
  const calls = [];
  const receipts = [];
  const cart = [{productId: uuid, sku: 'A', name: 'Part', price: 10, qty: 1, discount: 0}];
  const query = table => {
    const q = {select(){return q},eq(){return q},order(){return q},limit(){return q},
      async maybeSingle(){return {data: table === 'staff'
        ? {id:uuid, company_id:uuid, location_id:uuid, role:'cashier'}
        : table === 'cash_drawers' ? {id:uuid,status:'OPEN'} : {id:uuid},error:null}}};
    return q;
  };
  const win = {
    supabaseClient:{from:query, async rpc(name,args){calls.push({name,args}); return rpcImpl ? rpcImpl(name,args,calls) : name==='rt_staff_receipt_detail'
      ? {data:{id:uuid,invoiceNo:'INV-1',status:'PAID',paymentStatus:'PAID',total:10,items:[{name:'Part',qty:1,price:10}]},error:null}
      : {data:[{invoice_id:uuid,invoice_no:'INV-1',total:10,change_amount:10}],error:null}}},
    currentProfile:{uid:uuid}, posPayMethod:method, rtGetPosCart:()=>cart,
    showToast(){}, generateReceiptFromInvoice:async inv=>receipts.push(inv),
    rtSetPosCart:()=>{cart.length=0},posClearCart:()=>{cart.length=0},
    addEventListener(){}, loadPOS(){}, rtSyncCashTender(){}
  };
  const context = {window:win, document:{getElementById:id=>elements.get(id)||null},
    sessionStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},
    crypto:{randomUUID:()=>uuid}, setTimeout(){},setInterval(){},console:{error(){},warn(){}}, alert(){}};
  vm.runInNewContext(source,context);
  return {win,cart,calls,receipts,elements,storage};
}

test('repeated taps start only one checkout before asynchronous checks finish', async()=>{
  let release;
  const wait = new Promise(r=>{release=r});
  const h=setup({rpcImpl:async name=>name==='rt_post_pos_sale'?(await wait,{data:[{invoice_id:uuid,invoice_no:'INV-1',total:10}],error:null})
    :{data:{id:uuid,invoiceNo:'INV-1',status:'PAID',paymentStatus:'PAID',total:10,items:[{name:'Part',qty:1,price:10}]},error:null}});
  const first=h.win.posCheckout();
  const second=h.win.posCheckout();
  release();await Promise.all([first,second]);
  assert.equal(h.calls.filter(x=>x.name==='rt_post_pos_sale').length,1);
  assert.equal(h.receipts.length,1);
});

test('product checkout passes one stable transaction ID and keeps cart on API failure',async()=>{
  let fail=true;
  const h=setup({rpcImpl:async name=>{
    if(name==='rt_pos_transaction_lookup')return {data:null,error:null};
    if(name==='rt_post_pos_sale'&&fail)return {data:null,error:{message:'network'}};
    if(name==='rt_staff_receipt_detail')return {data:{id:uuid,invoiceNo:'INV-1',status:'PAID',paymentStatus:'PAID',total:10,items:[{name:'Part',qty:1,price:10}]},error:null};
    return {data:[{invoice_id:uuid,invoice_no:'INV-1',total:10}],error:null};
  }});
  await h.win.posCheckout();
  assert.equal(h.cart.length,1);
  fail=false;
  await h.win.posCheckout();
  const sales=h.calls.filter(x=>x.name==='rt_post_pos_sale');
  assert.equal(sales.length,2);
  assert.equal(sales[0].args.p_transaction_id,uuid);
  assert.equal(sales[1].args.p_transaction_id,uuid);
  assert.equal(h.receipts.length,1);
  assert.equal(h.cart.length,0);
});

test('saved invoice is used for receipt and no success receipt appears on failure',async()=>{
  const saved={id:uuid,invoiceNo:'INV-1',status:'PAID',paymentStatus:'PAID',total:12,items:[{name:'Part',qty:1,price:12}]};
  const h=setup({method:'QR',rpcImpl:async name=>name==='rt_staff_receipt_detail'
    ?{data:saved,error:null}:{data:[{invoice_id:uuid,invoice_no:'INV-1',total:12}],error:null}});
  await h.win.posCheckout();
  assert.equal(h.receipts.length,1);
  assert.equal(h.receipts[0].items[0].price,12);
  assert.equal(h.receipts[0].total,12);
  assert.equal(h.calls.find(x=>x.name==='rt_post_pos_sale').args.p_payment_method,'QR');
});

test('lost RPC response resolves the prior invoice without posting another sale',async()=>{
  let first=true;
  const h=setup({rpcImpl:async name=>{
    if(name==='rt_post_pos_sale')return first?(first=false,{data:null,error:{message:'timeout'}}):{data:null,error:{message:'duplicate'}};
    if(name==='rt_pos_transaction_lookup')return {data:{id:uuid},error:null};
    return {data:{id:uuid,invoiceNo:'INV-1',status:'PAID',paymentStatus:'PAID',total:10,items:[{name:'Part',qty:1,price:10}]},error:null};
  }});
  await h.win.posCheckout();
  assert.equal(h.calls.filter(x=>x.name==='rt_post_pos_sale').length,1);
  assert.equal(h.receipts.length,1);
});

test('refresh with a pending transaction looks up the prior invoice before posting',async()=>{
  const savedStorage=new Map();
  const first=setup({savedStorage,rpcImpl:async name=>name==='rt_pos_transaction_lookup'
    ?{data:null,error:null}:{data:null,error:{message:'offline'}}});
  await first.win.posCheckout();
  assert.equal(first.cart.length,1);
  const second=setup({savedStorage,rpcImpl:async name=>name==='rt_pos_transaction_lookup'
    ?{data:{id:uuid},error:null}:{data:{id:uuid,invoiceNo:'INV-1',status:'PAID',paymentStatus:'PAID',total:10,items:[{name:'Part',qty:1,price:10}]},error:null}});
  second.cart.length=0;
  await second.win.posCheckout();
  assert.equal(second.calls.filter(x=>x.name==='rt_post_pos_sale').length,0);
  assert.equal(second.receipts.length,1);
});

test('stock failure preserves cart and never renders a receipt',async()=>{
  const h=setup({rpcImpl:async name=>name==='rt_pos_transaction_lookup'
    ?{data:null,error:null}:{data:null,error:{message:'INSUFFICIENT_STOCK',code:'P0001'}}});
  await h.win.posCheckout();
  assert.equal(h.cart.length,1);
  assert.equal(h.receipts.length,0);
  assert.equal(h.storage.size,0);
});

function chargeRpc(){
  let saved;
  return async (name,args)=>{
    if(name==='rt_pos_transaction_lookup')return {data:null,error:null};
    if(name==='rt_post_pos_sale'){
      const charge=args.p_items.find(i=>i.item_type==='OTHER');
      const total=10-Number(args.p_discount||0)+Number(charge?.unit_price||0);
      saved={id:uuid,invoiceNo:'INV-1',status:'PAID',paymentStatus:'PAID',total,
        subtotal:10+Number(charge?.unit_price||0),discount:Number(args.p_discount||0),
        items:[{name:'Part',qty:1,price:10,itemType:'PART'},
          ...(charge?[{name:charge.description,qty:1,price:Number(charge.unit_price),lineTotal:Number(charge.unit_price),itemType:'OTHER'}]:[])]};
      return {data:[{invoice_id:uuid,invoice_no:'INV-1',total}],error:null};
    }
    if(name==='rt_staff_receipt_detail')return {data:saved,error:null};
    throw new Error('Unexpected RPC '+name);
  };
}

test('zero other charge keeps the existing one-item checkout',async()=>{
  const h=setup({rpcImpl:chargeRpc()});
  await h.win.posCheckout();
  const sale=h.calls.find(x=>x.name==='rt_post_pos_sale');
  assert.equal(sale.args.p_items.length,1);
  assert.equal(h.receipts[0].total,10);
});

test('other charge persists as a non-stock invoice item and adds to total',async()=>{
  const h=setup({rpcImpl:chargeRpc()});h.elements.get('rtOtherCharge').value='5';
  await h.win.posCheckout();
  const sale=h.calls.find(x=>x.name==='rt_post_pos_sale');
  const charge=sale.args.p_items.find(i=>i.item_type==='OTHER');
  assert.equal(charge.product_id,null);
  assert.equal(charge.unit_price,5);
  assert.equal(charge.quantity,1);
  assert.equal(charge.description,'CAJ LAIN');
  assert.equal(charge.other_charge,true);
  assert.equal(h.receipts[0].total,15);
  assert.equal(h.receipts[0].items[1].itemType,'OTHER');
});

test('manual discount applies to items before adding other charge',async()=>{
  const h=setup({rpcImpl:chargeRpc()});
  h.elements.get('rtOtherCharge').value='5';
  h.elements.get('posDiscount').value='2';
  h.elements.get('posAmountReceived').value='12';
  await h.win.posCheckout();
  assert.equal(h.calls.filter(x=>x.name==='rt_post_pos_sale').length,0);
  h.elements.get('posAmountReceived').value='13';
  await h.win.posCheckout();
  const sale=h.calls.find(x=>x.name==='rt_post_pos_sale');
  assert.equal(sale.args.p_discount,2);
  assert.equal(h.receipts[0].total,13);
});

test('repeated checkout taps with a charge post once',async()=>{
  let release;
  const wait=new Promise(r=>{release=r});
  const rpc=chargeRpc();
  const h=setup({rpcImpl:async(name,args)=>{if(name==='rt_post_pos_sale')await wait;return rpc(name,args)}});
  h.elements.get('rtOtherCharge').value='5';
  const first=h.win.posCheckout(),second=h.win.posCheckout();
  release();await Promise.all([first,second]);
  assert.equal(h.calls.filter(x=>x.name==='rt_post_pos_sale').length,1);
  assert.equal(h.receipts[0].total,15);
});

test('failed charged sale retries with the saved charge and transaction ID',async()=>{
  let fail=true;
  const rpc=chargeRpc();
  const h=setup({rpcImpl:async(name,args)=>{
    if(name==='rt_post_pos_sale'&&fail)return {data:null,error:{message:'offline'}};
    return rpc(name,args);
  }});
  h.elements.get('rtOtherCharge').value='5';
  await h.win.posCheckout();
  assert.equal(h.cart.length,1);
  h.elements.get('rtOtherCharge').value='0';
  fail=false;await h.win.posCheckout();
  const sales=h.calls.filter(x=>x.name==='rt_post_pos_sale');
  assert.equal(sales[0].args.p_transaction_id,sales[1].args.p_transaction_id);
  assert.equal(sales[1].args.p_items.find(i=>i.item_type==='OTHER').unit_price,5);
  assert.equal(h.receipts[0].total,15);
});

test('charged sale survives refresh and recovers its saved invoice',async()=>{
  const savedStorage=new Map();
  const first=setup({savedStorage,rpcImpl:async name=>name==='rt_pos_transaction_lookup'
    ?{data:null,error:null}:{data:null,error:{message:'offline'}}});
  first.elements.get('rtOtherCharge').value='5';
  await first.win.posCheckout();
  const pending=JSON.parse(savedStorage.get('rt_pos_pending_sale_v1'));
  assert.equal(pending.args.p_items.find(i=>i.item_type==='OTHER').unit_price,5);
  const second=setup({savedStorage,rpcImpl:async name=>name==='rt_pos_transaction_lookup'
    ?{data:{id:uuid},error:null}:{data:{id:uuid,invoiceNo:'INV-1',status:'PAID',paymentStatus:'PAID',total:15,
      items:[{name:'Part',qty:1,price:10,itemType:'PART'},
        {name:'CAJ LAIN',qty:1,price:5,lineTotal:5,itemType:'OTHER'}]},error:null}});
  second.cart.length=0;
  await second.win.posCheckout();
  assert.equal(second.calls.filter(x=>x.name==='rt_post_pos_sale').length,0);
  assert.equal(second.receipts[0].total,15);
  assert.equal(second.receipts[0].items[1].name,'CAJ LAIN');
});

test('promo and voucher payloads carry the marked charge without manual discount',async()=>{
  for(const mode of ['promo','voucher']){
    const h=setup({method:'QR',rpcImpl:async name=>{
      if(name==='rt_staff_receipt_detail')return {data:{id:uuid,invoiceNo:'INV-1',status:'PAID',paymentStatus:'PAID',total:13,
        items:[{name:'Part',qty:1,price:10,itemType:'PART'},
          {name:'CAJ LAIN',qty:1,price:5,lineTotal:5,itemType:'OTHER'}]},error:null};
      return {data:[{invoice_id:uuid,invoice_no:'INV-1',total:13}],error:null};
    }});
    h.elements.get('rtOtherCharge').value='5';
    h.elements.get('rtPosCustomerSelect').value=uuid;
    if(mode==='promo'){
      h.win.rtGetActivePromo=()=>({promotion_id:uuid,promo_code:'P2',discount_amount:2});
      h.win.rtRevalidateActivePromo=async()=>true;
    }else{
      h.win.rtPosGetActiveVoucher=()=>({code:'V2',customer_id:uuid,discount_applied:2});
      h.win.rtPosApplyVoucher=async()=>true;
    }
    await h.win.posCheckout();
    const sale=h.calls.find(x=>x.name===`rt_post_pos_sale_with_${mode==='promo'?'promo':'loyalty_voucher'}`);
    assert.ok(sale);
    assert.equal(sale.args.p_items.find(i=>i.item_type==='OTHER').other_charge,true);
    if(mode==='promo')assert.equal(sale.args.p_manual_discount,0);
    assert.equal(h.receipts[0].total,13);
  }
});

test('charge SQL excludes marked charge from promo base and never moves its stock',()=>{
  const sql=fs.readFileSync(path.join(__dirname,'../migration_2026_09_22_pos_other_charge.sql'),'utf8');
  const sale=fs.readFileSync(path.join(__dirname,'../migration_2026_09_18_pos_item_discount.sql'),'utf8');
  assert.match(sql,/item->>'other_charge'/);
  assert.match(sql,/item->>'item_type'[\s\S]*'OTHER'/);
  assert.match(sale,/item->>'item_type'[\s\S]*'OTHER'/);
  assert.match(sale,/if nullif\(item->>'product_id',''\) is not null and upper\(coalesce\(item->>'item_type','PART'\)\) not in \('SERVICE','LABOUR','OTHER'\)/);
});

test('cart and cash tender totals include the visible other charge',()=>{
  const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
  assert.match(html,/id="rtOtherCharge"[^>]*oninput="posCalculateTotal\(\)"/);
  assert.match(html,/id="rtOtherChargeDisplay"/);
  const elements=new Map();
  for(const [id,value] of Object.entries({posDiscount:'0',rtOtherCharge:'5',posAmountReceived:'20'}))
    elements.set(id,{value,innerText:'',textContent:'',className:'',style:{}});
  for(const id of ['posSubtotal','rtItemDiscountDisplay','rtDiscountDisplay','rtOtherChargeDisplay','posTotal','posChange','rtCashDue','rtCashTotal','rtCashReceived','btnCheckout','rtCashTenderBox'])
    elements.set(id,{value:'',innerText:'',textContent:'',className:'',style:{},disabled:false,title:''});
  const document={addEventListener(){},getElementById:id=>elements.get(id)||null,querySelectorAll:()=>[]};
  const win={RTPosDiscountModel:require('../js/pos-item-discount-model.js'),addEventListener(){}};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../js/pos.js'),'utf8'),
    {window:win,document,location:{hostname:'localhost',search:''},formatMoney:v=>'RM '+Number(v).toFixed(2),console:{warn(){}}});
  win.rtSetPosCart([{sku:'A',name:'Part',price:10,qty:1,discount:0}]);
  win.posCalculateTotal();
  assert.match(elements.get('posTotal').innerText,/15\.00/);
  assert.match(elements.get('rtOtherChargeDisplay').innerText,/5\.00/);
  vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../js/v36-4-8-cash-tender.js'),'utf8'),
    {window:win,document,console:{warn(){}},setTimeout(){}});
  win.rtPosCheckoutTotal=()=>15;
  win.rtSyncCashTender();
  assert.match(elements.get('rtCashDue').textContent,/15\.00/);
});

test('saved charge is a separate receipt and share line on checkout and reprint',async()=>{
  const saved={id:uuid,invoiceNo:'INV-1',status:'PAID',paymentStatus:'PAID',
    discount:2,orderDiscount:2,total:13,amountPaid:13,paymentMethod:'CASH',
    items:[{name:'Part',qty:1,price:10,discount:0,itemType:'PART'},
      {name:'CAJ LAIN',qty:1,price:5,lineTotal:5,discount:0,itemType:'OTHER'}]};
  const area={innerHTML:'',insertAdjacentHTML(position,html){this.innerHTML=html+this.innerHTML}};
  const modal={parentElement:null,classList:{add(){},remove(){}},style:{setProperty(){}}};
  const body={appendChild(node){node.parentElement=body}};
  const doc={body,addEventListener(){},getElementById:id=>id==='printArea'?area:modal};
  const win={RTPosDiscountModel:require('../js/pos-item-discount-model.js'),
    supabaseRpc:async()=>structuredClone(saved),rtPrintReceipt:async()=>true,
    currentProfile:{staffId:'AQIL'},showToast(){}};
  const context={window:win,document:doc,currentProfile:{staffId:'AQIL'},openModal(){},
    location:{hostname:'localhost',search:''},setTimeout(){},clearTimeout(){},console:{warn(){},error(){}}};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../js/pos.js'),'utf8'),context);
  await win.generateReceiptFromInvoice(saved);
  assert.match(area.innerHTML,/Subtotal asal:[\s\S]*RM 10\.00/);
  assert.match(area.innerHTML,/Caj lain:[\s\S]*RM 5\.00/);
  assert.match(win.__rtLastReceiptText,/Caj lain: RM 5\.00/);
  vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../js/receipt-reprint.js'),'utf8'),context);
  await win.rtReprintInvoice(uuid);
  assert.match(area.innerHTML,/SALINAN \/ REPRINT/);
  assert.match(area.innerHTML,/Caj lain:[\s\S]*RM 5\.00/);
  assert.match(win.__rtLastReceiptText,/Caj lain: RM 5\.00/);
});

test('discounted QR receipt shows the confirmed total as amount paid',async()=>{
  const area={innerHTML:''};
  const win={RTPosDiscountModel:require('../js/pos-item-discount-model.js')};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../js/pos.js'),'utf8'),
    {window:win,document:{addEventListener(){},getElementById:()=>area},currentProfile:{staffId:'AQIL'},
      openModal(){},location:{hostname:'localhost',search:''},console:{warn(){}}});
  await win.generateReceiptFromInvoice({invoiceNo:'INV-2',status:'PAID',paymentStatus:'PAID',
    paymentMethod:'QR',amountPaid:15,total:13,discount:2,promotion:{code:'P2',name:'Promo',discount:2},
    items:[{name:'Part',qty:1,price:10,itemType:'PART'},
      {name:'CAJ LAIN',qty:1,price:5,lineTotal:5,itemType:'OTHER'}]});
  assert.match(area.innerHTML,/Dibayar:[\s\S]*RM 13\.00/);
  assert.match(win.__rtLastReceiptText,/Dibayar: RM 13\.00/);
});

test('recovery SQL provides a role-checked, company-scoped lookup without schema changes',()=>{
  const sql=fs.readFileSync(path.join(__dirname,'../migration_2026_09_22_pos_transaction_stability.sql'),'utf8');
  assert.match(sql,/i\.company_id=v_staff\.company_id and i\.transaction_id=p_transaction_id/);
  assert.match(sql,/POS_ROLE_NOT_ALLOWED/);
  assert.doesNotMatch(sql,/\b(drop|truncate|alter table|create index|disable row level security)\b/i);
});

test('receipt reprint loads the saved invoice and marks the copy',async()=>{
  const src=fs.readFileSync(path.join(__dirname,'../js/receipt-reprint.js'),'utf8');
  const rendered=[];
  const area={insertAdjacentHTML(position,html){this.badge=html}};
  const modal={parentElement:null,classList:{add(){},remove(){}},style:{setProperty(){}}};
  const body={appendChild(node){node.parentElement=body}};
  const win={generateReceiptFromInvoice:async inv=>rendered.push(inv),
    rtPrintReceipt:async()=>true,
    supabaseRpc:async()=>({id:uuid,invoiceNo:'INV-1',status:'PAID',items:[{name:'Part'}]}),
    currentProfile:{staffId:'AQIL'},showToast(){}};
  vm.runInNewContext(src,{window:win,document:{body,getElementById:id=>id==='printArea'?area:modal},
    location:{hostname:'localhost'},setTimeout(){},clearTimeout(){},console:{error(){},warn(){}}});
  await win.rtReprintInvoice(uuid);
  assert.equal(rendered.length,1);
  assert.equal(rendered[0].__rtReprint,true);
  assert.match(area.badge,/SALINAN \/ REPRINT/);
});

test('existing WhatsApp share uses the generated receipt text',()=>{
  const src=fs.readFileSync(path.join(__dirname,'../js/pos.js'),'utf8');
  let opened='';
  const win={__rtLastReceiptText:'Resit: INV-1\nJUMLAH: RM 10.00',open:url=>{opened=url;return {}}};
  const location={hostname:'localhost',search:''};
  vm.runInNewContext(src,{window:win,location,document:{addEventListener(){}},console:{error(){},warn(){}}});
  win.rtShareReceiptWhatsApp();
  assert.equal(opened,'https://wa.me/?text='+encodeURIComponent(win.__rtLastReceiptText));
});
