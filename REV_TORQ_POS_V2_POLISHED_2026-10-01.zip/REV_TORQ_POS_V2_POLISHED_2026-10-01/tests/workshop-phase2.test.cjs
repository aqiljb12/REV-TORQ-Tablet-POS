const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('staff booking RPCs preserve workshop linkage and notifications',()=>{
  const staff=read('js/bookings.js');
  const sql=read('migration_2026_09_17_workshop_booking_confirmation.sql');
  assert.match(staff,/\.eq\('booking_department','WORKSHOP'\)/);
  assert.match(staff,/rt_staff_confirm_workshop_booking/);
  assert.match(staff,/rt_staff_reject_workshop_booking/);
  assert.match(staff,/rt_staff_reschedule_workshop_booking/);
  assert.match(sql,/booking_id = v_booking\.id/);
  assert.match(sql,/create unique index if not exists ux_job_cards_booking_id_one/);
  assert.match(sql,/booking-confirmed:/);
  assert.match(sql,/booking-rejected:/);
});

test('Job checkout uses transaction lookup and saved invoice receipt',()=>{
  const pos=read('js/v36-4-9-pos-cash-canonical.js');
  assert.match(pos,/rt_post_job_pos_sale_idempotent/);
  assert.match(pos,/p_transaction_id:transactionId/);
  assert.match(pos,/postProductSale\('rt_post_job_pos_sale_idempotent'/);
  assert.match(pos,/generateReceiptFromInvoice\(receipt\)/);
  assert.doesNotMatch(pos,/generateReceiptFromInvoice\(\{invoiceNo:row\.invoice_no/);
});

test('Job sale wrapper shares transaction ID and deducts only Job PART lines',()=>{
  const sql=read('migration_2026_09_22_workshop_flow_phase2.sql');
  assert.match(sql,/create or replace function public\.rt_post_job_pos_sale_idempotent/);
  assert.match(sql,/p_transaction_id uuid/);
  assert.match(sql,/for update/);
  assert.match(sql,/upper\(coalesce\(v_item->>'item_type',''\)\)='PART'/);
  assert.match(sql,/coalesce\(\(v_item->>'from_job_card'\)::boolean,false\)/);
  assert.match(sql,/update public\.stock_balances set quantity=quantity-v_qty/);
  assert.match(sql,/insert into public\.stock_movements/);
  assert.match(sql,/update public\.payments set transaction_id=p_transaction_id/);
  assert.match(sql,/update public\.invoices set transaction_id=p_transaction_id/);
  assert.match(sql,/revoke all on function public\.rt_post_job_pos_sale_idempotent/);
  assert.doesNotMatch(sql,/\b(drop table|truncate|disable row level security|grant execute .* to anon)\b/i);
});
