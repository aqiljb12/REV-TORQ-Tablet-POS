const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('payment QR settings use the existing company/location settings table with scoped RPCs',()=>{
  const sql=read('migration_2026_09_22_payment_qr_settings.sql');
  assert.match(sql,/create or replace function public\.rt_payment_qr_get\(/i);
  assert.match(sql,/create or replace function public\.rt_payment_qr_save\(/i);
  assert.match(sql,/public\.app_settings/);
  assert.match(sql,/company_id/);
  assert.match(sql,/location_id/);
  assert.match(sql,/POS_ROLE_NOT_ALLOWED/);
  assert.match(sql,/QR_SETTINGS_ADMIN_ONLY/);
  assert.match(sql,/grant execute .* to authenticated/i);
  assert.doesNotMatch(sql,/drop table|truncate|disable row level security|grant execute .* to anon/i);
});

test('configured QR has admin edit controls, staff checkout preview, and explicit manual confirmation',()=>{
  const html=read('index.html');
  const qr=read('js/payment-qr.js');
  for(const id of ['rtPaymentQrSettings','rtPaymentQrFile','rtPaymentQrMerchant','rtPaymentQrProvider',
    'rtPaymentQrLabel','rtPaymentQrActive','rtPaymentQrPreview','rtPaymentQrRemove','rtPaymentQrNote',
    'rtPaymentQrPanel','rtPaymentQrConfirm'])assert.match(html,new RegExp(`id="${id}"`));
  assert.match(qr,/rt_payment_qr_get/);
  assert.match(qr,/rt_payment_qr_save/);
  assert.match(qr,/posSetPaymentMethod/);
  assert.match(qr,/rt_post_job_pos_sale_idempotent|posCheckout/);
  assert.match(qr,/checked/);
  assert.doesNotMatch(qr,/rt_post_pos_sale|rt_post_job_pos_sale\(/);
});

test('printer keeps saved receipt, browser fallback, and native bridge without RawBT WebView navigation',()=>{
  const html=read('index.html');
  const raw=read('js/rt-rawbt-printer.js');
  const reprint=read('js/receipt-reprint.js');
  assert.match(html,/window\.print\(\)/);
  assert.match(html,/rtPrinterTestPrint/);
  assert.match(html,/rtHasAdminAccess/);
  assert.match(raw,/RevTorqNative\.launchRawBt/);
  assert.match(raw,/RAWBT_NATIVE_BRIDGE_UNAVAILABLE/);
  assert.match(reprint,/rt_staff_receipt_detail/);
  assert.match(reprint,/rt_log_receipt_reprint/);
});

