const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const model = require(path.resolve(__dirname,'../js/pos-promo-model.js'));

test('promo selection locks overall manual discount and keeps authoritative server amount',()=>{
  const s=model.applyPromo({promotion_id:'p1',promo_code:'OPEN10',name:'Opening',discount_amount:8,used_count:23,usage_limit:100});
  assert.equal(s.orderDiscountLocked,true);
  assert.equal(s.promoDiscount,8);
  assert.equal(s.promo.promotion_id,'p1');
});

test('remove promo unlocks overall manual discount',()=>{
  const s=model.removePromo(model.applyPromo({promotion_id:'p1',discount_amount:5}));
  assert.equal(s.orderDiscountLocked,false);
  assert.equal(s.promo,null);
  assert.equal(s.promoDiscount,0);
});

test('formats usage counts',()=>{
  assert.equal(model.usageText({used_count:23,usage_limit:100}),'23 / 100 digunakan');
  assert.equal(model.usageText({used_count:23,usage_limit:null}),'23 digunakan · Tiada had');
});

test('promo and loyalty voucher cannot remain active together',()=>{
  const s=model.applyPromo({promotion_id:'p1',discount_amount:5},{voucher:{code:'V1'}});
  assert.equal(s.voucher,null);
  assert.equal(s.promo.promotion_id,'p1');
});
