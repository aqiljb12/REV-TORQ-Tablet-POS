const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('Android 9 remains supported and native scanner dependencies are bundled',()=>{
  const gradle=read('app/build.gradle');
  assert.match(gradle,/minSdk\s+26/);
  assert.match(gradle,/camera-camera2:1\.4\.2/);
  assert.match(gradle,/camera-view:1\.4\.2/);
  assert.match(gradle,/com\.google\.mlkit:barcode-scanning:17\.3\.0/);
});

test('CameraX analyzer is low-latency and uses ML Kit media image without JPEG/Bitmap conversion',()=>{
  const java=read('app/src/main/java/com/revtorq/pos/NativeBarcodeScannerActivity.java');
  assert.match(java,/STRATEGY_KEEP_ONLY_LATEST/);
  assert.match(java,/InputImage\.fromMediaImage/);
  assert.match(java,/AtomicBoolean/);
  assert.doesNotMatch(java,/compressToJpeg|BitmapFactory|YuvImage/);
  for(const format of ['FORMAT_EAN_13','FORMAT_EAN_8','FORMAT_UPC_A','FORMAT_UPC_E','FORMAT_CODE_128'])assert.match(java,new RegExp(format));
});

test('scanner has duplicate guard, manual path, autofocus, torch and multi-scan',()=>{
  const java=read('app/src/main/java/com/revtorq/pos/NativeBarcodeScannerActivity.java');
  assert.match(java,/SAME_CODE_COOLDOWN_MS\s*=\s*850/);
  assert.match(java,/REARM_ABSENCE_MS\s*=\s*550/);
  assert.match(java,/FocusMeteringAction/);
  assert.match(java,/enableTorch/);
  assert.match(java,/acceptManualBarcode/);
  assert.match(java,/MODE_MULTI/);
  assert.match(java,/beepAndVibrate/);
});

test('WebView bridge keeps barcode as string and reuses existing cart',()=>{
  const js=read('js/native-barcode-bridge.js');
  assert.match(js,/normalizeBarcode/);
  assert.doesNotMatch(js,/Number\(normalized\)|parseInt\(normalized\)|parseFloat\(normalized\)/);
  assert.match(js,/\.eq\('barcode',normalized\)/);
  assert.match(js,/posAddToCart\(item\.sku,item\.name,item\.price,item\.stock\)/);
  assert.match(js,/scannerLookupResult/);
  assert.match(js,/MULTI_SCAN/);
});

test('native scanner activity is private to the app',()=>{
  const manifest=read('app/src/main/AndroidManifest.xml');
  assert.match(manifest,/NativeBarcodeScannerActivity/);
  assert.match(manifest,/android:exported="false"/);
});

test('native bridge normalization preserves leading zeros and adds through existing cart',async()=>{
  const vm=require('node:vm');
  const source=read('js/native-barcode-bridge.js');
  const calls=[],feedback=[];
  const ctx={
    console,
    setTimeout,
    Event:class Event{constructor(type,opts){this.type=type;this.opts=opts;}},
    RevTorqAndroid:{scanBarcode(){},scannerLookupResult:(code,found,message)=>feedback.push({code,found,message})},
    posProducts:[{sku:'SKU1',name:'Oil',barcode:'000123',price:12,stock:4}],
    posAddToCart:(...a)=>calls.push(a),
    document:{addEventListener(){},getElementById(){return null;}},
    showToast(){},
  };
  ctx.window=ctx;
  vm.createContext(ctx);
  vm.runInContext(source,ctx);
  assert.equal(ctx.rtNormalizeBarcode('  000123\n'),'000123');
  ctx.RevTorqNativeScanner.onBarcode(' 000123\n','MULTI_SCAN');
  await new Promise(r=>setImmediate(r));
  assert.deepEqual(calls,[['SKU1','Oil',12,4]]);
  assert.equal(feedback.at(-1).code,'000123');
  assert.equal(feedback.at(-1).found,true);
});

test('unknown native barcode reports clear not-found feedback without mutating cart',async()=>{
  const vm=require('node:vm');
  const source=read('js/native-barcode-bridge.js');
  const calls=[],feedback=[];
  const ctx={
    console,
    setTimeout,
    Event:class Event{},
    RevTorqAndroid:{scanBarcode(){},scannerLookupResult:(code,found,message)=>feedback.push({code,found,message})},
    posProducts:[],
    posAddToCart:(...a)=>calls.push(a),
    document:{addEventListener(){},getElementById(){return null;}},
    showToast(){},
  };
  ctx.window=ctx;
  vm.createContext(ctx);
  vm.runInContext(source,ctx);
  ctx.RevTorqNativeScanner.onBarcode('9556439890787','MULTI_SCAN');
  await new Promise(r=>setImmediate(r));
  assert.equal(calls.length,0);
  assert.equal(feedback.at(-1).found,false);
  assert.match(feedback.at(-1).message,/tidak dijumpai/i);
});

function bridgeHarness(){
  const vm=require('node:vm');
  const listeners={},opened=[],feedback=[],cart=[],lookups=[];
  const barcodeField={value:'',dispatchEvent(){}};
  const posField={id:'posSearch',value:'000123'};
  const ctx={
    console,setTimeout,
    Event:class Event{constructor(type){this.type=type;}},
    RevTorqAndroid:{scanBarcode:mode=>opened.push(mode),scannerLookupResult:(...args)=>feedback.push(args)},
    posProducts:[{sku:'SKU1',name:'Oil',barcode:'000123',price:12,stock:4}],
    posAddToCart:(...args)=>cart.push(args),
    inventoryBarcodeLookup:async code=>{lookups.push(code);return {sku:'SKU1'};},
    document:{addEventListener:(name,handler)=>{listeners[name]=handler;},getElementById:id=>({invBarcode:barcodeField,posSearch:posField})[id]||null},
    showToast(){},
  };
  ctx.window=ctx;
  vm.createContext(ctx);
  vm.runInContext(read('js/native-barcode-bridge.js'),ctx);
  return {ctx,listeners,opened,feedback,cart,lookups,barcodeField,posField};
}

test('inventory native lookup uses existing lookup and never adds POS cart',async()=>{
  const h=bridgeHarness();
  h.ctx.RevTorqNativeScanner.onBarcode(' 000123\n','INVENTORY_LOOKUP');
  await new Promise(r=>setImmediate(r));
  assert.deepEqual(h.lookups,['000123']);
  assert.equal(h.cart.length,0);
  assert.equal(h.feedback.at(-1)[1],true);
});

test('inventory barcode input accepts unknown string with leading zeros',async()=>{
  const h=bridgeHarness();
  h.ctx.RevTorqNativeScanner.onBarcode(' 000987\n','INVENTORY_BARCODE_INPUT');
  await new Promise(r=>setImmediate(r));
  assert.equal(h.barcodeField.value,'000987');
  assert.equal(h.cart.length,0);
  assert.equal(h.lookups.length,0);
  assert.equal(h.feedback.at(-1)[1],true);
});

test('inventory camera buttons open explicit native modes',()=>{
  const h=bridgeHarness();
  for(const [id,mode] of [['rtInventoryCameraBtn','INVENTORY_LOOKUP'],['rtInvScanBtn','INVENTORY_BARCODE_INPUT']]){
    const button={id};
    h.listeners.click({target:{closest:selector=>selector.includes('#'+id)?button:null},preventDefault(){},stopImmediatePropagation(){}});
    assert.equal(h.opened.at(-1),mode);
  }
});

test('HID Enter in POS barcode field adds exactly once and clears scan value',async()=>{
  const h=bridgeHarness();
  let prevented=0;
  const event={key:'Enter',target:h.posField,preventDefault(){prevented++;},stopImmediatePropagation(){}};
  h.listeners.keydown(event);
  h.listeners.keydown(event);
  await new Promise(r=>setImmediate(r));
  assert.equal(prevented,2);
  assert.equal(h.posField.value,'');
  assert.equal(h.cart.length,1);
});

test('native Java bridge retains explicit POS and inventory scanner modes',()=>{
  const activity=read('app/src/main/java/com/revtorq/pos/NativeBarcodeScannerActivity.java');
  const bridge=read('app/src/main/java/com/revtorq/pos/MainActivity.java');
  for(const mode of ['POS_MULTI','INVENTORY_LOOKUP','INVENTORY_BARCODE_INPUT']){
    assert.match(activity,new RegExp(mode));
    assert.match(bridge,new RegExp(mode));
  }
});

test('Inventory HID Enter fills the add/edit barcode field without a lookup',()=>{
  const vm=require('node:vm');
  let keydown,lookupCount=0,prevented=0;
  const field={id:'invBarcode',tagName:'INPUT',value:' 000456 ',dispatchEvent(){}};
  const ctx={console,performance:{now:()=>100},Event:class Event{},MutationObserver:class{observe(){}},
    document:{addEventListener:(type,fn)=>{if(type==='keydown')keydown=fn;},documentElement:{},getElementById:()=>null},
    window:{addEventListener(){},inventoryBarcodeLookup(){lookupCount++;}},
  };
  vm.createContext(ctx);
  vm.runInContext(read('js/inventory-tools-rc7.js'),ctx);
  keydown({key:'Enter',target:field,ctrlKey:false,altKey:false,metaKey:false,preventDefault(){prevented++;}});
  assert.equal(prevented,1);
  assert.equal(field.value,'000456');
  assert.equal(lookupCount,0);
});

test('Inventory list barcode field sends HID Enter to existing inventory lookup',()=>{
  const html=read('app/src/main/assets/index.html');
  const tag=html.match(/<input[^>]+id="inventoryBarcodeSearch"[^>]+>/)?.[0];
  assert.ok(tag);
  const handler=tag.match(/onkeydown="([^"]+)"/)?.[1];
  assert.ok(handler);
  const calls=[],field={value:'000321'};
  let prevented=0;
  new Function('event','inventoryBarcodeLookup',handler).call(field,
    {key:'Enter',preventDefault(){prevented++;}},code=>calls.push(code));
  assert.deepEqual(calls,['000321']);
  assert.equal(field.value,'');
  assert.equal(prevented,1);
});
