# REV TORQ POS v0.8.7 — Native Barcode Scanner Upgrade

Scope is scanner-only. Existing POS/cart/checkout/inventory/auth/Supabase business logic is preserved.

## Architecture

`CameraX Preview + ImageAnalysis` → `YUV_420_888 MediaImage` → `InputImage.fromMediaImage()` → bundled Google ML Kit Barcode Scanning → native duplicate/re-arm guard → WebView bridge → existing REV TORQ product lookup → existing `posAddToCart()`.

There is deliberately no JPEG/Bitmap conversion in the live analysis path. `ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST` and one in-flight ML Kit frame prevent frame backlog.

## Product barcode formats

The native scanner only enables the workshop formats needed for product scanning:

- EAN-13
- EAN-8
- UPC-A
- UPC-E
- Code 128

QR is not enabled in the native POS scanner so normal product barcode detection gets priority.

## Behaviour

- Rear camera by default.
- 1280×720 analysis target for low-latency recognition.
- Center focus on open and tap-to-focus.
- Pinch-to-zoom.
- Torch toggle when flash is available.
- Multi-scan remains open until **SELESAI**.
- Same code cannot spam the cart while it remains in view. It must leave the camera briefly before it can be intentionally scanned again.
- Manual barcode entry uses the same normalize → lookup → add pipeline.
- Leading zeros are preserved; barcodes are never converted to numbers.
- Successful add gives a short beep + vibration.
- Unknown barcode shows `Barcode tidak dijumpai` with **Cari Barang** and **Tambah Barang** actions.
- Camera permission denial is handled with retry/App Settings guidance.

## Android compatibility

- `minSdk 26` is unchanged, so Android 9 / API 28 remains supported.
- Version: `0.8.7-native-scanner` / versionCode `87`.

## Dependencies

- `androidx.activity:activity:1.9.3`
- `androidx.core:core:1.15.0`
- `androidx.camera:camera-core:1.4.2`
- `androidx.camera:camera-camera2:1.4.2`
- `androidx.camera:camera-lifecycle:1.4.2`
- `androidx.camera:camera-view:1.4.2`
- `com.google.mlkit:barcode-scanning:17.3.0` (bundled/on-device)

## Files added

- `app/src/main/java/com/revtorq/pos/NativeBarcodeScannerActivity.java`
- `app/src/main/java/com/revtorq/pos/NativeScannerBus.java`
- `js/native-barcode-bridge.js` and synchronized runtime copies
- `tests/native-scanner.test.cjs`

## Files changed

- `app/src/main/java/com/revtorq/pos/MainActivity.java`
- `app/src/main/AndroidManifest.xml`
- `app/build.gradle`
- synchronized `index.html` copies to load the bridge

No database migration is required.
