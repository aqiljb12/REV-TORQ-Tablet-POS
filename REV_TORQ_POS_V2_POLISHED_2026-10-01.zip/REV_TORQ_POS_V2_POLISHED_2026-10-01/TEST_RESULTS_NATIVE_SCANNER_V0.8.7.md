# Native Scanner v0.8.7 — Test Results

Date: 2026-09-22

## Automated checks run in this environment

- Node test suite: **31/31 PASS**
- Package/script verification: **PASS**
  - Local JavaScript compilation checks passed.
  - Local asset references passed.
  - Web target HTML copies remain synchronized.
- Java source syntax parse check: no Java syntax errors were detected before Android dependency resolution; missing Android/CameraX classes are expected without an Android SDK/classpath.

## Scanner checks covered by automated tests

- Android minSdk remains 26 (Android 9 / API 28 supported by project config).
- CameraX dependencies present.
- Bundled ML Kit barcode-scanning dependency present.
- `ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST` used.
- `InputImage.fromMediaImage()` used directly; no JPEG/Bitmap conversion path.
- Restricted formats: EAN-13, EAN-8, UPC-A, UPC-E, Code 128.
- Native duplicate/re-arm guard present.
- Manual barcode entry uses same bridge pipeline.
- Leading zeros preserved as strings.
- Exact barcode lookup path present.
- Existing `posAddToCart()` is reused.
- Unknown barcode does not mutate cart.
- Native scanner Activity is not exported.

## Not executable in this environment

A debug APK could not be assembled here because the runtime does not include an Android SDK or Gradle installation, and outbound dependency resolution is unavailable. No APK file is fabricated.

The Android project is prepared for Android Studio/Gradle sync. Physical validation is still required for:

- Real Android 9 tablet launch.
- Camera autofocus/tilt/small barcode performance.
- Torch hardware.
- Pinch zoom.
- Beep/vibration hardware.
- 10-item continuous multi-scan.
- Repeated scanner open/close and background/foreground.
- Offline ML Kit recognition after install.

No Supabase migration or database change is required for this scanner upgrade.
