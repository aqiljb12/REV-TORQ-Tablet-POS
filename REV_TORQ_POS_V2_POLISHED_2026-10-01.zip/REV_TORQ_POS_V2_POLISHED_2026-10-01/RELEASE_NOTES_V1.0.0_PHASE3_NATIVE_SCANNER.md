# REV TORQ POS Android 1.0.0 — Phase 3 + Native Scanner

This Android project merges the latest REV TORQ Phase 3 production POS web build with the native Android 9-compatible barcode scanner.

- POS web assets: Phase 3 final production build
- Customer PWA source retained at project root for deployment/reference
- Android wrapper: existing package com.revtorq.pos
- minSdk: 26 (Android 8+; Android 9/API 28 supported)
- Native scanner: CameraX + bundled Google ML Kit barcode scanning
- Scanner bridge reuses existing REV TORQ POS product lookup/cart logic
- Browser ZXing path remains only as non-native/web fallback
- No new database migration is required for the scanner
