from pathlib import Path
import re

css = Path(__file__).resolve().parents[1] / 'css' / 'rt-polish.css'
text = css.read_text(encoding='utf-8')

# Regression: on phone the inventory toolbar switches to flex-column.
# The iPad flex-basis values (220/260px) must be reset or they become vertical height.
mobile_blocks = re.findall(r'@media\s*\(max-width:640px\)\s*\{(.*?)\n\}', text, flags=re.S)
joined = '\n'.join(mobile_blocks)

assert re.search(r'#view-inventory\s+\.rt-inv-left>\.relative\s*\{[^}]*flex\s*:\s*0\s+0\s+auto', joined), \
    'phone search block must not keep fixed flex-basis'
assert re.search(r'#view-inventory\s+\.rt-inv-left>\.flex\s*\{[^}]*flex\s*:\s*0\s+0\s+auto', joined), \
    'phone scanner block must not keep fixed flex-basis'
assert re.search(r'#view-inventory\s+\.rt-inv-left>\.relative\s*\{[^}]*min-width\s*:\s*0', joined), \
    'phone search block must allow shrinking'

index = (Path(__file__).resolve().parents[1] / 'index.html').read_text(encoding='utf-8')
assert 'css/rt-polish.css?v=2.3.1-mobilefix' in index, 'cache-busting CSS version not bumped for phone fix'
