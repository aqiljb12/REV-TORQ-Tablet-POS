// ================= POS & TRANSACTIONS =================
        let posCart = [];
        let posPayMethod = 'CASH';
        let allProducts = [];

// Production hardening bridge: expose POS cart safely without changing legacy lexical state.
window.rtGetPosCart = () => posCart;
window.rtSetPosCart = (v) => { posCart = Array.isArray(v) ? v : []; renderCart(); };
window.rtRenderPosCart = renderCart;

        async function loadPOS() {
            if (typeof window.rtResetPosPage === 'function') window.rtResetPosPage();
            // V34.3: POS opens immediately and inventory loading is lightweight.
            // Avoid composite-index dependency for the initial POS screen.
            try {
                if (!window.db) throw new Error("Firebase belum tersedia.");
                allProducts = [];
                window.posProducts = [];

                let snap;
                try {
                    snap = await db.collection("inventory")
                        .orderBy("sku")
                        .limit(50)
                        .get();
                } catch (firstErr) {
                    console.warn("POS indexed query fallback:", firstErr);
                    snap = await db.collection("inventory").limit(50).get();
                }

                snap.forEach(doc => {
                    const d = doc.data() || {};
                    if (d.active === false) return;
                    allProducts.push({
                        ...d,
                        sku: String(d.sku || doc.id),
                        name: String(d.name || doc.id),
                        category: String(d.category || "Lain-lain"),
                        price: Number(d.sellPrice ?? d.price ?? 0),
                        cost: Number(d.cost || 0)
                    });
                });

                window.posProducts = allProducts.slice();
                renderPosGrid(allProducts);
            } catch (e) {
                console.error("Error loading POS inventory", e);
                window.posProducts = [];
                try { renderPosGrid([]); } catch (_) {}
                try {
                    showToast("POS dibuka, tetapi inventori belum dapat dimuat. Semak internet/Supabase.", "error");
                } catch (_) {}
            }
        }

        function posFilterProducts(query) {
            if (typeof window.rtResetPosPage === 'function') window.rtResetPosPage();
            const q = query.toLowerCase();
            const filtered = allProducts.filter(p => p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q) || String(p.barcode || '').toLowerCase().includes(q) || String(p.rackCode || '').toLowerCase().includes(q) || p.category.toLowerCase().includes(q));
            renderPosGrid(filtered);
        }

        function renderPosGrid(products) {
            // The enhanced POS UI is additive. Always route through it when available,
            // including calls from the original app.js lexical scope.
            if (typeof window.rtRenderEnhanced === 'function') {
                window.posProducts = (products || allProducts || []).slice();
                window.rtRenderEnhanced(products || window.posProducts);
                return;
            }
            const grid = document.getElementById('posProductGrid');
            if (!grid) return;
            let html = '';
            products.forEach(p => {
                const isLow = p.stock <= (p.minStock || 5);
                html += `
                    <div class="glass-panel p-4 rounded-xl border ${isLow ? 'border-red-900/50' : 'border-gray-800'} cursor-pointer hover:border-amber-500 transition-colors group flex flex-col" onclick="posAddToCart('${p.sku}', '${p.name.replace(/'/g, "\\'")}', ${p.sellPrice}, ${p.stock})">
                        <span class="text-[10px] text-gray-500 font-bold tracking-wider mb-1">${p.category}</span>
                        <h4 class="text-sm font-bold text-white leading-tight mb-2 flex-1 group-hover:text-amber-500 transition-colors">${p.name}</h4>
                        <div class="flex justify-between items-end mt-auto">
                            <span class="text-lg font-black text-amber-500 font-mono">RM ${Number(p.price ?? p.sellPrice ?? 0).toFixed(2)}</span>
                            <span class="text-xs font-mono font-bold px-2 py-1 rounded bg-gray-900 ${isLow ? 'text-red-400' : 'text-gray-400'}">Stok: ${p.stock}</span>
                        </div>
                    </div>
                `;
            });
            grid.innerHTML = html;
        }

        function posAddToCart(sku, name, price, maxStock) {
            const source = allProducts.find(i => String(i.sku) === String(sku)) || (window.posProducts || []).find(i => String(i.sku) === String(sku));
            const productId = source?.id || source?.productId || source?.product_id || null;
            if (source) {
                name = source.name;
                price = Number(source.price ?? source.sellPrice ?? 0);
                maxStock = Number(source.stock ?? 0);
            }
            if (Number(maxStock) <= 0) {
                showToast("Stok habis!", "error");
                return;
            }
            const exist = posCart.find(i => i.sku === sku);
            if (exist) {
                if(exist.qty >= Number(maxStock)) { showToast("Melebihi had stok!", "error"); return; }
                if (!exist.productId && productId) exist.productId = productId;
                exist.qty++;
            } else {
                posCart.push({ sku, name: name || sku, price: Number(price || 0), qty: 1, maxStock: Number(maxStock), discount: 0, productId });
            }
            rtLastAddedSku = sku;
            try { if (window.rtTrackProductUse) window.rtTrackProductUse(sku); } catch (_) {}
            renderCart();
            if (rtPosPromo) rtSchedulePromoRevalidate();
        }

        function posUpdateQty(sku, delta) {
            const item = posCart.find(i => i.sku === sku);
            if(!item) return;
            item.qty += delta;
            if(item.qty > item.maxStock) {
                item.qty = item.maxStock;
                showToast("Melebihi had stok!", "error");
            }
            if(item.qty <= 0) {
                posCart = posCart.filter(i => i.sku !== sku);
            }
            renderCart();
            if (rtPosPromo) rtSchedulePromoRevalidate();
        }

        function posSetItemDiscount(sku, value) {
            const item = posCart.find(i => i.sku === sku);
            if (!item) return;
            const model = window.RTPosDiscountModel;
            const normalized = model
                ? model.normalizeLineDiscount(value, item.qty, item.price)
                : Math.min(Math.max(0, Number(value || 0)), Math.max(0, Number(item.qty || 0) * Number(item.price || 0)));
            item.discount = Number(normalized || 0);
            renderCart();
            if (rtPosPromo) rtSchedulePromoRevalidate();
        }

        function posClearCart() {
            posCart = [];
            renderCart();
            if (rtPosPromo) rtSchedulePromoRevalidate();
        }

        // V2 polish: two-line cart rows sized for a tablet cart column. Same handlers
        // (posUpdateQty / posSetItemDiscount) and the same cart data as before.
        let rtLastAddedSku = null;
        function rtCartEsc(v) { return String(v ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
        function rtCartJs(v) { return rtCartEsc(String(v ?? '').replace(/\\/g, '\\\\').replace(/'/g, "\\'")); }
        function rtCartKind(item) {
            const type = String(item.itemType || '').toUpperCase();
            if (item.service || type === 'SERVICE') return /labour|upah|kerja/i.test(String(item.name || '')) ? 'LABOUR' : 'SERVIS';
            if (item.fromJobCard || type === 'PART') return 'PART';
            return '';
        }

        // Removing a line needs a second tap within 2.5s so a stray touch cannot drop an item.
        function rtCartArmRemove(btn, sku) {
            const item = posCart.find(i => String(i.sku) === String(sku));
            if (!item) return;
            if (btn && btn.classList.contains('armed')) { posUpdateQty(item.sku, -Number(item.qty || 1)); return; }
            if (!btn) return;
            document.querySelectorAll('#posCartList .armed').forEach(b => { b.classList.remove('armed'); if (b.dataset.label) b.innerHTML = b.dataset.label; });
            btn.dataset.label = btn.innerHTML;
            btn.classList.add('armed');
            btn.innerHTML = 'BUANG?';
            setTimeout(() => { if (btn.classList.contains('armed')) { btn.classList.remove('armed'); btn.innerHTML = btn.dataset.label || '×'; } }, 2500);
        }

        // Re-entrancy guard: replacing the list removes a focused discount input, whose
        // blur can fire `change` -> posSetItemDiscount -> renderCart while we are mid-render.
        let rtCartRendering = false, rtCartRenderAgain = false;
        function renderCart() {
            if (rtCartRendering) { rtCartRenderAgain = true; return; }
            rtCartRendering = true;
            try { rtRenderCartNow(); }
            finally {
                rtCartRendering = false;
                if (rtCartRenderAgain) { rtCartRenderAgain = false; renderCart(); }
            }
        }

        function rtRenderCartNow() {
            const list = document.getElementById('posCartList');
            const count = document.getElementById('rtCartCount');
            if (!list) return;
            // Let a pending discount edit commit before its input is replaced.
            const active = typeof document !== 'undefined' ? document.activeElement : null;
            if (active && typeof list.contains === 'function' && list.contains(active) && typeof active.blur === 'function') active.blur();
            if(count) count.textContent = posCart.reduce((n,i)=>n+Number(i.qty||0),0);
            if (posCart.length === 0) {
                list.innerHTML = '<div class="rt-cart-empty"><i data-feather="shopping-cart"></i><b>Troli kosong</b><span>Scan barcode atau tekan barang untuk mula jualan.</span></div>';
                rtLastAddedSku = null;
                posCalculateTotal();
                if (window.rtSyncCardBadges) window.rtSyncCardBadges();
                if(window.feather) feather.replace();
                return;
            }
            list.innerHTML = posCart.map((item) => {
                const model = window.RTPosDiscountModel;
                const gross = Number(item.qty||0) * Number(item.price||0);
                const disc = model
                    ? model.normalizeLineDiscount(item.discount, item.qty, item.price)
                    : Math.min(Math.max(0, Number(item.discount||0)), Math.max(0, gross));
                item.discount = Number(disc || 0);
                const total = Math.max(0, gross - item.discount);
                const sku = rtCartJs(item.sku);
                const name = rtCartEsc(item.name || item.sku);
                const kind = rtCartKind(item);
                const fromJob = !!item.fromJobCard || /^JOB(PART|SERVICE|LABOUR)-/.test(String(item.sku || ''));
                const ref = fromJob ? 'Job Card' : /^SERVICE-/.test(String(item.sku || '')) ? 'Caj kerja' : rtCartEsc(item.sku || '');
                const qty = Number(item.qty || 0);
                const flash = rtLastAddedSku != null && String(item.sku) === String(rtLastAddedSku) ? ' rt-row-flash' : '';
                const minus = qty > 1 ? `posUpdateQty('${sku}',-1)` : `rtCartArmRemove(this,'${sku}')`;
                return `<div class="rt-cart-row${flash}" data-sku="${rtCartEsc(item.sku)}">
                  <div class="rt-row-main">
                    <div class="item-title">${kind ? `<em class="rt-kind rt-kind-${kind.toLowerCase()}">${kind}</em>` : ''}${name}</div>
                    <div class="item-sub"><span>${ref}</span><span class="unit-price">@ ${formatMoney(item.price)}</span><label class="rt-row-disc${item.discount > 0 ? ' has-value' : ''}">Disk RM <input class="rt-item-discount" aria-label="Diskaun item ${name}" type="number" min="0" step="0.01" inputmode="decimal" value="${item.discount.toFixed(2)}" onchange="posSetItemDiscount('${sku}',this.value)"></label></div>
                  </div>
                  <div class="rt-qty"><button type="button" class="rt-qty-minus" aria-label="Kurang satu" onclick="${minus}">−</button><span>${qty}</span><button type="button" aria-label="Tambah satu" onclick="posUpdateQty('${sku}',1)">+</button></div>
                  <div class="rt-cart-total">${formatMoney(total)}${item.discount > 0 ? `<small>${formatMoney(gross)}</small>` : ''}</div>
                  <button type="button" class="rt-cart-remove" aria-label="Buang ${name}" onclick="rtCartArmRemove(this,'${sku}')">×</button>
                </div>`;
            }).join('');
            const flashRow = list.querySelector('.rt-row-flash');
            if (flashRow && typeof flashRow.scrollIntoView === 'function') { try { flashRow.scrollIntoView({ block: 'nearest' }); } catch (_) {} }
            rtLastAddedSku = null;
            posCalculateTotal();
            if (window.rtSyncCardBadges) window.rtSyncCardBadges();
            if(window.feather) feather.replace();
        }

        function posCalculateTotal() {
            const model = window.RTPosDiscountModel;
            const requestedOrderDiscount = parseFloat(document.getElementById('posDiscount')?.value) || 0;
            const totals = model
                ? model.cartTotals(posCart, requestedOrderDiscount)
                : (() => {
                    const grossSubtotal = posCart.reduce((sum,i)=>sum + Number(i.qty||0)*Number(i.price||0),0);
                    const itemDiscount = posCart.reduce((sum,i)=>sum + Math.min(Math.max(0,Number(i.discount||0)),Number(i.qty||0)*Number(i.price||0)),0);
                    const netBeforeOrderDiscount = Math.max(0,grossSubtotal-itemDiscount);
                    const orderDiscount = Math.min(Math.max(0,requestedOrderDiscount),netBeforeOrderDiscount);
                    return {grossSubtotal,itemDiscount,netBeforeOrderDiscount,orderDiscount,total:Math.max(0,netBeforeOrderDiscount-orderDiscount)};
                })();
            const promoDiscount = Math.min(Math.max(0, Number(rtPosPromo?.discount_amount || 0)), Math.max(0, Number(totals.netBeforeOrderDiscount || 0)));
            const chargeInput = Number(document.getElementById('rtOtherCharge')?.value || 0);
            const otherCharge = Number.isFinite(chargeInput) ? Math.max(0,Math.round(chargeInput*100)/100) : 0;
            const finalTotal = Math.round((Math.max(0, Number(totals.total || 0) - promoDiscount) + otherCharge)*100)/100;

            const subtotalEl = document.getElementById('posSubtotal');
            const itemDiscEl = document.getElementById('rtItemDiscountDisplay');
            const orderDiscEl = document.getElementById('rtDiscountDisplay');
            const totalEl = document.getElementById('posTotal');
            const chargeEl = document.getElementById('rtOtherChargeDisplay');
            if (subtotalEl) subtotalEl.innerText = formatMoney(totals.grossSubtotal);
            if (itemDiscEl) itemDiscEl.innerText = formatMoney(totals.itemDiscount);
            if (orderDiscEl) orderDiscEl.innerText = formatMoney(totals.orderDiscount);
            if (chargeEl) chargeEl.innerText = formatMoney(otherCharge);
            if (totalEl) totalEl.innerText = formatMoney(finalTotal);

            const received = parseFloat(document.getElementById('posAmountReceived')?.value) || 0;
            const change = received - finalTotal;
            const changeEl = document.getElementById('posChange');
            if (changeEl) {
                changeEl.innerText = formatMoney(change);
                changeEl.className = change >= 0 ? "font-mono text-green-400 font-bold" : "font-mono text-red-400 font-bold";
            }
            return {...totals,promoDiscount,total:finalTotal};
        }

        function posSetPaymentMethod(method) {
            posPayMethod = method;
            document.querySelectorAll('.pos-pay-btn').forEach(b => {
                b.classList.remove('bg-amber-500', 'text-gray-950', 'border-amber-500', 'font-bold');
                b.classList.add('bg-gray-800', 'text-white', 'border-gray-700');
            });
            const btn = document.getElementById('btnPay' + method);
            btn.classList.add('bg-amber-500', 'text-gray-950', 'border-amber-500', 'font-bold');
            btn.classList.remove('bg-gray-800', 'text-white', 'border-gray-700');
        }


        // ============================================================
        // REV TORQ V37 — LOYALTY → POS VOUCHER BRIDGE
        // Server-side validation/redeem via Supabase RPC.
        // Voucher discount replaces manual POS discount while applied.
        // ============================================================
        let rtPosVoucher = null;
        let rtPosManualDiscountBeforeVoucher = null;
        let rtPosPromo = null;
        let rtPosManualDiscountBeforePromo = null;
        let rtPosEligiblePromos = [];
        let rtPromoRevalidateTimer = null;

        function rtPosSelectedCustomerId() {
            const sel = document.getElementById('rtPosCustomerSelect');
            return sel && sel.value ? String(sel.value) : null;
        }


        // ============================================================
        // REV TORQ v1.0.5 — PHONE MEMBER / POINT BRIDGE
        // Phone identifies the customer record. POS may create a lightweight
        // member, but only the customer PWA can spend points to claim rewards.
        // ============================================================
        const rtPosMemberEsc = v => String(v ?? '').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));

        function rtPosMemberOption(member){
            const sel=document.getElementById('rtPosCustomerSelect');
            if(!sel||!member?.customer_id)return null;
            let opt=[...sel.options].find(o=>String(o.value)===String(member.customer_id));
            if(!opt){opt=document.createElement('option');opt.value=String(member.customer_id);sel.appendChild(opt)}
            opt.textContent=`${member.name||'Member'}${member.phone?' · '+member.phone:''}`;
            opt.dataset.name=member.name||'';opt.dataset.phone=member.phone||'';opt.dataset.docid=member.customer_id;
            sel.value=String(member.customer_id);
            sel.dispatchEvent(new Event('change',{bubbles:true}));
            return opt;
        }

        function rtPosRenderMemberSummary(summary){
            const info=document.getElementById('rtPosMemberInfo');
            const points=document.getElementById('rtPosMemberPoints');
            const list=document.getElementById('rtPosClaimedVoucherList');
            if(!summary){
                if(points)points.textContent='';
                if(info)info.textContent='Masukkan nombor telefon. Jika belum ada, POS akan daftar member asas dan sale ini boleh kumpul point.';
                if(list)list.innerHTML='';
                return;
            }
            if(points)points.textContent=`${Number(summary.points||0).toLocaleString()} POINT`;
            if(info)info.innerHTML=`<strong>${rtPosMemberEsc(summary.name||'Member')}</strong> · ${rtPosMemberEsc(summary.phone||'')}<br><span class="${summary.web_registered?'ok':'pending'}">${summary.web_registered?'✓ PWA sudah didaftarkan':'Belum daftar PWA · point tetap disimpan pada nombor ini'}</span>`;
            const vouchers=Array.isArray(summary.claimed_vouchers)?summary.claimed_vouchers:[];
            if(list){
                list.innerHTML=vouchers.length?vouchers.map(v=>{
                    const type=String(v.reward_type||'').toUpperCase();
                    const usable=type==='FIXED_DISCOUNT'||type==='PERCENT_DISCOUNT';
                    const value=type==='FIXED_DISCOUNT'?`RM ${Number(v.discount_value||0).toFixed(2)} OFF`:type==='PERCENT_DISCOUNT'?`${Number(v.discount_value||0)}% OFF`:'Reward servis';
                    return `<button type="button" class="rt-pos-member-voucher" ${usable?`onclick="window.rtPosUseClaimedVoucher?.('${rtPosMemberEsc(v.code)}')"`:'disabled'}><span><strong>${rtPosMemberEsc(v.reward_name||'Voucher')}</strong><small>${rtPosMemberEsc(v.code||'')} · ${rtPosMemberEsc(value)}${Number(v.minimum_spend||0)>0?` · Min RM ${Number(v.minimum_spend).toFixed(2)}`:''}</small></span><b>${usable?'GUNA':'STAFF'}</b></button>`;
                }).join(''):'<div class="text-[10px] font-bold text-slate-400">Tiada voucher yang sudah diclaim.</div>';
            }
        }

        async function rtPosLoadMemberSummary(customerId){
            if(!customerId||!window.supabaseRpc){rtPosRenderMemberSummary(null);return null}
            try{
                const data=await window.supabaseRpc('rt_pos_customer_member_summary',{p_customer_id:customerId});
                rtPosRenderMemberSummary(data||null);
                const phone=document.getElementById('rtPosMemberPhone');if(phone&&data?.phone)phone.value=data.phone;
                return data;
            }catch(e){
                rtPosRenderMemberSummary(null);
                const info=document.getElementById('rtPosMemberInfo');if(info)info.textContent='Gagal baca member: '+(e?.message||String(e));
                return null;
            }
        }

        async function rtPosFindOrCreateMember(){
            const input=document.getElementById('rtPosMemberPhone');
            const btn=document.getElementById('rtPosMemberFind');
            const phone=String(input?.value||'').trim();
            if(!phone)return showToast('Masukkan nombor telefon customer.','error');
            if(!window.supabaseRpc)return showToast('Supabase RPC belum tersedia.','error');
            if(btn){btn.disabled=true;btn.textContent='SEMAK...'}
            try{
                const raw=await window.supabaseRpc('rt_pos_find_or_create_customer',{p_phone:phone,p_name:null});
                const member=Array.isArray(raw)?raw[0]:raw;
                if(!member?.customer_id)throw new Error('Customer tidak dapat dibuat/dijumpai.');
                rtPosMemberOption(member);
                const summary=await rtPosLoadMemberSummary(member.customer_id);
                showToast(member.created_now?'Member baru didaftarkan. Point akan masuk selepas bayaran.':'Member dijumpai.','success');
                return summary||member;
            }catch(e){
                const msg=String(e?.message||e||'');
                const friendly=msg.includes('DUPLICATE_PHONE_NEEDS_ADMIN')?'Nombor ini ada lebih daripada satu rekod customer. Admin perlu gabungkan rekod dahulu.':msg.includes('VALID_PHONE_REQUIRED')?'Nombor telefon tidak sah.':msg;
                const info=document.getElementById('rtPosMemberInfo');if(info)info.textContent=friendly;
                showToast(friendly||'Gagal daftar member.','error');
                return null;
            }finally{if(btn){btn.disabled=false;btn.textContent='CARI / DAFTAR'}}
        }

        function rtPosClearMember(clearPhone=true){
            const sel=document.getElementById('rtPosCustomerSelect');if(sel)sel.value='';
            if(clearPhone){const phone=document.getElementById('rtPosMemberPhone');if(phone)phone.value=''}
            if(rtPosVoucher)rtPosRemoveVoucher();
            rtPosRenderMemberSummary(null);
            if(rtPosPromo)rtSchedulePromoRevalidate();
        }

        async function rtPosUseClaimedVoucher(code){
            const input=document.getElementById('rtPosVoucherCode');if(input)input.value=String(code||'');
            return rtPosValidateVoucher(true);
        }

        function rtPosSetVoucherMessage(text, ok=false) {
            const el = document.getElementById('rtPosVoucherMessage');
            if (!el) return;
            el.textContent = text || '';
            el.className = ok
                ? 'text-[10px] font-bold text-emerald-600 mt-1'
                : 'text-[10px] font-bold text-slate-500 mt-1';
        }

        function rtPosUpdateVoucherUI() {
            const code = document.getElementById('rtPosVoucherCode');
            const apply = document.getElementById('rtPosVoucherApply');
            const remove = document.getElementById('rtPosVoucherRemove');
            const disc = document.getElementById('posDiscount');
            const badge = document.getElementById('rtPosVoucherBadge');
            if (code) code.value = rtPosVoucher?.code || code.value || '';
            if (apply) apply.classList.toggle('hidden', !!rtPosVoucher);
            if (remove) remove.classList.toggle('hidden', !rtPosVoucher);
            if (disc) {
                disc.readOnly = !!rtPosVoucher;
                disc.classList.toggle('bg-emerald-50', !!rtPosVoucher);
            }
            if (badge) badge.textContent = rtPosVoucher
                ? `${rtPosVoucher.reward_name || 'Voucher'} · -RM ${Number(rtPosVoucher.discount_applied||0).toFixed(2)}`
                : '';
            posCalculateTotal();
        }

        async function rtPosValidateVoucher(showToastOnError=true) {
            if (rtPosPromo) rtPosRemovePromo(false);
            const codeEl = document.getElementById('rtPosVoucherCode');
            const code = String(codeEl?.value || '').trim();
            const customerId = rtPosSelectedCustomerId();
            if (!code) {
                if (showToastOnError) showToast('Masukkan kod voucher.', 'error');
                return null;
            }
            if (!customerId) {
                if (showToastOnError) showToast('Pilih customer dahulu. Voucher loyalty bukan untuk walk-in.', 'error');
                rtPosSetVoucherMessage('Pilih customer dahulu.');
                return null;
            }
            if (!window.supabaseRpc) {
                if (showToastOnError) showToast('Supabase RPC belum tersedia.', 'error');
                return null;
            }

            try {
                const result = await window.supabaseRpc('rt_validate_loyalty_voucher', {
                    p_code: code,
                    p_customer_id: customerId
                });
                if (!result?.valid) {
                    const reasons = {
                        NOT_FOUND:'Voucher tidak dijumpai.',
                        CUSTOMER_MISMATCH:'Voucher bukan milik customer ini.',
                        EXPIRED:'Voucher sudah tamat tempoh.',
                        REDEEMED:'Voucher sudah digunakan.'
                    };
                    throw new Error(reasons[result?.reason] || `Voucher tidak sah (${result?.reason || 'UNKNOWN'}).`);
                }

                const voucherCart = window.rtGetPosCart ? window.rtGetPosCart() : [];
                const voucherTotals = window.RTPosDiscountModel
                    ? window.RTPosDiscountModel.cartTotals(voucherCart, 0)
                    : {grossSubtotal:voucherCart.reduce((sum,i)=>sum+Number(i.qty||0)*Number(i.price||0),0), netBeforeOrderDiscount:voucherCart.reduce((sum,i)=>sum+Number(i.qty||0)*Number(i.price||0),0)};
                const subtotal = Number(voucherTotals.grossSubtotal || 0);
                const discountBase = Number(voucherTotals.netBeforeOrderDiscount || subtotal);

                if (subtotal < Number(result.minimum_spend || 0)) {
                    throw new Error(`Minimum belian voucher RM ${Number(result.minimum_spend||0).toFixed(2)}.`);
                }

                let allowed = 0;
                if (String(result.reward_type).toUpperCase() === 'PERCENT_DISCOUNT') {
                    allowed = subtotal * (Number(result.discount_value||0) / 100);
                    if (result.max_discount != null) allowed = Math.min(allowed, Number(result.max_discount));
                } else if (String(result.reward_type).toUpperCase() === 'FIXED_DISCOUNT') {
                    allowed = Math.min(Number(result.discount_value||0), discountBase);
                }

                allowed = Math.min(allowed, discountBase);

                if (allowed <= 0) {
                    throw new Error('Voucher ini tidak mempunyai nilai diskaun untuk order ini.');
                }

                rtPosManualDiscountBeforeVoucher = document.getElementById('posDiscount')?.value || '0';
                rtPosVoucher = {
                    code,
                    voucher_id: result.voucher_id,
                    customer_id: result.customer_id,
                    reward_name: result.reward_name,
                    reward_type: result.reward_type,
                    discount_applied: Number(allowed.toFixed(2)),
                    expires_at: result.expires_at
                };
                const disc = document.getElementById('posDiscount');
                if (disc) disc.value = rtPosVoucher.discount_applied.toFixed(2);
                rtPosSetVoucherMessage(`✓ ${result.reward_name || 'Voucher sah'} · Diskaun RM ${rtPosVoucher.discount_applied.toFixed(2)}`, true);
                rtPosUpdateVoucherUI();
                showToast('Voucher berjaya digunakan.', 'success');
                return rtPosVoucher;
            } catch (e) {
                rtPosVoucher = null;
                rtPosUpdateVoucherUI();
                rtPosSetVoucherMessage(e.message || 'Voucher tidak sah.');
                if (showToastOnError) showToast(e.message || 'Voucher tidak sah.', 'error');
                return null;
            }
        }

        function rtPosRemoveVoucher() {
            rtPosVoucher = null;
            const disc = document.getElementById('posDiscount');
            if (disc) {
                disc.value = rtPosManualDiscountBeforeVoucher ?? '0';
                disc.readOnly = false;
                disc.classList.remove('bg-emerald-50');
            }
            rtPosManualDiscountBeforeVoucher = null;
            const code = document.getElementById('rtPosVoucherCode');
            if (code) code.value = '';
            rtPosSetVoucherMessage('');
            rtPosUpdateVoucherUI();
        }

        // ============================================================
        // REV TORQ v1.0.4 — UNIFIED POS PROMO BRIDGE
        // Server returns eligibility + authoritative discount. Browser never
        // decides final promo discount and never writes promo_redemptions.
        // ============================================================
        function rtPosPromoSubtotal() {
            const cart = window.rtGetPosCart ? window.rtGetPosCart() : posCart;
            if (window.RTPosDiscountModel) return Number(window.RTPosDiscountModel.cartTotals(cart, 0).netBeforeOrderDiscount || 0);
            return cart.reduce((sum,i)=>sum+Math.max(0,Number(i.qty||0)*Number(i.price||0)-Math.max(0,Number(i.discount||0))),0);
        }
        function rtPosSetPromoMessage(text,ok=false){const el=document.getElementById('rtPosPromoMessage');if(!el)return;el.textContent=text||'';el.className=ok?'text-[10px] font-bold text-emerald-600 mt-1':'text-[10px] font-bold text-slate-500 mt-1'}
        function rtPosSyncPromoUI(){
            const badge=document.getElementById('rtPosPromoBadge'),remove=document.getElementById('rtPosPromoRemove'),disc=document.getElementById('posDiscount'),code=document.getElementById('rtPosPromoCode');
            if(badge)badge.textContent=rtPosPromo?`${rtPosPromo.name} · -RM ${Number(rtPosPromo.discount_amount||0).toFixed(2)}`:'';
            if(remove)remove.classList.toggle('hidden',!rtPosPromo);
            if(code&&rtPosPromo)code.value=rtPosPromo.promo_code||'';
            if(disc){disc.disabled=!!rtPosPromo;disc.classList.toggle('bg-rose-50',!!rtPosPromo);if(rtPosPromo)disc.value='0';}
            posCalculateTotal();
        }
        async function rtValidatePromoRequest({promotionId=null,code=null,showToastOnError=true}={}){
            try{
                if(!window.supabaseRpc)throw new Error('Supabase RPC belum tersedia.');
                const result=await window.supabaseRpc('rt_validate_promo',{p_promotion_id:promotionId,p_code:code,p_customer_id:rtPosSelectedCustomerId(),p_subtotal:rtPosPromoSubtotal()});
                if(!result?.eligible){const reasons={PROMO_NOT_FOUND:'Promo tidak dijumpai.',PROMO_NOT_PUBLISHED:'Promo belum dipublish.',PROMO_NOT_ACTIVE:'Promo tidak aktif.',PROMO_NOT_STARTED:'Promo belum bermula.',PROMO_EXPIRED:'Promo sudah tamat.',PROMO_USAGE_LIMIT_REACHED:'Promo sudah habis digunakan.',PROMO_CUSTOMER_REQUIRED:'Promo ini perlukan customer.',PROMO_CUSTOMER_LIMIT_REACHED:'Customer ini sudah capai had promo.',PROMO_MINIMUM_SPEND_NOT_MET:`Minimum belian promo RM ${Number(result?.minimum_spend||0).toFixed(2)}.`,PROMO_BIRTHDAY_ONLY:'Promo ini khas birthday customer.',PROMO_FIRST_VISIT_ONLY:'Promo ini khas lawatan pertama.'};throw new Error(reasons[result?.reason]||`Promo tidak layak (${result?.reason||'UNKNOWN'}).`)}
                return result;
            }catch(e){if(showToastOnError)showToast(e.message||'Promo tidak sah.','error');rtPosSetPromoMessage(e.message||'Promo tidak sah.');return null}
        }
        async function rtApplyPromoRecord(record){
            const promo=window.RTPosPromoModel?.normalizePromo(record)||record;if(!promo?.promotion_id)return null;
            if(rtPosVoucher)rtPosRemoveVoucher();
            if(rtPosManualDiscountBeforePromo==null)rtPosManualDiscountBeforePromo=document.getElementById('posDiscount')?.value||'0';
            rtPosPromo=promo;window.rtPosPromo=rtPosPromo;
            const list=document.getElementById('rtPosPromoList');if(list)list.classList.add('hidden');
            rtPosSetPromoMessage(`✓ ${promo.name} · Diskaun RM ${Number(promo.discount_amount||0).toFixed(2)} · ${window.RTPosPromoModel?.usageText(promo)||''}`,true);
            rtPosSyncPromoUI();showToast('Promo berjaya digunakan.','success');return promo;
        }
        async function rtApplyPromoById(id){const result=await rtValidatePromoRequest({promotionId:id});if(result)return rtApplyPromoRecord(result);return null}
        async function rtApplyPromoCode(){const code=String(document.getElementById('rtPosPromoCode')?.value||'').trim();if(!code)return showToast('Masukkan kod promo.','error');const result=await rtValidatePromoRequest({code});if(result)return rtApplyPromoRecord(result);return null}
        async function rtLoadEligiblePromos(){
            try{
                const rows=await window.supabaseRpc('rt_pos_available_promotions',{p_customer_id:rtPosSelectedCustomerId(),p_subtotal:rtPosPromoSubtotal()});
                rtPosEligiblePromos=(Array.isArray(rows)?rows:[]).map(r=>r?.promotion||r).filter(Boolean);
                const list=document.getElementById('rtPosPromoList');if(!list)return rtPosEligiblePromos;
                list.innerHTML=rtPosEligiblePromos.length?rtPosEligiblePromos.map(p=>{const x=window.RTPosPromoModel?.normalizePromo(p)||p;const use=window.RTPosPromoModel?.usageText(x)||'';const label=window.RTPosPromoModel?.discountLabel(x)||'';return `<button type="button" class="rt-pos-promo-option" onclick="window.rtApplyPromoById?.('${String(x.promotion_id)}')"><span><strong>${String(x.name||'Promo')}</strong><small>${String(x.promo_code||'')} · ${label} · Min RM ${Number(x.minimum_spend||0).toFixed(2)}</small><small>${use}</small></span><b>-RM ${Number(x.discount_amount||0).toFixed(2)}</b></button>`}).join(''):'<div class="text-[10px] text-slate-500">Tiada promo yang layak untuk cart/customer ini.</div>';
                list.classList.remove('hidden');return rtPosEligiblePromos;
            }catch(e){showToast(e.message||'Gagal load promo.','error');return []}
        }
        function rtPosRemovePromo(restoreManual=true){
            rtPosPromo=null;window.rtPosPromo=null;clearTimeout(rtPromoRevalidateTimer);
            const disc=document.getElementById('posDiscount');if(disc){disc.disabled=false;disc.classList.remove('bg-rose-50');if(restoreManual)disc.value=rtPosManualDiscountBeforePromo??'0'}
            rtPosManualDiscountBeforePromo=null;const code=document.getElementById('rtPosPromoCode');if(code)code.value='';rtPosSetPromoMessage('');rtPosSyncPromoUI();
        }
        async function rtRevalidateActivePromo(){if(!rtPosPromo)return null;const result=await rtValidatePromoRequest({promotionId:rtPosPromo.promotion_id,showToastOnError:false});if(!result){const name=rtPosPromo.name;rtPosRemovePromo(false);showToast(`Promo ${name} tidak lagi layak untuk cart ini.`,'error');return null}rtPosPromo=window.RTPosPromoModel?.normalizePromo(result)||result;window.rtPosPromo=rtPosPromo;rtPosSyncPromoUI();return rtPosPromo}
        function rtSchedulePromoRevalidate(){if(!rtPosPromo)return;clearTimeout(rtPromoRevalidateTimer);rtPromoRevalidateTimer=setTimeout(()=>rtRevalidateActivePromo().catch(()=>{}),450)}
        document.addEventListener('change',e=>{if(e.target?.id!=='rtPosCustomerSelect')return;const id=rtPosSelectedCustomerId();if(rtPosVoucher&&String(rtPosVoucher.customer_id)!==String(id||''))rtPosRemoveVoucher();if(id)rtPosLoadMemberSummary(id);else rtPosRenderMemberSummary(null);if(rtPosPromo)rtSchedulePromoRevalidate()});

        async function rtPosRedeemVoucher(invoiceId, discountApplied) {
            if (!rtPosVoucher) return null;
            if (!invoiceId) throw new Error('Invoice ID untuk redeem voucher tidak dijumpai.');
            return await window.supabaseRpc('rt_redeem_loyalty_voucher', {
                p_code: rtPosVoucher.code,
                p_invoice_id: invoiceId,
                p_discount_applied: Number(discountApplied || 0)
            });
        }

        async function rtPosRollbackFirestoreSale(invNo) {
            if (!invNo) throw new Error('Nombor invois untuk rollback tidak dijumpai.');
            const invRef = db.collection("invoices").doc(invNo);
            const snap = await invRef.get();
            if (!snap.exists) return;
            const inv = snap.data() || {};
            const items = Array.isArray(inv.items) ? inv.items : [];

            await db.runTransaction(async (transaction) => {
                const refs = [];
                for (const item of items) {
                    const ref = await resolveInventoryRefBySku(item.sku);
                    const doc = await transaction.get(ref);
                    if (!doc.exists) throw new Error(`Rollback gagal: SKU ${item.sku} tidak wujud.`);
                    refs.push({ref,doc,item});
                }

                refs.forEach(({ref,doc,item}) => {
                    const before = Number(doc.data().stock || 0);
                    const qty = Number(item.qty || item.quantity || 0);
                    const after = before + qty;
                    transaction.update(ref, {stock: after});
                    const ledgerRef = db.collection('stock_ledger').doc();
                    transaction.set(ledgerRef, {
                        sku: item.sku,
                        itemName: item.name,
                        activity: 'SALE_ROLLBACK',
                        quantity: qty,
                        beforeStock: before,
                        afterStock: after,
                        referenceType: 'INVOICE_ROLLBACK',
                        referenceId: invNo,
                        staffId: currentProfile.staffId,
                        staffName: currentProfile.name,
                        reason: 'Loyalty voucher redemption failed',
                        timestamp: new Date().toISOString()
                    });
                });

                transaction.delete(invRef);
            });
        }

        async function posCheckout() {
            if (posCart.length === 0) { showToast("Troli kosong!", "error"); return; }

            // Loyalty voucher must be revalidated against the current customer/cart
            // immediately before checkout so staff cannot redeem a stale/foreign code.
            if (rtPosVoucher) {
                const currentCustomer = rtPosSelectedCustomerId();
                if (!currentCustomer || currentCustomer !== String(rtPosVoucher.customer_id)) {
                    rtPosRemoveVoucher();
                    showToast("Customer berubah. Sila semak semula voucher.", "error");
                    return;
                }
                const rechecked = await rtPosValidateVoucher(false);
                if (!rechecked) return;
            }

            const checkoutTotals = window.RTPosDiscountModel
                ? window.RTPosDiscountModel.cartTotals(posCart, parseFloat(document.getElementById('posDiscount').value) || 0)
                : posCalculateTotal();
            const sub = Number(checkoutTotals.grossSubtotal || 0);
            const disc = Number(checkoutTotals.orderDiscount || 0);
            const total = Number(checkoutTotals.total || 0);
            let received = parseFloat(document.getElementById('posAmountReceived').value) || 0;
            // Non-cash methods are paid in full; the received amount is the actual amount paid.
            if (posPayMethod !== 'CASH') received = total;

            if (posPayMethod === 'CASH' && received < total) {
                showToast("Jumlah diterima tidak mencukupi!", "error"); return;
            }

            const btn = document.getElementById('btnCheckout');
            const origHtml = btn.innerHTML;
            btn.innerHTML = `<div class="loader mr-2"></div> Memproses...`;
            btn.disabled = true;

            const invNo = "INV" + new Date().getTime().toString().slice(-8);

            try {
                // FIRESTORE TRANSACTION FOR STOCK SAFETY
                await db.runTransaction(async (transaction) => {
                    // 1. Read all required stock docs
                    const docRefs = [];
                    for (let item of posCart) {
                        // Resolve legacy records whose Firestore document ID differs from SKU.
                        const ref = await resolveInventoryRefBySku(item.sku);
                        const doc = await transaction.get(ref);
                        if (!doc.exists) throw new Error(`SKU ${item.sku} tidak wujud dalam pangkalan data.`);
                        docRefs.push({ ref, doc, item });
                    }

                    // 2. Validate stock for all
                    docRefs.forEach(({doc, item}) => {
                        const currentStock = doc.data().stock || 0;
                        if (currentStock < item.qty) {
                            throw new Error(`Stok tidak mencukupi untuk ${item.name}. (Ada: ${currentStock}, Nak: ${item.qty})`);
                        }
                    });

                    // 3. Write updates and ledger
                    docRefs.forEach(({ref, doc, item}) => {
                        const currentStock = doc.data().stock || 0;
                        const newStock = currentStock - item.qty;
                        
                        transaction.update(ref, { stock: newStock });

                        const ledgerRef = db.collection('stock_ledger').doc();
                        transaction.set(ledgerRef, {
                            sku: item.sku,
                            itemName: item.name,
                            activity: 'SALE',
                            quantity: -item.qty,
                            beforeStock: currentStock,
                            afterStock: newStock,
                            referenceType: 'INVOICE',
                            referenceId: invNo,
                            staffId: currentProfile.staffId,
                            staffName: currentProfile.name,
                            timestamp: new Date().toISOString()
                        });
                    });

                    // 4. Create Invoice
                    const invRef = db.collection("invoices").doc(invNo);
                    const customerSelect = document.getElementById('rtPosCustomerSelect');
                    const customerOption = customerSelect && customerSelect.value
                        ? customerSelect.options[customerSelect.selectedIndex] : null;
                    const saleCustomer = customerOption ? {
                        customerId: customerSelect.value,
                        customerDocId: customerOption.dataset.docid || null,
                        customerName: customerOption.dataset.name || '',
                        customerPhone: customerOption.dataset.phone || ''
                    } : {
                        customerId: null, customerDocId: null, customerName: 'Walk-in', customerPhone: ''
                    };
                    transaction.set(invRef, {
                        invoiceNo: invNo,
                        customerId: saleCustomer.customerId,
                        customerDocId: saleCustomer.customerDocId,
                        customerName: saleCustomer.customerName,
                        customerPhone: saleCustomer.customerPhone,
                        items: posCart,
                        subtotal: sub,
                        discount: disc,
                        total: total,
                        paymentMethod: posPayMethod,
                        amountPaid: received,
                        balance: Math.max(0, received - total),
                        status: 'PAID',
                        createdAt: new Date().toISOString(),
                        createdBy: currentProfile.staffId
                    });
                });

                await logAudit('CREATE_INVOICE', `Processed POS sale: ${invNo} (Total: ${total})`);
                
                const savedInvoice = await db.collection("invoices").doc(invNo).get();
                if (!savedInvoice.exists) throw new Error("Invois berjaya disimpan tetapi tidak dapat dibaca semula.");

                // Redeem only after the paid invoice exists. The database RPC verifies
                // customer, company, expiry, minimum spend and allowed discount again.
                if (rtPosVoucher) {
                    try {
                        await rtPosRedeemVoucher(savedInvoice.ref.id, disc);
                        await logAudit('REDEEM_LOYALTY_VOUCHER', `Voucher ${rtPosVoucher.code} redeemed on ${invNo}`);
                    } catch (voucherErr) {
                        console.error('LOYALTY VOUCHER REDEEM:', voucherErr);
                        try {
                            await rtPosRollbackFirestoreSale(invNo);
                            await logAudit('ROLLBACK_INVOICE', `Rolled back ${invNo}: loyalty voucher redemption failed`);
                            rtPosRemoveVoucher();
                            throw new Error(`Voucher gagal ditebus. Invois ${invNo} telah dibatalkan dan stok dipulihkan. Sila cuba semula tanpa voucher atau semak konfigurasi voucher.`);
                        } catch (rollbackErr) {
                            if (String(rollbackErr.message||'').startsWith('Voucher gagal ditebus.')) throw rollbackErr;
                            throw new Error(`CRITICAL: Voucher gagal ditebus DAN rollback invois gagal. Jangan ulang transaksi ${invNo}; semak POS/Firestore segera. ${rollbackErr.message}`);
                        }
                    }
                }

                showToast(`Invois ${invNo} berjaya dicetak.`);
                const saved = savedInvoice.data();
                await generateReceiptFromInvoice({...saved, voucherCode: rtPosVoucher?.code || null});
                
                // Reset UI
                posClearCart();
                document.getElementById('posDiscount').value = "0";
                document.getElementById('posAmountReceived').value = "";
                const posCustomer = document.getElementById('rtPosCustomerSelect');
                if (posCustomer) posCustomer.value = "";
                rtPosVoucher = null;
                rtPosManualDiscountBeforeVoucher = null;
                rtPosUpdateVoucherUI();
                rtPosSetVoucherMessage('');
                loadPOS(); // reload products to reflect new stock

            } catch (e) {
                showToast(`Gagal: ${e.message}`, 'error');
            } finally {
                btn.innerHTML = origHtml;
                btn.disabled = false;
            }
        }

        async function generateReceiptFromInvoice(inv) {
            let shop = window.rtWorkshopProfile || {};
            try {
                if (window.db && typeof db.collection === 'function') {
                    const snap = await db.collection('settings').doc('workshop').get();
                    if (snap && snap.exists) {
                        shop = {...shop, ...(snap.data() || {})};
                        window.rtWorkshopProfile = shop;
                    }
                }
            } catch (e) { console.warn('Receipt shop profile load failed', e); }

            const items = Array.isArray(inv.items) ? inv.items : [];
            const normalizedItems = items.map(i => ({...i, price:Number(i.price ?? i.unitPrice ?? i.sellPrice ?? 0), qty:Number(i.qty ?? i.quantity ?? 0), discount:Number(i.discount || 0)}));
            const isOtherCharge = i => String(i.itemType||'').toUpperCase()==='OTHER' && String(i.name||'').trim().toUpperCase()==='CAJ LAIN';
            const saleItems = normalizedItems.filter(i => !isOtherCharge(i));
            const otherCharge = Math.round(normalizedItems.filter(isOtherCharge).reduce((sum,i)=>sum+Math.max(0,Number(i.lineTotal ?? (i.qty*i.price-i.discount))),0)*100)/100;
            const receiptSummary = window.RTPosDiscountModel
                ? window.RTPosDiscountModel.receiptDiscountSummary({items:saleItems, orderDiscount:Number(inv.orderDiscount ?? inv.discount ?? 0), total:inv.total})
                : {grossSubtotal:Math.max(0,Number(inv.subtotal||0)-otherCharge),itemDiscount:0,orderDiscount:Number(inv.discount||0),totalDiscount:Number(inv.discount||0),total:Number(inv.total||0)};
            const sub = Number(receiptSummary.grossSubtotal || 0);
            const itemDisc = Number(receiptSummary.itemDiscount || 0);
            const promotion = inv.promotion || (inv.promoCode || inv.promoName ? {code:inv.promoCode||'',name:inv.promoName||'Promo REV TORQ',discount:Number(inv.promoDiscount||0)} : null);
            const promoDiscount = Math.max(0, Number(promotion?.discount ?? inv.promoDiscount ?? 0));
            const promoCode = String(promotion?.code || inv.promoCode || '');
            const promoName = String(promotion?.name || inv.promoName || 'Promo REV TORQ');
            const voucherCode = String(inv.voucherCode || '');
            const voucherName = String(inv.voucherName || 'Loyalty Voucher');
            const voucherDiscount = voucherCode ? Math.max(0, Number(inv.discount ?? receiptSummary.orderDiscount ?? 0)) : 0;
            const disc = (promotion || voucherCode) ? 0 : Number(receiptSummary.orderDiscount || 0);
            const totalDisc = itemDisc + disc + promoDiscount + voucherDiscount;
            const total = Number(receiptSummary.total || 0);
            const method = String(inv.paymentMethod || inv.method || 'CASH').toUpperCase();
            const received = method==='CASH' ? Number(inv.amountPaid ?? inv.amountReceived ?? inv.paid ?? total) : total;
            const balance = method==='CASH' ? Math.max(0, Number(inv.change ?? inv.balance ?? (received - total))) : 0;
            const invNo = inv.invoiceNo || inv.invNo || inv.id || '-';
            const rtReceiptDate = (value) => {
                try {
                    if (!value) return new Date();
                    if (value instanceof Date && !Number.isNaN(value.getTime())) return value;
                    if (typeof value?.toDate === 'function') {
                        const d = value.toDate();
                        if (d instanceof Date && !Number.isNaN(d.getTime())) return d;
                    }
                    if (typeof value === 'object' && Number.isFinite(Number(value.seconds))) {
                        const d = new Date(Number(value.seconds) * 1000);
                        if (!Number.isNaN(d.getTime())) return d;
                    }
                    const d = new Date(value);
                    return Number.isNaN(d.getTime()) ? new Date() : d;
                } catch (_) { return new Date(); }
            };
            const created = rtReceiptDate(inv.createdAt || inv.created_at);

            let itemHtml = '';
            saleItems.forEach(i => {
                const price = Number(i.price || 0);
                const qty = Number(i.qty || 0);
                const gross = price * qty;
                const lineDiscount = window.RTPosDiscountModel
                    ? window.RTPosDiscountModel.normalizeLineDiscount(i.discount, qty, price)
                    : Math.min(Math.max(0,Number(i.discount||0)),Math.max(0,gross));
                const lineTotal = Math.max(0,gross-lineDiscount);
                itemHtml += `<div class="mt-1">
                    <div class="flex justify-between">
                        <div class="flex-1 truncate pr-2">${i.name || i.itemName || i.sku || '-'}</div>
                        <div class="w-8 text-right">${qty}</div>
                        <div class="w-16 text-right">${lineTotal.toFixed(2)}</div>
                    </div>
                    ${lineDiscount > 0 ? `<div class="text-[9px] text-right">Diskaun item: -RM ${lineDiscount.toFixed(2)} (asal RM ${gross.toFixed(2)})</div>` : ''}
                </div>`;
            });

            const html = `
                <div class="text-center border-b border-black pb-2 mb-2 font-bold uppercase text-lg">${shop.workshopName || 'REV TORQ WORKSHOP'}</div>
                 <div class="text-center text-[10px] mb-4 border-b border-black pb-2">
                     ${(shop.address || '').replace(/</g,'&lt;').replace(/>/g,'&gt;').split(String.fromCharCode(10)).join('<br>') || 'Alamat bengkel belum ditetapkan'}<br>
                     Tel: ${shop.phone || '-'}<br>
                     SSM / No. Pendaftaran: ${shop.regNo || '-'}
                 </div>
                <div class="mb-2 text-[10px]">
                    <div>No: ${invNo}</div>
                    <div>Tarikh: ${created.toLocaleString('ms-MY')}</div>
                    <div>Juruwang: ${inv.createdBy || currentProfile.staffId}</div>
                </div>
                <div class="border-t border-b border-black py-1 font-bold flex justify-between uppercase">
                    <div class="flex-1">Item</div><div class="w-8 text-right">Qty</div><div class="w-16 text-right">Total</div>
                </div>
                <div class="py-2 border-b border-black">${itemHtml}</div>
                <div class="mt-2 text-right">
                    <div class="flex justify-end"><span class="w-28 inline-block">Subtotal asal:</span><span class="w-16 inline-block">RM ${sub.toFixed(2)}</span></div>
                    ${itemDisc > 0 ? `<div class="flex justify-end"><span class="w-28 inline-block">Diskaun item:</span><span class="w-16 inline-block">-RM ${itemDisc.toFixed(2)}</span></div>` : ''}
                    ${promoDiscount > 0 ? `<div class="flex justify-end"><span class="w-28 inline-block">Promo ${promoName}${promoCode?` (${promoCode})`:''}:</span><span class="w-16 inline-block">-RM ${promoDiscount.toFixed(2)}</span></div>` : ''}
                    ${voucherDiscount > 0 ? `<div class="flex justify-end"><span class="w-28 inline-block">Voucher ${voucherName}${voucherCode?` (${voucherCode})`:''}:</span><span class="w-16 inline-block">-RM ${voucherDiscount.toFixed(2)}</span></div>` : ''}
                    ${disc > 0 ? `<div class="flex justify-end"><span class="w-28 inline-block">Diskaun keseluruhan:</span><span class="w-16 inline-block">-RM ${disc.toFixed(2)}</span></div>` : ''}
                    ${totalDisc > 0 ? `<div class="flex justify-end font-bold"><span class="w-28 inline-block">Jumlah diskaun:</span><span class="w-16 inline-block">RM ${totalDisc.toFixed(2)}</span></div>` : ''}
                    ${otherCharge > 0 ? `<div class="flex justify-end"><span class="w-28 inline-block">Caj lain:</span><span class="w-16 inline-block">RM ${otherCharge.toFixed(2)}</span></div>` : ''}
                    <div class="flex justify-end font-bold text-sm mt-1"><span class="w-28 inline-block">JUMLAH:</span><span class="w-16 inline-block border-t border-black">RM ${total.toFixed(2)}</span></div>
                </div>
                <div class="mt-2 border-t border-black pt-1">
                    <div class="flex justify-end"><span class="w-20 inline-block">Kaedah:</span><span class="w-16 inline-block font-bold">${method}</span></div>
                    <div class="flex justify-end"><span class="w-20 inline-block">Dibayar:</span><span class="w-16 inline-block">RM ${received.toFixed(2)}</span></div>
                    <div class="flex justify-end"><span class="w-20 inline-block">Baki:</span><span class="w-16 inline-block">RM ${balance.toFixed(2)}</span></div>
                </div>
                <div class="text-center text-[10px] mt-6 italic">Terima kasih kerana berurusan dengan kami.</div>
            `;
            document.getElementById('printArea').innerHTML = html;

            const shareLines = [
                String(shop.workshopName || 'REV TORQ WORKSHOP'),
                `Resit: ${invNo}`,
                `Tarikh: ${created.toLocaleString('ms-MY')}`,
                '',
                ...saleItems.flatMap(i => {
                    const price = Number(i.price || 0);
                    const qty = Number(i.qty || 0);
                    const name = i.name || i.itemName || i.sku || '-';
                    const gross = price * qty;
                    const lineDiscount = window.RTPosDiscountModel ? window.RTPosDiscountModel.normalizeLineDiscount(i.discount,qty,price) : Math.min(Math.max(0,Number(i.discount||0)),gross);
                    const lines = [`${name} x${qty} = RM ${Math.max(0,gross-lineDiscount).toFixed(2)}`];
                    if(lineDiscount>0) lines.push(`  Diskaun item: -RM ${lineDiscount.toFixed(2)} (asal RM ${gross.toFixed(2)})`);
                    return lines;
                }),
                '',
                `Subtotal asal: RM ${sub.toFixed(2)}`,
                itemDisc > 0 ? `Diskaun item: RM ${itemDisc.toFixed(2)}` : null,
                promoDiscount > 0 ? `Promo ${promoName}${promoCode?` (${promoCode})`:''}: RM ${promoDiscount.toFixed(2)}` : null,
                voucherDiscount > 0 ? `Voucher ${voucherName}${voucherCode?` (${voucherCode})`:''}: RM ${voucherDiscount.toFixed(2)}` : null,
                disc > 0 ? `Diskaun keseluruhan: RM ${disc.toFixed(2)}` : null,
                totalDisc > 0 ? `Jumlah diskaun: RM ${totalDisc.toFixed(2)}` : null,
                otherCharge > 0 ? `Caj lain: RM ${otherCharge.toFixed(2)}` : null,
                `JUMLAH: RM ${total.toFixed(2)}`,
                `Kaedah: ${method}`,
                `Dibayar: RM ${received.toFixed(2)}`,
                `Baki: RM ${balance.toFixed(2)}`,
                '',
                'Terima kasih kerana berurusan dengan kami.'
            ].filter(v => v !== null);
            window.__rtLastReceiptText = shareLines.join('\n');
            openModal('receiptModal');
        }

        // WhatsApp number in international digits (Malaysia default): 012-345 6789 -> 60123456789.
        // Returns '' when the value is not a usable phone number.
        function rtWhatsAppNumber(raw) {
            const s = String(raw ?? '').trim();
            if (!s) return '';
            let d = s.replace(/\D/g, '');
            if (/^\+/.test(s)) { /* already international */ }
            else if (/^00/.test(d)) d = d.slice(2);
            else if (/^60/.test(d)) { /* Malaysia with country code */ }
            else if (/^0/.test(d)) d = '6' + d;
            else if (/^1\d{8,9}$/.test(d)) d = '60' + d;
            return /^\d{10,15}$/.test(d) ? d : '';
        }

        // phone: optional; without a valid number WhatsApp opens its contact picker as before.
        function rtShareReceiptWhatsApp(phone) {
            const text = String(window.__rtLastReceiptText || '').trim();
            if (!text) {
                if (typeof showToast === 'function') showToast('Resit belum tersedia untuk dikongsi.', 'error');
                return;
            }
            const to = rtWhatsAppNumber(phone);
            const url = 'https://wa.me/' + to + '?text=' + encodeURIComponent(text);
            const isNative = location.hostname === 'appassets.androidplatform.net' || /(?:^|[?&])native=1(?:&|$)/.test(location.search);
            if (isNative) {
                location.href = url;
                return;
            }
            const popup = window.open(url, '_blank', 'noopener,noreferrer');
            if (!popup) location.href = url;
        }

// Public APIs used by inline UI/history layers.
window.generateReceiptFromInvoice = generateReceiptFromInvoice;
window.rtShareReceiptWhatsApp = rtShareReceiptWhatsApp;
window.rtWhatsAppNumber = rtWhatsAppNumber;
window.loadPOS = loadPOS;
window.rtPosFindOrCreateMember = rtPosFindOrCreateMember;
window.rtPosLoadMemberSummary = rtPosLoadMemberSummary;
window.rtPosClearMember = rtPosClearMember;
window.rtPosUseClaimedVoucher = rtPosUseClaimedVoucher;
window.rtPosGetActiveVoucher = () => rtPosVoucher;
window.rtPosApplyVoucher = rtPosValidateVoucher;
window.rtPosRemoveVoucher = rtPosRemoveVoucher;
window.rtLoadEligiblePromos = rtLoadEligiblePromos;
window.rtApplyPromoById = rtApplyPromoById;
window.rtApplyPromoCode = rtApplyPromoCode;
window.rtPosRemovePromo = rtPosRemovePromo;
window.rtGetActivePromo = () => rtPosPromo;
window.rtRevalidateActivePromo = rtRevalidateActivePromo;
        window.posAddToCart = posAddToCart;
window.posUpdateQty = posUpdateQty;
window.posSetItemDiscount = posSetItemDiscount;
window.posClearCart = posClearCart;
window.rtCartArmRemove = rtCartArmRemove;
window.posCalculateTotal = posCalculateTotal;
window.posSetPaymentMethod = posSetPaymentMethod;
