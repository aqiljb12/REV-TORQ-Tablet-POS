/* REV TORQ POS V2 WEB — park / resume orders + cart draft restore.
   Device-local only (localStorage on this tablet). Nothing here posts a sale,
   touches stock or calls Supabase: a parked order is just the cart lines waiting
   on the counter. Payment still goes through the canonical BAYAR checkout, and
   prices/stock are refreshed from the loaded product list when an order resumes.
   Guarded so it never interferes with a checkout that is running or waiting to be
   confirmed (sessionStorage 'rt_pos_pending_sale_v1'), or with a Job Card cart. */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  var MAX_PARKED=10, DRAFT_MAX_AGE=12*60*60*1000, PENDING_KEY='rt_pos_pending_sale_v1';
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
  function num(v){var n=Number(v);return isFinite(n)?n:0;}
  function money(v){return 'RM '+num(v).toFixed(2);}
  function toast(m,t){try{if(window.showToast)window.showToast(m,t||'success');}catch(_){}}
  function feather(){try{if(window.feather)window.feather.replace();}catch(_){}}
  function cart(){try{return (window.rtGetPosCart&&window.rtGetPosCart())||[];}catch(_){return [];}}
  function profile(){return window.currentProfile||null;}
  function isService(i){return !!(i&&(i.service||String(i.itemType||'').toUpperCase()==='SERVICE'));}
  function read(key,fallback){try{var v=JSON.parse(localStorage.getItem(key)||'null');return v==null?fallback:v;}catch(_){return fallback;}}
  function write(key,val){try{if(val==null)localStorage.removeItem(key);else localStorage.setItem(key,JSON.stringify(val));return true;}catch(_){return false;}}
  function parkKey(){var p=profile();return p&&p.companyId?'rt_pos_parked_v1:'+p.companyId:null;}
  function draftKey(){var p=profile();return p&&p.companyId&&p.staffUuid?'rt_pos_draft_v1:'+p.companyId+':'+p.staffUuid:null;}
  function parked(){var k=parkKey();var list=k?read(k,[]):[];return Array.isArray(list)?list:[];}
  function saveParked(list){var k=parkKey();return k?write(k,list.length?list:null):false;}
  function pendingSale(){try{return !!sessionStorage.getItem(PENDING_KEY);}catch(_){return false;}}
  function checkoutBusy(){var b=$('btnCheckout');return !!(b&&/Memproses/i.test(b.textContent||''));}

  // Why the current cart cannot be parked / replaced right now ('' = OK).
  function blockReason(){
    if(checkoutBusy())return 'Pembayaran sedang diproses. Tunggu sehingga selesai.';
    if(pendingSale())return 'Ada jualan yang belum disahkan. Tekan BAYAR untuk semak status dahulu.';
    if(window.rtActiveJob)return 'Troli Job Card tidak perlu digantung — Job kekal dalam Job Card (BAWA KE POS bila sedia).';
    return '';
  }

  function customer(){
    var sel=$('rtPosCustomerSelect');if(!sel||!sel.value)return null;
    var o=sel.options[sel.selectedIndex];
    return {id:String(sel.value),name:(o&&(o.getAttribute('data-name')||o.textContent))||'Pelanggan',phone:(o&&o.getAttribute('data-phone'))||''};
  }
  function setCustomer(c){
    var sel=$('rtPosCustomerSelect');if(!sel)return;
    if(!c||!c.id){if(sel.value&&window.rtPosClearMember)window.rtPosClearMember();return;}
    var opt=[].slice.call(sel.options).filter(function(o){return String(o.value)===String(c.id);})[0];
    if(!opt){opt=document.createElement('option');opt.value=String(c.id);opt.textContent=(c.name||'Pelanggan')+(c.phone?' · '+c.phone:'');opt.setAttribute('data-name',c.name||'');opt.setAttribute('data-phone',c.phone||'');sel.appendChild(opt);}
    if(sel.value===String(c.id))return;
    sel.value=String(c.id);
    // Same event the member flow uses: loads points and re-checks vouchers/promo.
    try{sel.dispatchEvent(new Event('change',{bubbles:true}));}catch(_){}
  }
  function inputVal(id){var el=$(id);return el?num(String(el.value||'').replace(/,/g,'')):0;}
  function setInput(id,v,evt){
    var el=$(id);if(!el)return;var s=num(v).toFixed(2);
    if(window.rtSetNativeInputValue)window.rtSetNativeInputValue(el,s,{dispatch:false,rebuild:true});else el.value=s;
    try{el.dispatchEvent(new Event(evt,{bubbles:true}));}catch(_){}
  }
  function totals(lines,orderDiscount,otherCharge){
    var m=window.RTPosDiscountModel,t;
    if(m&&m.cartTotals){t=m.cartTotals(lines,num(orderDiscount)).total;}
    else{
      var net=lines.reduce(function(s,i){var g=num(i.qty)*num(i.price);return s+Math.max(0,g-Math.min(Math.max(0,num(i.discount)),g));},0);
      t=Math.max(0,net-Math.min(Math.max(0,num(orderDiscount)),net));
    }
    return Math.round((num(t)+Math.max(0,num(otherCharge)))*100)/100;
  }
  function snapshot(){
    var promo=null,voucher=null;
    try{promo=window.rtGetActivePromo&&window.rtGetActivePromo();}catch(_){}
    try{voucher=window.rtPosGetActiveVoucher&&window.rtPosGetActiveVoucher();}catch(_){}
    var lines=JSON.parse(JSON.stringify(cart()));
    // A voucher writes its amount into the order-discount box and a promo replaces it:
    // never carry that over as a manual discount. The cashier re-applies the offer.
    return {cart:lines,customer:customer(),orderDiscount:(promo||voucher)?0:inputVal('posDiscount'),otherCharge:inputVal('rtOtherCharge'),hadOffer:!!(promo||voucher)};
  }
  // Same reset the canonical checkout does after a successful sale.
  function clearCurrent(){
    setInput('rtOtherCharge',0,'input');
    if(window.rtSetPosCart)window.rtSetPosCart([]);
    if(window.posClearCart)window.posClearCart();
    try{if(window.rtPosRemovePromo)window.rtPosRemovePromo(false);}catch(_){}
    try{if(window.rtPosRemoveVoucher)window.rtPosRemoveVoucher();}catch(_){}
    try{if(window.rtPosClearMember)window.rtPosClearMember();}catch(_){}
    setInput('posDiscount',0,'change');
    var r=$('posAmountReceived');if(r){r.value='';try{r.dispatchEvent(new Event('input',{bubbles:true}));}catch(_){}}
  }
  // Re-check every line against the products loaded now: current price, current
  // stock as the limit, sold-out / removed items dropped. Service lines keep their price.
  function refreshLines(lines){
    var products=window.posProducts||[],bySku={},notes=[];
    products.forEach(function(p){bySku[String(p.sku||'').toUpperCase()]=p;});
    var model=window.RTPosDiscountModel,out=[];
    (lines||[]).forEach(function(i){
      var line=JSON.parse(JSON.stringify(i));line.qty=Math.max(1,Math.floor(num(line.qty)||1));
      if(!isService(line)){
        var p=bySku[String(line.sku||'').toUpperCase()];
        if(!p){notes.push((line.name||line.sku)+' tiada lagi');return;}
        var stock=Math.max(0,num(p.stock));
        if(stock<=0){notes.push((line.name||line.sku)+' habis stok');return;}
        if(num(p.price)!==num(line.price))notes.push((line.name||line.sku)+' harga baru '+money(p.price));
        line.price=num(p.price);line.maxStock=stock;line.name=p.name||line.name;
        if(p.id)line.productId=p.id; // current product id (checkout posts it directly)
        if(line.qty>stock){notes.push((line.name||line.sku)+' tinggal '+stock);line.qty=stock;}
      }
      line.discount=model&&model.normalizeLineDiscount?num(model.normalizeLineDiscount(line.discount,line.qty,line.price)):Math.min(Math.max(0,num(line.discount)),line.qty*num(line.price));
      out.push(line);
    });
    return {lines:out,notes:notes};
  }
  function apply(state){
    var r=refreshLines(state.cart);
    if(window.rtSetPosCart)window.rtSetPosCart(r.lines);
    setCustomer(state.customer);
    setInput('posDiscount',state.orderDiscount,'change');
    setInput('rtOtherCharge',state.otherCharge,'input');
    try{if(window.posCalculateTotal)window.posCalculateTotal();}catch(_){}
    return r;
  }
  function label(o){
    if(o.customer&&o.customer.name)return o.customer.name;
    var names=(o.cart||[]).map(function(i){return i.name||i.sku;}).filter(Boolean);
    return names.length?names.slice(0,2).join(', ')+(names.length>2?' +'+(names.length-2):''):'Order';
  }
  function itemCount(lines){return (lines||[]).reduce(function(n,i){return n+num(i.qty);},0);}
  function ago(t){
    var m=Math.max(0,Math.round((Date.now()-num(t))/60000));
    if(m<1)return 'baru tadi';if(m<60)return m+' min lalu';
    var h=Math.floor(m/60);if(h<24)return h+' jam lalu';
    return Math.floor(h/24)+' hari lalu';
  }

  // ---------------------------------------------------------------- park / resume
  window.rtParkOrder=function(opts){
    opts=opts||{};
    var why=blockReason();if(why){toast(why,'error');return false;}
    if(!cart().length){toast('Troli kosong — tiada order untuk digantung.','error');return false;}
    if(!parkKey()){toast('Sesi staff belum sedia.','error');return false;}
    var list=parked();
    if(list.length>=MAX_PARKED){toast('Maksimum '+MAX_PARKED+' order digantung. Sambung atau buang order lama dahulu.','error');return false;}
    var s=snapshot(),p=profile()||{};
    var order={id:'P'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),at:Date.now(),by:p.name||p.staffId||'',
      cart:s.cart,customer:s.customer,orderDiscount:s.orderDiscount,otherCharge:s.otherCharge,hadOffer:s.hadOffer};
    order.total=totals(order.cart,order.orderDiscount,order.otherCharge);
    list.unshift(order);
    if(!saveParked(list)){toast('Gagal simpan order dalam tablet (storan penuh?).','error');return false;}
    clearCurrent();
    syncButtons();
    if(!opts.quiet)toast('Order digantung · '+label(order)+' ('+itemCount(order.cart)+' item)'+(s.hadOffer?' · promo/voucher perlu dipilih semula':''),'success');
    return true;
  };

  function resume(id){
    var why=blockReason();if(why){toast(why,'error');return;}
    var order=parked().filter(function(o){return o.id===id;})[0];
    if(!order){toast('Order tidak dijumpai.','error');renderList();return;}
    var swap=cart().length>0;
    var go=function(){
      var again=blockReason();if(again){toast(again,'error');return;}
      // Take it off the list first so a swap never needs an 11th slot.
      saveParked(parked().filter(function(o){return o.id!==id;}));
      if(cart().length&&!window.rtParkOrder({quiet:true})){saveParked([order].concat(parked()));syncButtons();return;}
      var r=apply(order);
      closeList();syncButtons();
      var msg='Order disambung · '+label(order)+(swap?' · troli tadi digantung':'')+(order.hadOffer?' · pilih semula promo/voucher':'');
      if(r.notes.length)toast(msg+' · '+r.notes.join(' · '),'info');else toast(msg,'success');
      if(!r.lines.length)toast('Semua barang dalam order ini sudah habis / tiada.','error');
    };
    if(!swap){go();return;}
    var ask=window.rtConfirm?window.rtConfirm({title:'Troli semasa ada barang',message:'Gantung troli semasa ('+itemCount(cart())+' item) dan sambung order '+label(order)+'?',confirmText:'GANTUNG & SAMBUNG'}):Promise.resolve(window.confirm('Gantung troli semasa dan sambung order ini?'));
    ask.then(function(ok){if(ok)go();});
  }
  function drop(id){
    var order=parked().filter(function(o){return o.id===id;})[0];if(!order)return;
    var ask=window.rtConfirm?window.rtConfirm({title:'Buang order digantung?',message:label(order)+' · '+itemCount(order.cart)+' item · '+money(order.total),confirmText:'BUANG',danger:true}):Promise.resolve(window.confirm('Buang order ini?'));
    ask.then(function(ok){
      if(!ok)return;
      saveParked(parked().filter(function(o){return o.id!==id;}));
      syncButtons();renderList();
      if(!parked().length)closeList();
    });
  }

  // ---------------------------------------------------------------- parked list
  function closeList(){var m=$('rtParkedModal');if(m)m.remove();}
  function renderList(){
    var m=$('rtParkedModal');if(!m)return;
    var list=parked(),body=m.querySelector('.rt-parked-list');
    if(!list.length){body.innerHTML='<div class="rt-parked-empty">Tiada order digantung.</div>';return;}
    body.innerHTML=list.map(function(o){
      var items=(o.cart||[]).map(function(i){return esc(i.name||i.sku)+' ×'+num(i.qty);}).join(', ');
      return '<div class="rt-parked-row" data-id="'+esc(o.id)+'">'+
        '<div class="rt-parked-info"><b>'+esc(label(o))+'</b><small>'+esc(ago(o.at))+(o.by?' · '+esc(o.by):'')+' · '+itemCount(o.cart)+' item</small><span>'+items+'</span></div>'+
        '<div class="rt-parked-total">'+money(o.total)+'</div>'+
        '<div class="rt-parked-actions"><button type="button" class="rt-btn rt-btn-primary" data-park-act="resume">SAMBUNG</button><button type="button" class="rt-btn rt-btn-secondary" data-park-act="drop" aria-label="Buang order">BUANG</button></div>'+
      '</div>';
    }).join('');
  }
  window.rtOpenParkedOrders=function(){
    closeList();
    var m=document.createElement('div');
    m.id='rtParkedModal';m.className='rt-confirm-backdrop rt-parked-backdrop';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');
    m.innerHTML='<div class="rt-confirm-box rt-parked-box"><div class="rt-parked-head"><h3>ORDER DIGANTUNG</h3><button type="button" class="rt-icon-btn" data-park-act="close" aria-label="Tutup"><i data-feather="x"></i></button></div>'+
      '<p class="rt-parked-note">Disimpan dalam tablet ini sahaja. Harga &amp; stok disemak semula bila disambung.</p><div class="rt-parked-list"></div></div>';
    document.body.appendChild(m);
    m.addEventListener('click',function(e){
      var b=e.target.closest?e.target.closest('[data-park-act]'):null;
      if(!b){if(e.target===m)closeList();return;}
      var act=b.getAttribute('data-park-act'),row=b.closest('[data-id]'),id=row?row.getAttribute('data-id'):'';
      if(act==='close')closeList();else if(act==='resume')resume(id);else if(act==='drop')drop(id);
    });
    renderList();feather();
  };
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&$('rtParkedModal')&&!$('rtConfirmModal'))closeList();});

  // ---------------------------------------------------------------- cart head buttons
  function ensureButtons(){
    var head=document.querySelector('#view-pos .rt-cart-head-actions');
    if(!head||$('rtParkBtn'))return;
    var clear=$('rtClearCartBtn');
    var park=document.createElement('button');
    park.type='button';park.id='rtParkBtn';park.className='rt-icon-btn rt-park-btn';park.title='Gantung order (simpan troli, layan pelanggan lain)';park.setAttribute('aria-label','Gantung order');
    park.innerHTML='<i data-feather="pause-circle"></i>';
    park.onclick=function(){window.rtParkOrder();};
    var list=document.createElement('button');
    list.type='button';list.id='rtParkedBtn';list.className='rt-parked-btn';list.hidden=true;list.setAttribute('aria-label','Order digantung: 0');
    list.onclick=function(){window.rtOpenParkedOrders();};
    head.insertBefore(list,clear||null);
    head.insertBefore(park,clear||null);
    feather();
  }
  function syncButtons(){
    ensureButtons();
    var n=parked().length,b=$('rtParkedBtn'),p=$('rtParkBtn');
    if(b&&b.getAttribute('data-n')!==String(n)){b.hidden=!n;b.setAttribute('data-n',String(n));b.setAttribute('aria-label','Order digantung: '+n);b.title='Order digantung: '+n+' (tekan untuk sambung)';b.innerHTML='<i data-feather="clock"></i><span>'+n+'</span>';feather();}
    if(p)p.disabled=!cart().length;
  }
  window.rtSyncParkButtons=syncButtons;
  // Shared with quick search: put a customer on the current sale (same event as the member flow).
  window.rtPosSelectCustomer=setCustomer;

  // ---------------------------------------------------------------- draft (refresh / app restart)
  // One draft per staff on this tablet. A draft written while BAYAR was running
  // (or waiting to be confirmed) is never rebuilt: after an app restart the
  // pending marker in sessionStorage is gone, and the sale may already exist.
  var restored=false, lastSig=null, draftHold=null, who=null, needLoadAfter=0, lastTick=0, whoAt=0;
  function draftSig(){
    var c=cart();if(!c.length)return '';
    var cu=customer();
    return JSON.stringify([c,cu&&cu.id,inputVal('posDiscount'),inputVal('rtOtherCharge'),checkoutBusy()||pendingSale()]);
  }
  function saveDraft(){
    var k=draftKey();if(!k||!restored)return;
    if(window.rtActiveJob){if(lastSig!=='job'){write(k,null);lastSig='job';}return;}
    var sig=draftSig();
    if(sig===lastSig)return;
    lastSig=sig;
    if(!sig){write(k,null);return;}
    var s=snapshot();s.at=Date.now();s.inFlight=checkoutBusy()||pendingSale();
    write(k,s);
  }
  function tryRestore(){
    var p=profile(),id=p&&p.companyId&&p.staffUuid?p.companyId+':'+p.staffUuid:null;
    if(id!==who){who=id;whoAt=Date.now();restored=false;lastSig=null;draftHold=null;needLoadAfter=lastTick;}
    if(restored||!who)return;
    // Wait for a product list loaded for this login (current prices and stock).
    var loaded=num(window.rtPosProductsLoadedAt);
    if(!loaded||loaded<needLoadAfter){
      // Only right after login/refresh: never pop an old cart back in later on.
      if(Date.now()-whoAt>45000)restored=true;
      return;
    }
    restored=true;
    var k=draftKey(),d=k?read(k,null):null;
    if(!d||!Array.isArray(d.cart)||!d.cart.length)return;
    // A sale that is still waiting to be confirmed owns the cart: never rebuild it here.
    if(pendingSale()||window.rtActiveJob||cart().length||num(d.at)<Date.now()-DRAFT_MAX_AGE){write(k,null);return;}
    if(d.inFlight){
      write(k,null);
      toast('App tertutup semasa BAYAR sedang diproses. Semak Jualan dahulu sebelum caj pelanggan sekali lagi.','error');
      return;
    }
    var r=apply(d);
    if(!r.lines.length){write(k,null);return;}
    draftHold=d.customer&&d.customer.id?{until:Date.now()+8000,customer:d.customer}:null;
    toast('Troli dipulihkan · '+itemCount(r.lines)+' item'+(r.notes.length?' · '+r.notes.join(' · '):'')+(d.hadOffer?' · pilih semula promo/voucher':''),'info');
  }
  // The customer list loads after startup and rebuilds the selector; put the
  // restored customer back once if that wiped it (unless the cashier changed it).
  function holdCustomer(){
    if(!draftHold)return;
    if(Date.now()>draftHold.until||!cart().length){draftHold=null;return;}
    var sel=$('rtPosCustomerSelect');
    if(sel&&!sel.value){setCustomer(draftHold.customer);draftHold=null;}
  }
  document.addEventListener('change',function(e){if(e.target&&e.target.id==='rtPosCustomerSelect'&&e.isTrusted)draftHold=null;},true);
  window.addEventListener('pagehide',saveDraft);
  document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden')saveDraft();});
  // Mark the draft the moment BAYAR starts (the canonical checkout sets the button
  // label synchronously), before any request leaves the tablet.
  function watchCheckout(){
    var b=$('btnCheckout');
    if(!b||b.__rtParkWatch||!('MutationObserver' in window))return;
    b.__rtParkWatch=true;
    try{new MutationObserver(function(){try{saveDraft();}catch(_){}}).observe(b,{childList:true,characterData:true,subtree:true});}catch(_){}
  }

  function tick(){
    try{watchCheckout();tryRestore();holdCustomer();saveDraft();if(window.__rtActiveView==='pos'||$('rtParkBtn'))syncButtons();}catch(e){console.warn('rt-park',e);}
    lastTick=Date.now();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',tick,{once:true});else tick();
  setInterval(tick,600);
})();
