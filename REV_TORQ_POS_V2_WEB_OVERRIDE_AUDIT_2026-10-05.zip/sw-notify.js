/* REV TORQ POS — notification-only service worker (booking alerts).
   No fetch handler and no cache: it never changes how the POS loads or works offline.
   Tapping a notification brings the POS tab forward and opens the booking. */
self.addEventListener('install',function(){self.skipWaiting();});
self.addEventListener('activate',function(e){e.waitUntil(self.clients.claim());});
self.addEventListener('notificationclick',function(e){
  e.notification.close();
  var data=e.notification.data||{};
  e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(function(list){
    for(var i=0;i<list.length;i++){
      var c=list[i];
      if('focus' in c){c.postMessage({type:'rt-open-booking',bookingId:data.bookingId||null});return c.focus();}
    }
    if(self.clients.openWindow)return self.clients.openWindow(self.registration.scope);
  }));
});
