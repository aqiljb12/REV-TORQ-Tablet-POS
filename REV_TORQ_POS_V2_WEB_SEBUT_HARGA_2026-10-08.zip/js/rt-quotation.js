/* REV TORQ POS V2 — Sebut Harga (quotation) page.
   Two separate kinds (UBAH SUAI and SERVIS), each with its own number series, kept in the shared database through the
   rt_quote_* functions of migration_2026_10_08_quotations.sql. A quotation is a document only: it is NOT linked to the
   POS cart, a sale, stock or a Job Card. Customers / stock are only READ (to fill the form); nothing else is written
   except through rt_quote_save / rt_quote_set_status.
   The unsaved form is also kept on this device (localStorage) so a reload or a dropped connection does not lose it.
   Plain ES2017-compatible code (older iPad Safari). Needs js/rt-quotation-pdf.js loaded first. */
(function(w,d){
  'use strict';
  var PDF=w.RTQuotePdf;
  var root=d.getElementById('rtQuoteBody');
  if(!root||!PDF)return;

  var KEY_TYPE='rt_quote_type',KEY_DRAFTS='rt_quote_drafts_v1';
  var STATUS={DRAFT:['DRAF','rt-badge-neutral'],SENT:['DIHANTAR','rt-badge-low'],ACCEPTED:['DITERIMA','rt-badge-ok'],REJECTED:['DITOLAK','rt-badge-danger'],CANCELLED:['DIBATALKAN','rt-badge-neutral']};
  var CHIPS=[['ALL','Semua'],['DRAFT','Draf'],['SENT','Dihantar'],['ACCEPTED','Diterima'],['REJECTED','Ditolak'],['CANCELLED','Dibatal']];
  var TYPES={UBAH_SUAI:'UBAH SUAI',SERVIS:'SERVIS'};
  var KINDS={PART:'Barang',LABOUR:'Upah',OTHER:'Lain'};
  var SETUP_FILE='migration_2026_10_08_quotations.sql';

  var S={type:'UBAH_SUAI',status:'ALL',search:'',rows:[],counts:{},hasMore:false,loading:false,err:'',mode:'list',q:null,ed:null,
         ready:null,seq:0,busy:false,shop:null,listStale:true,draftTimer:null,searchTimer:null};
  try{var t0=w.localStorage.getItem(KEY_TYPE);if(t0==='UBAH_SUAI'||t0==='SERVIS')S.type=t0;}catch(_){}
  w.__rtQuote={state:S};

  // ------------------------------------------------------------------ small helpers
  function $(id){return d.getElementById(id);}
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
  function toast(m,t){try{if(typeof w.showToast==='function')w.showToast(m,t||'success');}catch(_){}}
  function role(){return String((w.currentProfile||{}).role||'').toLowerCase();}
  function isAdmin(){return ['owner','super_admin','admin','manager'].indexOf(role())>=0;}
  function money(v){return PDF.money(v);}
  function dtext(v){return PDF.dateText(v);}
  function uuid(){
    try{if(w.crypto&&typeof w.crypto.randomUUID==='function')return w.crypto.randomUUID();}catch(_){}
    return 'q'+Date.now().toString(36)+Math.random().toString(36).slice(2,12);
  }
  // decimal rounding on the typed text (3.335 -> 3.34, like the database), not on a binary float
  function rnd2(v){
    var n=Number(v);if(!isFinite(n))return 0;
    var s=String(n);
    if(/e/i.test(s))return Math.round(n*100)/100;
    return Number(Math.round(Number(s+'e2'))+'e-2');
  }
  // "1,000" -> 1000, "100,5" -> 100.5, "12.50" -> 12.5, "" / text -> NaN
  function parseNum(v){
    var s=String(v==null?'':v).replace(/\s+/g,'');
    if(!s)return NaN;
    if(/^\d{1,3}(,\d{3})+(\.\d+)?$/.test(s))s=s.replace(/,/g,'');
    else s=s.replace(',','.');
    if(!/^-?\d*\.?\d+$/.test(s)&&!/^-?\d+\.$/.test(s))return NaN;
    return Number(s);
  }
  function myToday(plus){            // YYYY-MM-DD in Malaysia time (UTC+8)
    var t=new Date(Date.now()+8*3600*1000+(plus||0)*86400000);
    function two(n){return (n<10?'0':'')+n;}
    return t.getUTCFullYear()+'-'+two(t.getUTCMonth()+1)+'-'+two(t.getUTCDate());
  }
  function waNum(v){return typeof w.rtWhatsAppNumber==='function'?w.rtWhatsAppNumber(v):'';}
  function store(k,v){try{if(v==null)w.localStorage.removeItem(k);else w.localStorage.setItem(k,v);}catch(_){}}
  function load(k){try{return w.localStorage.getItem(k);}catch(_){return null;}}

  function rpc(name,args){
    if(typeof w.supabaseRpc!=='function')return Promise.reject(new Error('Supabase belum tersedia. Muat semula app.'));
    return Promise.resolve(w.supabaseRpc(name,args));
  }
  function msgOf(e){return String((e&&(e.message||e.details||e.hint))||e||'');}
  function isMissing(e){
    var m=msgOf(e);
    return !!(e&&(e.code==='PGRST202'||e.code==='42883'))||(/rt_quote_/.test(m)&&/(could not find|does not exist|not found|schema cache)/i.test(m));
  }
  var ERR={
    AUTH_REQUIRED:'Sesi tamat. Sila log masuk semula.',STAFF_ONLY:'Akaun staf tidak ditemui.',
    QUOTE_ROLE_NOT_ALLOWED:'Akaun ini tidak dibenarkan menggunakan Sebut Harga.',
    QUOTE_CUSTOMER_REQUIRED:'Isi nama pelanggan.',QUOTE_ITEMS_REQUIRED:'Tambah sekurang-kurangnya satu baris.',
    QUOTE_ITEM_DESCRIPTION_REQUIRED:'Setiap baris perlu perihal.',QUOTE_ITEM_QTY_INVALID:'Kuantiti mesti lebih daripada 0.',
    QUOTE_ITEM_PRICE_INVALID:'Harga tidak sah.',QUOTE_ITEM_NUMBER_INVALID:'Kuantiti / harga mesti nombor.',
    QUOTE_DISCOUNT_TOO_BIG:'Diskaun lebih besar daripada jumlah kecil.',QUOTE_DISCOUNT_INVALID:'Diskaun tidak sah.',
    QUOTE_VALID_UNTIL_INVALID:'Tarikh sah tidak sah.',QUOTE_TOO_MANY_ITEMS:'Terlalu banyak baris (maksimum 80).',
    QUOTE_TOTAL_TOO_BIG:'Jumlah terlalu besar.',QUOTE_TYPE_INVALID:'Jenis sebut harga tidak sah.',
    QUOTE_CHANGED:'Sebut harga ini telah diubah oleh orang lain. Buka semula untuk melihat versi terkini.',
    QUOTE_LOCKED:'Sebut harga ini sudah dikunci (diterima / ditolak / dibatal) dan tidak boleh diedit.',
    QUOTE_NOT_FOUND:'Sebut harga tidak ditemui.',QUOTE_STATUS_NOT_ALLOWED:'Status ini tidak boleh ditukar dari keadaan sekarang.',
    QUOTE_ADMIN_ONLY:'Hanya admin / owner boleh membatalkan sebut harga yang sudah DITERIMA.',
    QUOTE_REASON_REQUIRED:'Sebab diperlukan.',QUOTE_STATUS_INVALID:'Status tidak sah.'
  };
  function errText(e){
    var m=msgOf(e);
    var hit=/(QUOTE_[A-Z_]+|AUTH_REQUIRED|STAFF_ONLY)/.exec(m);
    if(hit&&ERR[hit[1]])return ERR[hit[1]];
    if(/failed to fetch|networkerror|load failed|network request failed/i.test(m)||(w.navigator&&w.navigator.onLine===false))return 'Tiada sambungan internet. Cuba lagi bila sambungan pulih.';
    return m||'Ralat tidak diketahui.';
  }
  function isNetwork(e){var m=msgOf(e);return /failed to fetch|networkerror|load failed|network request failed/i.test(m)||(w.navigator&&w.navigator.onLine===false);}

  // ------------------------------------------------------------------ dialogs
  function sheet(html,wide){
    var old=$('rtqSheet');if(old)old.remove();
    var m=d.createElement('div');
    m.id='rtqSheet';m.className='rt-confirm-backdrop';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');
    m.innerHTML='<div class="rt-confirm-box'+(wide?' rtq-wide':'')+'">'+html+'</div>';
    d.body.appendChild(m);
    var api={el:m,onclose:null,close:function(v){d.removeEventListener('keydown',onKey,true);if(m.parentNode)m.remove();if(api.onclose)api.onclose(v);}};
    function onKey(e){if(e.key==='Escape'){e.preventDefault();api.close(null);}}
    d.addEventListener('keydown',onKey,true);
    m.addEventListener('click',function(e){if(e.target===m)api.close(null);});
    return api;
  }
  // -> Promise<null | {value}>   (null = cancelled)
  function ask(o){
    return new Promise(function(resolve){
      var html='<h3>'+esc(o.title)+'</h3>'+(o.intro?'<p>'+esc(o.intro)+'</p>':'')+
        (o.input?'<textarea id="rtqAskIn" class="rtq-ask" rows="3" maxlength="300" placeholder="'+esc(o.input.placeholder||'')+'"></textarea><div id="rtqAskErr" class="rtq-err"></div>':'')+
        '<div class="rt-confirm-actions"><button type="button" class="rt-btn rt-btn-secondary" data-a="no">'+esc(o.cancel||'BATAL')+'</button>'+
        '<button type="button" class="rt-btn '+(o.danger?'rt-btn-danger':'rt-btn-primary')+'" data-a="yes">'+esc(o.ok||'OK')+'</button></div>';
      var s=sheet(html),settled=false;
      s.onclose=function(){if(!settled){settled=true;resolve(null);}};
      s.el.addEventListener('click',function(ev){
        var b=ev.target.closest?ev.target.closest('[data-a]'):null;if(!b)return;
        if(b.getAttribute('data-a')==='no'){s.close(null);return;}
        var val='';
        if(o.input){
          val=String($('rtqAskIn').value||'').trim();
          if(o.input.required&&val.length<3){$('rtqAskErr').textContent='Sila isi sebab (sekurang-kurangnya 3 huruf).';return;}
        }
        settled=true;resolve({value:val});s.close(true);
      });
      var ta=$('rtqAskIn');if(ta)setTimeout(function(){try{ta.focus();}catch(_){}},60);
    });
  }

  // ------------------------------------------------------------------ the workshop profile (name / address for the PDF)
  function loadShop(){
    if(S.shop)return Promise.resolve(S.shop);
    var base=w.rtWorkshopProfile||{};
    try{
      if(w.db&&typeof w.db.collection==='function'){
        return Promise.resolve(w.db.collection('settings').doc('workshop').get()).then(function(snap){
          var data=(snap&&snap.exists&&typeof snap.data==='function')?snap.data():{};
          S.shop=Object.assign({},base,data||{});w.rtWorkshopProfile=S.shop;return S.shop;
        },function(){S.shop=Object.assign({},base);return S.shop;});
      }
    }catch(_){}
    S.shop=Object.assign({},base);return Promise.resolve(S.shop);
  }
  function shopNow(){return Object.assign({},w.rtWorkshopProfile||{},S.shop||{});}

  // ------------------------------------------------------------------ page frame (head tools live in index.html)
  function setHead(on){var h=$('rtQuoteHead');if(h)h.classList.toggle('hidden',!on);}
  function badge(status,expired){
    var s=STATUS[status]||[status,'rt-badge-neutral'];
    return '<span class="rt-badge '+s[1]+'">'+esc(s[0])+'</span>'+(expired?'<span class="rt-badge rt-badge-late">LUPUT</span>':'');
  }
  function setup(){
    setHead(false);S.mode='setup';
    root.innerHTML='<div class="rtq-banner"><b>Sebut Harga belum diaktifkan di pangkalan data.</b><br>Jalankan fail <b>'+esc(SETUP_FILE)+'</b> di Supabase (SQL Editor), kemudian tekan <b>Semak Semula</b>. '+
      'Fail itu hanya menambah jadual dan fungsi baharu untuk Sebut Harga; ia tidak mengubah jualan, stok atau Job Card.</div>'+
      '<button type="button" class="rt-btn rt-btn-secondary" data-qact="recheck">Semak Semula</button>';
  }
  function failed(e){
    setHead(false);S.mode='error';
    root.innerHTML='<div class="rtq-banner"><b>Sebut Harga tidak dapat dimuatkan.</b><br>'+esc(errText(e))+'</div><button type="button" class="rt-btn rt-btn-secondary" data-qact="recheck">Cuba Lagi</button>';
  }
  function checkReady(){
    if(S.ready===true)return Promise.resolve(true);
    return rpc('rt_quote_ready',{}).then(function(r){S.ready=!!(r&&r.ready);return S.ready;},function(e){
      if(isMissing(e)){S.ready=false;return false;}
      throw e;
    });
  }

  // entry point used by the sidebar (viewDefinitions.quotes.func)
  w.rtLoadQuotes=function(){
    var me=who();
    if(S.who!==me){                                                     // another staff member signed in: start clean
      S.who=me;S.rows=[];S.counts={};S.hasMore=false;S.q=null;S.ed=null;S.shop=null;S.ready=null;S.mode='list';S.err='';S.search='';
      var si=$('rtQuoteSearch');if(si)si.value='';
    }
    if(S.mode==='edit'||S.mode==='detail'){return Promise.resolve();}   // keep what the user is working on
    return start();
  };
  function start(){
    S.mode='list';
    root.innerHTML='<div class="rt-muted-note">Memuatkan...</div>';
    return checkReady().then(function(ok){
      if(!ok){setup();return;}
      showList(true);
    }).catch(failed);
  }

  // ------------------------------------------------------------------ LIST
  function showList(reload){
    S.mode='list';S.ed=null;S.q=null;setHead(true);
    root.innerHTML=
      '<div class="rtq-tabs" role="tablist">'+Object.keys(TYPES).map(function(k){return '<button type="button" role="tab" data-qact="type" data-type="'+k+'" class="'+(S.type===k?'active':'')+'">'+TYPES[k]+'</button>';}).join('')+'</div>'+
      '<div class="rt-filter-chips rtq-chips" id="rtqChips"></div>'+
      '<div id="rtqRows"></div><div id="rtqMore"></div>';
    paintChips();paintRows();
    if(reload||S.listStale)loadList(false);
  }
  function paintChips(){
    var el=$('rtqChips');if(!el)return;
    var c=S.counts||{},total=0,k;
    for(k in c)if(k!=='CANCELLED')total+=Number(c[k])||0;
    el.innerHTML=CHIPS.map(function(x){
      var n=x[0]==='ALL'?total:(Number(c[x[0]])||0);
      return '<button type="button" data-qact="chip" data-status="'+x[0]+'" class="'+(S.status===x[0]?'active':'')+'">'+esc(x[1])+'<i>'+n+'</i></button>';
    }).join('');
  }
  function visibleRows(){
    return S.status==='ALL'?S.rows.filter(function(r){return r.status!=='CANCELLED';}):S.rows;
  }
  function rowHtml(r){
    var bike=[r.plate_no,r.vehicle_model].filter(Boolean).join(' · ');
    var who=[r.customer_name,r.customer_phone].filter(Boolean).join(' · ');
    return '<button type="button" class="rtq-row" data-qact="open" data-id="'+esc(r.id)+'">'+
      '<span class="rtq-row-main"><span class="rtq-row-top"><b>'+esc(r.quote_no)+'</b>'+badge(r.status,r.expired)+'</span>'+
      '<span class="rtq-row-line">'+esc(who||'-')+'</span>'+
      (bike?'<span class="rtq-row-line">'+esc(bike)+'</span>':'')+
      (r.title?'<span class="rtq-row-line muted">'+esc(r.title)+'</span>':'')+'</span>'+
      '<span class="rtq-row-side"><b>'+esc(money(r.total))+'</b><small>'+esc(dtext(r.created_at))+(r.valid_until?' · sah '+esc(dtext(r.valid_until)):'')+'</small></span></button>';
  }
  function paintRows(){
    var box=$('rtqRows'),more=$('rtqMore');if(!box)return;
    var rows=visibleRows();
    if(S.err){
      box.innerHTML='<div class="rtq-banner">'+esc(S.err)+'</div><button type="button" class="rt-btn rt-btn-secondary" data-qact="refresh">Cuba Lagi</button>';
      if(more)more.innerHTML='';return;
    }
    if(!rows.length){
      box.innerHTML='<div class="rt-muted-note" style="text-align:center;padding:36px 8px">'+
        (S.loading?'Memuatkan...':(S.search?'Tiada sebut harga sepadan dengan carian.':'Belum ada sebut harga '+esc(TYPES[S.type])+(S.status!=='ALL'?' dengan status ini':'')+'. Tekan <b>+ SEBUT HARGA BARU</b>.'))+'</div>';
    }else{
      box.innerHTML=rows.map(rowHtml).join('');
    }
    if(more)more.innerHTML=(S.hasMore&&!S.loading)?'<button type="button" class="rt-btn rt-btn-secondary rt-btn-block" data-qact="more">MUAT LAGI</button>':'';
  }
  function loadList(append){
    var seq=++S.seq;S.loading=true;S.err='';paintRows();
    var off=append?S.rows.length:0;
    return rpc('rt_quote_list',{p_type:S.type,p_status:S.status==='ALL'?null:S.status,p_search:S.search||null,p_limit:30,p_offset:off}).then(function(r){
      if(seq!==S.seq)return;
      r=r||{};
      var rows=Array.isArray(r.rows)?r.rows:[];
      S.rows=append?S.rows.concat(rows):rows;S.hasMore=!!r.has_more;S.counts=r.counts||{};S.loading=false;S.listStale=false;
      if(S.mode==='list'){paintChips();paintRows();}
    },function(e){
      if(seq!==S.seq)return;
      S.loading=false;
      if(isMissing(e)){S.ready=false;setup();return;}
      S.err=errText(e);if(S.mode==='list')paintRows();
    });
  }
  function onSearch(){
    clearTimeout(S.searchTimer);
    var el=$('rtQuoteSearch');
    S.searchTimer=setTimeout(function(){
      S.search=String((el&&el.value)||'').trim();
      if(S.mode==='list')loadList(false);
    },350);
  }

  // ------------------------------------------------------------------ DETAIL (the document + actions)
  function openQuote(id){
    S.mode='detail';setHead(false);S.ed=null;
    root.innerHTML='<div class="rt-muted-note">Memuatkan sebut harga...</div>';
    loadShop();
    return rpc('rt_quote_get',{p_id:id}).then(function(q){showDetail(q);},function(e){
      toast(errText(e),'error');showList(true);
    });
  }
  function lineHtml(it,n){
    return '<div class="rtq-line"><span class="n">'+(n+1)+'</span><span class="d">'+esc(it.description)+(it.sku?'<small>SKU: '+esc(it.sku)+'</small>':'')+(it.kind==='LABOUR'?'<small>Upah</small>':'')+'</span>'+
      '<span class="q">'+esc(String(Math.round(Number(it.quantity)*100)/100))+' × '+esc(PDF.fmt(it.unit_price))+'</span>'+
      '<span class="t">'+esc(PDF.fmt(it.line_total))+'</span></div>';
  }
  function showDetail(q){
    S.q=q;S.mode='detail';S.ed=null;setHead(false);
    var st=q.status,items=Array.isArray(q.items)?q.items:[];
    var canEdit=st==='DRAFT'||st==='SENT';
    var main=[],stat=[];
    function add(list,act,label,cls,extra){list.push('<button type="button" class="rt-btn '+cls+'" data-qact="'+act+'"'+(extra||'')+'>'+label+'</button>');}
    add(main,'pdf','PDF / KONGSI','rt-btn-primary');
    add(main,'wa','WHATSAPP (TEKS)','rt-btn-green');
    if(canEdit)add(main,'edit','EDIT','rt-btn-secondary');
    add(main,'copy','SALIN','rt-btn-secondary');
    if(st==='DRAFT'){add(stat,'status','TANDAKAN DIHANTAR','rt-btn-secondary',' data-to="SENT"');}
    if(st==='DRAFT'||st==='SENT'){
      add(stat,'status','DITERIMA','rt-btn-secondary',' data-to="ACCEPTED"');
      add(stat,'status','DITOLAK','rt-btn-secondary',' data-to="REJECTED"');
    }
    if(st==='REJECTED')add(stat,'status','BUKA SEMULA (DIHANTAR)','rt-btn-secondary',' data-to="SENT"');
    if(st==='DRAFT'||st==='SENT'||st==='REJECTED'||(st==='ACCEPTED'&&isAdmin()))add(stat,'status','BATALKAN','rt-btn-danger-soft',' data-to="CANCELLED"');
    var help=st==='ACCEPTED'?'Diterima = pelanggan setuju. Sebut harga dikunci. Ia tidak menambah barang ke troli POS atau Job Card.':
             st==='CANCELLED'?'Sebut harga ini sudah dibatalkan.':st==='REJECTED'?'Ditolak oleh pelanggan. Boleh dibuka semula atau disalin sebagai sebut harga baharu.':
             'Sebut harga ini rekod sahaja: ia tidak menambah barang ke troli POS atau Job Card.';
    root.innerHTML=
      '<div class="rtq-bar"><button type="button" class="rt-btn rt-btn-secondary rt-btn-sm" data-qact="list">‹ Senarai</button>'+
        '<div class="rtq-bar-title"><b>'+esc(q.quote_no)+'</b>'+badge(st,q.expired)+'</div></div>'+
      '<div class="rtq-doc"><div class="rtq-doc-top"><div><span class="rtq-type">SEBUT HARGA · '+esc(TYPES[q.quote_type]||q.quote_type)+'</span><h2>'+esc(q.quote_no)+'</h2></div>'+
        '<div class="rtq-meta">Tarikh: <b>'+esc(dtext(q.created_at))+'</b><br>Sah sehingga: <b>'+esc(dtext(q.valid_until)||'-')+'</b>'+(q.created_by_name?'<br>Disediakan oleh: <b>'+esc(q.created_by_name)+'</b>':'')+'</div></div>'+
        '<div class="rtq-party"><div><small>KEPADA</small><b>'+esc(q.customer_name)+'</b>'+(q.customer_phone?'<span>'+esc(q.customer_phone)+'</span>':'')+'</div>'+
        ((q.plate_no||q.vehicle_model)?'<div><small>MOTOSIKAL</small><b>'+esc(q.plate_no||q.vehicle_model)+'</b>'+(q.plate_no&&q.vehicle_model?'<span>'+esc(q.vehicle_model)+'</span>':'')+'</div>':'')+'</div>'+
        (q.title?'<p class="rtq-doc-title">Perkara: '+esc(q.title)+'</p>':'')+
        items.map(lineHtml).join('')+
        '<div class="rtq-totals" style="margin-top:10px">'+
          '<div><span>Jumlah kecil</span><b>'+esc(money(q.subtotal))+'</b></div>'+
          (Number(q.discount)>0?'<div><span>Diskaun</span><b>-'+esc(money(q.discount))+'</b></div>':'')+
          '<div class="rtq-grand"><span>JUMLAH</span><b>'+esc(money(q.total))+'</b></div></div>'+
        (q.notes?'<div class="rtq-note"><small>CATATAN</small>'+esc(q.notes)+'</div>':'')+
        (q.status_note?'<div class="rtq-note"><small>SEBAB ('+esc((STATUS[st]||[st])[0])+')</small>'+esc(q.status_note)+'</div>':'')+
      '</div>'+
      '<div class="rtq-actions"><h4>Hantar kepada pelanggan</h4><div class="rtq-btns">'+main.join('')+'</div>'+
        (stat.length?'<h4 style="margin-top:6px">Status</h4><div class="rtq-btns">'+stat.join('')+'</div>':'')+
        '<p class="rtq-help">'+esc(help)+'</p></div>';
  }

  // ------------------------------------------------------------------ send: PDF share / WhatsApp text
  function offerMarkSent(q){
    if(!q||q.status!=='DRAFT')return;
    ask({title:'Tandakan DIHANTAR?',intro:'Sebut harga '+q.quote_no+' masih DRAF. Tandakan sebagai sudah dihantar kepada pelanggan?',ok:'YA, DIHANTAR',cancel:'BELUM'}).then(function(r){
      if(r&&S.q&&S.q.id===q.id)changeStatus('SENT','');
    });
  }
  function download(blob,name){
    var url=URL.createObjectURL(blob),a=d.createElement('a');
    a.href=url;a.download=name;d.body.appendChild(a);a.click();a.remove();
    setTimeout(function(){URL.revokeObjectURL(url);},30000);
  }
  function saveAndChat(blob,name,phone,q){
    download(blob,name);
    if(phone){
      toast('PDF disimpan ('+name+'). WhatsApp dibuka: lampirkan fail itu.','success');
      var msg='Sebut Harga '+q.quote_no+' ('+money(q.total)+') - PDF dilampirkan. Terima kasih.';
      var url='https://wa.me/'+phone+'?text='+encodeURIComponent(msg);
      setTimeout(function(){var p=w.open(url,'_blank','noopener,noreferrer');if(!p)toast('Buka WhatsApp dan lampirkan fail PDF yang baru disimpan.','success');},350);
    }else{
      toast('PDF disimpan ('+name+'). Lampirkan dalam WhatsApp.','success');
    }
    setTimeout(function(){offerMarkSent(q);},900);
  }
  function sharePdf(){
    var q=S.q;if(!q)return;
    var blob;
    try{blob=new Blob([PDF.buildQuotePdfBytes(q,shopNow())],{type:'application/pdf'});}
    catch(e){toast('PDF tidak dapat dibuat: '+(e&&e.message||e),'error');return;}
    var name=PDF.fileName(q),phone=waNum(q.customer_phone),file=null;
    try{file=new File([blob],name,{type:'application/pdf'});}catch(_){}
    var title='Sebut Harga '+q.quote_no,text=title+' - '+money(q.total);
    if(file&&typeof w.navigator.share==='function'&&typeof w.navigator.canShare==='function'){
      var can=false;try{can=w.navigator.canShare({files:[file]});}catch(_){}
      if(can){
        // no await before this call: the share sheet needs the tap that started it
        w.navigator.share({files:[file],title:title,text:text}).then(function(){offerMarkSent(q);},function(e){
          if(e&&e.name==='AbortError')return;                         // the sheet was closed
          console.warn('share quotation pdf',e);saveAndChat(blob,name,phone,q);
        });
        return;
      }
    }
    saveAndChat(blob,name,phone,q);
  }
  function sendWhatsApp(){
    var q=S.q;if(!q)return;
    var text=PDF.whatsappText(q,shopNow()),phone=waNum(q.customer_phone);
    var url='https://wa.me/'+(phone||'')+'?text='+encodeURIComponent(text);
    var p=w.open(url,'_blank','noopener,noreferrer');
    if(!p)toast('Pelayar menyekat WhatsApp. Benarkan pop-up atau guna PDF / KONGSI.','error');
    else if(!phone)toast('Tiada no. telefon pelanggan: pilih sendiri penerima dalam WhatsApp.','success');
    setTimeout(function(){offerMarkSent(q);},900);
  }

  // ------------------------------------------------------------------ status changes
  function changeStatus(to,reason){
    var q=S.q;if(!q||S.busy)return Promise.resolve();
    S.busy=true;
    return rpc('rt_quote_set_status',{p_id:q.id,p_status:to,p_reason:reason||null}).then(function(r){
      S.busy=false;S.listStale=true;
      if(S.q&&S.q.id===q.id){showDetail(r);toast('Status: '+(STATUS[to]||[to])[0],'success');}
    },function(e){
      S.busy=false;toast(errText(e),'error');
      if(/QUOTE_CHANGED|QUOTE_LOCKED|QUOTE_STATUS_NOT_ALLOWED/.test(msgOf(e)))openQuote(q.id);
    });
  }
  function askStatus(to){
    var q=S.q;if(!q)return;
    if(to==='SENT'){changeStatus('SENT','');return;}
    if(to==='ACCEPTED'){
      ask({title:'Pelanggan setuju?',intro:'Sebut harga '+q.quote_no+' ('+money(q.total)+') ditanda DITERIMA dan dikunci: tidak boleh diedit lagi. Ia tidak menambah apa-apa ke troli POS atau Job Card.',ok:'YA, DITERIMA',cancel:'BATAL'}).then(function(r){if(r)changeStatus('ACCEPTED','');});
      return;
    }
    if(to==='REJECTED'){
      ask({title:'Pelanggan menolak?',intro:'Sebab (pilihan) membantu anda kemudian, cth. "mahal".',input:{placeholder:'Sebab (pilihan)'},ok:'TANDA DITOLAK',cancel:'BATAL'}).then(function(r){if(r)changeStatus('REJECTED',r.value);});
      return;
    }
    if(to==='CANCELLED'){
      ask({title:'Batalkan sebut harga ini?',intro:q.quote_no+' tidak akan dipadam: ia ditanda DIBATALKAN dan sebab direkod.',input:{placeholder:'Sebab pembatalan (wajib)',required:true},ok:'BATALKAN',cancel:'KEMBALI',danger:true}).then(function(r){if(r)changeStatus('CANCELLED',r.value);});
    }
  }

  // ------------------------------------------------------------------ EDITOR
  function blankItem(kind){return {kind:kind||'PART',description:'',sku:'',product_id:'',quantity:'1',unit_price:''};}
  function newEditor(type,from){
    var e={id:null,type:type,quote_no:'',client_ref:uuid(),revision:null,customer_id:null,vehicle_id:null,customer_name:'',customer_phone:'',plate_no:'',
           vehicle_model:'',title:'',notes:'',valid_until:myToday(14),discount:'',items:[blankItem('PART')],dirty:false,saving:false};
    if(from){
      e.customer_id=from.customer_id||null;e.vehicle_id=from.vehicle_id||null;
      e.customer_name=from.customer_name||'';e.customer_phone=from.customer_phone||'';e.plate_no=from.plate_no||'';e.vehicle_model=from.vehicle_model||'';
      e.title=from.title||'';e.notes=from.notes||'';e.discount=Number(from.discount)>0?String(from.discount):'';
      e.items=(from.items||[]).map(itemFromRow);
      if(!e.items.length)e.items=[blankItem('PART')];
      e.dirty=true;
    }
    return e;
  }
  function itemFromRow(it){
    return {kind:it.kind||'PART',description:it.description||'',sku:it.sku||'',product_id:it.product_id||'',
            quantity:String(Math.round(Number(it.quantity)*100)/100),unit_price:Number(it.unit_price).toFixed(2)};
  }
  function editExisting(q){
    var e=newEditor(q.quote_type);
    e.id=q.id;e.quote_no=q.quote_no;e.client_ref='';e.revision=q.revision;
    e.customer_id=q.customer_id||null;e.vehicle_id=q.vehicle_id||null;
    e.customer_name=q.customer_name||'';e.customer_phone=q.customer_phone||'';e.plate_no=q.plate_no||'';e.vehicle_model=q.vehicle_model||'';
    e.title=q.title||'';e.notes=q.notes||'';e.valid_until=q.valid_until||'';e.discount=Number(q.discount)>0?Number(q.discount).toFixed(2):'';
    e.items=(q.items||[]).map(itemFromRow);if(!e.items.length)e.items=[blankItem('PART')];
    e.dirty=false;
    return e;
  }

  // ---- local draft (this device only)
  function who(){var p=w.currentProfile||{};return String(p.staffId||p.staff_code||p.id||'');}
  function draftKey(e){return who()+'|'+(e.id?('edit:'+e.id):('new:'+e.type));}      // per staff member: a shared counter device does not offer someone else's draft
  function drafts(){try{var o=JSON.parse(load(KEY_DRAFTS)||'{}');return o&&typeof o==='object'?o:{};}catch(_){return {};}}
  function writeDrafts(o){
    var keys=Object.keys(o).sort(function(a,b){return (o[b].at||0)-(o[a].at||0);});
    var out={};keys.slice(0,12).forEach(function(k){if(Date.now()-(o[k].at||0)<14*86400000)out[k]=o[k];});
    store(KEY_DRAFTS,Object.keys(out).length?JSON.stringify(out):null);
  }
  function hasContent(e){
    return !!(String(e.customer_name).trim()||String(e.customer_phone).trim()||String(e.plate_no).trim()||String(e.title).trim()||String(e.notes).trim()||
      e.items.some(function(i){return String(i.description).trim()||String(i.unit_price).trim();}));
  }
  function snapshot(e){
    return {id:e.id,type:e.type,revision:e.revision,customer_id:e.customer_id,vehicle_id:e.vehicle_id,customer_name:e.customer_name,customer_phone:e.customer_phone,
            plate_no:e.plate_no,vehicle_model:e.vehicle_model,title:e.title,notes:e.notes,valid_until:e.valid_until,discount:e.discount,items:e.items,client_ref:e.client_ref};
  }
  function saveDraftSoon(){
    clearTimeout(S.draftTimer);
    S.draftTimer=setTimeout(function(){
      var e=S.ed;if(!e||!e.dirty||e.saving)return;
      var all=drafts();
      if(hasContent(e))all[draftKey(e)]={at:Date.now(),e:snapshot(e)};else delete all[draftKey(e)];
      writeDrafts(all);
    },500);
  }
  function clearDraft(e){clearTimeout(S.draftTimer);var all=drafts();delete all[draftKey(e)];writeDrafts(all);}
  function applyDraft(e,snap){
    ['customer_id','vehicle_id','customer_name','customer_phone','plate_no','vehicle_model','title','notes','valid_until','discount'].forEach(function(k){e[k]=snap[k]==null?'':snap[k];});
    if(snap.customer_id==null)e.customer_id=null;if(snap.vehicle_id==null)e.vehicle_id=null;
    e.items=(Array.isArray(snap.items)&&snap.items.length?snap.items:[blankItem('PART')]).map(function(i){return {kind:i.kind||'PART',description:i.description||'',sku:i.sku||'',product_id:i.product_id||'',quantity:String(i.quantity==null?'1':i.quantity),unit_price:String(i.unit_price==null?'':i.unit_price)};});
    if(snap.client_ref&&!e.id)e.client_ref=snap.client_ref;
    e.dirty=true;
  }
  function openEditor(e){
    var snap=drafts()[draftKey(e)];
    var usable=snap&&snap.e&&(e.id?Number(snap.e.revision)===Number(e.revision):true);
    S.ed=e;S.mode='edit';setHead(false);
    if(!usable||(e.dirty&&!e.id)){renderEditor();return;}      // no draft, or a copy of another quotation: do not offer an old draft
    renderEditor();
    var when=new Date(snap.at);
    var hh=('0'+when.getHours()).slice(-2)+':'+('0'+when.getMinutes()).slice(-2);
    ask({title:'Sambung draf?',intro:'Ada draf yang belum disimpan dalam peranti ini ('+PDF.dateText(when)+' '+hh+'). Sambung draf itu?',ok:'SAMBUNG DRAF',cancel:'MULA BARU'}).then(function(r){
      if(!S.ed||S.ed!==e)return;
      if(r){applyDraft(e,snap.e);renderEditor();}else{clearDraft(e);}
    });
  }
  function startNew(type){
    var t=type||S.type;
    openEditor(newEditor(t));
  }

  function fld(label,f,val,o){
    o=o||{};
    return '<label class="rtq-f'+(o.cls?' '+o.cls:'')+'"><span>'+label+'</span><input data-f="'+f+'" type="'+(o.type||'text')+'" value="'+esc(val)+'" autocomplete="off"'+(o.attrs?' '+o.attrs:'')+'></label>';
  }
  function itemHtml(it,i){
    return '<div class="rtq-item" data-i="'+i+'"><div class="rtq-item-top">'+
      '<select data-k="kind" aria-label="Jenis baris">'+Object.keys(KINDS).map(function(k){return '<option value="'+k+'"'+(it.kind===k?' selected':'')+'>'+KINDS[k]+'</option>';}).join('')+'</select>'+
      '<textarea data-k="description" rows="2" maxlength="200" placeholder="Perihal (cth. Kit racing 62mm / Upah pasang)" aria-label="Perihal">'+esc(it.description)+'</textarea>'+
      '<button type="button" class="rtq-del" data-qact="delrow" aria-label="Buang baris">×</button></div>'+
      (it.sku?'<div class="rtq-sku">SKU: '+esc(it.sku)+'</div>':'')+
      '<div class="rtq-item-nums"><label class="rtq-f"><span>Kuantiti</span><input data-k="quantity" inputmode="decimal" autocomplete="off" value="'+esc(it.quantity)+'"></label>'+
      '<label class="rtq-f"><span>Harga seunit (RM)</span><input data-k="unit_price" inputmode="decimal" autocomplete="off" placeholder="0.00" value="'+esc(it.unit_price)+'"></label>'+
      '<div class="rtq-linetotal"><span>Jumlah</span><b data-rt>RM 0.00</b></div></div></div>';
  }
  function itemsHtml(e){return e.items.map(itemHtml).join('');}

  function renderEditor(){
    var e=S.ed;if(!e)return;
    var isNew=!e.id;
    root.innerHTML=
      '<div class="rtq-bar"><button type="button" class="rt-btn rt-btn-secondary rt-btn-sm" data-qact="back">‹ Kembali</button>'+
        '<div class="rtq-bar-title"><b>'+(isNew?'Sebut Harga Baru':'Edit '+esc(e.quote_no))+'</b>'+(isNew?'':'<span class="rt-badge rt-badge-neutral">'+esc(TYPES[e.type])+'</span>')+'</div></div>'+
      (isNew?'<div class="rtq-type-switch" role="tablist">'+Object.keys(TYPES).map(function(k){return '<button type="button" role="tab" data-qact="settype" data-type="'+k+'" class="'+(e.type===k?'active':'')+'">'+TYPES[k]+'</button>';}).join('')+'</div>':'')+
      '<div class="rtq-card"><div class="rtq-h-row"><h4>Pelanggan</h4><button type="button" class="rt-btn rt-btn-secondary rt-btn-sm" data-qact="pickcust">CARI PELANGGAN</button></div>'+
        '<div class="rtq-grid">'+fld('Nama *','customer_name',e.customer_name,{attrs:'maxlength="120" placeholder="Nama pelanggan"'})+
        fld('No. telefon','customer_phone',e.customer_phone,{type:'tel',attrs:'inputmode="tel" maxlength="40" placeholder="01x-xxxxxxx"'})+
        fld('No. plat','plate_no',e.plate_no,{attrs:'maxlength="20" autocapitalize="characters" spellcheck="false" placeholder="cth. JXX 1234"'})+
        fld('Model motosikal','vehicle_model',e.vehicle_model,{attrs:'maxlength="80" placeholder="cth. Yamaha NVX 155"'})+'</div></div>'+
      '<div class="rtq-card"><h4>Perkara</h4><div class="rtq-grid">'+
        fld('Tajuk / perkara','title',e.title,{cls:'wide',attrs:'maxlength="160" placeholder="cth. Kit racing + remap"'})+
        fld('Sah sehingga','valid_until',e.valid_until,{type:'date'})+'</div></div>'+
      '<div class="rtq-card"><h4>Barang &amp; upah</h4><div id="rtqItems">'+itemsHtml(e)+'</div>'+
        '<div class="rtq-add"><button type="button" class="rt-btn rt-btn-secondary rt-btn-sm" data-qact="addrow" data-kind="PART">+ BARANG</button>'+
        '<button type="button" class="rt-btn rt-btn-secondary rt-btn-sm" data-qact="addrow" data-kind="LABOUR">+ UPAH</button>'+
        '<button type="button" class="rt-btn rt-btn-secondary rt-btn-sm" data-qact="addstock">+ DARI STOK</button></div>'+
        '<div class="rtq-totals" style="margin-top:14px"><div><span>Jumlah kecil</span><b id="rtqSub">RM 0.00</b></div>'+
        '<div class="rtq-disc"><span>Diskaun (RM)</span><input data-f="discount" inputmode="decimal" autocomplete="off" placeholder="0.00" value="'+esc(e.discount)+'"></div>'+
        '<div class="rtq-grand"><span>JUMLAH</span><b id="rtqTotal">RM 0.00</b></div></div></div>'+
      '<div class="rtq-card"><h4>Catatan (muncul pada PDF)</h4><label class="rtq-f"><textarea data-f="notes" maxlength="2000" placeholder="cth. Harga termasuk upah. Deposit RM300 diperlukan.">'+esc(e.notes)+'</textarea></label></div>'+
      '<div class="rtq-err" id="rtqErr"></div>'+
      '<div class="rtq-foot"><button type="button" class="rt-btn rt-btn-secondary" data-qact="back">BATAL</button>'+
        '<button type="button" class="rt-btn rt-btn-primary" id="rtqSave" data-qact="save">'+(isNew?'SIMPAN SEBUT HARGA':'SIMPAN PERUBAHAN')+'</button></div>';
    refreshNumbers();pinFoot();
  }
  // The page scrolls inside #viewsContainer, which has bottom padding: without this the sticky bar stops that far above the screen edge
  function pinFoot(){
    var f=root.querySelector('.rtq-foot'),c=$('viewsContainer');
    if(!f||!c)return;
    var pb=parseFloat(w.getComputedStyle(c).paddingBottom)||0;
    f.style.bottom=(-pb)+'px';f.style.paddingBottom='calc('+(10+pb)+'px + env(safe-area-inset-bottom))';
  }

  function calc(e){
    var sub=0,lines=[];
    e.items.forEach(function(it){
      var q=parseNum(it.quantity),p=parseNum(it.unit_price);
      var t=(isFinite(q)&&isFinite(p)&&q>0&&p>=0)?rnd2(rnd2(q)*rnd2(p)):0;
      lines.push(t);sub+=t;
    });
    sub=rnd2(sub);
    var disc=parseNum(e.discount);if(!isFinite(disc)||disc<0)disc=0;disc=rnd2(disc);
    return {lines:lines,sub:sub,disc:disc,total:rnd2(sub-disc)};
  }
  function refreshNumbers(){
    var e=S.ed;if(!e)return;
    var c=calc(e);
    var rows=root.querySelectorAll('.rtq-item');
    for(var i=0;i<rows.length;i++){var el=rows[i].querySelector('[data-rt]');if(el)el.textContent=money(c.lines[i]||0);}
    var s=$('rtqSub'),t=$('rtqTotal');
    if(s)s.textContent=money(c.sub);
    if(t)t.textContent=money(c.total);
  }
  function touch(){var e=S.ed;if(!e)return;e.dirty=true;refreshNumbers();saveDraftSoon();var er=$('rtqErr');if(er)er.textContent='';}
  function repaintItems(focusIdx){
    var box=$('rtqItems');if(!box||!S.ed)return;
    box.innerHTML=itemsHtml(S.ed);refreshNumbers();
    if(focusIdx!=null){
      var el=box.querySelector('.rtq-item[data-i="'+focusIdx+'"] textarea');
      if(el){try{el.focus();if(el.scrollIntoView)el.scrollIntoView({block:'center'});}catch(_){}}
    }
  }
  function addRow(kind,fill){
    var e=S.ed;if(!e)return;
    var it=blankItem(kind);if(fill)Object.assign(it,fill);
    // a single untouched blank row is replaced instead of left empty above the new one
    if(e.items.length===1&&!String(e.items[0].description).trim()&&!String(e.items[0].unit_price).trim())e.items=[it];
    else e.items.push(it);
    touch();repaintItems(fill?null:e.items.length-1);
  }
  function delRow(i){
    var e=S.ed;if(!e)return;
    e.items.splice(i,1);if(!e.items.length)e.items.push(blankItem('PART'));
    touch();repaintItems(null);
  }

  // ---- validate -> {items:[...], message, field, index}
  function validate(e){
    function bad(msg,sel,idx){return {message:msg,sel:sel,idx:idx};}
    if(!String(e.customer_name).trim())return bad('Isi nama pelanggan.','[data-f="customer_name"]');
    var d0=String(e.discount||'').trim(),disc=0;
    if(d0){disc=parseNum(d0);if(!isFinite(disc)||disc<0)return bad('Diskaun mesti nombor (0 atau lebih).','[data-f="discount"]');}
    var out=[];
    for(var i=0;i<e.items.length;i++){
      var it=e.items[i];
      var blank=!String(it.description).trim()&&!String(it.unit_price).trim();
      if(blank)continue;                                     // empty rows are dropped silently
      var row='.rtq-item[data-i="'+i+'"] ';
      if(!String(it.description).trim())return bad('Baris '+(i+1)+': isi perihal.',row+'textarea',i);
      var q=parseNum(it.quantity),p=parseNum(it.unit_price);
      if(!isFinite(q)||q<=0)return bad('Baris '+(i+1)+': kuantiti mesti lebih daripada 0.',row+'[data-k="quantity"]',i);
      if(!isFinite(p)||p<0)return bad('Baris '+(i+1)+': isi harga (taip 0 jika percuma).',row+'[data-k="unit_price"]',i);
      out.push({kind:it.kind||'PART',description:String(it.description).trim(),sku:it.sku||'',product_id:it.product_id||'',quantity:rnd2(q),unit_price:rnd2(p)});
    }
    if(!out.length)return bad('Tambah sekurang-kurangnya satu baris barang atau upah.','.rtq-item textarea',0);
    var c=calc(e);
    if(disc>c.sub)return bad('Diskaun lebih besar daripada jumlah kecil ('+money(c.sub)+').','[data-f="discount"]');
    return {items:out,discount:rnd2(disc)};
  }
  function showBad(v){
    var er=$('rtqErr');if(er)er.textContent=v.message;
    var el=v.sel?root.querySelector(v.sel):null;
    if(el){
      el.classList.add('rtq-bad');
      try{el.focus();if(el.scrollIntoView)el.scrollIntoView({block:'center'});}catch(_){}
      var off=function(){el.classList.remove('rtq-bad');el.removeEventListener('input',off);};
      el.addEventListener('input',off);
    }
    toast(v.message,'error');
  }

  function saveQuote(){
    var e=S.ed;if(!e||e.saving)return;
    var v=validate(e);
    if(v.message){showBad(v);return;}
    var payload={id:e.id||null,client_ref:e.id?null:e.client_ref,quote_type:e.type,expected_revision:e.id?e.revision:null,
      customer_id:e.customer_id||null,vehicle_id:e.vehicle_id||null,customer_name:String(e.customer_name).trim(),customer_phone:String(e.customer_phone).trim(),
      plate_no:String(e.plate_no).trim(),vehicle_model:String(e.vehicle_model).trim(),title:String(e.title).trim(),notes:String(e.notes).trim(),
      valid_until:e.valid_until||null,discount:v.discount,items:v.items};
    e.saving=true;
    var btn=$('rtqSave');if(btn){btn.disabled=true;btn.textContent='MENYIMPAN...';}
    rpc('rt_quote_save',{p_quote:payload}).then(function(q){
      e.saving=false;
      if(S.ed!==e)return;
      clearDraft(e);S.listStale=true;S.ed=null;
      toast(q&&q.duplicate?'Sudah disimpan sebelum ini: '+q.quote_no:'Disimpan: '+q.quote_no,'success');
      showDetail(q);loadShop();
    },function(err){
      e.saving=false;
      var b=$('rtqSave');if(b){b.disabled=false;b.textContent=e.id?'SIMPAN PERUBAHAN':'SIMPAN SEBUT HARGA';}
      if(isMissing(err)){S.ready=false;toast('Sebut Harga belum diaktifkan di pangkalan data.','error');var er0=$('rtqErr');if(er0)er0.textContent='Jalankan '+SETUP_FILE+' di Supabase dahulu.';return;}
      if(/QUOTE_CHANGED/.test(msgOf(err))){resolveConflict(e);return;}
      var msg=errText(err);
      var er=$('rtqErr');if(er)er.textContent=msg+(isNetwork(err)?' Draf kekal dalam peranti ini.':'');
      toast(msg,'error');
      if(/QUOTE_LOCKED/.test(msgOf(err)))saveDraftSoon();
    });
  }
  // Someone else saved this quotation after it was opened: the saver chooses, nothing is overwritten silently.
  function resolveConflict(e){
    ask({title:'Diubah oleh orang lain',intro:'Seseorang telah menyimpan sebut harga ini selepas anda membukanya. TIMPA = simpan perubahan anda di atas versi itu (tekan SIMPAN sekali lagi). LIHAT TERKINI = buang perubahan anda dan lihat versi terbaharu.',ok:'TIMPA',cancel:'LIHAT TERKINI'}).then(function(r){
      if(!S.ed||S.ed!==e)return;
      if(!r){clearDraft(e);S.ed=null;openQuote(e.id);return;}
      rpc('rt_quote_get',{p_id:e.id}).then(function(q){
        if(S.ed!==e)return;
        if(q.status!=='DRAFT'&&q.status!=='SENT'){
          clearDraft(e);S.ed=null;showDetail(q);
          toast('Sebut harga ini sudah '+(STATUS[q.status]||[q.status])[0]+' dan dikunci. Perubahan anda tidak disimpan.','error');return;
        }
        e.revision=q.revision;
        var er=$('rtqErr');if(er)er.textContent='Tekan SIMPAN sekali lagi untuk menimpa versi orang lain.';
        toast('Tekan SIMPAN sekali lagi untuk menimpa versi orang lain.','success');
      },function(er2){toast(errText(er2),'error');});
    });
  }
  function leaveEditor(){
    var e=S.ed;if(!e)return;
    var done=function(){
      var id=e.id;S.ed=null;
      if(id&&S.q&&S.q.id===id)showDetail(S.q);else showList(true);
    };
    if(!e.dirty||!hasContent(e)){clearDraft(e);done();return;}
    ask({title:'Keluar tanpa menyimpan?',intro:'Perubahan belum disimpan ke pangkalan data. Draf ini kekal dalam peranti ini dan boleh disambung kemudian.',ok:'KELUAR',cancel:'TERUSKAN EDIT'}).then(function(r){if(r){saveDraftNow(e);done();}});
  }
  function saveDraftNow(e){
    clearTimeout(S.draftTimer);
    var all=drafts();if(hasContent(e))all[draftKey(e)]={at:Date.now(),e:snapshot(e)};writeDrafts(all);
  }

  // ------------------------------------------------------------------ pickers (customers / vehicles / stock) — READ only
  function searchCustomers(text){
    var sb=w.supabaseClient,company=(w.currentProfile||{}).companyId;
    if(!sb||typeof sb.from!=='function'||!company)return Promise.resolve([]);
    var clean=String(text||'').replace(/[%_,()\\]/g,' ').replace(/\s+/g,' ').trim(),digits=clean.replace(/\D/g,'');
    var jobs=[];
    if(clean.length>=2&&/\D/.test(clean))jobs.push(sb.from('customers').select('id,name,phone').eq('company_id',company).eq('active',true).ilike('name','%'+clean+'%').order('name',{ascending:true}).limit(12));
    if(digits.length>=3)jobs.push(sb.from('customers').select('id,name,phone').eq('company_id',company).eq('active',true).ilike('phone_normalized','%'+digits+'%').limit(12));
    return Promise.all(jobs.map(function(j){return Promise.resolve(j).then(function(r){return (r&&r.data)||[];},function(){return [];});})).then(function(parts){
      var seen={},out=[];[].concat.apply([],parts).forEach(function(c){if(!seen[c.id]){seen[c.id]=1;out.push(c);}});return out;
    });
  }
  function vehiclesOf(customerId){
    var sb=w.supabaseClient,company=(w.currentProfile||{}).companyId;
    if(!sb||typeof sb.from!=='function')return Promise.resolve([]);
    var q=sb.from('vehicles').select('id,plate_no,brand,model').eq('customer_id',customerId);
    if(company)q=q.eq('company_id',company);
    return Promise.resolve(q.limit(20)).then(function(r){return (r&&r.data)||[];},function(){return [];});
  }
  function pickCustomer(){
    var e=S.ed;if(!e)return;
    var s=sheet('<h3>Cari pelanggan</h3><p>Taip nama (2 huruf) atau telefon (3 digit). Pilihan ini hanya mengisi borang.</p>'+
      '<input type="search" class="rtq-search" id="rtqCustIn" placeholder="Nama / no. telefon" autocomplete="off">'+
      '<div class="rtq-results" id="rtqCustOut"></div><div class="rtq-sheet-foot"><button type="button" class="rt-btn rt-btn-secondary" data-a="close">TUTUP</button></div>',true);
    var out=$('rtqCustOut'),input=$('rtqCustIn'),seq=0,timer=null;
    function fill(c,v){
      e.customer_id=c.id;e.customer_name=c.name||'';e.customer_phone=c.phone||'';
      if(v){e.vehicle_id=v.id;e.plate_no=v.plate_no||'';e.vehicle_model=[v.brand,v.model].filter(Boolean).join(' ');}
      else{e.vehicle_id=null;}
      e.dirty=true;saveDraftSoon();s.close(true);renderEditor();
    }
    function showVehicles(c,list){
      out.innerHTML='<div class="rt-muted-note"><b>'+esc(c.name)+'</b> — pilih motosikal:</div>'+
        list.map(function(v,i){return '<button type="button" data-v="'+i+'"><b>'+esc(v.plate_no||'-')+'</b><small>'+esc([v.brand,v.model].filter(Boolean).join(' '))+'</small></button>';}).join('')+
        '<button type="button" data-v="-1"><b>Tanpa motosikal</b><small>Isi no. plat sendiri</small></button>';
      out.onclick=function(ev){var b=ev.target.closest?ev.target.closest('[data-v]'):null;if(!b)return;var i=Number(b.getAttribute('data-v'));fill(c,i>=0?list[i]:null);};
    }
    function paint(list,msg){
      if(!list.length){out.innerHTML='<div class="rt-muted-note">'+esc(msg)+'</div>';out.onclick=null;return;}
      out.innerHTML=list.map(function(c,i){return '<button type="button" data-c="'+i+'"><b>'+esc(c.name||'-')+'</b><small>'+esc(c.phone||'')+'</small></button>';}).join('');
      out.onclick=function(ev){
        var b=ev.target.closest?ev.target.closest('[data-c]'):null;if(!b)return;
        var c=list[Number(b.getAttribute('data-c'))];
        out.innerHTML='<div class="rt-muted-note">Memuatkan motosikal...</div>';
        vehiclesOf(c.id).then(function(vs){if(!vs.length)fill(c,null);else showVehicles(c,vs);});
      };
    }
    input.addEventListener('input',function(){
      clearTimeout(timer);var my=++seq,text=input.value;
      var digits=text.replace(/\D/g,'');
      if(text.trim().length<2&&digits.length<3){out.innerHTML='';return;}
      out.innerHTML='<div class="rt-muted-note">Mencari...</div>';
      timer=setTimeout(function(){searchCustomers(text).then(function(list){if(my!==seq)return;paint(list,'Tiada pelanggan dijumpai. Isi nama dan telefon sendiri dalam borang.');});},300);
    });
    s.el.addEventListener('click',function(ev){var b=ev.target.closest?ev.target.closest('[data-a="close"]'):null;if(b)s.close(null);});
    setTimeout(function(){try{input.focus();}catch(_){}},60);
  }
  function searchProducts(text){
    var sb=w.supabaseClient,company=(w.currentProfile||{}).companyId;
    if(!sb||typeof sb.from!=='function'||!company)return Promise.resolve([]);
    var words=String(text||'').replace(/[%_,()\\]/g,' ').split(/\s+/).filter(Boolean).slice(0,5);
    if(!words.length)return Promise.resolve([]);
    var q=sb.from('products').select('id,sku,name,sell_price,active').eq('company_id',company).eq('active',true);
    words.forEach(function(wd){q=q.ilike('name','%'+wd+'%');});
    var bySku=sb.from('products').select('id,sku,name,sell_price,active').eq('company_id',company).eq('active',true).ilike('sku','%'+words.join(' ')+'%').limit(8);
    return Promise.all([Promise.resolve(q.order('name',{ascending:true}).limit(15)).then(function(r){return (r&&r.data)||[];},function(){return [];}),
                        Promise.resolve(bySku).then(function(r){return (r&&r.data)||[];},function(){return [];})]).then(function(parts){
      var seen={},out=[];parts[1].concat(parts[0]).forEach(function(p){if(!seen[p.id]){seen[p.id]=1;out.push(p);}});return out.slice(0,20);
    });
  }
  function pickStock(){
    var e=S.ed;if(!e)return;
    var added=0;
    var s=sheet('<h3>Tambah dari stok</h3><p>Harga diisi dari harga jual semasa dan boleh diubah. Stok tidak ditolak.</p>'+
      '<input type="search" class="rtq-search" id="rtqStockIn" placeholder="Nama / SKU barang" autocomplete="off">'+
      '<div class="rtq-results" id="rtqStockOut"></div><div class="rtq-sheet-foot"><button type="button" class="rt-btn rt-btn-primary" data-a="close" id="rtqStockDone">SIAP</button></div>',true);
    var out=$('rtqStockOut'),input=$('rtqStockIn'),seq=0,timer=null,list=[];
    input.addEventListener('input',function(){
      clearTimeout(timer);var my=++seq,text=input.value;
      if(text.trim().length<2){out.innerHTML='';return;}
      out.innerHTML='<div class="rt-muted-note">Mencari...</div>';
      timer=setTimeout(function(){searchProducts(text).then(function(rows){
        if(my!==seq)return;list=rows;
        if(!rows.length){out.innerHTML='<div class="rt-muted-note">Tiada barang dijumpai. Guna + BARANG untuk taip sendiri.</div>';return;}
        out.innerHTML=rows.map(function(p,i){return '<button type="button" data-p="'+i+'"><b>'+esc(p.name)+'</b><small>'+esc(p.sku||'')+' · '+esc(money(p.sell_price))+'</small></button>';}).join('');
      });},300);
    });
    out.addEventListener('click',function(ev){
      var b=ev.target.closest?ev.target.closest('[data-p]'):null;if(!b)return;
      var p=list[Number(b.getAttribute('data-p'))];if(!p)return;
      addRow('PART',{description:p.name||'',sku:p.sku||'',product_id:p.id||'',quantity:'1',unit_price:Number(p.sell_price||0).toFixed(2)});
      added++;b.classList.add('done');
      var done=$('rtqStockDone');if(done)done.textContent='SIAP ('+added+' ditambah)';
    });
    s.el.addEventListener('click',function(ev){var b=ev.target.closest?ev.target.closest('[data-a="close"]'):null;if(b)s.close(null);});
    setTimeout(function(){try{input.focus();}catch(_){}},60);
  }

  // ------------------------------------------------------------------ events
  function bind(){
    var view=$('view-quotes');if(!view)return;
    view.addEventListener('click',function(ev){
      var b=ev.target.closest?ev.target.closest('[data-qact]'):null;if(!b||!view.contains(b))return;
      var act=b.getAttribute('data-qact');
      switch(act){
        case 'new':startNew(S.type);break;
        case 'refresh':case 'recheck':S.ready=null;S.err='';start();break;
        case 'type':S.type=b.getAttribute('data-type');store(KEY_TYPE,S.type);S.rows=[];S.counts={};S.hasMore=false;showList(true);break;
        case 'chip':S.status=b.getAttribute('data-status');S.rows=[];paintChips();loadList(false);break;
        case 'more':loadList(true);break;
        case 'open':openQuote(b.getAttribute('data-id'));break;
        case 'list':showList(true);break;
        case 'pdf':sharePdf();break;
        case 'wa':sendWhatsApp();break;
        case 'edit':if(S.q)openEditor(editExisting(S.q));break;
        case 'copy':if(S.q)openEditor(newEditor(S.q.quote_type,S.q));break;
        case 'status':askStatus(b.getAttribute('data-to'));break;
        case 'back':leaveEditor();break;
        case 'settype':if(S.ed&&!S.ed.id){S.ed.type=b.getAttribute('data-type');S.type=S.ed.type;store(KEY_TYPE,S.type);var tabs=root.querySelectorAll('.rtq-type-switch button');for(var i=0;i<tabs.length;i++)tabs[i].classList.toggle('active',tabs[i].getAttribute('data-type')===S.ed.type);S.ed.dirty=true;saveDraftSoon();}break;
        case 'pickcust':pickCustomer();break;
        case 'addrow':addRow(b.getAttribute('data-kind')||'PART');break;
        case 'addstock':pickStock();break;
        case 'delrow':var row=b.closest('.rtq-item');if(row)delRow(Number(row.getAttribute('data-i')));break;
        case 'save':saveQuote();break;
      }
    });
    function onEdit(ev){
      var e=S.ed;if(!e||S.mode!=='edit')return;
      var t=ev.target;if(!t||!t.getAttribute)return;
      var f=t.getAttribute('data-f'),k=t.getAttribute('data-k');
      if(f){
        e[f]=t.value;
        if(f==='customer_name'||f==='customer_phone')e.customer_id=null;
        if(f==='plate_no'||f==='vehicle_model')e.vehicle_id=null;
        touch();return;
      }
      if(k){
        var row=t.closest?t.closest('.rtq-item'):null;if(!row)return;
        var i=Number(row.getAttribute('data-i'));
        if(e.items[i]){e.items[i][k]=t.value;touch();}
      }
    }
    view.addEventListener('input',onEdit);
    view.addEventListener('change',onEdit);
    var s=$('rtQuoteSearch');if(s){s.addEventListener('input',onSearch);}
  }
  bind();
})(window,document);
