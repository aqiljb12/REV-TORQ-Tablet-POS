const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const vm=require('vm');
const root=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
const core=read('js/core.js'),css=read('css/rt-polish.css'),html=read('index.html');

function sideMode(width,stored){
  const code=core.slice(core.indexOf('        function rtSideModeStored() {'),core.indexOf('        function rtNavMoreOpen() {'));
  const cls=new Set(),store=new Map(stored?[['rt_side_mode',stored]]:[]);const listeners={};
  const btn={attrs:{},title:'',setAttribute(k,v){this.attrs[k]=v;}};
  const win={innerWidth:width,addEventListener:(t,f)=>{listeners[t]=f;},dispatchEvent:()=>{}};
  const ctx={window:win,localStorage:{getItem:k=>store.has(k)?store.get(k):null,setItem:(k,v)=>store.set(k,v)},Event:class{},
    document:{documentElement:{classList:{toggle:(c,on)=>{on?cls.add(c):cls.delete(c);},contains:c=>cls.has(c)}},getElementById:id=>id==='rtSideModeBtn'?btn:null}};
  vm.createContext(ctx);vm.runInContext(code,ctx);
  return {full:()=>cls.has('rt-side-full'),btn,store,win,listeners,toggle:()=>win.rtToggleSideMode()};
}

test('side menu: full menu by default on 1180 px+ landscape, small icons on 1024-1179, always small under 1024',()=>{
  assert.equal(sideMode(1180).full(),true,'iPad 10 / Air landscape');
  assert.equal(sideMode(1366).full(),true,'small laptop');
  assert.equal(sideMode(1024).full(),false,'iPad 9.7 landscape');
  assert.equal(sideMode(820,'full').full(),false,'iPad portrait stays small even when full was chosen');
});

test('side menu: the toggle switches, is kept per device, and the button says what it does',()=>{
  const h=sideMode(1180);
  assert.equal(h.btn.title,'Kecilkan menu');assert.equal(h.btn.attrs['aria-pressed'],'true');
  h.toggle();
  assert.equal(h.full(),false);assert.equal(h.store.get('rt_side_mode'),'rail');assert.equal(h.btn.title,'Besarkan menu');
  h.toggle();assert.equal(h.full(),true);assert.equal(h.store.get('rt_side_mode'),'full');
  assert.equal(sideMode(1024,'full').full(),true,'a 1024 px iPad can choose the full menu');
  assert.equal(sideMode(1366,'rail').full(),false,'a laptop can choose the small icons');
  // turning the iPad re-applies the rule
  const r=sideMode(1180,'full');r.win.innerWidth=820;r.listeners.resize();assert.equal(r.full(),false);r.win.innerWidth=1180;r.listeners.resize();assert.equal(r.full(),true);
});

test('side menu: toggle button next to the logo; group headings in the menu',()=>{
  const brand=html.slice(html.indexOf('<aside id="sidebar"'),html.indexOf('<!-- User Profile -->'));
  assert.match(brand,/<button type="button" id="rtSideModeBtn" class="rt-side-mode-btn" onclick="window\.rtToggleSideMode && window\.rtToggleSideMode\(\)"/);
  assert.match(brand,/<i data-feather="sidebar"><\/i>/);
  assert.match(core,/const navGroups = \{ pos: 'Utama', sales: 'Jualan', jobcard: 'Bengkel & Stok', staff: 'Pengurusan' \};/);
});

test('side menu CSS: every small-icon rule on tablets is switched off by .rt-side-full; the full menu only from 1024 px',()=>{
  const heads=['@media (min-width:768px) and (max-width:1366px){','@media (min-width:768px) and (max-width:1366px) and (max-height:860px){'];
  let i=0,blocks=0;
  for(;;){const at=heads.map(h=>css.indexOf(h,i)).filter(x=>x>=0);if(!at.length)break;const p=Math.min(...at);
    let k=css.indexOf('{',p)+1,d=1;const b=k;while(d){if(css[k]==='{')d++;else if(css[k]==='}')d--;k++;}
    const body=css.slice(b,k-1);blocks++;
    for(const m of body.matchAll(/([^{}]+)\{[^{}]*\}/g))for(const sel of m[1].split(',').map(x=>x.trim()))
      if(!sel.startsWith('.rt-pos-mobile-menu'))assert.ok(sel.startsWith('html:not(.rt-side-full) ')||sel.startsWith('html.rt-side-full '),'not switchable: '+sel);
    i=k;}
  assert.ok(blocks>=6,'rail blocks found: '+blocks);
  const full=css.slice(css.indexOf('/* REV TORQ 2026-10-30: full side menu'));
  assert.match(full,/@media \(min-width:1024px\) and \(max-width:1366px\)\{[\s\S]*html\.rt-side-full #appContainer\.rt-reference-ui #sidebar\{width:216px!important;min-width:216px!important\}/);
  assert.match(full,/html\.rt-side-full #appContainer\.rt-reference-ui #mainNav \.rt-nav-item\{min-height:44px/);
  assert.match(css,/#appContainer\.rt-reference-ui #mainNav \.rt-nav-sep>span\{display:block/);
});
