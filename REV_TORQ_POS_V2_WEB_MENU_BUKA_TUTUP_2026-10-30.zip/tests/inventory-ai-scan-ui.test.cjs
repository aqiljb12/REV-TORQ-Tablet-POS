const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const vm=require('vm');
const root=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
const ui=read('js/rt-admin-inventory-control.js');
const css=read('css/rt-admin-inventory-control.css');
// the AI scan flow (states, timeout, errors, BATAL) up to the receipt lines, without the photo resize (needs a canvas)
const code=ui.slice(ui.indexOf('// AI scan states shown in #rticAiDraftPanel'),ui.indexOf('function drawLines(){'));

function harness(invoke,{fireTimeout=false,clock=null}={}){
  const els={};
  const el=id=>els[id]||(els[id]={id,innerHTML:'',textContent:'',value:'',onclick:null,onchange:null,firstElementChild:null,classList:{toggle(){}},querySelectorAll:()=>[],scrollIntoView(){},click(){this.clicked=(this.clicked||0)+1;}});
  const toasts=[],statuses=[];
  const ctx={s:{products:[{id:'p1',sku:'MO-1',name:'MINYAK',category:'MINYAK'}],suppliers:[],lines:[],aiDraft:null,aiBusy:false,ai:{state:'idle'},aiToken:0},
    $:el,escape:v=>String(v??''),norm:v=>String(v||'').trim().toUpperCase(),cash:v=>'RM '+v,admin:()=>true,
    toast:(m,t)=>toasts.push([t,m]),status:m=>statuses.push(m),confirm:()=>true,aiMatchProduct:r=>r.supplier_sku==='MO-1'?'p1':'',
    aiPhotoDataURL:async()=>'data:image/jpeg;base64,'+'A'.repeat(4000),drawLines(){},
    sb:{functions:{invoke}},document:{querySelector:()=>({classList:{toggle(){}}})},
    setTimeout:(fn,ms)=>{if(fireTimeout&&ms===150000)Promise.resolve().then(fn);return 1;},setInterval:()=>1,clearInterval(){},Date:clock?{now:()=>clock.t}:Date,Math,Promise,String,Number,Array,Object,Error,JSON};
  vm.createContext(ctx);vm.runInContext(code,ctx);
  ctx.panel=()=>el('rticAiDraftPanel').innerHTML;
  return Object.assign(ctx,{toasts,statuses,els});
}
const flush=()=>new Promise(r=>setImmediate(r));

test('AI scan: no answer within 150 s = clear message on screen, the photo buttons unlock again',async()=>{
  const h=harness(()=>new Promise(()=>{}),{fireTimeout:true});
  await h.aiReadInvoiceImage({});
  assert.equal(h.s.ai.state,'error');
  assert.equal(h.s.aiBusy,false);
  assert.match(h.panel(),/AI tidak dapat membaca invois/);
  assert.match(h.panel(),/belum jawab selepas 150 saat/);
  assert.match(h.panel(),/AMBIL SEMULA/);
  assert.ok(h.toasts.some(([t,m])=>t==='error'&&/150 saat/.test(m)));
});

test('AI scan: a server error code is explained and stays on screen (it used to be wiped straight away)',async()=>{
  const h=harness(async()=>({data:null,error:{name:'FunctionsHttpError',message:'non-2xx',context:{status:502,json:async()=>({error:'AI_SERVICE_FAILED'})}}}));
  await h.aiReadInvoiceImage({});
  assert.match(h.panel(),/OpenAI API gagal/);
  assert.match(h.panel(),/Tiada stok diubah/);
  h.renderAiDraft();                                   // a later re-render (tab switch) keeps it
  assert.match(h.panel(),/OpenAI API gagal/);
});

const NET={name:'FunctionsFetchError',message:'Failed to send a request to the Edge Function'};
const okInvoice={data:{invoice:{items:[{description:'MINYAK',supplier_sku:'MO-1',quantity:1,unit_cost:2}]}},error:null};
test('AI scan: server time limit (504, no JSON) and the new server AI_TIMEOUT get their own message',async()=>{
  let h=harness(async()=>({data:null,error:{name:'FunctionsHttpError',message:'non-2xx',context:{status:504,json:async()=>{throw new Error('x')}}}}));
  await h.aiReadInvoiceImage({});assert.match(h.panel(),/terlalu lama \(had masa server\)/);
  h=harness(async()=>({data:null,error:{name:'FunctionsHttpError',message:'non-2xx',context:{status:504,json:async()=>({error:'AI_TIMEOUT'})}}}));
  await h.aiReadInvoiceImage({});assert.match(h.panel(),/tidak siap membaca dalam had masa server \(~2 minit\)/);
});

test('AI scan "network error": a ping finds out why — function unreachable vs. server cut a long request',async()=>{
  // function not reachable at all: the ping fails too, no resend
  let sent=[];let h=harness(async(n,o)=>{sent.push(o.body.ping?'ping':'photo');return {data:null,error:NET};});
  await h.aiReadInvoiceImage({});
  assert.match(h.panel(),/tidak dapat dihubungi langsung/);assert.deepEqual(sent,['photo','ping']);
  // the photo request failed after 95 s but the function answers a ping: the server cut it, not the Wi-Fi; no resend
  const clock={t:1000};sent=[];
  h=harness(async(n,o)=>{sent.push(o.body.ping?'ping':'photo');if(o.body.ping)return {data:{ok:true,ping:true},error:null};clock.t+=95000;return {data:null,error:NET};},{clock});
  await h.aiReadInvoiceImage({});
  assert.match(h.panel(),/sambungan diputuskan oleh server, bukan Wi-Fi anda/);assert.match(h.panel(),/gagal selepas 95 saat/);
  assert.deepEqual(sent,['photo','ping']);
  // the ping tells the real reason (key missing) instead of "network"
  h=harness(async(n,o)=>o.body.ping?{data:null,error:{name:'FunctionsHttpError',message:'x',context:{status:503,json:async()=>({error:'OPENAI_API_KEY_NOT_CONFIGURED'})}}}:{data:null,error:NET});
  await h.aiReadInvoiceImage({});assert.match(h.panel(),/OPENAI_API_KEY dalam Supabase Secrets/);
});

test('AI scan "network error" after a few seconds: resent once automatically (works with the old function too)',async()=>{
  let sent=[];
  // old deployed function: a ping is answered 400 PHOTO_INVALID_OR_TOO_LARGE = alive
  let h=harness(async(n,o)=>{sent.push(o.body.ping?'ping':'photo');if(o.body.ping)return {data:null,error:{name:'FunctionsHttpError',message:'x',context:{status:400,json:async()=>({error:'PHOTO_INVALID_OR_TOO_LARGE'})}}};return sent.filter(x=>x==='photo').length===1?{data:null,error:NET}:okInvoice;});
  await h.aiReadInvoiceImage({});
  assert.deepEqual(sent,['photo','ping','photo']);assert.equal(h.s.ai.state,'draft');
  sent=[];h=harness(async(n,o)=>{sent.push(o.body.ping?'ping':'photo');return o.body.ping?{data:{ok:true},error:null}:{data:null,error:NET};});
  await h.aiReadInvoiceImage({});
  assert.deepEqual(sent,['photo','ping','photo'],'only one resend');
  assert.match(h.panel(),/Sambungan terputus semasa menghantar gambar \(2 kali\)/);
  assert.match(h.panel(),/Jangan kunci skrin/);
});

test('AI scan: BATAL ignores the late answer; a new photo is refused while one is being read',async()=>{
  let release;const h=harness(()=>new Promise(r=>{release=r;}));
  const run=h.aiReadInvoiceImage({});await flush();
  assert.equal(h.s.ai.state,'busy');
  assert.match(h.panel(),/AI sedang membaca invois/);
  assert.match(h.panel(),/KB dihantar/);
  await h.aiReadInvoiceImage({});
  assert.ok(h.toasts.some(([,m])=>/masih membaca/.test(m)),'second photo refused while busy');
  h.aiCancel();
  release({data:{invoice:{items:[{description:'MINYAK',supplier_sku:'MO-1',quantity:1,unit_cost:2}]}},error:null});await run;
  assert.equal(h.s.aiDraft,null);
  assert.equal(h.s.ai.state,'idle');
  assert.equal(h.panel(),'');
  assert.ok(h.statuses.some(m=>/dibatalkan/.test(m)));
});

test('AI scan: a good answer opens the review (matched by SKU), nothing is posted to stock',async()=>{
  const h=harness(async()=>({data:{invoice:{supplier_name:'X',invoice_number:'INV-1',items:[{description:'MINYAK',supplier_sku:'MO-1',quantity:2,unit_cost:3.5,unit:'pcs'}]},needs_review:true},error:null}));
  await h.aiReadInvoiceImage({});
  assert.equal(h.s.ai.state,'draft');
  assert.equal(h.s.aiDraft.rows[0].product_id,'p1');
  assert.match(h.panel(),/SEMAK HASIL AI · BELUM SIMPAN STOK/);
  assert.equal(h.els.rticDo.value,'INV-1');
  assert.doesNotMatch(code,/rpc\(|\.insert\(|\.update\(|\.delete\(/,'the AI flow never writes data');
});

test('Inventory Control layout: tabs never shrink, full screen on tablets / phones, finger-sized on touch',()=>{
  const block=css.slice(css.indexOf('/* REV TORQ 2026-10-28 iPad / phone'));
  assert.match(block,/\.rtic-top,\.rtic-tabs,\.rtic-foot\{flex:none\}/);
  assert.match(block,/@media \(max-width:1366px\),\(any-pointer:coarse\)\{[\s\S]*\.rtic-shell\{width:100%;max-width:none;height:100vh;height:100dvh;max-height:none;border-radius:0/);
  assert.match(block,/\.rtic-tabs button\{min-height:44px/);
  const coarse=block.slice(block.indexOf('@media (any-pointer:coarse){'));
  assert.match(coarse,/\.rtic-table button\{min-height:40px/);
  assert.match(coarse,/font-size:16px;min-height:44px/);
  assert.match(read('css/rt-polish.css'),/#toast\{z-index:22000!important\}/,'messages show above Inventory Control (15500)');
});
