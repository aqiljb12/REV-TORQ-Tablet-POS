/* Runs supabase/functions/rt-ai-invoice-scan/index.ts in node with a fake Supabase + fake OpenAI (no network).
   Needs the "typescript" package to strip the types; skipped when it is not installed. */
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const vm=require('vm');
let ts=null;try{ts=require('typescript');}catch(_){}
const src=fs.readFileSync(path.join(__dirname,'../supabase/functions/rt-ai-invoice-scan/index.ts'),'utf8');

function load({env={},openai}){
  const js=ts.transpileModule(src.replace(/^import \{ createClient \} from 'npm:@supabase\/supabase-js@2';$/m,'const { createClient } = __deps;'),
    {compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None}}).outputText;
  let handler=null;const calls=[];const timers=[];
  const E=Object.assign({SUPABASE_URL:'https://x.supabase.co',SUPABASE_SERVICE_ROLE_KEY:'srv',OPENAI_API_KEY:'sk-test'},env);
  const staffQ={select(){return this},eq(){return this},is(){return this},limit(){return this},async maybeSingle(){return {data:{id:'s1',role:'admin'},error:null}}};
  const ctx={__deps:{createClient:()=>({auth:{getUser:async()=>({data:{user:{id:'u1'}},error:null})},from:()=>staffQ})},
    Deno:{env:{get:k=>E[k]},serve:h=>{handler=h;}},
    fetch:async(url,opt)=>{calls.push({url,body:JSON.parse(opt.body),signal:opt.signal});return openai(opt,calls.length);},
    setTimeout:(fn,ms)=>{timers.push({fn,ms});return timers.length;},clearTimeout(){},
    Response,Request,AbortController,JSON,Math,Number,String,Array,Object,Date,Promise,console:{log(){},error(){}}};
  vm.createContext(ctx);vm.runInContext(js,ctx);
  const send=body=>handler(new Request('https://x.supabase.co/functions/v1/rt-ai-invoice-scan',{method:'POST',headers:{Authorization:'Bearer jwt','content-type':'application/json'},body:JSON.stringify(body)}));
  return {send,calls,timers};
}
const photo='data:image/jpeg;base64,'+'A'.repeat(400);
const okAI=()=>new Response(JSON.stringify({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify({supplier_name:'A',invoice_number:'1',invoice_date:null,currency:'MYR',invoice_total:10,items:[{description:'X',supplier_sku:null,barcode:null,quantity:1,unit_cost:10,line_total:10,unit:'pcs'}],warnings:[]})}]}]}),{status:200,headers:{'content-type':'application/json'}});

test('edge: { ping: true } answers at once (with CORS) and never calls OpenAI',{skip:!ts&&'typescript not installed'},async()=>{
  const h=load({openai:okAI});
  const r=await h.send({ping:true});
  assert.equal(r.status,200);
  assert.deepEqual(await r.json(),{ok:true,ping:true});
  assert.equal(r.headers.get('access-control-allow-origin'),'*');
  assert.equal(h.calls.length,0);
});

test('edge: an OpenAI call that hangs is stopped at 120 s and answered AI_TIMEOUT (504, with CORS) instead of being cut by the platform',{skip:!ts&&'typescript not installed'},async()=>{
  const h=load({openai:opt=>new Promise((_,rej)=>{opt.signal.addEventListener('abort',()=>rej(Object.assign(new Error('aborted'),{name:'AbortError'})));})});
  const pending=h.send({image_data_url:photo});
  await new Promise(r=>setImmediate(r));
  const t=h.timers.find(x=>x.ms===120000);assert.ok(t,'a 120 s limit is set: '+h.timers.map(x=>x.ms));
  t.fn();
  const r=await pending;
  assert.equal(r.status,504);
  assert.equal((await r.json()).error,'AI_TIMEOUT');
  assert.equal(r.headers.get('access-control-allow-origin'),'*');
});

test('edge: OPENAI_INVOICE_TIMEOUT_MS is kept between 20 s and 140 s (under the platform limit)',{skip:!ts&&'typescript not installed'},async()=>{
  for(const [v,want] of [['5000',20000],['90000',90000],['999999',140000]]){
    const h=load({env:{OPENAI_INVOICE_TIMEOUT_MS:v},openai:okAI});
    await h.send({image_data_url:photo});
    assert.ok(h.timers.some(x=>x.ms===want),v+' -> '+h.timers.map(x=>x.ms));
  }
});

test('edge: a normal scan still returns the invoice; reasoning effort only for o-series / gpt-5 models',{skip:!ts&&'typescript not installed'},async()=>{
  let h=load({openai:okAI});
  let r=await h.send({image_data_url:photo});
  assert.equal(r.status,200);
  const d=await r.json();assert.equal(d.invoice.items.length,1);assert.equal(d.needs_review,true);
  assert.equal(h.calls[0].body.model,'gpt-4o-mini');assert.equal(h.calls[0].body.reasoning,undefined);
  assert.ok(h.calls[0].signal,'the OpenAI request can be stopped');
  h=load({env:{OPENAI_INVOICE_MODEL:'gpt-5-mini'},openai:okAI});await h.send({image_data_url:photo});
  assert.deepEqual(h.calls[0].body.reasoning,{effort:'low'});
  h=load({openai:()=>new Response('boom',{status:500})});r=await h.send({image_data_url:photo});
  assert.equal(r.status,502);assert.equal((await r.json()).error,'AI_SERVICE_FAILED');
});
