const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const vm=require('vm');
const path=require('path');
const root=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
const html=read('index.html');

test('tablet fix: the correction bar is not shown for the POS cash box or the POS search box',()=>{
  const s=read('js/rt-input-correction.js');
  assert.match(s,/const SKIP='#posAmountReceived,#posSearch,\[data-rt-no-correct\]';/);
  assert.match(s,/if\(el\.matches\(SKIP\)\) return false;/);
});

test('tablet fix: the bar is placed by score, never on the field being typed in, pay / save buttons weigh most',()=>{
  const s=read('js/rt-input-correction.js');
  assert.match(s,/const KEY='#btnCheckout,#rtqSave,#rtqTemp,\.rt-btn-primary/);
  assert.match(s,/let s=overlap\(r,f\)\?100000:0;/,'a spot on the field itself is ruled out');
  assert.match(s,/toolbar\.style\.left=Math\.round\(best\.x\)\+'px';/);
  assert.match(s,/toolbar\.style\.top=Math\.round\(best\.y\)\+'px';/);
  assert.match(s,/document\.addEventListener\('scroll',placeSoon,true\)/,'moves again when a page scrolls');
  assert.match(s,/visualViewport\.addEventListener\('resize',placeSoon\)/,'moves again when the keyboard opens');
  assert.doesNotMatch(s,/\.delete\(|\.from\(|\.rpc\(|localStorage/);
  assert.doesNotMatch(s,/\?\./,'no optional chaining (older iPad Safari)');
  const css=read('css/rt-polish.css');
  assert.match(css,/#rtCorrectionToolbar\{right:auto;bottom:auto\}/,'the old bottom-right anchor is switched off');
});

test('tablet fix: UNDO keeps every removal since the cart was cleared (newest first back)',()=>{
  const src=read('js/pos.js');
  const code=src.slice(src.indexOf('let rtCartLastRemoved = null;'),src.indexOf('// V2 polish: two-line cart rows'));
  const ctx={posCart:[{sku:'A',name:'Minyak',qty:3,discount:1},{sku:'B',name:'Tayar',qty:1,discount:0},{sku:'C',name:'Rantai',qty:2,discount:0}],renderCart:()=>{},rtPosPromo:null,rtSchedulePromoRevalidate:()=>{},rtCartEsc:v=>v,window:{}};
  vm.createContext(ctx);vm.runInContext(code,ctx);
  ctx.rtCartRemove('A');ctx.rtCartRemove('C');
  assert.deepEqual(ctx.posCart.map(x=>x.sku),['B']);
  assert.match(vm.runInContext('rtCartUndoHtml()',ctx),/Rantai dibuang daripada troli \(\+1 lagi\)/);
  ctx.rtCartUndoRemove();
  assert.deepEqual(ctx.posCart.map(x=>x.sku),['B','C']);
  ctx.rtCartUndoRemove();
  assert.deepEqual(ctx.posCart.map(x=>[x.sku,x.qty,x.discount]),[['A',3,1],['B',1,0],['C',2,0]],'the first removal is not lost');
  assert.equal(vm.runInContext('rtCartUndoHtml()',ctx),'');
  for(let i=0;i<12;i++){ctx.posCart.push({sku:'X'+i,name:'X',qty:1,discount:0});ctx.rtCartRemove('X'+i);}
  assert.equal(vm.runInContext('rtCartRemoved.length',ctx),10,'at most 10 kept');
  ctx.posClearCart();ctx.rtCartUndoRemove();
  assert.equal(ctx.posCart.length,0,'a cleared cart cannot bring back old lines');
  assert.match(src,/window\.rtSetPosCart = \(v\) => \{[^}]*rtCartRemoved = \[\];/,'switching / restoring an order also clears the undo list');
});

test('tablet fix: files changed since the 2026-10-09 release carry a newer ?v= (later releases may raise it again), and the app version matches the service worker',()=>{
  // the versions in the 2026-10-27 WhatsApp-resit build, before the tablet fix
  const old={'js/customers.js':'37.0.4-override','js/stable-fixes.js':'1.0.2-override','js/rt-override.js':'2.4.0-override','css/rt-polish.css':'2.8.0-audit','js/pos.js':'37.0.8-audit&wa_points=20261027','js/rt-input-correction.js':'20261027-fix-keyin','js/rt-offline.js':'2.5.0-offline'};
  for(const f of ['js/customers.js','js/stable-fixes.js','js/rt-override.js','css/rt-polish.css','js/pos.js','js/rt-input-correction.js','js/rt-offline.js']){
    const m=new RegExp(f.replace(/[.\/]/g,'\\$&')+'\\?v=([^"]+)"').exec(html);
    assert.ok(m,f+' is loaded with a ?v=');
    if(old[f])assert.notEqual(m[1],old[f],f+' version raised');
  }
  const sw=/var BUILD='([^']+)'/.exec(read('sw-notify.js'))[1],app=/var BUILD='([^']+)'/.exec(read('js/rt-offline.js'))[1];
  assert.equal(sw,app);
  assert.notEqual(sw,'2026-10-09-quotes');
});

test('tablet fix: finger-sized controls only on touch screens (mouse screens unchanged)',()=>{
  const css=read('css/rt-polish.css');
  const block=css.slice(css.indexOf('/* REV TORQ tablet fix (2026-10-27)'));
  const coarse=block.slice(block.indexOf('@media (any-pointer:coarse){'));
  for(const sel of ['#rtCorrectionToolbar button{min-height:40px','#view-pos .rt-cart-remove{height:40px!important}','#view-pos .rt-cart-undo button{min-height:40px','#view-inventory [data-rt-quick-restock]{min-height:40px','#rtPurchaseSettingsButton{min-height:40px!important','#tblStaff td button,#view-suppliers td button{min-height:40px'])
    assert.ok(coarse.includes(sel),sel);
});

test('tablet fix: the customer list works where window is not defined (tests), same result in the browser',()=>{
  const s=read('js/customers.js');
  assert.ok(s.includes("(typeof window!=='undefined'&&typeof window.rtHasAdminAccess==='function'&&window.rtHasAdminAccess())"));
  assert.ok(!s.includes('window.rtHasAdminAccess?.()'));
});
