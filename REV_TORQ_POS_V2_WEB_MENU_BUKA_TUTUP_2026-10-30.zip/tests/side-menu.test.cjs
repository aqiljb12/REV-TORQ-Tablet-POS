const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const vm=require('vm');
const root=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
const core=read('js/core.js'),css=read('css/rt-polish.css'),html=read('index.html');

function sideMode(width,closed){
  const code=core.slice(core.indexOf('        let rtSidePeeking = false;'),core.indexOf('        function rtNavMoreOpen() {'));
  const cls=new Set(),store=new Map(closed?[['rt_side_open','0']]:[]);const listeners={},docListeners={};
  const btn={attrs:{},title:'',setAttribute(k,v){this.attrs[k]=v;}};
  const win={innerWidth:width,addEventListener:(t,f)=>{listeners[t]=f;},dispatchEvent:()=>{}};
  const ctx={window:win,localStorage:{getItem:k=>store.has(k)?store.get(k):null,setItem:(k,v)=>store.set(k,v)},Event:class{},setTimeout:f=>f(),
    document:{addEventListener:(t,f)=>{docListeners[t]=f;},documentElement:{classList:{toggle:(c,on)=>{on?cls.add(c):cls.delete(c);},contains:c=>cls.has(c)}},getElementById:id=>id==='rtSideModeBtn'?btn:null}};
  vm.createContext(ctx);vm.runInContext(code,ctx);
  const click=sel=>{let stopped=false;const ev={target:{closest:q=>q.split(',').map(x=>x.trim()).includes(sel)?{}:null},preventDefault(){},stopPropagation(){stopped=true;}};docListeners.click(ev);return stopped;};
  return {has:c=>cls.has(c),btn,store,win,listeners,docListeners,click,toggle:()=>win.rtToggleSideMode(),peek:on=>win.rtSidePeek(on)};
}

test('side menu: open by default — full menu from 1024 px, small icons in iPad portrait',()=>{
  let h=sideMode(1180);assert.ok(h.has('rt-side-full')&&!h.has('rt-side-closed'));assert.equal(h.btn.title,'Tutup menu (lebih ruang)');
  h=sideMode(1024);assert.ok(h.has('rt-side-full'));
  h=sideMode(820);assert.ok(!h.has('rt-side-full')&&!h.has('rt-side-closed'));
});

test('side menu: ▢ closes it for a full-width page, kept per device; phones ignore it',()=>{
  const h=sideMode(1180);h.toggle();
  assert.ok(h.has('rt-side-closed'));assert.equal(h.store.get('rt_side_open'),'0');
  assert.ok(sideMode(1180,true).has('rt-side-closed'),'remembered');
  assert.ok(sideMode(820,true).has('rt-side-closed'),'iPad portrait can close it too');
  assert.ok(!sideMode(390,true).has('rt-side-closed'),'phones keep their slide-in menu');
});

test('side menu: ☰ slides it over the page; picking a page / Esc closes it; ▢ in it keeps it open again',()=>{
  const h=sideMode(1180,true);
  assert.equal(h.click('[onclick*="toggleSidebar"]'),true,'☰ handled on tablets (phone drawer not used)');
  assert.ok(h.has('rt-side-peek')&&!h.has('rt-side-closed')&&h.has('rt-side-full'));assert.equal(h.btn.title,'Kekalkan menu terbuka');
  h.click('#mainNav [data-view]');assert.ok(!h.has('rt-side-peek')&&h.has('rt-side-closed'),'picking a page slides it away');
  h.peek(true);h.docListeners.keydown({key:'Escape'});assert.ok(!h.has('rt-side-peek'),'Esc');
  h.peek(true);h.toggle();assert.ok(!h.has('rt-side-closed')&&!h.has('rt-side-peek'));assert.equal(h.store.get('rt_side_open'),'1');
  const open=sideMode(1180);assert.equal(open.click('[onclick*="toggleSidebar"]'),false,'menu open: ☰ not intercepted');
  const phone=sideMode(390,true);assert.equal(phone.click('[onclick*="toggleSidebar"]'),false,'phone: ☰ left to the phone slide-in menu');
  // turning the iPad keeps the closed menu closed
  const r=sideMode(1180,true);r.win.innerWidth=820;r.listeners.resize();assert.ok(r.has('rt-side-closed')&&!r.has('rt-side-full'));
});

test('side menu: toggle button next to the logo; group headings in the menu',()=>{
  const brand=html.slice(html.indexOf('<aside id="sidebar"'),html.indexOf('<!-- User Profile -->'));
  assert.match(brand,/<button type="button" id="rtSideModeBtn" class="rt-side-mode-btn" onclick="window\.rtToggleSideMode && window\.rtToggleSideMode\(\)"/);
  assert.match(brand,/<i data-feather="sidebar"><\/i>/);
  assert.match(core,/const navGroups = \{ pos: 'Utama', sales: 'Jualan', jobcard: 'Bengkel & Stok', staff: 'Pengurusan' \};/);
});

test('side menu CSS: small-icon rules switch off with .rt-side-full; full menu from 1024 px; closed / slid-over menu',()=>{
  const heads=['@media (min-width:768px) and (max-width:1366px){','@media (min-width:768px) and (max-width:1366px) and (max-height:860px){'];
  let i=0,blocks=0;
  for(;;){const at=heads.map(h=>css.indexOf(h,i)).filter(x=>x>=0);if(!at.length)break;const p=Math.min(...at);
    let k=css.indexOf('{',p)+1,d=1;const b=k;while(d){if(css[k]==='{')d++;else if(css[k]==='}')d--;k++;}
    const body=css.slice(b,k-1);blocks++;
    for(const m of body.matchAll(/([^{}]+)\{[^{}]*\}/g))for(const sel of m[1].split(',').map(x=>x.trim()))
      if(!sel.startsWith('.rt-pos-mobile-menu'))assert.ok(sel.startsWith('html:not(.rt-side-full) ')||sel.startsWith('html.rt-side-full '),'not switchable: '+sel);
    i=k;}
  assert.ok(blocks>=6,'rail blocks found: '+blocks);
  const full=css.slice(css.indexOf('/* REV TORQ 2026-10-30: side menu like a desktop app'));assert.ok(full.length>500,'side menu CSS block found');
  assert.match(full,/@media \(min-width:1024px\) and \(max-width:1366px\)\{[\s\S]*html\.rt-side-full #appContainer\.rt-reference-ui #sidebar\{width:216px!important;min-width:216px!important\}/);
  assert.match(full,/html\.rt-side-closed #appContainer\.rt-reference-ui #sidebar\{display:none!important\}/);
  assert.match(full,/html\.rt-side-peek #appContainer\.rt-reference-ui #sidebar\{position:fixed!important/);
  assert.match(full,/html\.rt-side-closed #appContainer\.rt-reference-ui \.rt-pos-mobile-menu/);
  assert.match(full,/html\.rt-side-full #appContainer\.rt-reference-ui #mainNav \.rt-nav-item\{min-height:44px/);
  assert.match(css,/#appContainer\.rt-reference-ui #mainNav \.rt-nav-sep>span\{display:block/);
});
