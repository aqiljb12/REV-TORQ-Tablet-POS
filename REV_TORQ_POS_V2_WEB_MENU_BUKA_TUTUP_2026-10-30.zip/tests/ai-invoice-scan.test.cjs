/* REV TORQ | AI invoice scan safety / integration unit checks. No API calls. */
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),cp=require('child_process'),vm=require('node:vm');
const root=path.join(__dirname,'..');
const ui=fs.readFileSync(path.join(root,'js/rt-admin-inventory-control.js'),'utf8');
const edge=fs.readFileSync(path.join(root,'supabase/functions/rt-ai-invoice-scan/index.ts'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
let n=0;
function test(description,pass){assert.ok(pass,description);n++}
test('POS integration JS syntax valid',cp.spawnSync(process.execPath,['--check',path.join(root,'js/rt-admin-inventory-control.js')]).status===0);
test('photo capture enabled',ui.includes('id="rticAiCamera"')&&ui.includes('capture="environment"'));
test('photo gallery enabled',ui.includes('id="rticAiGallery"'));
test('photo data URL resized with canvas before upload (2026-10-29: what the AI reads — long 2048, short 1100, 1.6 MP, JPEG 0.8)',ui.includes('max=2048,short=1100')&&ui.includes('1600000')&&ui.includes("toDataURL('image/jpeg',0.8)"));
test('edge stops a slow OpenAI call itself (AbortController, AI_TIMEOUT) and answers a ping without the AI',edge.includes('new AbortController()')&&edge.includes("error: 'AI_TIMEOUT'")&&edge.includes('body?.ping === true'));
test('function invoked via authenticated supabase client',ui.includes("sb.functions.invoke('rt-ai-invoice-scan'"));
test('AI result not posted without admin confirmation',ui.includes('PINDAH BARANG KE DRAF STOK MASUK')&&ui.includes('SAHKAN STOK MASUK'));
test('uses same existing inventory receipt RPC',ui.includes("rpc('rt_inv_admin_receive'"));
test('does not auto create stock product',!ui.includes("from('products').insert") && !ui.includes("from('stock_movements').insert"));
test('AI key stored only server-side',!ui.includes('OPENAI_API_KEY') || ui.includes('OPENAI_API_KEY_NOT_CONFIGURED'));
test('edge requires auth JWT',edge.includes('admin.auth.getUser(jwt)'));
test('edge validates staff admin role',edge.includes("['admin','owner','super_admin']"));
test('edge never mutates inventory',!edge.includes('.insert(')&&!edge.includes('.update(')&&!edge.includes('.delete('));
test('edge uses OpenAI Responses with structured schema',edge.includes('/v1/responses')&&edge.includes("type: 'json_schema'")&&edge.includes('strict: true'));
test('edge provider key from secret',edge.includes("Deno.env.get('OPENAI_API_KEY')"));
test('edge avoids response storage',edge.includes('store: false'));
test('invoice photo checks size and MIME',edge.includes('PHOTO_INVALID_OR_TOO_LARGE')&&edge.includes('PHOTO_TOO_LARGE'));
test('old POS inventory modules preserved',html.includes('js/rt-purchase-points.js')&&html.includes('js/rt-inventory-delete-duplicate.js'));
// Exact matching: no fuzzing / no auto match if only partial description.
const matcher=ui.slice(ui.indexOf('function aiMatchProduct(row){'),ui.indexOf('async function aiPhotoDataURL(file)'));
assert.ok(matcher.startsWith('function aiMatchProduct(row){'));
const ctx={s:{products:[{id:'a',sku:'MOTUL51001550',barcode:'3374650399225',name:'MOTUL 5100 15/50',category:'MINYAK'},{id:'b',sku:'SP-NGK-CR8E',barcode:'777777777777',name:'NGK SPARK PLUG CR8E',category:'SPAREPART'},{id:'c',sku:'SERVICECVTOVERHUL',barcode:'',name:'SERVICE CVT FULL',category:'SERVIS'}]},norm:v=>String(v||'').normalize('NFKC').replace(/\s+/g,' ').trim().toUpperCase()};
vm.createContext(ctx);vm.runInContext(matcher,ctx);
test('match exact SKU',ctx.aiMatchProduct({supplier_sku:' motul51001550 ',barcode:'',description:'Motor oil'})==='a');
test('match exact barcode',ctx.aiMatchProduct({supplier_sku:'',barcode:'3374650399225',description:'something'})==='a');
test('match exact normalized name',ctx.aiMatchProduct({supplier_sku:'',barcode:'',description:'ngk spark plug CR8E'})==='b');
test('partial name not auto matched',ctx.aiMatchProduct({supplier_sku:'',barcode:'',description:'MOTUL 5100'})==='');
test('cannot import a service as inventory',ctx.aiMatchProduct({supplier_sku:'SERVICECVTOVERHUL',barcode:'',description:'SERVICE CVT FULL'})==='');
console.log(`${n}/${n} AI Invoice integration checks passed`);
