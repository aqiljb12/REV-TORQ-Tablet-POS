# TEST RESULTS — Menu + iPad / telefon (2026-10-28)

Base: `REV_TORQ_LATE_ENTRY_DEPLOY` (ZIP pengguna). Semua ujian dijalankan dengan Supabase **simulasi** (mock), bukan
pangkalan data sebenar. Tiada sambungan ke Supabase anda.

## Node (dalam ZIP ini)

`node --test tests/*.test.cjs tests/*.pglite.cjs tests/test_duplicate_inventory.cjs`

| | |
|---|---|
| Jumlah | 128 |
| Lulus | 126 |
| Gagal | 0 |
| Skip | 2 (`pos-customer-link`: folder Customer PWA tiada dalam pakej ini; set `REVTORQ_PWA_DIR` untuk jalankan) |

Baharu: `tests/menu-tablet.test.cjs` (6 ujian). Ia menyemak:
- susunan menu dan kumpulan;
- Jualan Tertinggal hanya untuk Admin;
- kedudukan AI Hub;
- `rt-polish.js` kekal fail terakhir;
- versi `?v=` dan BUILD;
- butang sentuh;
- tiada panggilan Supabase dalam kod menu.

Dikemas kini:
- `tests/tablet-fix.test.cjs` dan `tests/quotation-ui.test.cjs` tidak lagi mengunci nombor versi tepat. Ia kini menyemak bahawa versi telah dinaikkan.
- `tests/test_inventory_mobile_css.py`: lulus.

## Ujian pelayar (Chromium, saiz iPad / telefon / laptop, skrin sentuh)

| Suite | Keputusan |
|---|---|
| Menu + iPad/telefon (baharu, 7 saiz + juruwang) | 180 / 180 |
| Semua halaman × 6 saiz (ralat, skrol ke tepi, butang < 32 px) | 84 semakan, 0 isu |
| Toolbar pembetulan / BAYAR tidak ditutup (tabfix) | 192 / 192 |
| Sebut Harga | 216 / 216 |
| POS audit fixes (fixes9) | 114 / 0 |
| Motosikal di POS | 72 / 0 |
| Ruang troli | 182 / 0 |
| Resit | 57 / 0 |
| Pesanan serentak | 88 / 0 |
| Park | 31 / 31 |
| Interaksi (interact) | 57 / 57 |
| WhatsApp | 15 / 15 |
| Papan bengkel | 25 / 25 |
| Carian pantas | 25 / 25 |
| Pesan stok | 28 / 28 |
| Booking | 28 / 28 |
| Nama penuh | 63 / 0 |
| Tidy | 26 / 0 |
| Override | 109 / 0 |
| Offline | 59 / 0 |
| Pelanggan (layout) | 0 isu |
| Overlay | 0 tersangkut |
| Heal | resit OK |
| Barang Job Card | jualan dengan plat OK |
| Scanner | 0 ralat |

Hasil utama:
- **iPad 1024×768:** semua item menu muat tanpa skrol. Sebelum ini Tetapan dan "Lagi" terkeluar dari skrin, dan butang AI pecah.
- **Telefon 390×844:**
  - Menu muat tanpa skrol.
  - Butang ☰ di header 40 px. Sebelum ini 14 px.
  - Tajuk tidak bertindih dengan butang.
- **Butang 40 px pada skrin sentuh:**
  - baris Inventori (sebelum ini 30 px);
  - PILIH MOTO (sebelum ini 18 px);
  - AI Hub;
  - Jualan Tertinggal.
- **Juruwang:** menu tetap POS / Jualan / Quotation. Tiada Jualan Tertinggal, tiada AI Hub, dan buka terus Jualan Tertinggal ditolak.
- **Servis:**
  - Walk-in dengan labour ditolak sebelum sebarang jualan dihantar, dan troli kekal.
  - Dengan pelanggan + motosikal, jualan berjalan sekali dengan plat.

Ujian yang dikemas kini kerana peraturan baharu dalam ZIP anda (walk-in labour kini perlu pelanggan + plat):
- fixes9 (langkah labour);
- korpus `job-checkout-phase2` (guard plat ditambah, dan ujian baharu "tanpa guard = ditolak");
- `ipad-2026-10-03` (baris troli kini ada `category`, versi 37.1.x).

Ujian yang dikemas kini kerana susunan menu baharu:
- interact;
- korpus `pos-v2-polish`.

## Korpus (ujian lama + ZIP)

229 / 232 lulus, 2 skip.

Gagal 1: "root, Android assets and WAB_DEPLOY runtime files are identical". Ini salinan Android, tiada dalam pakej web, dan sama seperti keluaran sebelum ini.

## TIDAK diuji / perlu semak sendiri

- **iPad / telefon sebenar:** semua ujian dijalankan di Chromium dengan saiz dan sentuhan iPad. Safari sebenar dan papan kekunci sebenar tidak diuji.
- **Jualan Tertinggal (SQL `rt_late_sale_*`) dan AI Hub (Edge Function `rt-ai-ops-assistant`):** diuji dengan simulasi sahaja. SQL dan Edge Function tiada dalam ZIP anda.
- **Semakan plat dengan jadual `vehicles` sebenar:** hanya diuji dengan simulasi.
