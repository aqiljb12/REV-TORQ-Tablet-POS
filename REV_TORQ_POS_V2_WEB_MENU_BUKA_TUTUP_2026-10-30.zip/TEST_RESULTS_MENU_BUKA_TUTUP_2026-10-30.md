# TEST RESULTS — Menu tepi boleh buka / tutup (2026-10-30, kemas kini ke-2)

Semua ujian guna Supabase **simulasi**. Tiada sambungan ke Supabase sebenar.

## Node (dalam ZIP ini)

`node --test tests/*.test.cjs tests/*.pglite.cjs tests/test_duplicate_inventory.cjs`

| | |
|---|---|
| Jumlah | 145 |
| Lulus | 143 |
| Gagal | 0 |
| Skip | 2 (folder Customer PWA tiada) |

`tests/side-menu.test.cjs` ditulis semula (5 ujian). Ia menyemak:
- terbuka secara lalai;
- ▢ menutup menu dan pilihan diingat; telefon tidak terjejas;
- ☰ membuka laci di atas halaman;
- pilih halaman atau Esc menutup laci;
- "Kekalkan menu terbuka" berfungsi;
- pusing iPad mengekalkan menu tertutup;
- CSS.

## Pelayar (Chromium, saiz iPad 10 / iPad 9.7 / potret / laptop / skrin besar / telefon)

| Suite | Keputusan |
|---|---|
| Menu buka / tutup / laci (baharu) | 86 / 86 |
| Semua halaman dengan menu tertutup (☰ ada, lebar penuh, tiada skrol ke tepi, tiada ralat) × 3 saiz | 42 / 42 |
| Menu + iPad/telefon | 180 / 180 |
| Semua halaman × 6 saiz | 84 semakan, 0 ralat, 0 skrol ke tepi |
| Toolbar pembetulan (tabfix) | 192 / 192 |
| Inventory Control + AI scan | 209 / 209 |
| Sebut Harga | 216 / 216 |
| Regression penuh | fixes9 114, motosikal 72, troli 182, resit 57, pesanan 88, park 31, interact 57, WhatsApp 15, papan 25, carian 25, pesan stok 28, booking 28, nama penuh 63, tidy 26, override 109, offline 59. Semua 0 gagal. Pelanggan 0 isu, overlay 0 tersangkut, heal / barang job / scanner OK |

Hasil utama: **menu ditutup → kawasan barang POS lebih lebar** pada setiap saiz:

| Skrin | Menu terbuka | Menu ditutup |
|---|---|---|
| iPad 1180×820 | 3 lajur | 4 lajur |
| iPad 1024×768 | 2 lajur | 3 lajur |
| Laptop 1366 / 1440 | — | lajur bertambah |
| iPad potret | 4 lajur | 4 lajur, kad lebih lebar |

BAYAR kekal kelihatan dalam semua keadaan di atas.

## Korpus

246 / 249 lulus, 2 skip.

Gagal 1: salinan Android, sama seperti sebelum ini.

## TIDAK diuji

- **iPad sebenar (Safari):** semua ujian guna Chromium dengan saiz dan sentuhan iPad.
