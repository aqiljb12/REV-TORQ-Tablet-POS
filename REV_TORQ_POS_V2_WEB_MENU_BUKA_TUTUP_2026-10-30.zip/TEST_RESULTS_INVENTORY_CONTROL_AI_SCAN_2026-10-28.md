# TEST RESULTS — Inventory Control penuh skrin + AI scan invois (2026-10-28, kemas kini ke-2)

Semua ujian guna Supabase **simulasi**. Tiada sambungan ke Supabase atau OpenAI sebenar.

## Node (dalam ZIP ini)

`node --test tests/*.test.cjs tests/*.pglite.cjs tests/test_duplicate_inventory.cjs`

| | |
|---|---|
| Jumlah | 134 |
| Lulus | 132 |
| Gagal | 0 |
| Skip | 2 (folder Customer PWA tiada dalam pakej ini) |

Baharu: `tests/inventory-ai-scan-ui.test.cjs` (6 ujian, jam palsu). Ia menyemak:
- tiada jawapan dalam 150 saat menghasilkan mesej di skrin;
- ralat server kekal di skrin walaupun dipapar semula;
- 504 dan putus sambungan ada mesej sendiri;
- BATAL mengabaikan jawapan lewat;
- gambar kedua ditolak semasa sibuk;
- hasil yang baik membuka jadual semakan tanpa menulis data;
- CSS penuh skrin dan tab.

`tests/test_inventory_mobile_css.py`: lulus.

## Pelayar (Chromium, saiz iPad 10 / iPad 9.7 / potret / telefon / laptop / skrin besar)

| Suite | Keputusan |
|---|---|
| Inventory Control + AI scan (baharu) | 143 / 143 |
| Menu + iPad/telefon | 180 / 180 |
| Toolbar pembetulan (tabfix) | 192 / 192 |
| Sebut Harga | 216 / 216 |
| Regression penuh | fixes9 114, motosikal 72, troli 182, resit 57, pesanan 88, park 31, interact 57, WhatsApp 15, papan 25, carian 25, pesan stok 28, booking 28, nama penuh 63, tidy 26, override 109, offline 59 — semua 0 gagal; pelanggan 0 isu, overlay 0 tersangkut, heal / barang job / scanner OK |

Hasil utama Inventory Control (sebelum → selepas):
- **Saiz tetingkap:** sebelum ini berubah ikut tab (601, 779, 404 px tinggi). Sekarang penuh skrin 1180×820 pada setiap tab.
- **Baris tab:** sebelum ini mengecut ke 29 px (butang 24 px) pada Master Barang / Audit Stok. Sekarang 57 px (butang 44 px) pada semua tab.
- **Mesej toast semasa Inventory Control terbuka:** sebelum ini tersorok. Sekarang dipapar di atas, pada semua 6 saiz.
- **AI gagal:** sebelum ini panel kosong. Sekarang ada kotak merah dengan sebab, dan ia kekal di skrin. Diuji untuk ralat OpenAI, 504, putus sambungan dan "tiada baris".
- **Tukar tab semasa AI membaca:** sebelum ini status hilang. Sekarang kekal.
- **BATAL:** jawapan lewat diabaikan dan butang dibuka semula.
- **Gambar 12 MP:** dihantar 875 KB, ≤ 2048 px dan ~3.2 MP. Sebelum ini 2400 px, JPEG 0.88.
- **Semua kawalan pada skrin sentuh:** ≥ 40 px, dan kotak input 16 px.
- **Menu iPad:** "Lagi" bermula tertutup pada landskap. Telefon kekal ikut pilihan terakhir.

## Korpus (ujian lama + ZIP)

235 / 238 lulus, 2 skip.

Gagal 1: "root, Android assets and WAB_DEPLOY runtime files are identical". Ini salinan Android, tiada dalam pakej web, dan sama seperti sebelum ini.

## TIDAK diuji

- **OpenAI / Edge Function `rt-ai-invoice-scan` sebenar:** masa sebenar AI membaca dan ketepatan bacaan tidak diuji.
- **iPad sebenar:** kamera iPad dan Safari sebenar tidak diuji. Ujian guna Chromium dengan saiz dan sentuhan iPad.
