# TEST RESULTS — AI scan invois lebih stabil (2026-10-29)

Semua ujian guna Supabase dan OpenAI **simulasi**. Tiada sambungan ke Supabase atau OpenAI sebenar.

## Node (dalam ZIP ini)

`node --test tests/*.test.cjs tests/*.pglite.cjs tests/test_duplicate_inventory.cjs`

| | |
|---|---|
| Jumlah | 140 |
| Lulus | 138 |
| Gagal | 0 |
| Skip | 2 (folder Customer PWA tiada) |

Ujian `ai-invoice-edge` perlukan pakej `typescript`. Tanpanya, 4 ujian itu di-skip.

- **Baharu: `tests/ai-invoice-edge.test.cjs`** (4 ujian). Ia menjalankan fungsi Supabase `rt-ai-invoice-scan` sebenar dalam node:
  - ping dijawab tanpa OpenAI (ada header CORS);
  - OpenAI yang tergantung dihentikan pada 120 saat dan dijawab `AI_TIMEOUT` 504 (ada CORS);
  - had masa disimpan antara 20–140 s;
  - scan biasa tetap berjaya;
  - reasoning effort hanya untuk model o / gpt-5;
  - OpenAI 500 dijawab `AI_SERVICE_FAILED`.
- **`tests/inventory-ai-scan-ui.test.cjs`** (8 ujian, jam palsu):
  - fungsi tidak dapat dihubungi: ping gagal, tiada hantar semula;
  - gagal selepas 95 s dengan ping OK: "diputuskan oleh server, bukan Wi-Fi", tiada hantar semula;
  - ping beri sebab sebenar (`OPENAI_API_KEY`);
  - gagal cepat: hantar semula sekali sahaja. Ini berfungsi juga dengan fungsi lama (ping dijawab 400);
  - gagal 2 kali: "(2 kali)" + "Jangan kunci skrin";
  - `AI_TIMEOUT` daripada server: "~2 minit".
- **`tests/ai-invoice-scan.test.cjs`:** 23/23.

## Pelayar (Chromium, iPad 10 / iPad 9.7 / potret / telefon / laptop / skrin besar)

| Suite | Keputusan |
|---|---|
| Inventory Control + AI scan (termasuk ping / hantar semula / tidak dapat dihubungi / tiada API key / fungsi lama) | 209 / 209 |
| Menu + iPad/telefon | 180 / 180 |
| Regression penuh | fixes9 114, motosikal 72, troli 182, resit 57, pesanan 88, park 31, interact 57, WhatsApp 15, papan 25, carian 25, pesan stok 28, booking 28, nama penuh 63, tidy 26, override 109, offline 59. Semua 0 gagal. Pelanggan 0 isu, overlay 0 tersangkut, heal / barang job / scanner OK |

Saiz gambar dihantar (foto ujian 12 MP 4032×3024 yang "bising"): **283 KB**, ≤ 2048 px, sisi pendek ≤ 1100, ≤ 1.6 MP. Semalam 875 KB.

## Korpus

241 / 244 lulus, 2 skip.

Gagal 1: salinan Android, sama seperti sebelum ini.

## TIDAK diuji

- **Supabase / OpenAI sebenar:**
  - punca sebenar "network error" pada telefon anda;
  - masa AI sebenar;
  - had masa platform sebenar.
- **Deploy fungsi baharu:** belum dibuat. Ia pilihan, dan anda yang deploy.
