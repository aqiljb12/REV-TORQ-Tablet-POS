/* REV TORQ Admin POS — Jualan Tertinggal. Actual sales/payment recording via admin-only RPC. */
(function(w){
'use strict';
const $=id=>document.getElementById(id);
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const RM=n=>'RM '+Number(n||0).toLocaleString('en-MY',{minimumFractionDigits:2,maximumFractionDigits:2});
const state={catalog:[],items:[],busy:false,init:false,requestId:null,loaded:false,hasSaved:false};
const admin=()=>w.rtHasAdminAccess?.()===true&&['owner','admin','super_admin'].includes(String(w.currentProfile?.role||'').toLowerCase());
const notify=(m,t='info')=>{if(w.showToast)w.showToast(m,t);else alert(m)};
const today=()=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Kuala_Lumpur',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const yesterday=()=>{let d=new Date();d.setDate(d.getDate()-1);return new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Kuala_Lumpur',year:'numeric',month:'2-digit',day:'2-digit'}).format(d)};
const uuid=()=>w.crypto?.randomUUID?.()||'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>{const n=Math.floor(Math.random()*16);return(c==='x'?n:((n&3)|8)).toString(16)});
function markup(){return `<div class="rtle-overlay" id="rtLateEntryOverlay" hidden>
 <section class="rtle-modal" role="dialog" aria-modal="true" aria-label="Jualan Tertinggal">
  <header class="rtle-head"><div><small>REV TORQ PERFORMANCE · ADMIN</small><h2>Jualan Tertinggal</h2><p>Jualan sudah dibayar, tetapi belum key-in ke POS</p></div><button type="button" id="rtleClose" aria-label="Tutup">✕</button></header>
  <div class="rtle-tabs"><button id="rtleTabInput" data-tab="input" class="active">+ Rekod jualan</button><button id="rtleTabHistory" data-tab="history">Sejarah & laporan</button></div>
  <div id="rtleInput" class="rtle-body">
   <div class="rtle-info">✅ Pelanggan sudah bayar. Rekod ikut <b>tarikh bayaran sebenar</b>. Masa key-in kekal hari ini untuk audit. Cash drawer hari ini <b>tidak ditambah</b>.</div>
   <div class="rtle-fields"><label>Tarikh pelanggan bayar <input id="rtleDate" type="date" required></label><label>Kaedah bayaran <select id="rtleMethod"><option>CASH</option><option>QR</option><option>DUITNOW</option><option>CARD</option><option>TRANSFER</option><option>OTHER</option></select></label></div>
   <div class="rtle-fields"><label>Rujukan bayaran / transfer <input id="rtleRef" type="text" maxlength="120" placeholder="Wajib untuk QR, Card, Transfer"></label><label>No. plat motosikal (jika servis) <input id="rtlePlate" maxlength="16" autocomplete="off" placeholder="JXX 1234"></label></div>
   <label>Nota sebab rekod lambat <textarea id="rtleNote" maxlength="500" rows="2" placeholder="Contoh: Kedai sibuk semalam, jualan tunai belum dimasukkan"></textarea></label>
   <div class="rtle-items-head"><strong>Barang / servis yang telah dibayar</strong><span>Harga boleh dilaras oleh Admin; semua perubahan ada rekod</span></div>
   <div class="rtle-fields"><label>Pilih barang <select id="rtleProduct"><option value="">Memuatkan inventori...</option></select></label><label>Kuantiti <input type="number" id="rtleQty" min="0.001" max="1000" step="1" value="1"></label></div>
   <button type="button" id="rtleAddProduct" class="rtle-add">+ Tambah barang</button>
   <div class="rtle-fields"><label>Servis / upah (pilihan) <input id="rtleLabourName" maxlength="160" placeholder="Contoh: Tukar minyak hitam"></label><label>Upah (RM) <input id="rtleLabourPrice" type="number" min="0" step="0.01" value="0"></label></div>
   <button type="button" id="rtleAddLabour" class="rtle-add ghost">+ Tambah servis / upah</button>
   <div id="rtleCart" class="rtle-cart"><p>Belum ada item.</p></div>
   <div class="rtle-total">Jumlah sebenar dibayar <strong id="rtleTotal">RM 0.00</strong></div>
   <div class="rtle-confirm"><label><input id="rtleConfirmed" type="checkbox"> Saya sahkan pelanggan sudah bayar dan transaksi ini <b>belum direkod</b> sebelum ini.</label></div>
   <div id="rtleError" role="alert" class="rtle-error" hidden></div>
   <button type="button" id="rtleSave" class="rtle-submit">Simpan Jualan Tertinggal</button>
   <p class="rtle-footnote">Cash drawer semasa tidak diubah; jika closing semalam telah siap, semak beza kutipan dengan rekod bank/tunai secara berasingan. POS Dashboard biasa mungkin masih mengikut masa key-in; laporan di tab Sejarah mengikut tarikh jualan asal.</p>
  </div>
  <div id="rtleHistory" class="rtle-body" hidden><div class="rtle-histtools"><button id="rtleRefresh" class="rtle-add">↻ Refresh sejarah</button><button id="rtleExport" class="rtle-add ghost">Eksport CSV</button></div><div id="rtleHistContent">Belum dimuatkan.</div><p class="rtle-footnote">Laporan ini khusus jualan tertinggal. Jangan tambah sekali lagi pada laporan harian tanpa tolak daripada jumlah yang dikira mengikut masa key-in.</p></div>
 </section></div>`}
function init(){if(state.init)return;state.init=true;document.body.insertAdjacentHTML('beforeend',markup());
 $('rtleClose').onclick=close;
 $('rtLateEntryOverlay').addEventListener('click',e=>{if(e.target===$('rtLateEntryOverlay'))close()});
 $('rtleDate').value=yesterday();$('rtleDate').max=today();
 $('rtleMethod').onchange=()=>{const m=$('rtleMethod').value;$('rtleRef').required=m!=='CASH';$('rtleRef').placeholder=m==='CASH'?'Pilihan; resit asal jika ada':'Wajib: no. transaksi bayaran'};
 $('rtleAddProduct').onclick=addProduct;$('rtleAddLabour').onclick=addLabour;$('rtleSave').onclick=save;
 $('rtleTabInput').onclick=()=>showTab('input');$('rtleTabHistory').onclick=()=>showTab('history');
 $('rtleRefresh').onclick=loadHistory;$('rtleExport').onclick=exportCsv;
 $('rtleCart').onclick=e=>{const b=e.target.closest('button[data-remove]');if(b){state.items.splice(Number(b.dataset.remove),1);drawCart()}};
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('rtLateEntryOverlay').hidden)close()});
 w.addEventListener('rt-auth-ready',sync);
 const n=$('navUserRole');if(n&&w.MutationObserver)new MutationObserver(sync).observe(n,{childList:true,subtree:true,characterData:true});
 document.addEventListener('click',()=>sync(),true);
 document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('[data-rt-late-launch]');if(b){e.preventDefault();open()}});sync();
}
// The menu (js/core.js, under "Lagi") and the Jualan page carry [data-rt-late-launch] buttons: shown to Admin / Owner only.
// An older menu without that slot still gets a button at the end of the menu.
function sync(){const ok=admin();const slots=document.querySelectorAll('[data-rt-late-launch]');
 if(slots.length){slots.forEach(s=>{s.hidden=!ok});const old=$('rtLateEntryLauncher');if(old)old.remove()}
 else{const nav=$('mainNav');if(!nav)return;let b=$('rtLateEntryLauncher');if(!b){b=document.createElement('button');b.id='rtLateEntryLauncher';b.type='button';b.className='w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left text-sm font-bold text-slate-700 hover:bg-slate-100';b.innerHTML='<i class="fa-solid fa-clock-rotate-left text-indigo-600"></i><span>Jualan Tertinggal</span>';b.onclick=open;nav.appendChild(b)}b.hidden=!ok}
 const ov=$('rtLateEntryOverlay');if(!ok&&ov&&!ov.hidden)close()}
async function rpc(name,args){if(!w.supabaseClient?.rpc)throw Error('Supabase belum disambungkan.');const {data,error}=await w.supabaseClient.rpc(name,args||{});if(error)throw Error(error.message||'RPC gagal');return data}
async function open(){if(!admin())return notify('Admin sahaja.','error');init();$('rtLateEntryOverlay').hidden=false;document.body.classList.add('rtle-open');showTab('input');if(!state.loaded)await loadCatalog()}
function close(){$('rtLateEntryOverlay').hidden=true;document.body.classList.remove('rtle-open')}
function showTab(tab){$('rtleInput').hidden=tab!=='input';$('rtleHistory').hidden=tab!=='history';$('rtleTabInput').classList.toggle('active',tab==='input');$('rtleTabHistory').classList.toggle('active',tab==='history');if(tab==='history')loadHistory()}
async function loadCatalog(){try{const r=await rpc('rt_late_sale_catalog');state.catalog=r?.products||[];state.loaded=true;
 $('rtleProduct').innerHTML='<option value="">-- Pilih barang --</option>'+state.catalog.filter(x=>!['LABOUR','SERVICE','SERVIS'].includes(String(x.category||'').toUpperCase())).map(x=>`<option value="${esc(x.id)}">${esc(x.name)} · ${esc(x.sku)} (stok ${esc(x.stock)})</option>`).join('');
 }catch(e){error('Tidak dapat baca barang: '+e.message);$('rtleProduct').innerHTML='<option value="">SQL Late Entry belum dipasang / akses ditolak</option>'}}
function addProduct(){const id=$('rtleProduct').value;const p=state.catalog.find(p=>p.id===id);const q=Number($('rtleQty').value);if(!p)return error('Pilih barang dahulu.');if(!Number.isFinite(q)||q<=0||q>1000)return error('Kuantiti tidak sah.');state.items.push({type:'PART',product_id:p.id,description:p.name,qty:q,price:Number(p.sell_price||0)});dirty();drawCart()}
function addLabour(){const name=$('rtleLabourName').value.trim(),price=Number($('rtleLabourPrice').value);if(name.length<3||name.length>160)return error('Isi nama servis / upah.');if(!Number.isFinite(price)||price<0)return error('Harga upah tidak sah.');state.items.push({type:'LABOUR',description:name,qty:1,price});$('rtleLabourName').value='';dirty();drawCart()}
function dirty(){state.requestId=null;$('rtleConfirmed').checked=false}
function drawCart(){const box=$('rtleCart');box.innerHTML=state.items.length?state.items.map((x,i)=>`<div class="rtle-line"><div><b>${esc(x.description)}</b><small>${x.type==='PART'?'Barang':'Servis'} · ${esc(x.qty)} unit</small></div><label>RM <input type="number" min="0" max="100000" step="0.01" data-price="${i}" value="${Number(x.price).toFixed(2)}" aria-label="Harga item ${i+1}"></label><button data-remove="${i}" aria-label="Buang item">✕</button></div>`).join(''):'<p>Belum ada item.</p>';
 box.querySelectorAll('input[data-price]').forEach(input=>input.addEventListener('change',()=>{const i=Number(input.dataset.price),val=Number(input.value);if(!Number.isFinite(val)||val<0||val>100000){error('Harga tidak sah');drawCart();return}state.items[i].price=val;dirty();sum()}));sum()}
function sum(){const total=state.items.reduce((v,x)=>v+Math.round(Number(x.qty)*Number(x.price)*100)/100,0);$('rtleTotal').textContent=RM(total)}
function error(text){const el=$('rtleError');el.hidden=!text;el.textContent=text||''}
async function save(){if(state.busy)return;error('');if(!admin())return error('Sesi Admin tamat. Sila login.');
 if(!state.items.length)return error('Masukkan sekurang-kurangnya satu item.');
 if(!$('rtleConfirmed').checked)return error('Tandakan pengesahan jualan sudah dibayar dan belum direkod.');
 const amount=Number(state.items.reduce((n,x)=>n+Math.round(x.qty*x.price*100)/100,0).toFixed(2));
 const payload={request_id:state.requestId||uuid(),business_date:$('rtleDate').value,payment_method:$('rtleMethod').value,payment_reference:$('rtleRef').value.trim(),plate_no:$('rtlePlate').value.trim(),note:$('rtleNote').value.trim(),items:state.items.map(x=>({type:x.type,product_id:x.product_id||null,description:x.description,qty:Number(x.qty),price:Number(x.price)})),amount,confirm_similar:false};
 if(payload.business_date>today())return error('Tak boleh rekod tarikh akan datang.');
 if(payload.payment_method!=='CASH'&&!payload.payment_reference)return error('Masukkan nombor rujukan untuk QR / transfer / card.');
 if(payload.items.some(x=>x.type==='LABOUR')&&!payload.plate_no)return error('Nombor plat diperlukan untuk servis.');
 if(payload.note.length<5)return error('Masukkan nota sebab jualan tak sempat key-in (minimum 5 aksara).');
 const summary=`Jualan ${payload.business_date} · ${RM(amount)} · ${payload.payment_method}. Stok barang akan ditolak SEKALI dan cash drawer hari ini tidak ditambah. Simpan?`;
 if(!w.confirm(summary))return;
 state.requestId=payload.request_id;
 state.busy=true;$('rtleSave').disabled=true;$('rtleSave').textContent='Merekod...';
 try{let r;try{r=await rpc('rt_late_sale_post',{p_payload:payload})}catch(e){
  if(/POSSIBLE_DUPLICATE_CONFIRM_REQUIRED/.test(e.message)){
    if(!w.confirm('AMARAN: Ada jualan tertinggal dengan tarikh, kaedah, jumlah dan plat yang sama. Adakah pasti ini transaksi BERLAINAN?'))throw Error('Tidak disimpan kerana kemungkinan duplikat.');
    payload.confirm_similar=true;r=await rpc('rt_late_sale_post',{p_payload:payload});
  }else throw e;
 }
 if(!r?.ok)throw Error('Server tidak sahkan simpan.');
 state.hasSaved=true;notify(`Jualan ${r.invoice_no||''} disimpan pada tarikh asal ${payload.business_date}.`,'success');
 $('rtleConfirmed').checked=false;state.items=[];state.requestId=null;drawCart();
 $('rtleRef').value='';$('rtleNote').value='';$('rtlePlate').value='';showTab('history');
 }catch(e){error('Gagal simpan: '+(e.message||e)+' — Jika rangkaian putus, jangan buat transaksi baharu sebelum semak Sejarah.')}
 finally{state.busy=false;$('rtleSave').disabled=false;$('rtleSave').textContent='Simpan Jualan Tertinggal'}
}
let history=[];
async function loadHistory(){const area=$('rtleHistContent');area.textContent='Memuatkan sejarah...';try{const d=await rpc('rt_late_sale_list',{p_start:null,p_end:null});history=d.rows||[];let totals=d.daily_totals||[];
 area.innerHTML=`<div class="rtle-daily">${totals.length?totals.map(x=>`<div><b>${esc(x.business_date)}</b><strong>${RM(x.total)}</strong><small>${esc(x.transactions)} transaksi</small></div>`).join(''):'Tiada jualan tertinggal 30 hari.'}</div><div class="rtle-history-list">${history.map(x=>`<div><b>${esc(x.invoice_no)}</b><span>${esc(x.business_date)} · ${esc(x.payment_method)}</span><strong>${RM(x.amount)}</strong><small>${esc(x.plate_snapshot||'Tiada plat')} · ${esc(x.entered_by||'Admin')}</small></div>`).join('')}</div>`;
 }catch(e){area.innerHTML='<p class="rtle-error">'+esc(e.message||e)+'</p>'}}
function exportCsv(){const data=[['INVOICE','TARIKH BAYAR','MASA KEY IN','KAEDAH','RM','PLAT','NOTA','ADMIN']];for(const r of history)data.push([r.invoice_no,r.business_date,r.recorded_at,r.payment_method,r.amount,r.plate_snapshot,r.note,r.entered_by]);const csv='\ufeff'+data.map(x=>x.map(v=>{let val=String(v??'');if(/^[=+@\-\t\r]/.test(val))val="'"+val;return '"'+val.replace(/"/g,'""')+'"'}).join(',')).join('\r\n');const a=document.createElement('a'),url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.href=url;a.download='REV_TORQ_JUALAN_TERTINGGAL_'+today()+'.csv';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500)}
w.rtLateEntry={open,close,sync};if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})(window);
