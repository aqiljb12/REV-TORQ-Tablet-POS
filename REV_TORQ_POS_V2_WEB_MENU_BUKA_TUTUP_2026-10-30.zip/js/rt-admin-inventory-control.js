/* REV TORQ | Inventory Control Admin POS 1-5 | 2026-10-27
   Master review, unit/cost checks, count-to-ledger audit, safe stock adjustments,
   supplier DO receipts and duplicate prevention. No silent live changes. */
(function(){
'use strict';
const $=id=>document.getElementById(id);
const sb=window.supabaseClient;
const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const norm=v=>String(v||'').normalize('NFKC').replace(/\s+/g,' ').trim().toUpperCase();
const cash=v=>'RM '+Number(v||0).toLocaleString('en-MY',{minimumFractionDigits:2,maximumFractionDigits:2});
const admin=()=>window.rtHasAdminAccess?.()===true;
const categories=['MINYAK','TAYAR','SPAREPART','AKSESORI','BARANG LUAR','SERVIS'];
const units=['pcs','botol','set','kotak','pasang','liter'];
const s={products:[],stocks:{},suppliers:[],receipts:[],location:null,company:null,tab:'overview',search:'',masterFilter:'issues',busy:false,lines:[],stockSearch:'',lastLoaded:0,quickProductId:null,quickRequestId:null,quickSearch:'',aiDraft:null,aiBusy:false,ai:{state:'idle'},aiToken:0};
function toast(msg,type='info'){if(window.showToast)window.showToast(msg,type);else alert(msg)}
function err(e){const v=String(e?.message||e||'Ralat');if(/PGRST202|Could not find the function|does not exist/i.test(v))return 'SQL Inventory Control belum dipasang dalam Supabase. Jalankan migrasi dalam ZIP dahulu.';if(v.includes('STOCK_CHANGED_REFRESH'))return 'Baki stok sudah berubah sejak paparan dibuka. Tekan Refresh dan kira semula sebelum sahkan.';if(v.includes('DO_ALREADY_RECEIVED'))return 'Nombor DO/invois pembekal ini sudah direkod. Jangan terima barang dua kali.';if(v.includes('DUPLICATE_NAME_CATEGORY_REVIEW'))return 'Nama dan kategori sama sudah ada. Semak rekod duplikat dahulu.';if(v.includes('PRODUCT_CHANGED_REFRESH'))return 'Maklumat produk berubah. Refresh semula.';return v;}
async function rpc(fn,args){if(!sb)throw new Error('Supabase tidak tersedia');const r=await sb.rpc(fn,args);if(r.error)throw r.error;return r.data;}
async function getContext(){if(!admin())throw new Error('Hanya Owner/Admin boleh guna Inventory Control');if(typeof window.rtContext!=='function')throw new Error('Sesi POS belum bersedia. Login semula.');const c=await window.rtContext();if(!c?.companyId||!c.locationId)throw new Error('Lokasi atau company tidak sah');s.company=c.companyId;s.location=c.locationId;return c;}
function suggestedCategory(p){const n=norm(p.name); if(/\b(TYRE|TIRE|TAYAR)\b/.test(n)&&!/UBAT TAYAR|TYRE SEAL|VALVE|TUBELESS|TAMPAL/.test(n))return 'TAYAR';if(/SPARK PLUG|SPROCKET/.test(n))return 'SPAREPART';if(/\bGEAR OIL\b|ENGINE OIL|MOTUL 300[0-9V]|MOTUL 5100|MOTUL 7100|ESTREMO (FULLY|SEMI|MINERAL)/.test(n))return 'MINYAK';return null;}
function issues(p){const list=[];if(norm(p.name)!==String(p.name||''))list.push('NAMA');if(suggestedCategory(p)&&suggestedCategory(p)!==p.category)list.push('KATEGORI');if(Number(p.sell_price||0)<Number(p.cost_price||0))list.push('KOS > JUAL');if(Number(p.sell_price||0)===0)list.push('JUAL RM0');if(Number(p.cost_price||0)===0)list.push('KOS RM0');if(!p.brand)list.push('JENAMA');if(!p.rack_location)list.push('RAK');if(/\s/.test(String(p.sku||'')))list.push('SKU');return list;}
function duplicateGroups(){const groups=new Map();for(const p of s.products){const key=norm(p.name)+'|'+norm(p.category);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(p);}return [...groups.values()].filter(g=>g.length>1);}
function el(tag,attrs={}){const x=document.createElement(tag);for(const [k,v] of Object.entries(attrs)){if(k==='text')x.textContent=v;else x.setAttribute(k,v);}return x;}
function modal(){let root=$('rtInvCenterOverlay');if(root)return root;root=el('div',{id:'rtInvCenterOverlay',class:'rtic-backdrop'});
root.innerHTML=`<div class="rtic-shell" role="dialog" aria-modal="true" aria-label="Inventory Control Admin"><header class="rtic-top"><div><small>REV TORQ / ADMIN POS</small><h2>Inventory Control</h2><p>Urus master, semak kos, audit fizikal dan terimaan stok. Semua tindakan disahkan oleh Admin.</p></div><button type="button" id="rticClose" title="Tutup">✕</button></header>
<nav id="rticTabs" class="rtic-tabs"><button data-tab="overview">Ringkasan</button><button data-tab="master">Master Barang</button><button data-tab="cost">Kos & Unit</button><button data-tab="count">Audit Stok</button><button data-tab="receipts">Barang Sampai</button><button data-tab="quick">RESTOK PANTAS +</button></nav><section id="rticContent" class="rtic-content"><p>Memuatkan inventori...</p></section><footer class="rtic-foot"><span id="rticStatus">Tiada perubahan automatik pada stok.</span><button id="rticRefresh" type="button">↻ Refresh Data</button></footer></div>`;
document.body.appendChild(root);$('rticClose').onclick=close;$('rticRefresh').onclick=()=>refresh(true);root.addEventListener('click',e=>{if(e.target===root)close()});root.addEventListener('keydown',e=>{if(e.key==='Escape')close();});$('rticTabs').addEventListener('click',e=>{const b=e.target.closest('[data-tab]');if(!b)return;s.tab=b.dataset.tab;render();});return root;}
function status(msg){if($('rticStatus'))$('rticStatus').textContent=msg;}
function open(){if(!admin()){toast('Hanya Admin / Owner.','error');return}const root=modal();root.classList.add('rtic-open');document.body.classList.add('rtic-modal-open');refresh(false);}
function close(){$('rtInvCenterOverlay')?.classList.remove('rtic-open');document.body.classList.remove('rtic-modal-open');}
async function refresh(force=true){if(s.busy&&!force)return;try{await getContext();status('Memuatkan daripada Supabase...');
const [products,balances,suppliers,receipts]=await Promise.all([
sb.from('products').select('id,sku,barcode,name,category,brand,unit,cost_price,sell_price,rack_location,active,updated_at').eq('company_id',s.company).eq('active',true).order('sku').limit(1500),
sb.from('stock_balances').select('product_id,quantity,reserved_quantity').eq('location_id',s.location).limit(1500),
sb.from('suppliers').select('id,name,active').eq('company_id',s.company).eq('active',true).order('name').limit(300),
sb.from('rt_inventory_admin_receipts').select('id,reference_no,created_at,status,supplier_id,created_by,reverse_reason').eq('company_id',s.company).order('created_at',{ascending:false}).limit(50)
]);
for(const v of [products,balances,suppliers])if(v.error)throw v.error;
s.products=products.data||[];s.stocks={};for(const b of balances.data||[])s.stocks[b.product_id]={quantity:Number(b.quantity||0),reserved:Number(b.reserved_quantity||0)};
s.suppliers=suppliers.data||[];s.receipts=receipts.error?[]:(receipts.data||[]);s.lastLoaded=Date.now();status(receipts.error?'SQL Inventory Control belum dipasang; paparan semakan tersedia, tetapi simpan tidak tersedia.':'Data live dibaca. Simpan hanya selepas pengesahan Admin.');render();
}catch(e){const ct=$('rticContent');if(ct)ct.innerHTML=`<p class="rtic-error">${escape(err(e))}</p>`;status('Ralat baca data');}}
function header(title,subtitle){return `<div class="rtic-heading"><h3>${escape(title)}</h3><p>${escape(subtitle)}</p></div>`;}
function render(){if(!$('rticContent'))return;document.querySelectorAll('#rticTabs [data-tab]').forEach(b=>b.classList.toggle('rtic-active',b.dataset.tab===s.tab));
const on=document.querySelector('#rticTabs .rtic-active'),bar=$('rticTabs');if(on&&bar&&bar.scrollWidth>bar.clientWidth){const l=on.offsetLeft-bar.offsetLeft,r=l+on.offsetWidth;if(l<bar.scrollLeft||r>bar.scrollLeft+bar.clientWidth)bar.scrollLeft=Math.max(0,l-12);}   // phone: the chosen tab stays in view
({overview:overview,master:master,cost:cost,count:count,receipts:receipts,quick:quick}[s.tab]||overview)();}
function overview(){const total=s.products.length,dubs=duplicateGroups().length,names=s.products.filter(p=>norm(p.name)!==p.name).length,wrong=s.products.filter(p=>suggestedCategory(p)&&suggestedCategory(p)!==p.category).length,pricing=s.products.filter(p=>Number(p.sell_price||0)<Number(p.cost_price||0)||!Number(p.sell_price||0)||!Number(p.cost_price||0)).length;
$('rticContent').innerHTML=header('Semakan inventori','Semua rekod kekal dalam POS dan database sedia ada. Tiada perubahan auto.')+`<div class="rtic-stats"><div><b>${total}</b><span>Barang aktif</span></div><div><b>${names}</b><span>Nama perlu kemas</span></div><div><b>${dubs}</b><span>Kumpulan duplikat</span></div><div><b>${wrong}</b><span>Kategori dicadangkan semak</span></div><div><b>${pricing}</b><span>Harga / kos untuk audit</span></div></div><div class="rtic-guide"><strong>Aliran kerja disyorkan:</strong><p>1. Master Barang → 2. Kos & Unit → 3. Audit Stok Fizikal → 4. Simpan Pelarasan → 5. Barang Sampai dengan DO.</p><p><b>Nota:</b> "Stok dalam POS" ialah angka sistem. Untuk sahkan stok sebenar, mesti kira barang secara fizikal.</p></div><div class="rtic-buttons"><button data-go="master">Semak Nama & SKU</button><button data-go="count">Mula Kira Stok</button><button data-go="receipts">Terima Barang Sampai</button></div>`;
$('rticContent').querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>{s.tab=b.dataset.go;render()});}
function master(){const groups=duplicateGroups(), dupids=new Set(groups.flat().map(p=>p.id));let products=s.products.filter(p=>s.masterFilter==='all'||(s.masterFilter==='duplicates'?dupids.has(p.id):issues(p).length||dupids.has(p.id)));
if(s.search.trim()){const term=norm(s.search);products=products.filter(p=>norm([p.name,p.sku,p.barcode,p.category].join(' ')).includes(term));}
$('rticContent').innerHTML=header('1 · Master Barang','Normalisasikan nama kepada HURUF BESAR, semak kategori dan SKU sebelum simpan. Barang duplikat tidak digabungkan automatik.')+
`<div class="rtic-toolbar"><input id="rticMasterSearch" placeholder="Cari nama / SKU / barcode" value="${escape(s.search)}"><select id="rticMasterFilter"><option value="issues" ${s.masterFilter==='issues'?'selected':''}>Perlu semak</option><option value="duplicates" ${s.masterFilter==='duplicates'?'selected':''}>Duplikat sahaja</option><option value="all" ${s.masterFilter==='all'?'selected':''}>Semua barang</option></select><button id="rticBulkNames">KEMASKAN HURUF BESAR (${s.products.filter(p=>norm(p.name)!==p.name).length})</button><button id="rticMasterExport">BACKUP CSV</button></div><div class="rtic-scroll"><table class="rtic-table"><thead><tr><th>Item</th><th>SKU</th><th>Isu</th><th>Betulkan</th></tr></thead><tbody>${products.slice(0,250).map(p=>`<tr><td><b>${escape(p.name)}</b><small>${escape(p.category)}</small></td><td><code>${escape(p.sku)}</code></td><td>${(dupids.has(p.id)?['DUPLIKAT']:[]).concat(issues(p)).slice(0,5).map(i=>`<span class="rtic-tag">${escape(i)}</span>`).join('')}</td><td><button data-edit="${escape(p.id)}">EDIT</button></td></tr>`).join('')}</tbody></table></div><p class="rtic-note">${products.length} item dipaparkan · Tukar SKU hanya jika perlu, dan cetak semula label lama. Rekod jualan dikaitkan kepada ID produk yang sama.</p>`;
$('rticMasterSearch').oninput=e=>{const cursor=e.target.selectionStart;s.search=e.target.value;master();const next=$('rticMasterSearch');next?.focus();try{next?.setSelectionRange(cursor,cursor)}catch(_){}};$('rticMasterFilter').onchange=e=>{s.masterFilter=e.target.value;master()};$('rticBulkNames').onclick=bulkNames;$('rticMasterExport').onclick=()=>exportCSV(false);
$('rticContent').querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>editMaster(b.dataset.edit));}
function editMaster(id){const p=s.products.find(x=>x.id===id);if(!p)return;
const suggestions=suggestedCategory(p);$('rticContent').innerHTML=header('Betulkan Rekod Master','Simpan perubahan pada produk yang sama. Stok, invoice dan sejarah pergerakan tidak disentuh.')+
`<form id="rticEditMaster" class="rtic-form"><div class="rtic-full"><label>Nama barang (automatik HURUF BESAR)</label><input name="name" value="${escape(norm(p.name))}" required maxlength="220"></div><div><label>SKU (jika tukar, kod lama disimpan sebagai alias)</label><input name="sku" value="${escape(p.sku)}" required><button type="button" id="rticSuggestSku" class="rtic-sku-button">CADANG SKU STANDARD BARU</button></div><div><label>Kategori ${suggestions&&suggestions!==p.category?'· cadangan: '+escape(suggestions):''}</label><select name="category">${categories.map(c=>`<option ${c===p.category?'selected':''}>${c}</option>`).join('')}</select></div><div><label>Jenama (jika pasti)</label><input name="brand" value="${escape(p.brand||'')}"></div><div><label>Unit stok / jualan</label><select name="unit">${units.map(u=>`<option ${u===p.unit?'selected':''}>${u}</option>`).join('')}</select></div><div><label>Lokasi Rak</label><input name="rack_location" value="${escape(p.rack_location||'')}"></div><div><label>Barcode (kekal, tidak diedit di sini)</label><input value="${escape(p.barcode||'-')}" disabled></div><div><label>Kos / unit (RM)</label><input name="cost_price" type="number" min="0" step="0.01" value="${Number(p.cost_price||0)}"></div><div><label>Harga Jual / unit (RM)</label><input name="sell_price" type="number" min="0" step="0.01" value="${Number(p.sell_price||0)}"></div><div class="rtic-full rtic-guide"><p><b>Stok POS sekarang:</b> ${Number(s.stocks[p.id]?.quantity||0)} · Jika unit semasa ialah kotak dan akan bertukar ke biji, buat audit fizikal dahulu; borang ini tidak menukar nombor stok secara automatik.</p></div><div class="rtic-full rtic-buttons"><button type="button" id="rticBackMaster">← Kembali</button><button type="submit">SEMAK & SIMPAN MASTER</button></div></form>`;
$('rticBackMaster').onclick=master;$('rticSuggestSku').onclick=async()=>{if(!confirm('Jana SKU standard untuk menggantikan SKU lama? Jangan tukar SKU jika label dan pembekal masih guna kod lama.'))return;try{const cat=$('rticEditMaster').elements.category.value;const next=await rpc('rt_inv_admin_next_sku',{p_category:cat});$('rticEditMaster').elements.sku.value=String(next||'');toast('SKU baharu disediakan. Belum disimpan.','info');}catch(e){toast(err(e),'error')}};$('rticEditMaster').onsubmit=async ev=>{ev.preventDefault();const fd=new FormData(ev.currentTarget),patch={};for(const k of ['name','sku','category','brand','unit','rack_location','cost_price','sell_price'])patch[k]=fd.get(k);patch.name=norm(patch.name);patch.sku=norm(patch.sku).replace(/\s+/g,'-');patch.brand=norm(patch.brand);patch.rack_location=norm(patch.rack_location);
if(patch.sku!==p.sku&&!confirm(`Tukar SKU ${p.sku} → ${patch.sku}? Barcode asal dikekalkan. Label SKU lama mungkin perlu cetak semula.`))return;
if(Number(patch.cost_price)>Number(patch.sell_price)&&!confirm('Kos lebih tinggi daripada harga jual. Sahkan angka ini memang betul?'))return;
if(!confirm(`Simpan pembetulan master bagi ${p.sku}? Stok tidak berubah.`))return;
try{status('Menyimpan master...');await rpc('rt_inv_admin_master',{p_product_id:p.id,p_patch:patch,p_expected_updated_at:p.updated_at});toast('Master produk dikemaskini.','success');await refresh(true);master();}catch(e){toast(err(e),'error');status(err(e));}};}
async function bulkNames(){const items=s.products.filter(p=>norm(p.name)!==p.name);if(!items.length){toast('Nama sudah seragam.','success');return;}const yes=confirm(`CADANGAN: ${items.length} nama ditukar kepada huruf besar dan ruang seragam. Stok, SKU, barcode, harga tidak berubah. Jalankan secara berperingkat sekarang?`);if(!yes)return;
let saved=0,errors=[];const btn=$('rticBulkNames');if(btn)btn.disabled=true;
for(const p of items){try{await rpc('rt_inv_admin_master',{p_product_id:p.id,p_patch:{name:norm(p.name)},p_expected_updated_at:p.updated_at});saved++;}catch(e){errors.push(`${p.sku}: ${err(e)}`);}status(`Kemaskan nama: ${saved}/${items.length} berjaya · ${errors.length} gagal`);}
toast(`${saved} nama dikemaskini, ${errors.length} perlu semak.`,errors.length?'info':'success');if(errors.length){console.warn('Semak semula nama',errors);alert('Rekod yang perlu semak:\n'+errors.slice(0,12).join('\n'));}await refresh(true);master();}
function cost(){let list=s.products.filter(p=>Number(p.cost_price)<=0||Number(p.sell_price)<=0||Number(p.cost_price)>Number(p.sell_price)||p.unit==='kotak'||p.category==='SERVIS');
$('rticContent').innerHTML=header('2 · Semak Kos & Unit','Kos setiap UNIT JUALAN. Bezakan satu kotak, botol, set atau biji. Harga bawah kos hanya amaran, bukan auto-pembetulan.')+
`<div class="rtic-scroll"><table class="rtic-table"><thead><tr><th>Barang</th><th>Unit</th><th>Kos</th><th>Jual</th><th>Status</th><th>Semak</th></tr></thead><tbody>${list.map(p=>`<tr><td><b>${escape(p.name)}</b><small>${escape(p.sku)}</small></td><td>${escape(p.unit)}</td><td>${cash(p.cost_price)}</td><td>${cash(p.sell_price)}</td><td><span class="rtic-tag">${p.category==='SERVIS'?'BUKAN STOK FIZIKAL':Number(p.sell_price)<=0?'JUAL RM0':Number(p.cost_price)<=0?'KOS RM0':Number(p.cost_price)>Number(p.sell_price)?'JUAL BAWAH KOS':'SEMAK UNIT'}</span></td><td><button data-cost-edit="${escape(p.id)}">EDIT</button></td></tr>`).join('')}</tbody></table></div><p class="rtic-note">Jika harga kos dimasukkan bagi satu kotak, bahagikan kepada bilangan unit yang dijual sebelum sahkan. Kos historical invoice tidak dipinda.</p>`;
$('rticContent').querySelectorAll('[data-cost-edit]').forEach(b=>b.onclick=()=>editMaster(b.dataset.costEdit));}
function count(){const term=norm(s.stockSearch);const list=s.products.filter(p=>!term||norm([p.name,p.sku,p.barcode].join(' ')).includes(term));
$('rticContent').innerHTML=header('3 & 4 · Audit Fizikal + Pelarasan Stok','Kira fizikal dahulu, kemudian tulis jumlah sebenar. Sistem mengira beza dan menyimpan ADJUSTMENT berjejak selepas Admin sahkan.')+
`<div class="rtic-guide">Jangan salin angka POS sebagai kiraan fizikal. Jika baki berubah kerana ada jualan serentak, pelayan akan menolak pembetulan dan minta Refresh. Untuk SERVIS, masukkan 0 hanya selepas Admin sahkan baki itu bukan barang fizikal.</div><div class="rtic-toolbar"><button id="rticCountExport">EXPORT SENARAI KIRAAN</button><input id="rticCountSearch" placeholder="Cari / scan nama, SKU, barcode" value="${escape(s.stockSearch)}"></div><div class="rtic-scroll"><table class="rtic-table"><thead><tr><th>Barang</th><th>Stok POS</th><th>Kiraan fizikal</th><th>Tindakan</th></tr></thead><tbody>${list.slice(0,300).map(p=>`<tr><td><b>${escape(p.name)}</b><small>${escape(p.sku)} ${p.category==='SERVIS'?'· SERVIS (BUKAN STOK FIZIKAL)':''}</small></td><td><b>${Number(s.stocks[p.id]?.quantity||0)}</b></td><td><input class="rtic-small-input" data-count-input="${escape(p.id)}" type="number" min="0" step="1" placeholder="KIRA" inputmode="numeric"></td><td><button data-save-count="${escape(p.id)}">SEMAK</button></td></tr>`).join('')}</tbody></table></div><p class="rtic-note">Selepas kiraan fizikal, simpan setiap baris. Setiap perubahan dicatat dalam audit log dan stock_movements. Tiada kuantiti dipinda apabila membuka tab ini.</p>`;
$('rticCountExport').onclick=()=>exportCSV(true);$('rticCountSearch').oninput=e=>{const cursor=e.target.selectionStart;s.stockSearch=e.target.value;count();const next=$('rticCountSearch');next?.focus();try{next?.setSelectionRange(cursor,cursor)}catch(_){}};$('rticContent').querySelectorAll('[data-save-count]').forEach(b=>b.onclick=()=>prepareCount(b.dataset.saveCount));}
async function prepareCount(id){const p=s.products.find(x=>x.id===id),input=$('rticContent').querySelector(`[data-count-input="${id}"]`);if(!p||!input)return;
const raw=input.value.trim(),actual=Number(raw),expected=Number(s.stocks[id]?.quantity||0);if(raw===''||!Number.isInteger(actual)||actual<0){toast('Masukkan kiraan stok fizikal dalam unit bulat. 0 dibenarkan.','error');return;}
const delta=actual-expected;const reason=prompt(`BARANG: ${p.name}\nStok POS: ${expected}\nKiraan fizikal: ${actual}\nBeza: ${delta>=0?'+':''}${delta}\n\nTulis SEBAB pembetulan (minimum 8 aksara).`,'Kiraan stok fizikal disahkan');if(reason===null)return;
if(reason.trim().length<8){toast('Sebab sekurang-kurangnya 8 aksara','error');return;}
if(!confirm(`SAHKAN KIRAAN: ${p.sku}\n${expected} → ${actual} (${delta>=0?'+':''}${delta})\nStok akan berubah serta-merta dan tindakan direkod.`))return;
try{const res=await rpc('rt_inv_admin_adjust',{p_product_id:p.id,p_location_id:s.location,p_expected_quantity:expected,p_physical_quantity:actual,p_reason:reason.trim()});toast(`Stok ${p.sku}: ${res.before} → ${res.after} · Audit disimpan.`,'success');await refresh(true);count();window.loadInventory?.({silent:true});}catch(e){toast(err(e),'error');await refresh(true);count();}}
function quick(){
 const p=s.products.find(x=>x.id===s.quickProductId);
 $('rticContent').innerHTML=header('RESTOK PANTAS · Dari Inventori','Barang lama yang datang semula: pilih item, isi kuantiti dan sahkan. Tidak perlu PO, DO atau buat SKU baru.')+
 `<div class="rtic-form rtic-quick-form"><div class="rtic-full"><label>Cari / scan barang dalam inventory</label><input id="rticQuickFind" value="${escape(s.quickSearch)}" placeholder="Nama, SKU atau barcode" autocomplete="off"><div id="rticQuickMatches" class="rtic-matches"></div></div>`+
 (p?`<div class="rtic-full rtic-quick-selected"><strong>${escape(p.name)}</strong><small>${escape(p.sku)} · ${escape(p.category)} · Baki semasa ${Number(s.stocks[p.id]?.quantity||0)} ${escape(p.unit||'pcs')}</small></div><div><label>Kuantiti SAMPAI (bukan jumlah stok)</label><input id="rticQuickQty" type="number" inputmode="numeric" min="1" step="1" value="1"></div><div><label>Kos seunit (RM)</label><input id="rticQuickCost" type="number" inputmode="decimal" min="0" step="0.01" value="${Number(p.cost_price||0).toFixed(2)}"></div><div class="rtic-full"><label>Catatan (jika perlu)</label><input id="rticQuickNote" maxlength="350" placeholder="Contoh: Order melalui WhatsApp, supplier XXX"></div><div class="rtic-full rtic-buttons"><button type="button" id="rticQuickConfirm">+ SAHKAN RESTOK</button></div>`:
 `<div class="rtic-full rtic-guide">Cari barang yang sudah ada dahulu. Jika barang belum wujud, daftar sekali dalam Master Barang, bukan berulang kali ketika restok.</div>`)+
 `</div><p class="rtic-note">Restok Pantas masuk ledger sebagai PURCHASE dan direkodkan pada audit Admin. Kos terimaan tidak mengubah harga kos master secara senyap. Untuk audit penerimaan lengkap dengan DO dan supplier, guna tab Barang Sampai.</p>`;
 const search=$('rticQuickFind'), matches=$('rticQuickMatches');
 function suggestions(){const term=search.value.trim();s.quickSearch=term;matches.innerHTML=term.length<2?'':productOptions(term).map(x=>`<button type="button" data-quick-pick="${escape(x.id)}"><b>${escape(x.name)}</b><small>${escape(x.sku)} · Baki ${Number(s.stocks[x.id]?.quantity||0)}</small></button>`).join('')||'<p>Tiada barang dijumpai. Semak nama/SKU dahulu.</p>';
 matches.querySelectorAll('[data-quick-pick]').forEach(b=>b.onclick=()=>{s.quickProductId=b.dataset.quickPick;s.quickSearch='';s.quickRequestId=null;quick();});}
 search.oninput=suggestions;if(search.value.trim().length>=2)suggestions();
 if(p){for(const id of ['rticQuickQty','rticQuickCost','rticQuickNote'])$(id).addEventListener('input',()=>{s.quickRequestId=null});$('rticQuickConfirm').onclick=postQuickRestock;}
}
function openQuickRestock(productId){if(!admin())return toast('Restok Pantas hanya untuk Admin/Owner.','error');s.quickProductId=productId||null;s.quickSearch='';s.quickRequestId=null;s.tab='quick';const root=modal();root.classList.add('rtic-open');document.body.classList.add('rtic-modal-open');refresh(true);}
async function postQuickRestock(){if(s.busy)return;
 const p=s.products.find(x=>x.id===s.quickProductId),qty=Number($('rticQuickQty')?.value),cost=Number($('rticQuickCost')?.value),note=String($('rticQuickNote')?.value||'').trim();
 if(!p||p.category==='SERVIS')return toast('Pilih barang fizikal yang sah.','error');
 if(!Number.isInteger(qty)||qty<=0||qty>99999)return toast('Isi kuantiti sampai yang betul (minimum 1).','error');
 if(!Number.isFinite(cost)||cost<0||cost>10000000)return toast('Kos seunit tidak sah.','error');
 if(!confirm(`SAHKAN RESTOK?\n${p.name}\nBaki POS sekarang: ${Number(s.stocks[p.id]?.quantity||0)}\nBARANG SAMPAI: +${qty}\nKos unit: RM ${cost.toFixed(2)}\n\nIni akan TAMBAH ${qty} unit. Bukan set jumlah stok.`))return;
 if(!s.quickRequestId){if(!window.crypto?.randomUUID)return toast('Browser perlu menyokong crypto.randomUUID untuk elak restok berganda.','error');s.quickRequestId=window.crypto.randomUUID();}
 s.busy=true;const b=$('rticQuickConfirm');if(b)b.disabled=true;
 try{
  const ret=await rpc('rt_inv_admin_quick_restock',{p_product_id:p.id,p_location_id:s.location,p_quantity:qty,p_unit_cost:cost,p_request_id:s.quickRequestId,p_note:note||null});
  toast(`${p.sku}: +${qty} unit masuk. Baki terkini ${ret.stock_after}.`,'success');s.quickRequestId=null;
  await refresh(true);s.tab='quick';quick();window.loadInventory?.({silent:true});
 }catch(e){toast(err(e),'error');status('Restok belum dapat disahkan. Jika sambungan terputus, cuba semula dengan nilai sama untuk elak berganda.');}
 finally{s.busy=false;if(b)b.disabled=false;}
}
function productOptions(term){term=norm(term);return s.products.filter(p=>p.category!=='SERVIS'&&(!term||norm([p.sku,p.barcode,p.name].join(' ')).includes(term))).slice(0,14);}
function receipts(){const suppliers=s.suppliers;
$('rticContent').innerHTML=header('5 · Barang Sampai (DO / Invois)','Pilih produk yang sudah wujud, masukkan kuantiti & kos per unit. Simpan sekali sahaja mengikut nombor DO pembekal.')+
`<section class="rtic-ai-intro"><div class="rtic-ai-title"><strong>📷 AI SCAN INVOIS SUPPLIER</strong><small>Ambil gambar invois · AI baca barang dan kos · Admin semak dulu</small></div><div class="rtic-ai-actions"><label class="rtic-ai-btn">📸 AMBIL GAMBAR<input type="file" accept="image/*" capture="environment" id="rticAiCamera" hidden></label><label class="rtic-ai-btn secondary">🖼️ PILIH GAMBAR<input type="file" accept="image/*" id="rticAiGallery" hidden></label></div><div class="rtic-ai-privacy">Imej dihantar ke AI untuk dibaca. Belum ada stok ditambah atau barang baharu didaftarkan. Gambar tidak disimpan secara automatik dalam POS.</div></section><div id="rticAiDraftPanel"></div>`+
`<div class="rtic-form"><div><label>Pembekal</label><select id="rticSupplier"><option value="">— PILIH PEMBEKAL —</option>${suppliers.map(x=>`<option value="${escape(x.id)}">${escape(x.name)}</option>`).join('')}</select></div><div><label>No. DO / Invois Pembekal</label><input id="rticDo" placeholder="Contoh: DO-2026-1027" maxlength="100"></div><div class="rtic-full"><label>Catatan (optional)</label><input id="rticDoNote" placeholder="Contoh: Stok masuk rak A1"></div><div class="rtic-full"><label>Cari Produk Sedia Ada (nama / SKU / barcode)</label><input id="rticProductSearch" placeholder="Taip sekurang-kurangnya 2 aksara"><div id="rticProductMatches" class="rtic-matches"></div></div><div class="rtic-full"><div id="rticReceiptLines"></div></div><div class="rtic-full rtic-buttons"><button id="rticReceivePost" type="button">SAHKAN STOK MASUK</button></div></div>`+
`<div class="rtic-heading"><h3>Sejarah DO</h3><p>Jika tersalah terima, pembatalan dibenarkan hanya apabila stok masih cukup untuk reversal. Tiada pemadaman ledger.</p></div><div class="rtic-scroll"><table class="rtic-table"><thead><tr><th>Tarikh</th><th>DO / Invois</th><th>Pembekal</th><th>Status</th><th>Betulkan</th></tr></thead><tbody>${s.receipts.map(r=>`<tr><td>${escape(new Date(r.created_at).toLocaleDateString('ms-MY'))}</td><td><b>${escape(r.reference_no)}</b></td><td>${escape(s.suppliers.find(x=>x.id===r.supplier_id)?.name||'-')}</td><td>${escape(r.status)}</td><td>${r.status==='POSTED'?`<button data-reverse="${escape(r.id)}">BATAL TERIMAAN</button>`:'—'}</td></tr>`).join('')}</tbody></table></div>`;
$('rticProductSearch').oninput=e=>{const val=e.target.value,out=$('rticProductMatches');out.innerHTML=val.trim().length<2?'':productOptions(val).map(p=>`<button data-pick="${escape(p.id)}"><b>${escape(p.name)}</b><small>${escape(p.sku)} · Baki ${Number(s.stocks[p.id]?.quantity||0)}</small></button>`).join('')||'<p>Tiada item. Daftar di Master Inventori dahulu, jangan buat SKU baru di sini.</p>';
out.querySelectorAll('[data-pick]').forEach(b=>b.onclick=()=>{const p=s.products.find(x=>x.id===b.dataset.pick);if(p&&!s.lines.some(x=>x.product_id===p.id)){s.lines.push({product_id:p.id,quantity:1,unit_cost:Number(p.cost_price||0)});drawLines();}$('rticProductSearch').value='';out.innerHTML='';});};
$('rticAiCamera').onchange=e=>aiReadInvoiceImage(e.target.files?.[0]);$('rticAiGallery').onchange=e=>aiReadInvoiceImage(e.target.files?.[0]);renderAiDraft();
$('rticReceivePost').onclick=postReceipt;$('rticContent').querySelectorAll('[data-reverse]').forEach(b=>b.onclick=()=>reverseReceipt(b.dataset.reverse));drawLines();}
// Invoice photos are OCR/extraction drafts, NOT a purchase or a receipt until Admin confirmation.
function aiMatchProduct(row){
 const sku=norm(row.supplier_sku),barcode=String(row.barcode||'').trim(),name=norm(row.description);
 const choices=s.products.filter(p=>p.category!=='SERVIS');
 for(const rule of [p=>barcode&&String(p.barcode||'').trim()===barcode,p=>sku&&norm(p.sku)===sku,p=>name&&norm(p.name)===name]){
  const matches=choices.filter(rule);if(matches.length===1)return matches[0].id;
 }
 return '';
}
async function aiPhotoDataURL(file){
 if(!file)throw new Error('Pilih gambar invois dahulu.');
 if(file.size>16*1024*1024)throw new Error('Gambar terlalu besar (maksimum 16 MB sebelum dimampatkan).');
 if(!/^image\//.test(file.type))throw new Error('Format gambar tidak disokong. Guna JPG, PNG atau gambar kamera.');
 const temp=URL.createObjectURL(file);
 try{
  const pic=new Image();pic.src=temp;
  if(pic.decode)await pic.decode();else await new Promise((resolve,reject)=>{pic.onload=resolve;pic.onerror=reject;});
  if(pic.width<350||pic.height<350)throw new Error('Gambar terlalu kecil untuk baca invois. Ambil semula gambar dengan jelas.');
  // The AI never reads more than this: it scales a photo to fit 2048 px and then to a short side of 768 px
  // (newer models: ~1.6 megapixels). So long side <= 2048, short side <= 1100, <= 1.6 MP, JPEG 0.8:
  // the same detail for the AI, a much smaller upload on phone data (a 12 MP photo becomes ~0.2-0.5 MB).
  const max=2048,short=1100,scale=Math.min(1,max/Math.max(pic.width,pic.height),short/Math.min(pic.width,pic.height),Math.sqrt(1600000/(pic.width*pic.height)));
  const c=document.createElement('canvas');c.width=Math.max(1,Math.round(pic.width*scale));c.height=Math.max(1,Math.round(pic.height*scale));
  const g=c.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,c.width,c.height);g.drawImage(pic,0,0,c.width,c.height);
  const data=c.toDataURL('image/jpeg',0.8);
  if(data.length>9_000_000)throw new Error('Gambar terlalu besar selepas dimampatkan. Sila crop invois.');
  return data;
 }catch(e){if(/decode|image|Format gambar|source/i.test(String(e.message||e)))throw new Error('Gambar gagal dibaca pada peranti ini. Guna JPG/PNG atau ambil foto semula.');throw e}
 finally{URL.revokeObjectURL(temp);}
}
// AI scan states shown in #rticAiDraftPanel: busy (seconds counter + BATAL), error (stays on screen until the next
// try), draft (review table). The server stops a request at about 150 s, so the page stops waiting then as well.
const AI_WAIT_S=150;
const AI_CODES={OPENAI_API_KEY_NOT_CONFIGURED:'API AI belum dikonfigurasi. Admin perlu set OPENAI_API_KEY dalam Supabase Secrets.',
 ADMIN_ONLY:'Akses AI hanya Admin / Owner.',AI_SERVICE_FAILED:'OpenAI API gagal. Semak billing / API key / model di Supabase Edge Function.',
 AI_OUTPUT_INCOMPLETE:'AI tidak sempat habis membaca (invois terlalu panjang). Ambil gambar separuh-separuh, contoh baris 1–20 dahulu, kemudian baki.',
 AI_NO_INVOICE_DATA:'AI tidak pulangkan data. Cuba gambar lebih terang dan lurus.',AI_INVALID_ITEMS:'AI pulangkan format tidak sah. Cuba sekali lagi.',
 PHOTO_TOO_LARGE:'Gambar terlalu besar untuk server. Crop pada senarai barang sahaja.',PHOTO_INVALID_OR_TOO_LARGE:'Gambar tidak sah atau terlalu besar. Ambil semula gambar.',
 INVOICE_SCAN_ERROR:'Ralat server semasa membaca invois. Cuba lagi.',SESSION_INVALID:'Sesi tamat. Log masuk semula.',LOGIN_REQUIRED:'Sesi tamat. Log masuk semula.',
 SERVER_SUPABASE_CONFIG_MISSING:'Konfigurasi server Supabase tidak lengkap.',
 AI_TIMEOUT:'AI tidak siap membaca dalam had masa server (~2 minit). Crop pada senarai barang sahaja (kurang baris = lebih cepat) dan cuba lagi.',
 AI_WAIT_LIMIT:'AI masih belum jawab selepas '+AI_WAIT_S+' saat. Biasanya gambar terlalu besar / kabur atau server AI sibuk. Crop pada senarai barang dan cuba lagi.',
 AI_UNREACHABLE:'Fungsi AI (rt-ai-invoice-scan) tidak dapat dihubungi langsung. Semak internet. Jika internet OK: fungsi belum dideploy atau Supabase sedang bermasalah (semak Supabase > Edge Functions > Logs).',
 AI_NO_REPLY:'Gambar sampai ke server, tetapi AI tidak menjawab dalam had masa server Supabase (sambungan diputuskan oleh server, bukan Wi-Fi anda). Crop pada senarai barang sahaja dan cuba lagi. Jika kerap berlaku: deploy versi baharu fungsi rt-ai-invoice-scan (lihat nota keluaran).',
 AI_NET_TWICE:'Sambungan terputus semasa menghantar gambar (2 kali). Semak isyarat Wi-Fi / data telefon dan cuba lagi. Jangan kunci skrin atau tukar app semasa AI membaca.'};
const isFetchErr=e=>!!e&&(e.name==='FunctionsFetchError'||/Failed to send a request|Failed to fetch|Load failed|NetworkError/i.test(String(e.message||'')));
// A tiny request (no photo, no AI call): does the function answer at all? Any real HTTP reply = it is deployed and reachable.
async function aiPing(){try{const r=await Promise.race([sb.functions.invoke('rt-ai-invoice-scan',{body:{ping:true}}),new Promise(x=>setTimeout(()=>x({timeout:true}),20000))]);
 if(r.timeout)return {alive:false};if(!r.error)return {alive:true};if(isFetchErr(r.error))return {alive:false};
 let code='';try{const c=r.error.context;if(c&&typeof c.json==='function'){const j=await c.json();code=(j&&j.error)||'';}}catch(_){}
 return {alive:true,code};}catch(_){return {alive:false};}}
async function aiErrorText(e){let code='',st=0;
 try{const ctx=e&&e.context;st=Number(ctx&&ctx.status||0);if(ctx&&typeof ctx.json==='function'){const j=await ctx.json();code=(j&&j.error)||'';}}catch(_){}
 if(code)return AI_CODES[code]||code;
 const txt=String((e&&e.name)||'')+' '+String((e&&e.message)||e||'');
 if(/FunctionsFetchError|Failed to send|Failed to fetch|NetworkError|Load failed|network/i.test(txt))return 'Sambungan internet terputus semasa menghantar gambar. Semak Wi-Fi dan cuba lagi.';
 if(st===504||st===546||st===408)return 'Server AI ambil masa terlalu lama (had masa server). Crop pada senarai barang sahaja dan cuba lagi.';
 if(st===404)return 'Fungsi rt-ai-invoice-scan belum dideploy dalam Supabase.';
 if(st===401)return 'Sesi tamat. Log masuk semula.';
 return ((e&&e.message)||'Gagal hubungi AI. Pastikan fungsi rt-ai-invoice-scan telah dideploy.')+(st?' (kod '+st+')':'');}
let aiTimer=null;
function aiTick(){clearInterval(aiTimer);aiTimer=setInterval(()=>{if(s.ai.state!=='busy'){clearInterval(aiTimer);return;}const e=$('rticAiElapsed');if(e)e.textContent=String(Math.floor((Date.now()-s.ai.started)/1000));},1000);}
function aiCancel(){s.aiToken++;s.aiBusy=false;s.ai={state:'idle'};clearInterval(aiTimer);renderAiDraft();status('Bacaan AI dibatalkan. Tiada stok diubah.');}
async function aiReadInvoiceImage(file){
 if(!file)return;
 if(s.aiBusy){toast('AI masih membaca invois sebelum ini. Tunggu atau tekan BATAL.','info');return;}
 if(!admin())return toast('Admin sahaja boleh scan invois.','error');
 const token=++s.aiToken;
 s.aiBusy=true;s.aiDraft=null;s.ai={state:'busy',stage:'Menyediakan gambar…',started:Date.now(),thumb:''};renderAiDraft();aiTick();
 try{
  const url=await aiPhotoDataURL(file);
  if(token!==s.aiToken)return;
  const kb=Math.round(url.length*0.75/1024);
  s.ai.thumb=url;s.ai.stage='Gambar '+kb+' KB dihantar · AI sedang membaca barang dan kos';renderAiDraft();
  const call=()=>Promise.race([sb.functions.invoke('rt-ai-invoice-scan',{body:{image_data_url:url}}),new Promise(r=>setTimeout(()=>r({timeout:true}),AI_WAIT_S*1000))]);
  let t0=Date.now(),res=await call();
  if(token!==s.aiToken)return;                                   // BATAL pressed, or a newer photo taken
  if(res.timeout)throw new Error(AI_CODES.AI_WAIT_LIMIT);
  if(res.error&&isFetchErr(res.error)){
   // "network error" in the browser = no usable reply: the line dropped, the function is missing, or the server cut a
   // request that ran past its time limit. A tiny ping tells which, so the message says what really happened.
   const took=Math.round((Date.now()-t0)/1000);
   s.ai.stage='Tiada jawapan selepas '+took+' saat · menyemak sambungan ke server AI…';renderAiDraft();
   const ping=await aiPing();
   if(token!==s.aiToken)return;
   if(!ping.alive)throw new Error(AI_CODES.AI_UNREACHABLE);
   if(ping.code&&ping.code!=='PHOTO_INVALID_OR_TOO_LARGE')throw new Error(AI_CODES[ping.code]||ping.code);
   if(took>=60)throw new Error(AI_CODES.AI_NO_REPLY+' (gagal selepas '+took+' saat)');
   s.ai.stage='Sambungan terputus · menghantar semula sekali secara automatik…';renderAiDraft();
   t0=Date.now();res=await call();
   if(token!==s.aiToken)return;
   if(res.timeout)throw new Error(AI_CODES.AI_WAIT_LIMIT);
   if(res.error&&isFetchErr(res.error)){const t2=Math.round((Date.now()-t0)/1000);throw new Error((t2>=60?AI_CODES.AI_NO_REPLY:AI_CODES.AI_NET_TWICE)+' (gagal selepas '+t2+' saat)');}
  }
  const {data,error:fnError}=res;
  if(fnError)throw new Error(await aiErrorText(fnError));
  if(data?.error)throw new Error(AI_CODES[data.error]||data.error);
  const inv=data?.invoice;if(!inv||!Array.isArray(inv.items)||!inv.items.length)throw new Error('AI tak jumpa baris barang. Cuba gambar lebih terang dan lurus.');
  if(s.lines.length&&!confirm('Ada barang dalam draf manual. Gambar AI tidak akan memadamnya. Semak sebelum pindahkan baris AI. Teruskan?')){s.ai={state:'idle'};status('Hasil AI tidak digunakan.');return;}
  s.aiDraft={...inv,photo:url,rows:inv.items.map(r=>({...r,product_id:aiMatchProduct(r)}))};s.ai={state:'draft'};
  const invoiceRef=$('rticDo');if(invoiceRef&&!invoiceRef.value.trim()&&inv.invoice_number)invoiceRef.value=String(inv.invoice_number).slice(0,100);
  const supplierMatch=s.suppliers.filter(x=>norm(x.name)===norm(inv.supplier_name));
  if(supplierMatch.length===1&&$('rticSupplier')&&!$('rticSupplier').value)$('rticSupplier').value=supplierMatch[0].id;
  status('AI selesai. Semak setiap barang, SKU dan kos, kemudian pindahkan ke senarai terimaan.');
  toast('AI selesai membaca '+inv.items.length+' baris. Semak sebelum pindah.','success');
 }catch(e){
  if(token!==s.aiToken)return;
  const msg=String(e&&e.message||e);s.aiDraft=null;s.ai={state:'error',error:msg,thumb:s.ai.thumb||''};
  status('AI gagal membaca invois. Tiada stok diubah.');toast(msg,'error');
 }finally{
  if(token===s.aiToken){s.aiBusy=false;clearInterval(aiTimer);
   if($('rticAiCamera'))$('rticAiCamera').value='';if($('rticAiGallery'))$('rticAiGallery').value='';
   renderAiDraft();const panel=$('rticAiDraftPanel');if(panel&&panel.firstElementChild)try{panel.scrollIntoView({behavior:'smooth',block:'start'})}catch(_){}}
 }
}
function aiStateHtml(){const st=s.ai||{};const thumb=st.thumb?`<img class="rtic-ai-thumb" src="${st.thumb}" alt="Gambar invois">`:'';
 if(st.state==='busy')return `<div class="rtic-ai-loading" role="status">${thumb}<div class="rtic-ai-wait"><b>⏳ AI sedang membaca invois… <span id="rticAiElapsed">${Math.floor((Date.now()-st.started)/1000)}</span> saat</b><small>${escape(st.stage||'')}</small><small>Biasanya 15–60 saat. Jangan tutup halaman ini. Stok belum berubah.</small></div><button type="button" id="rticAiCancel">BATAL</button></div>`;
 if(st.state==='error')return `<div class="rtic-ai-failed" role="alert">${thumb}<div class="rtic-ai-wait"><b>❌ AI tidak dapat membaca invois</b><small>${escape(st.error||'')}</small><small>Tiada stok diubah. Boleh cuba lagi, atau masukkan barang secara manual di bawah.</small></div><div class="rtic-ai-retry"><button type="button" data-ai-retry="rticAiCamera">📸 AMBIL SEMULA</button><button type="button" data-ai-retry="rticAiGallery">🖼️ PILIH GAMBAR LAIN</button><button type="button" id="rticAiDismiss">TUTUP</button></div></div>`;
 return '';}
function renderAiDraft(){
 const panel=$('rticAiDraftPanel');if(!panel)return;const d=s.aiDraft;
 const intro=document.querySelector('.rtic-ai-intro');if(intro)intro.classList.toggle('rtic-ai-busy',s.ai.state==='busy');
 if(!d){panel.innerHTML=aiStateHtml();
  if($('rticAiCancel'))$('rticAiCancel').onclick=aiCancel;
  if($('rticAiDismiss'))$('rticAiDismiss').onclick=()=>{s.ai={state:'idle'};renderAiDraft();};
  panel.querySelectorAll('[data-ai-retry]').forEach(b=>b.onclick=()=>{const i=$(b.dataset.aiRetry);if(i)i.click();});
  return;}
 const options=s.products.filter(p=>p.category!=='SERVIS').map(p=>`<option value="${escape(p.id)}">${escape(p.sku)} · ${escape(p.name)}</option>`).join('');
 const note=(d.warnings||[]).map(w=>`<li>${escape(w)}</li>`).join('');
 panel.innerHTML=`<section class="rtic-ai-review"><div class="rtic-ai-head"><h3>SEMAK HASIL AI · BELUM SIMPAN STOK</h3><button type="button" id="rticAiDiscard">BUANG DRAF AI</button></div><img class="rtic-ai-photo" src="${d.photo}" alt="Gambar invoice pembekal untuk semakan" loading="lazy"><p><strong>Pembekal:</strong> ${escape(d.supplier_name||'Tidak pasti')} · <strong>No Invois:</strong> ${escape(d.invoice_number||'Tidak terbaca')} · <strong>Jumlah:</strong> ${d.invoice_total===null||d.invoice_total===undefined?'Semak invoice asal':cash(d.invoice_total)}</p>${note?`<ul class="rtic-ai-warnings">${note}</ul>`:''}<p class="rtic-ai-attention">Setiap produk mesti dipadankan dengan item inventori sedia ada. AI tidak boleh mencipta SKU. Kos/kuantiti masih boleh diedit. Jika harga kotak, tukar kepada kos seunit sebenar sebelum sahkan.</p><div class="rtic-scroll"><table class="rtic-table rtic-ai-table"><thead><tr><th>Barang pada invois</th><th>Padan produk POS</th><th>Qty</th><th>Kos seunit (RM)</th></tr></thead><tbody>${d.rows.map((r,i)=>`<tr class="${r.product_id?'':'rtic-ai-unmatched'}"><td><b>${escape(r.description)}</b><small>${escape(r.supplier_sku||'')} · ${escape(r.unit||'unit tidak pasti')}</small></td><td><select data-ai-product="${i}"><option value="">— SEMAK / PILIH BARANG —</option>${options.replaceAll('value="'+escape(r.product_id)+'"','value="'+escape(r.product_id)+'" selected')}</select></td><td><input type="number" inputmode="numeric" min="1" step="1" data-ai-qty="${i}" value="${Number.isInteger(r.quantity)&&r.quantity>0?escape(r.quantity):''}" placeholder="Semak"></td><td><input type="number" inputmode="decimal" min="0" step="0.01" data-ai-cost="${i}" value="${typeof r.unit_cost==='number'&&r.unit_cost>=0?escape(r.unit_cost.toFixed(2)):''}" placeholder="Semak"></td></tr>`).join('')}</tbody></table></div><div class="rtic-ai-actions"><button id="rticAiTransfer" type="button" class="rtic-ai-btn">✓ PINDAH BARANG KE DRAF STOK MASUK</button></div><p class="rtic-ai-privacy">AI tidak menyimpan stok. Admin masih perlu pilih pembekal dan tekan SAHKAN STOK MASUK sekali sahaja.</p></section>`;
 $('rticAiDiscard').onclick=()=>{s.aiDraft=null;s.ai={state:'idle'};renderAiDraft();};
 panel.querySelectorAll('[data-ai-product]').forEach(el=>el.onchange=()=>{d.rows[Number(el.dataset.aiProduct)].product_id=el.value;el.closest('tr')?.classList.toggle('rtic-ai-unmatched',!el.value)});
 panel.querySelectorAll('[data-ai-qty]').forEach(el=>el.onchange=()=>{d.rows[Number(el.dataset.aiQty)].quantity=el.value===''?null:Number(el.value)});
 panel.querySelectorAll('[data-ai-cost]').forEach(el=>el.onchange=()=>{d.rows[Number(el.dataset.aiCost)].unit_cost=el.value===''?null:Number(el.value)});
 $('rticAiTransfer').onclick=()=>{
  const rows=d.rows, ids=new Set();
  for(const r of rows){if(!r.product_id){toast('Ada baris AI belum dipadankan kepada barang POS. Sila pilih semua barang dahulu.','error');return;}
   if(!Number.isInteger(r.quantity)||r.quantity<1||!Number.isFinite(r.unit_cost)||r.unit_cost<0){toast('Semak kuantiti (unit bulat) dan kos seunit semua baris AI.','error');return;}
   if(ids.has(r.product_id)){toast('Satu produk sama dibaca lebih sekali. Gabungkan kuantiti secara manual dahulu.','error');return;}ids.add(r.product_id);
  }
  if(rows.some(r=>/\b(BOX|PACK|CARTON|KOTAK|DUS|DOZEN|SET|CTN)\b/.test(norm(r.unit)))&&!confirm('AMARAN: Invois mengandungi unit kotak/pack/set. Pastikan setiap QTY dan KOS sudah ditukar kepada unit stok POS (contoh botol/biji). Teruskan?'))return;
  if(s.lines.length){if(!confirm('GANTIKAN draf terimaan manual yang ada dengan hasil semakan AI? Stok BELUM bertambah.'))return;}
  s.lines=rows.map(r=>({product_id:r.product_id,quantity:r.quantity,unit_cost:r.unit_cost}));
  s.aiDraft=null;s.ai={state:'idle'};renderAiDraft();drawLines();
  $('rticReceiptLines')?.scrollIntoView({behavior:'smooth',block:'center'});
  toast('Baris invoice dipindah ke draf terimaan. Semak pembekal, nombor invoice dan jumlah sebelum SAHKAN.','success');
 };
}
function drawLines(){const box=$('rticReceiptLines');if(!box)return;box.innerHTML=s.lines.length?`<table class="rtic-table"><thead><tr><th>Barang</th><th>Qty</th><th>Kos / unit RM</th><th></th></tr></thead><tbody>${s.lines.map((line,i)=>{const p=s.products.find(x=>x.id===line.product_id);return `<tr><td><b>${escape(p?.name||'')}</b><small>${escape(p?.sku||'')}</small></td><td><input type="number" min="1" step="1" data-line-qty="${i}" value="${line.quantity}" class="rtic-small-input"></td><td><input type="number" min="0" step="0.01" data-line-cost="${i}" value="${line.unit_cost}" class="rtic-small-input"></td><td><button data-del-line="${i}" type="button">✕</button></td></tr>`;}).join('')}</tbody></table>`:'<p class="rtic-guide">Belum pilih item. Scan / cari barang dahulu. Produk sama tidak boleh diulang dua kali dalam DO yang sama.</p>';
box.querySelectorAll('[data-line-qty]').forEach(e=>e.onchange=ev=>{s.lines[Number(e.dataset.lineQty)].quantity=Number(ev.target.value)});box.querySelectorAll('[data-line-cost]').forEach(e=>e.onchange=ev=>{s.lines[Number(e.dataset.lineCost)].unit_cost=Number(ev.target.value)});box.querySelectorAll('[data-del-line]').forEach(e=>e.onclick=()=>{s.lines.splice(Number(e.dataset.delLine),1);drawLines()});}
async function postReceipt(){if(s.busy)return;const supplier=$('rticSupplier')?.value,ref=$('rticDo')?.value.trim(),note=$('rticDoNote')?.value.trim();if(!supplier){toast('Pilih pembekal.','error');return}if(!ref||ref.length<3){toast('Isi nombor DO atau invois pembekal.','error');return}if(!s.lines.length){toast('Tambah barang diterima.','error');return}
for(const x of s.lines)if(!Number.isInteger(x.quantity)||x.quantity<=0||!Number.isFinite(x.unit_cost)||x.unit_cost<0){toast('Kuantiti mesti positif dan kos sah.','error');return;}
const total=s.lines.reduce((v,x)=>v+x.quantity*x.unit_cost,0);
if(!confirm(`TERIMA STOK?\nDO: ${ref}\n${s.lines.length} item · Kos RM ${total.toFixed(2)}\nStok akan ditambah serta-merta. No. DO yang sama tak boleh diterima dua kali.`))return;
s.busy=true;const button=$('rticReceivePost');if(button)button.disabled=true;
try{const result=await rpc('rt_inv_admin_receive',{p_location_id:s.location,p_supplier_id:supplier,p_reference_no:ref,p_lines:s.lines,p_note:note||null});toast(`DO ${result.reference_no} berjaya · ${result.item_count} jenis barang direkod.`,'success');s.lines=[];await refresh(true);receipts();window.loadInventory?.({silent:true});}catch(e){toast(err(e),'error');status(err(e));}
finally{s.busy=false;if(button)button.disabled=false;}}
async function reverseReceipt(id){const receipt=s.receipts.find(r=>r.id===id);if(!receipt)return;
const ref=prompt(`BATAL TERIMAAN DO ${receipt.reference_no}\n\nTaip semula nombor DO untuk sahkan.`);if(ref===null)return;
if(norm(ref)!==norm(receipt.reference_no)){toast('Nombor DO tidak sama.','error');return;}
const reason=prompt('Sebab pembatalan / salah key-in (minimum 8 aksara):','Kuantiti terimaan tersalah key in');if(reason===null)return;if(reason.trim().length<8){toast('Sebab terlalu pendek.','error');return;}
if(!confirm(`BATAL DO ${ref}? Kuantiti asal setiap item akan ditolak daripada stok semasa. Jika stok tak cukup, pelayan akan batalkan seluruh transaksi.`))return;
try{const ret=await rpc('rt_inv_admin_reverse_receipt',{p_receipt_id:id,p_confirm_ref:ref,p_reason:reason.trim()});toast(`DO ${ret.reference_no} berjaya dibatalkan dengan rekod reversal.`,'success');await refresh(true);receipts();window.loadInventory?.({silent:true});}catch(e){toast(err(e),'error');}}
function exportCSV(stocktake){
 if(!admin())return;
 const h=stocktake?['SKU','NAMA','KATEGORI','RAK','STOK_POS','KIRAAN_FIZIKAL_KOSONG']:['SKU','NAMA','KATEGORI','JENAMA','UNIT','BARCODE','KOS','HARGA_JUAL','STOK_POS','RAK'];
 const rows=[h];
 for(const p of s.products){const q=s.stocks[p.id]?.quantity??0;rows.push(stocktake?[p.sku,p.name,p.category,p.rack_location||'',q,'']:[p.sku,p.name,p.category,p.brand||'',p.unit,p.barcode||'',p.cost_price,p.sell_price,q,p.rack_location||'']);}
 const csv='\ufeff'+rows.map(line=>line.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\r\n');
 const a=document.createElement('a');const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
 a.href=url;a.download=(stocktake?'REV_TORQ_KIRA_STOK_':'REV_TORQ_MASTER_BACKUP_')+new Date().toISOString().slice(0,10)+'.csv';
 document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
 toast('Fail CSV disediakan. Simpan di lokasi selamat.','success');
}
function addButton(){const view=$('view-inventory');if(!view||$('rtInvControlLauncher'))return;const b=el('button',{id:'rtInvControlLauncher',type:'button'});b.innerHTML='⚙ INVENTORY CONTROL <small>Admin sahaja</small>';b.className='rtic-launch';b.onclick=open;const tabs=view.querySelector('.rt-section-tabs');tabs?.insertAdjacentElement('afterend',b);}
function syncVisibility(){addButton();const b=$('rtInvControlLauncher');if(b)b.hidden=!admin();}
const onBoot=()=>{syncVisibility();};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',onBoot);else onBoot();
// Auth becomes available after script loading; only UI visibility is updated, no DB polling.
document.addEventListener('click',e=>{if(e.target.closest?.('[data-view="inventory"], [onclick*="switchView(\'inventory\')"]'))setTimeout(syncVisibility,60);});
window.addEventListener('rt-auth-ready',syncVisibility);
window.rtOpenInventoryControl=open;
window.rtOpenQuickRestock=openQuickRestock;
// Preserve old SKU aliases for a scanner/manual SKU typed in POS; only exact aliases are rerouted.
let lastAliasQuery='',aliasEpoch=0;
document.addEventListener('keyup',async ev=>{const input=ev.target;if(input?.id!=='posSearch'||!sb)return;const key=norm(input.value);if(key.length<3||key===lastAliasQuery)return;lastAliasQuery=key;const epoch=++aliasEpoch;
try{const ctx=await window.rtContext();const q=await sb.from('rt_inventory_sku_aliases').select('product_id').eq('company_id',ctx.companyId).eq('legacy_sku',key).maybeSingle();if(q.error||!q.data||epoch!==aliasEpoch||norm(input.value)!==key)return;const p=await sb.from('products').select('sku').eq('id',q.data.product_id).maybeSingle();if(!p.data?.sku)return;input.value=p.data.sku;window.posFilterProducts?.(p.data.sku);toast(`SKU lama ${key} dipadankan kepada ${p.data.sku}`,'info');}catch(_){/* optional migration not present */}});
})();
// Inventory form safeguard: name uppercase and optional generated internal SKU.
(function(){
 'use strict';
 const norm=v=>String(v||'').normalize('NFKC').replace(/\s+/g,' ').trim().toUpperCase();
 const $=id=>document.getElementById(id);
 function enhance(){
  const name=$('invName'),sku=$('invSku'),cat=$('invCat');if(!name||!sku||!cat)return;
  if(!name.dataset.rticUpper){name.dataset.rticUpper='1';name.addEventListener('blur',()=>{name.value=norm(name.value)});}
  if(!sku.dataset.rticSku){sku.dataset.rticSku='1';const b=document.createElement('button');b.type='button';b.id='rticSkuGen';b.className='mt-2 text-xs font-black text-indigo-700 underline';b.textContent='JANA SKU BARU MENGIKUT KATEGORI';sku.insertAdjacentElement('afterend',b);
    b.onclick=async()=>{if($('invIsEdit')?.value==='true'){window.showToast?.('SKU ini sudah didaftarkan. Guna Inventory Control untuk tukar SKU lama.','error');return;}
      if(sku.value.trim()&&!confirm('Gantikan SKU yang sudah ditaip dengan SKU baharu?'))return;
      try{const r=await window.supabaseClient.rpc('rt_inv_admin_next_sku',{p_category:cat.value});if(r.error)throw r.error;const val=String(r.data||'');if(window.rtSetNativeInputValue)window.rtSetNativeInputValue(sku,val,{uppercase:true,rebuild:true});else sku.value=val;window.showToast?.('SKU dijana: '+val,'success');}catch(e){window.showToast?.('Gagal jana SKU: '+(e.message||e),'error')}
    };
  }
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',enhance);else enhance();
 document.addEventListener('submit',e=>{if(e.target?.querySelector?.('#invName')){const x=$('invName');if(x)x.value=norm(x.value);}},true);
})();
