/* REV TORQ AI HUB v1 — Admin only. Read-only analyses + OpenAI-powered chat via authenticated Edge Function. */
(function(w){
 'use strict';
 const $=id=>document.getElementById(id);
 const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const ringgit=v=>'RM '+Number(v||0).toLocaleString('en-MY',{minimumFractionDigits:2,maximumFractionDigits:2});
 const s={tab:'ringkasan',snapshot:null,busy:false,chatBusy:false,chat:[],lastFetch:0,aiEnabled:false,identity:null};
 const isAdmin=()=>w.rtHasAdminAccess?.()===true&&['owner','admin','super_admin'].includes(String(w.currentProfile?.role||'').toLowerCase());
 const validTabs=new Set(['ringkasan','inventori','restok','audit','chat']);
 const toast=(msg,type='info')=>{if(w.showToast)w.showToast(msg,type);else alert(msg)};
 const tabs=[['ringkasan','Ringkasan'],['inventori','Kemas Inventori'],['restok','Cadangan Restok'],['audit','Audit Stok'],['chat','Tanya AI']];
 function root(){return $('rtAiHubOverlay')}
 function template(){
  return `<div class="rtai-backdrop" id="rtAiHubOverlay" hidden>
    <section class="rtai-shell" role="dialog" aria-modal="true" aria-label="REV TORQ AI Hub">
      <div class="rtai-header"><div><span class="rtai-eyebrow">REV TORQ PERFORMANCE · ADMIN ONLY</span><h2>✦ AI HUB <span class="rtai-v1">V1</span></h2><p>Pembantu operasi workshop · data live dibaca sahaja</p></div><button id="rtAiClose" type="button" aria-label="Tutup AI Hub">✕</button></div>
      <div id="rtAiTabs" class="rtai-tabs" role="tablist">${tabs.map(([id,label])=>`<button type="button" data-rtai-tab="${id}" role="tab">${label}</button>`).join('')}</div>
      <div class="rtai-tools"><span id="rtAiStatus" role="status">Belum memuatkan data</span><button type="button" id="rtAiRefresh">↻ Refresh data</button></div>
      <div id="rtAiContents" class="rtai-contents" aria-live="polite"></div>
      <div class="rtai-foot"><span>🔒 Baca sahaja · Tidak ubah stok, SKU, harga atau pembayaran</span><span>Admin perlu sahkan semua tindakan</span></div>
    </section>
  </div>`;
 }
 function init(){
  if(!root())document.body.insertAdjacentHTML('beforeend',template());
  $('rtAiClose').addEventListener('click',close);
  root().addEventListener('click',e=>{if(e.target===root())close()});
  $('rtAiTabs').addEventListener('click',e=>{const b=e.target.closest('[data-rtai-tab]');if(!b)return;const id=b.dataset.rtaiTab;if(validTabs.has(id)){s.tab=id;draw()}});
  $('rtAiRefresh').addEventListener('click',()=>load(true));
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!root().hidden)close()});
  const btn=$('rtAiHubLauncher');if(btn)btn.addEventListener('click',open);
  syncLauncher();
  const roleNode=$('navUserRole');if(roleNode)new MutationObserver(syncLauncher).observe(roleNode,{childList:true,subtree:true,characterData:true});
  document.addEventListener('click',()=>{if($('appContainer')&&!$('appContainer').classList.contains('hidden'))syncLauncher()},{capture:true});
  w.addEventListener('rt-auth-ready',syncLauncher);
 }
 function syncLauncher(){
  const allowed=isAdmin(),identity=allowed?String(w.currentUser?.id||''):null;
  if(!allowed || (s.identity&&identity!==s.identity)){
    s.snapshot=null;s.chat=[];s.lastFetch=0;s.aiEnabled=false;
    if(root()&&!root().hidden)close();
  }
  s.identity=identity;
  const b=$('rtAiHubLauncher');if(b)b.hidden=!allowed;
}
 function open(){if(!isAdmin())return toast('AI Hub untuk Admin / Owner sahaja.','error');root().hidden=false;document.body.classList.add('rtai-open');draw();if(!s.snapshot||Date.now()-s.lastFetch>60000)load(false)}
 function close(){if(root())root().hidden=true;document.body.classList.remove('rtai-open')}
 async function invoke(body){
  const sb=w.supabaseClient;if(!sb?.functions?.invoke)throw Error('Sambungan Supabase belum siap.');
  const {data,error}=await sb.functions.invoke('rt-ai-ops-assistant',{body});
  if(error){let code='';try{if(typeof error.context?.json==='function'){const d=await error.context.json();code=d?.error||''}}catch{}
    const map={LOGIN_REQUIRED:'Sila login semula.',SESSION_INVALID:'Sesi tamat, sila login semula.',ADMIN_ONLY:'Admin sahaja dibenarkan.',OPENAI_API_KEY_NOT_CONFIGURED:'OPENAI_API_KEY belum ditetapkan dalam Supabase Secrets.',AI_SERVICE_UNAVAILABLE:'OpenAI API tidak tersedia. Semak billing dan secret.',DATA_QUERY_FAILED:'Tidak dapat baca data POS daripada server. Semak akses dan schema.',NO_LOCATION:'Lokasi staff belum dipautkan.'};
    throw Error(map[code]||`${code?code+' — ':''}${error.message||'Gagal menghubungi AI Hub. Pastikan fungsi Edge dideploy.'}`);
  }
  if(data?.error)throw Error(data.error);
  return data;
 }
 async function load(force){
  if(s.busy||!isAdmin())return;
  if(!force&&Date.now()-s.lastFetch<60000&&s.snapshot){draw();return}
  s.busy=true;setStatus('Membaca inventori, stok, jualan dan Job Card...',true);
  try{const data=await invoke({mode:'snapshot'});if(!data.snapshot)throw Error('Server tidak pulangkan analisis.');s.snapshot=data.snapshot;s.aiEnabled=!!data.aiEnabled;s.lastFetch=Date.now();draw()}
  catch(e){setStatus('Gagal muatkan data: '+String(e.message||e),false,true);if(!s.snapshot)$('rtAiContents').innerHTML=`<div class="rtai-alert">${escape(e.message||e)}. Tiada data diubah.</div>`;}
  finally{s.busy=false}
 }
 function setStatus(str,loading=false,error=false){const el=$('rtAiStatus');if(!el)return;el.textContent=str;el.className=loading?'loading':error?'error':'';const b=$('rtAiRefresh');if(b)b.disabled=loading}
 function kpi(label,value,note){return `<article class="rtai-kpi"><small>${escape(label)}</small><strong>${escape(value)}</strong>${note?`<em>${escape(note)}</em>`:''}</article>`}
 function draw(){const content=$('rtAiContents');if(!content)return;
  $('rtAiTabs').querySelectorAll('[data-rtai-tab]').forEach(b=>{const on=b.dataset.rtaiTab===s.tab;b.classList.toggle('active',on);b.setAttribute('aria-selected',on?'true':'false')});
  const d=s.snapshot;
  if(!d){content.innerHTML='<div class="rtai-empty">Sila tunggu bacaan dari Supabase. Tiada stok akan berubah.</div>';return}
  setStatus('Dikemas kini: '+new Date(d.asOf).toLocaleString('ms-MY')+' · Tempoh 30 hari · '+(s.aiEnabled?'AI chat tersedia':'Analisis tersedia; AI chat perlukan API key'));
  if(s.tab==='ringkasan'){
    const c=d.counts||{}, jobs=d.jobStatuses||{};
    content.innerHTML=`<div class="rtai-kpis">${kpi('Produk aktif',c.products)}${kpi('Item perlu disemak',c.needReview)}${kpi('Stok rendah',c.lowStock)}${kpi('SKU duplikat (kumpulan)',c.duplicateGroups)}${kpi('Invois berbayar / 30 hari',c.paidInvoiceCount30)}${kpi('Jumlah invois dibayar',ringgit(c.paidInvoiceTotal30),'Bukan keuntungan bersih')}</div><div class="rtai-grid"><div class="rtai-panel"><h3>Cadangan tindakan hari ini</h3><ul><li>${escape(c.needReview)} barang perlu semakan nama, kos atau kategori.</li><li>${escape(c.restockCandidates)} cadangan restok berdasarkan rekod penggunaan.</li><li>${escape(c.opening30)} pergerakan OPENING, ${escape(c.adjustment30)} pelarasan dalam 30 hari untuk disemak.</li></ul></div><div class="rtai-panel"><h3>Status Job Card</h3>${Object.keys(jobs).length?Object.entries(jobs).map(([key,val])=>`<div class="rtai-line"><span>${escape(key)}</span><strong>${escape(val)}</strong></div>`).join(''):'<p>Tiada Job Card dapat dibaca.</p>'}</div></div>${notice(d)}`;
  }else if(s.tab==='inventori'){
    content.innerHTML=`<div class="rtai-panel"><h3>Kemas Inventori <small>${escape(d.issues?.length||0)} contoh teratas</small></h3><p>Cadangan sahaja. Nama, SKU, kategori dan harga belum diubah.</p><div class="rtai-scroll"><table><thead><tr><th>Produk / SKU</th><th>Kategori</th><th>Semakan diperlukan</th></tr></thead><tbody>${(d.issues||[]).map(p=>`<tr><td><b>${escape(p.name)}</b><small>${escape(p.sku)}</small></td><td>${escape(p.category)}</td><td>${(p.flags||[]).map(f=>`<span class="rtai-tag">${escape(f)}</span>`).join('')}</td></tr>`).join('')||'<tr><td colspan="3">Tiada isu dikesan dalam data yang dibaca.</td></tr>'}</tbody></table></div><button class="rtai-action" id="rtAiGoInventory">Buka Inventory Control untuk semak</button></div>${notice(d)}`;
  }else if(s.tab==='restok'){
    content.innerHTML=`<div class="rtai-panel"><h3>Cadangan Restok <small>Anggaran 14 hari</small></h3><p>Berdasarkan jumlah penggunaan SALE dan JOB_USAGE 30 hari. Semak stok fizikal, lead time supplier dan kemungkinan catatan berganda.</p><div class="rtai-scroll"><table><thead><tr><th>Barang / SKU</th><th>Stok semasa</th><th>Digunakan 30H</th><th>Cadangan beli</th><th>Anggaran kos</th></tr></thead><tbody>${(d.restock||[]).map(x=>`<tr><td><b>${escape(x.name)}</b><small>${escape(x.sku)}</small></td><td>${escape(x.stock)}</td><td>${escape(x.used30)}</td><td><b>${escape(x.suggest)}</b></td><td>${ringgit(x.estimatedCost)}</td></tr>`).join('')||'<tr><td colspan="5">Tiada produk memenuhi kriteria cadangan.</td></tr>'}</tbody></table></div><div class="rtai-actions"><button class="rtai-action" id="rtAiExport">Eksport cadangan CSV</button><button class="rtai-action ghost" id="rtAiGoInventory">Buka Inventory Control</button></div></div>${notice(d)}`;
  }else if(s.tab==='audit'){
    content.innerHTML=`<div class="rtai-kpis">${kpi('Pergerakan OPENING 30H',d.counts?.opening30)}${kpi('Pelarasan 30H',d.counts?.adjustment30)}${kpi('Kumpulan nama duplikat',d.counts?.duplicateGroups)}${kpi('Stok kosong',d.counts?.zeroStock)}</div><div class="rtai-panel"><h3>Produk berpotensi duplikat</h3><div class="rtai-scroll"><table><thead><tr><th>Nama</th><th>Kategori</th><th>SKU dijumpai</th></tr></thead><tbody>${(d.duplicates||[]).map(x=>`<tr><td>${escape(x.name)}</td><td>${escape(x.category)}</td><td>${(x.skus||[]).map(sku=>`<span class="rtai-tag">${escape(sku)}</span>`).join('')}</td></tr>`).join('')||'<tr><td colspan="3">Tiada nama duplikat tepat.</td></tr>'}</tbody></table></div><p class="rtai-note">Petunjuk sahaja; bukan bukti stok hilang. Jangan padam rekod stok atau transaksi tanpa audit dan pengesahan.</p><button class="rtai-action" id="rtAiGoInventory">Buka Audit Stok</button></div>${notice(d)}`;
  }else{
    content.innerHTML=`<div class="rtai-chat"><div class="rtai-chat-log" id="rtAiChatLog" role="log" aria-live="polite">${s.chat.length?s.chat.map(x=>`<div class="rtai-bubble ${x.who==='user'?'user':'bot'}"><span>${x.who==='user'?'Admin':'REV TORQ AI'}</span><p>${escape(x.text)}</p></div>`).join(''):'<div class="rtai-chat-welcome"><strong>✦ Tanya REV TORQ AI</strong><p>Contoh: Barang mana perlu restok? Apa masalah dalam inventori? Kenapa jumlah jualan bukan untung bersih?</p></div>'}</div><form id="rtAiChatForm" class="rtai-chat-form"><textarea id="rtAiQuestion" rows="2" maxlength="600" placeholder="Tanya tentang stok, jualan, servis atau inventori..." aria-label="Soalan kepada AI"></textarea><button type="submit" ${s.chatBusy?'disabled':''}>${s.chatBusy?'Menjawab...':'HANTAR'}</button></form><p class="rtai-note">AI hanya menerima ringkasan data workshop. Tiada akses kepada nombor telefon pelanggan, password, transaksi tulis atau Accounting. Semak semua angka.</p></div>`;
    $('rtAiChatForm').addEventListener('submit',submitChat);
    const log=$('rtAiChatLog');log.scrollTop=log.scrollHeight;
  }
  $('rtAiGoInventory')?.addEventListener('click',()=>{close();w.switchView?.('inventory');setTimeout(()=>w.rtOpenInventoryControl?.(),120)});
  $('rtAiExport')?.addEventListener('click',exportRestock);
 }
 function notice(d){const flags=Object.entries(d.limits||{}).filter(x=>x[1]).map(x=>x[0]);return `<div class="rtai-disclaimer">${escape((d.notes||[]).join(' '))}${flags.length?'<br><b>Amaran: had bacaan rekod dicapai: '+escape(flags.join(', '))+'. Cadangan mungkin tidak lengkap.</b>':''}</div>`}
 function exportRestock(){const rows=[['SKU','NAMA','STOK','MIN_STOK','PENGGUNAAN_30_HARI','CADANG_BELI','ANGGARAN_KOS']];for(const x of s.snapshot?.restock||[])rows.push([x.sku,x.name,x.stock,x.min,x.used30,x.suggest,x.estimatedCost]);const csv='\ufeff'+rows.map(line=>line.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\r\n');const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='REV_TORQ_CADANGAN_RESTOK_'+new Date().toISOString().slice(0,10)+'.csv';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}
 async function submitChat(e){e.preventDefault();if(s.chatBusy||!isAdmin())return;const q=$('rtAiQuestion')?.value?.trim();if(!q||q.length<3)return toast('Taip soalan sekurang-kurangnya 3 aksara.','error');s.chatBusy=true;s.chat.push({who:'user',text:q});draw();try{const result=await invoke({mode:'chat',question:q});s.chat.push({who:'bot',text:result.answer||'Tiada jawapan.'});if(result.snapshot){s.snapshot=result.snapshot;s.lastFetch=Date.now();}}catch(err){s.chat.push({who:'bot',text:'Tidak dapat jawab: '+String(err.message||err)});}finally{s.chatBusy=false;draw()}}
 w.rtAiHub={open,close,refresh:()=>load(true)};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})(window);
