/* REV TORQ 2026-10-28 — plate required for service/job checkout only.
 * Never writes to products, vehicles, sales or stock. The canonical checkout
 * awaits this guard BEFORE invoking the payment/stock RPC.
 * A pending/uncertain transaction is recovered by the canonical handler first.
 */
(function (w) {
  'use strict';
  const $=id=>document.getElementById(id);
  const norm=v=>String(v??'').trim();
  function serviceItem(item){
    return !!(item?.service || String(item?.itemType||'').toUpperCase()==='SERVICE' ||
      ['SERVIS','SERVICE'].includes(String(item?.category||'').trim().toUpperCase()));
  }
  function needsPlate(items,job){return !!job || (Array.isArray(items)&&items.some(serviceItem));}
  function showCustomer(){
    try{w.rtToggleCustPanel?.(true)}catch(_){}
    try{$('rtCustBar')?.scrollIntoView?.({block:'nearest',behavior:'smooth'})}catch(_){}
  }
  async function requirePlate({items=[],activeJob=null,customerId=null}={}){
    if(!needsPlate(items,activeJob))return {required:false};
    const job=activeJob||null;
    const cid=norm(job?.customerId || customerId);
    if(!cid){
      if(!job)showCustomer();
      throw new Error(job?'Job Card mesti ada pelanggan dan nombor plat. Kemas kini Job Card dahulu.':'Untuk servis, pilih/daftar pelanggan dan motosikal sebelum BAYAR.');
    }
    if(!job && norm($('rtPosCustomerSelect')?.value)!==cid){showCustomer();throw new Error('Pelanggan POS telah berubah. Pilih pelanggan dan plat sekali lagi.');}
    const vid=norm(job ? job.vehicleId : (typeof w.rtPosSelectedVehicleId==='function'?w.rtPosSelectedVehicleId(cid):null));
    if(!vid){
      if(!job)showCustomer();
      throw new Error(job?'Job Card ini belum mempunyai motosikal/nombor plat. Edit Job Card dahulu.':'Untuk servis, pilih nombor plat motosikal pelanggan dahulu (atau TAMBAH MOTOSIKAL).');
    }
    const sb=w.supabaseClient;
    if(!sb?.from)throw new Error('Sambungan pangkalan data belum sedia. Tidak boleh sahkan nombor plat servis.');
    const response=await sb.from('vehicles').select('id,customer_id,plate_no,brand,model')
      .eq('id',vid).eq('customer_id',cid).limit(1).maybeSingle();
    if(response.error)throw new Error('Gagal sahkan nombor plat dalam database: '+String(response.error.message||response.error));
    const plate=norm(response.data?.plate_no).toUpperCase();
    if(!response.data?.id||!plate){
      if(!job)showCustomer();
      throw new Error(job?'Nombor plat dalam Job Card kosong/tidak padan. Betulkan Job Card dahulu.':'Nombor plat kosong atau bukan milik pelanggan ini. Pilih/tambah motosikal yang betul.');
    }
    // Protect against a changed selection during the asynchronous vehicle lookup.
    if(job){
      if(norm(w.rtActiveJob?.jobCardId)!==norm(job.jobCardId)||norm(w.rtActiveJob?.vehicleId)!==vid)
        throw new Error('Job Card berubah semasa semakan. Sila tekan BAYAR sekali lagi.');
    }else{
      if(norm($('rtPosCustomerSelect')?.value)!==cid ||
         norm(w.rtPosSelectedVehicleId?.(cid))!==vid){
        showCustomer();throw new Error('Pilihan motosikal telah berubah. Semak nombor plat dan tekan BAYAR sekali lagi.');
      }
    }
    return {required:true,vehicleId:vid,plateNo:plate,vehicleModel:[response.data.brand,response.data.model].filter(Boolean).join(' ')};
  }
  function updateHint(){
    const hint=$('rtServicePlateHint');if(!hint)return;
    let rows=[];try{rows=w.rtGetPosCart?.()||[]}catch(_){}
    const show=needsPlate(rows,w.rtActiveJob||null);
    hint.hidden=!show;
    hint.style.display=show?'block':'none';
  }
  function init(){
    const list=$('posCartList');
    if(list&&!list.dataset.rtPlateGuard){
      list.dataset.rtPlateGuard='1';new MutationObserver(updateHint).observe(list,{childList:true,subtree:true,characterData:true});
    }
    const chip=$('rtCurrentJob');
    if(chip&&!chip.dataset.rtPlateGuard){chip.dataset.rtPlateGuard='1';new MutationObserver(updateHint).observe(chip,{childList:true,subtree:true,characterData:true});}
    updateHint();
  }
  w.rtRequirePlateForService=requirePlate;
  w.rtServiceSaleNeedsPlate=needsPlate;
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);
  else init();
})(window);
