# TEST RESULTS — Menu tepi penuh macam video (2026-10-30)

Semua ujian guna Supabase **simulasi**. Tiada sambungan ke Supabase sebenar.

## Node (dalam ZIP ini)

`node --test tests/*.test.cjs tests/*.pglite.cjs tests/test_duplicate_inventory.cjs`

| | |
|---|---|
| Jumlah | 144 |
| Lulus | 142 |
| Gagal | 0 |
| Skip | 2 (folder Customer PWA tiada) |

**Baharu: `tests/side-menu.test.cjs`** (4 ujian). Ia menyemak:
- **Mod lalai:** penuh pada ≥ 1180 px, ikon pada 1024 px, dan sentiasa ikon bawah 1024 px.
- **Butang tukar:** bertukar mod, diingat, dan tajuk butang betul.
- **Pusing iPad:** peraturan mod dikenakan semula.
- **Tajuk kumpulan:** ada dalam menu.
- **CSS:** setiap peraturan menu ikon tablet dimatikan oleh `.rt-side-full`.

`tests/menu-tablet.test.cjs` dikemas kini mengikut tajuk kumpulan.

## Pelayar (Chromium, saiz iPad 10 / iPad 9.7 / potret / mini / telefon / laptop / skrin besar)

| Suite | Keputusan |
|---|---|
| Menu penuh / kecil + butang tukar (baharu) | 48 / 48 |
| Menu + iPad/telefon | 180 / 180 |
| Semua halaman × 6 saiz (ralat, skrol ke tepi) | 84 semakan, 0 ralat, 0 skrol ke tepi |
| Toolbar pembetulan (tabfix) | 192 / 192 |
| Inventory Control + AI scan | 209 / 209 |
| Sebut Harga | 216 / 216 |
| Regression penuh | fixes9 114, motosikal 72, troli 182, resit 57, pesanan 88, park 31, interact 57, WhatsApp 15, papan 25, carian 25, pesan stok 28, booking 28, nama penuh 63, tidy 26, override 109, offline 59. Semua 0 gagal. Pelanggan 0 isu, overlay 0 tersangkut, heal / barang job / scanner OK |

Hasil utama:
- **iPad 10 / Air 1180×820:**
  - menu penuh 216 px dengan tajuk Utama / Jualan / Bengkel & Stok / Pengurusan;
  - semua item termasuk Lagi muat tanpa skrol;
  - POS kekal 3 lajur barang, BAYAR kelihatan.
- **Butang ▢:** menu ikon 84 px, dan pilihan diingat selepas muat semula.
- **iPad 9.7 1024×768:** lalai menu ikon. Boleh tukar ke penuh; POS kekal 2 lajur dan BAYAR kelihatan.
- **iPad potret (820):** sentiasa menu ikon, walaupun "penuh" dipilih ketika landskap.
- **Pusing iPad:** landskap penuh → potret ikon → landskap penuh.
- **Telefon 390×844 dan skrin besar 1440:** tajuk kumpulan ada, tiada butang tukar, semua item muat.
- **Juruwang:** tiada tajuk kumpulan; menu POS / Jualan / Quotation.

Diperhatikan, tidak berubah: pada iPad mini (744 px), butang BAYAR terkeluar 12 px di bawah skrin. Ia masih boleh ditekan, dan sama seperti sebelum perubahan ini.

## Korpus

245 / 248 lulus, 2 skip.

Gagal 1: salinan Android, sama seperti sebelum ini.

## TIDAK diuji

- **iPad sebenar (Safari):** semua ujian guna Chromium dengan saiz dan sentuhan iPad.
